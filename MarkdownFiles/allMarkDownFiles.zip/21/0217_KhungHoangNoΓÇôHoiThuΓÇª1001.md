# Khủng Hoảng Nợ – Hồi Thứ … 1001

15/10/2013

...thất nghiệp vẫn lửng lơ trên ngọn cây, kinh tế vẫn lẹt đẹt dưới
gốc...<br/><br/>Khi quý độc giả đọc được bài viết này thì cũng là lúc có thể đã
có giải pháp cho khủng hoảng ngân sách và công nợ, mà cũng có thể
chưa có giải pháp, đưa Nhà Nước Mỹ đến tình trạng một mặt vẫn đóng
cửa, một mặt phải xin khất nợ ít lâu chờ các chính khách hai bên cò
cưa trả giá như mấy chú Ba Chợ Lớn thời xa xưa. Lồng trong khung cảnh
Nhà Nước đóng cửa tiệm là vấn đề công nợ.<br/><br/>Trên nguyên tắc, hạn mức nợ sẽ đụng đỉnh do quốc hội ấn định 16.700
tỷ vào ngày 15 tháng 10, nhưng Bộ Tài Chánh có thể tìm cách du di
thêm vài ba ngày, bằng cách chuyển trương mục qua lại, làm phù phép
kế toán, hay tạm ngưng vài chi tiêu để dành tiền trả một ít tiền
lãi đã đáo hạn, có thể kéo dài tới cuối tháng 10. Khi bài này
được viết thì tình hình chưa ngã ngũ đâu vào đâu hết.<br/><br/>Bất kể trường hợp nào xẩy ra, tình trạng Nhà Nước Mỹ cũng đều
không sáng sủa gì cho lắm. Nếu các chính khách thoả thuận tăng mức
nợ trần theo yêu cầu của TT Obama thì công nợ lại tăng mà vẫn chẳng
ai thấy những khoản nợ chồng chất sẽ được trả khi nào và bằng cách
nào. Đó là chuyện mai hậu, con cháu phải lo, ta thắc mắc làm chi cho
mệt. Nói theo kiểu các cụ tỵ nạn phóng tay xài thẻ tín dụng mút
chỉ, ai hỏi mấy cụ làm sao trả thì các cụ nhún vai trả lời “mai
mốt tao chết thì con cháu tao nó phải lo thôi, tụi nó lo cách nào
làm sao tao biết được, chuyện của tụi nó”. Trường hợp các chính
khách không thỏa thuận được với nhau, mức nợ trần không tăng được,
Nhà Nước Obama không được đi vay mượn nợ mới để trang trải nợ cũ đã
đáo hạn, sẽ coi như vi phạm hợp đồng vay mượn vì đã không trả nợ cũ
đúng hạn kỳ. Uy tín trên phương diện tín dụng lại bị sứt mẻ một
lần nữa, lần thứ hai trong lịch sử cận đại Mỹ, cả hai lần đều dưới
sự chủ trì của TT Obama.<br/><br/>Các cụ cao tuổi có thái độ bất cần đời thật ra cũng dễ thông cảm
được, nhưng vị lãnh đạo quốc gia mà cũng có thái độ phóng khoáng
như vậy thì có phần... đáng lo. Và những người hồ hởi hoan hô việc
“phóng tay” vay mượn của TT Obama thì quả là... đáng sợ.<br/><br/>Người ta còn nhớ ông Barack Obama khi còn làm thượng nghị sĩ, đã biểu
quyết bác bỏ mọi đề nghị tăng nợ trần của TT Bush, để rồi khi ra
tranh cử tổng thống những năm 2007-08, ông lớn tiếng đả kích Bush là
tổng thống “vô trách nhiệm nhất lịch sử Mỹ”. Theo đà hiện nay thì
sau hai nhiệm kỳ, TT Obama sẽ tăng mức nợ gấp sáu lần ông tổng thống
vô trách nhiệm Bush.<br/><br/>Dĩ nhiên những người ủng hộ TT Obama sẽ nhao nhao phản đối cách nhìn
này, và sẽ lập lại những lập luận “đổ thừa “ của TT Obama, cho là
TT Obama chỉ là thừa kế đại họa của TT Bush để lại. Không ai chối
cãi được TT Obama đã nhậm chức đúng khi khủng hoảng tài chính kinh
tế lên đến cao điểm, nhưng ta cũng không thể quên những lời hứa của
ứng viên Obama. Khi ra tranh cử, ông đã biết trước gia tài của Bush như
thế nào rồi, nhưng vẫn tự tô vẽ cho mình hình ảnh một Đấng Tiên Tri
toàn năng đầy phép lạ sẽ dọn dẹp sạch sẽ mọi rác rến Bush để lại,
hạ cả thủy triều và hàn gắn mọi vết thương của nhân loại.<br/><br/>Điều ứng viên Obama không nói rõ là cái giá phải trả sẽ đến mức
nào. Với cái giá ghê gớm đã trả rồi mà thiên hạ vẫn chưa thấy vết
thương nào của Mỹ được hàn gắn hết, thất nghiệp vẫn lửng lơ trên
ngọn cây, kinh tế vẫn lẹt đẹt dưới gốc. Khoan nói tới các vết thương
khác của nhân loại trên thế giới. Thế thì cái giá ta còn phải trả
thêm là bao nhiêu nữa để thấy được một tình trạng sáng sủa hơn?<br/><br/>Theo thăm dò mới nhất, trong bốn người, có ba người cho rằng nước Mỹ
đang đi trật hướng, chỉ có một người cho là đang đi đúng đường. Nói
cách khác, sau khi mắc nợ và chi cả ngàn tỷ, ta vẫn còn chưa đi đúng
đường, hay ít ra thì cũng còn đang mò đường.<br/><br/>Qua truyền thông dòng chính, ta đã thấy rõ ràng hình ảnh đảng đối
lập Cộng Hòa của ông “tổng thống vô trách nhiệm” cũng là một đảng
vô trách nhiệm, chủ trương phá hoại kinh tế và làm tê liệt chính
quyền. Một đảng hại dân hại nước không hơn không kém. Tất cả do một
thiểu số cực đoan khuynh đảo.<br/><br/>Đây là lập luận có vẻ ngây ngô, nhưng lại là lập luận căn bản của
chính quyền Obama. Trong cuộc tranh chấp hiện nay, chính quyền Obama
vẫn tìm đủ mọi cách để đưa ra hình ảnh một chiều của một đối lập
Cộng Hòa chỉ biết phá bĩnh, chống đối mọi đề nghị, đường lối,
chính sách của chính quyền Dân Chủ, trong khi cố khỏa lấp thực tế
của một chính quyền vung tay xài tiền như không có ngày mai. Xứ Mỹ
là thành đồng của tự do ngôn luận, chính quyền và truyền thông có
quyền nói bất cứ chuyện gì họ muốn, tin hay không là quyền của thiên
hạ.<br/><br/>Trước hết, phải nói cho rõ, không có một thiểu số cực đoan nào chi
phối được chính quyền Mỹ. Một thiểu số thì không khi nào có đủ
phiếu để chi phối ai trong một chế độ dân chủ hết. Thiểu số mà phe
Dân Chủ chỉ trích ở đây là nhóm Tea Party. Trong gần 550 dân biểu và
nghị sĩ Mỹ, có chưa tới một tá có quan hệ mật thiết với các nhóm
Tea Party, không ai có thể nói số người này đã chi phối hết chính
trị Mỹ. Không phải như trong chế độ cộng sản, chỉ một tá ủy viên
trong Chính Trị Bộ quyết định mọi chuyện. Báo phe ta New York Times,
cho rằng thiểu số cực hữu “phá hoại” có tới 40 vị. Cho dù chấp
nhận con số này thì ta cũng thấy nhóm “quá khích” chiếm chưa tới 10%
lưỡng viện, làm sao khuynh đảo được hết cả chính quyền Mỹ. Nhà báo
phe ta khác, Fareed Zakaria viết trên Washington Post, cho rằng đảng Cộng
Hoà bị nhóm thiểu số quá khích phân hoá, đại loạn, chẳng ai kiểm
soát ai nữa. Thế thì sao lại có chuyện 90% dân biểu Cộng Hoà và 100%
nghị sĩ Cộng Hoà biểu quyết “nhất trí” bốn lần liền trong một ngày
30/9?<br/><br/>Đảng Cộng Hoà không thể ngăn cản được chính quyền Obama trong bất cứ
vấn đề gì nếu không có một đa số phiếu ít nhất là trong Hạ Viện.
Và cái đa số đó không phải là do tự phong, mà do chính dân Mỹ bầu
ra, cũng y như dân Mỹ đã bầu cho TT Obama. Đối lập Cộng Hoà có trách
nhiệm phản ánh quan điểm của những người dân đã bầu cho họ. Do đó,
khi chống đối TT Obama, họ cũng chỉ chu toàn trách nhiệm của họ đối
với những người dân đã bầu cho họ. Hành động của họ chính danh không
thua gì hành động của TT Obama.<br/><br/>Một điểm quan trọng khác mà truyền thông dòng chính có vẻ quên. TT
Obama được bầu lại với 52% phiếu, và cho đến nay, tỷ lệ hậu thuẫn
đã rớt xuống còn có 37% theo thăm dò mới nhất của hãng thông tấn
Associated Press. Tỷ lệ này trồi sụt hàng ngày cũng như tùy theo công
ty thăm dò. Nhưng đại khái thì cứ cho là TT Obama được hậu thuẫn của
một nửa dân Mỹ. Không ai có thể nói nửa chống đối còn lại chỉ là
những thành phần phá hoại. Đó là lý luận kiểu cộng sản, chống đối
là phản động, phá hoại.<br/><br/>Nhiều người cũng cho Fox News là tiếng nói của đối lập phá hoại. Như
vậy làm sao giải thích số người xem các chương trình bình luận của
đài Fox cao hơn tổng cộng số người xem tất cả các đài ABC, CBS, NBC, MSNBC,
và CNN cộng lại? Mỗi tuần, bản tin điện tử The Drudge Report đều có
thống kê đầy đủ về số người coi các đài trên, để xác nhận tình
trạng trên đã kéo dài cả mấy năm nay rồi.<br/><br/>Thế nào là phá hoại? Mỗi đảng đều có một chính sách, đường lối
mình tin tưởng và có trách nhiệm tranh đấu. Đảng nào có được đa số
để nắm quyền thì có phương tiện áp dụng chính sách của mình, và
đảng thiểu số không nắm quyền có bổn phận phản đối nếu không chia
sẻ quan điểm đó. Đây là trường hợp của những năm 2009-10 khi đảng Dân
Chủ nắm Tòa Bạch Ốc cũng như giữ thế đa số tuyệt đối tại cả
Thượng Viện lẫn Hạ Viện. Phe đối lập Cộng Hoà chỉ có cách đứng
ngoài phản đối mà không làm gì khác được. Nhờ vậy mà TT Obama khi
đó đã làm được ba việc mà ông cho là những thành quả để đời: thông
qua các luật cải tổ y tế, cải tổ ngân hàng, và kích cầu kinh tế.<br/><br/>Đến cuối năm 2010, cử tri Mỹ đã bỏ phiếu cho Cộng Hòa nắm quyền
kiểm soát Hạ Viện. Nếu đó không phải là dân Mỹ lo sợ chính sách
cấp tiến cực đoan của TT Obama và muốn tìm cách thắng bớt lại thì
là gì? Và nếu Cộng Hoà không chịu ký chi phiếu trắng cho TT Obama
thì sao có thể gọi đó là “hành động phá hoại” được?<br/><br/>Nếu một đảng không nắm được trọn cả Hành Pháp lẫn Lập Pháp, thì
hai bên cần thương thảo, để đi đến thỏa thuận, đồng thuận để cùng
nhau đưa ra một chính sách trị nước. Đó chính là tư tưởng của các
nhà lập quốc Mỹ. Nếu không có thỏa thuận, thì không bên nào có thể
nói bên kia là “phá hoại” gì hết. Chỉ là khoảng cách biệt quá lớn,
không bên nào nhân nhượng đủ để có thỏa thuận. Tại sao khi không có
thoả hiệp thì lại là lỗi của Cộng Hòa chỉ lo phá hoại? Tại sao
không nói đảng Cộng Hoà đang cố gắng ngăn chận TT Obama vô trách nhiệm
đang phá hoại kinh tế Mỹ với chính sách nợ hơn Chúa Chỏm, vung tay
xài tiền quá đáng hiện nay cũng như trong tương lai. Nếu ông chồng vung
tay xài tiền, mua sắm “hàng xịn”, ăn nhậu “rượu ngoại” đắt tiền,...,
và bà vợ tằn tiện lo tương lai lâu dài của con cái, lên tiếng phản
đối, có thể gọi bà vợ là “phá hoại hạnh phúc gia đình” không?<br/><br/>Mức nợ trần theo Hiến Pháp quy định phải do quốc hội ấn định, và
ngân sách cũng phải như vậy. Tất cả đều có lý do chính đáng. Các
nhà lập quốc Mỹ đã nhìn những vấn đề đó như là những vấn đề cực
kỳ quan trọng phải có tiếng nói quyết định của cả Hành Pháp lẫn
cả hai viện quốc hội. Không thể có chuyện trao cho Hành Pháp hay trao
cho một đảng toàn quyền chi tiêu công qũy vô giới hạn, cũng như toàn
quyền mắc nợ vô giới hạn. Chế độ dân chủ của Mỹ dựa trên nguyên tắc
phân quyền, cân bằng quyền hạn và kiểm soát lẫn nhau để tránh mọi
lạm dụng quá mức. Việc phân quyền này được áp dụng bất kể khi đảng
Dân Chủ nắm quyền hay khi đảng Cộng Hòa nắm quyền. Tổng thống Dân
Chủ hay Cộng Hòa cũng đều bị chi phối bởi nguyên tắc phân quyền này
hết. Khi hành pháp đưa ra bất cứ một đề nghị gì đều phải có sự
thương thảo, trao đổi, với quốc hội cũng như với phe đối lập để mọi
phiá cùng tìm ra được một giải pháp đáp ứng được nhu cầu của nhiều
người dân nhất.<br/><br/>TT Obama đe dọa nếu không tăng mức nợ trần thì sẽ có đại họa giống
như “bom nguyên tử” vậy. Không sai chút nào. Nếu không tăng mức nợ trần
thì điểm tín dụng của Nhà Nước Obama sẽ bị hạ, tức lãi suất cho
Nhà Nước Mỹ vay sẽ phải tăng, kéo theo gia tăng tất cả các loại lãi
suất khác lãi suất nợ mua nhà, mua xe, nợ thương mại làm ăn, thẻ tín
dụng, đưa đến trì trệ kinh tế nặng hơn nữa. Nhưng vấn đề không phải
chỗ đó. Vấn đề là tại sao Nhà Nước vung tay xài quá cỡ vậy, đến
độ mức trần vay mượn cứ phải tăng điều chi vài tháng một lần, bất
kể khả năng trả nợ có nổi hay không, ai trả, khi nào trả, trả bằng
cách nào? Mà cũng không ai biết tăng đến chừng nào? Sao không ai nghe
TT Obama đề cập những chuyện này mà chỉ nghe dọa phải cho ông ta đi
vay nợ tiếp tục nếu không thì sẽ chết cả đám?<br/><br/>TT Obama cho rằng Nhà Nước đóng cửa tiệm đã tạo ra không biết bao khó
khăn cho cuộc sống bình thường của người dân. Các nông gia đã không
còn được sự giúp đỡ của công chức nên sẽ bớt lợi nhuận. Những
người muốn mua nhà rẻ tiền đã không biết cách nào vì công chức không
có cơ hội giúp họ. Có lẽ TT Obama cũng phải nói thêm mấy đại gia đi
du lịch cũng bị khó khăn vì thông hành không làm kịp thời, và biết
bao chuyện vớ vẩn khác nữa. Thực tế là chẳng có ông bà nông dân nào
cần công chức chỉ dẩn cách kinh doanh cho ra lợi nhuận, chẳng có ông
bà nào muốn mua nhà rẻ tiền mà lại phải trông cậy vàl sự giúp đỡ
của các công chức. Trái lại, đối với tuyệt đại đa số dân Mỹ -và cả
dân tỵ nạn- việc Nhà Nước đóng cửa tiệm từ hơn một tuần qua chẳng
có hệ quả gì khủng khiếp cả.<br/><br/>Báo New York Times hậu thuẫn cho phe ta, ước tính việc ngăn cản tăng
mức nợ trần “của nhóm cực hữu” sẽ tốn cho kinh tế Mỹ gần 20 tỷ
trong 10 năm tới. Sao không thấy NYT tính xem cái phóng tay xài tiền
rồi đi vay của TT Obama đã tốn bao nhiêu tiền lãi mà kinh tế Mỹ phải
trả? Kẻ viết này sẽ tính dùm. Theo Google, lãi suất trung bình Nhà
Nước phải trả hiện nay trên công nợ là trên dưới 2%. Và 2% trên mức
nợ 16.700 tỷ là 33,5 tỷ một năm tính theo lãi đơn không tích luỹ, hay
335 tỷ tiền lãi phải trả trong 10 năm, tức là gấp 17 lần cái phí
tổn mà NYT đã tính.<br/><br/>TT Obama liên tục khẳng định “không điều đình gì hết”. Ông cũng bác
bỏ đề nghị của Cộng Hoà là chuẩn chi cho một số cơ quan trọng yếu
để tiếp tục họat động vì ông không chấp nhận giải pháp lẻ tẻ. Rồi
trong bài diễn văn cho toàn dân ngày 8/10 vừa qua, TT Obama có vẻ dịu
giọng lại, tuyên bố ông sẵn sàng “điều đình”, chỉ cần phe Cộng Hoà
chấp nhận tăng mức nợ trần, và biểu quyết ngân sách. Đúng là một lời
tuyên bố của một chính khách. Nói để mà chẳng nói gì hết. Cộng
Hòa chưa bao giờ khẳng định không chấp nhận tăng mức nợ trần hay không
cho Hành Pháp ngân sách. Vấn đề là trong chi tiết, trong các điều
kiện, như tăng nợ trần lên bao nhiêu, trong bao nhiêu lâu, với những điều
kiện gì, cũng như biểu quyết ngân sách là bao nhiêu, cho thời điểm
nào, với điều kiện nào. Đó mới là những chi tiết quan trọng cần
điều đình, chứ còn nguyên tắc chung chung như TT Obama nêu lên thì đâu
có ai không đồng ý đâu.<br/><br/>Ít ra thì sau đó, TT Obama đã chấp nhận nói chuyện với đối lập Cộng
Hòa để tìm giải pháp.<br/><br/>Một lý do có thể đã khiến TT Obama dịu dọng là Obamacare thật sự
chưa sẵn sàng đúng như phe Cộng Hòa cảnh báo. Trang mạng Healthcare
của Nhà Nước bị tắc nghẽn ngay từ ngày đầu đến nay vẫn chưa sửa
được, và tất cả đã gây thiệt hại lên đến hơn 600 triệu đô tính cho
đến ngày 10/10 rồi. Nhà báo phe ta Wolf Blitzer của CNN cũng đã phải
lên tiếng kêu gọi TT Obama hoãn Obamacare lại như Cộng Hòa đề nghị.
Phải chăng CNN đã trở thành đồng loã phá hoại với Cộng Hoà?<br/><br/>Nhìn vào bế tắc chính trị hiện nay, ta thấy có ba vấn đề, hai vấn
đề tương đối nhỏ là hoãn Obamacare và biểu quyết ngân sách Nhà Nước,
và một vấn đề lớn với hậu quả trầm trọng và lâu dài hơn nhiều:
công nợ. Cuộc tranh cãi thật sự là ở đây. Khủng hoảng được giải
quyết như thế nào sẽ nói lên tinh thần trách nhiệm của các chính
khách Mỹ đối với thế hệ con cháu họ.<br/><br/>Cho đến nay, cả hai bên đều có thái độ cương quyết không nhượng bộ,
chỉ vì trên thực tế, cả hai bên chưa thấy có nhu cầu phải thoả thuận
nên còn đang tố xả láng. (13-10-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a211679/khung-hoang-no-hoi-thu-1001

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/