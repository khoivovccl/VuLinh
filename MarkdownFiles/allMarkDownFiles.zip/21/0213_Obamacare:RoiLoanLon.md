# Obamacare: Rối Loạn Lớn

12/11/2013

...từ năm 2010, chính quyền Obama đã ước tính sẽ có 93 triệu người
bị mất bảo hiểm...<br/><br/>Đề tài Obamacare đã được bàn tới bàn lui khá nhiều trên cột báo
này, vậy mà dường như vẫn còn chưa đủ. Lý do dễ hiểu vì đây là một
vấn đề liên quan trực tiếp đến tất cả chúng ta. Dân nghèo lo xin
oe-phe, dân già thắc mắc chuyện tiền già, dân trung lưu bận chuyện job,
nhà giàu sợ đóng thuế. Nhưng tất cả đều có vấn đề sức khoẻ phải
ưu tư. Mà Obamacare đảo lộn mọi chuyện, thay đổi toàn diện tình trạng
bảo hiểm cũng như dịch vụ y tế của tất cả mọi người. Bảo sao thiên
hạ không chú ý được. Rồi trước những lộn xộn hiện nay, bảo sao thiên
hạ không lo được.<br/><br/>Đã vậy, việc áp dụng luật Obamacare đã mang ra ánh sáng nhiều chuyện
thực tế mà từ trước đến giờ hầu hết mọi người không biết, kể cả
những người làm luật cũng không biết hết được những hậu quả thực
tế của luật mới. Nói như bà cựu Chủ Tịch Hạ Viện Nancy Pelosi,
“chúng ta phải biểu quyết luật cải tổ y tế rồi thì mới biết trong
luật có gì”. Nói kiểu quái lạ giống như chúng ta phải đặt cái cày
trước con trâu mới biết con trâu có đi tới được không, nhưng lại không
thiếu gì người tin và hoan hô.<br/><br/>Những ngày qua, thiên hạ đọc báo và khám phá ra là những vấn đề
của Obamacare lớn hơn tất cả mọi dự đoán bi quan nhất từ trước đến
nay.<br/><br/>Trên cột báo này, ngay từ những năm 2009-2010 khi Obamacare mới được đưa
ra tranh cãi cũng như vừa được biểu quyết “chui” xong, kẻ viết này
cùng với quan điểm chung của những người nghi ngờ Obamacare, đã cảnh
giác những hậu quả tai hại của Obamacare.<br/><br/>Đại khái, tác giả tin rằng Obamacare sẽ đưa đến hai tình trạng: ngắn
hạn, chi phí y tế, cho dù là tiền mua bảo hiểm hay tiền nhà thương
bác sĩ, sẽ gia tăng đồng loạt, và dài hạn, dân Mỹ sẽ phải xếp hàng
dài người để được chữa trị vì tình trạng thiếu nhà thương, bác sĩ,
và thuốc men.<br/><br/>Không cần phải là đại trí thức, kinh tế gia với giải nobel, người ta
cũng đoán ra được những hậu quả trên. Chỉ cần ta lý luận theo kiểu
một cộng một là hai là sẽ thấy. Một khi trong vòng vỏn vẹn hai ba
năm, có thêm ba chục triệu người nữa tham gia vào thị trường y tế,
được bảo hiểm và được chữa trị đầy đủ, bất kể bệnh nặng đến đâu
và chữa trị tốn kém đến đâu, thì dĩ nhiên là giá cả sẽ phải gia
tăng ngay, và sau đó sẽ thiếu bác sĩ, thiếu nhà thương, thiếu thuốc
men. Bài tính không thể nào giản dị hơn. Luật cung cầu sơ đẳng.<br/><br/>Cái oái ăm là trong tình trạng đó, TT Obama, là người đi rao bán món
hàng Obamacacre cho thiên hạ, vẫn khăng khăng khẳng định là sẽ không có
gì thay đổi hết, chi phí y tế nếu không giảm thì bảo đảm cũng không
tăng, tất cả mọi người đều có thể giữ bác sĩ, giữ hãng bảo hiểm, giữ
nhà thương của mình nếu muốn, không phải thay đổi gì hết.<br/><br/>"If you like your health care plan, you’ll be able to keep your health
care plan. Period. No one will take it away. No matter what." Tạm dịch
là “Nếu bạn thích chương trình y tế của bạn, bạn có thể giữ nó.
Chấm hết. Không ai sẽ lấy nó đi. Bất kể chuyện gì khác”. Đó là nguyên
văn câu nói của TT Obama. Không thể nào rõ ràng hơn. Đó là lời hứa
và lời trấn an ngắn gọn của tổng thống. Chấm hết!<br/><br/>Ta phải hiểu đây là lời hứa quan trọng nhất trong Obamacare. Đối với
dân tỵ nạn ta, chuyện thay đổi bác sĩ, nhà thương, không bao giờ là
chuyện đáng quan tâm, trong ý nghĩ bác sĩ nào cũng thế, nhất là sau
cuộc đổi đời phải di tản qua Mỹ thay đổi hết, thì sống ở đâu cũng
thế, làm job gì cũng xong, đi bác sĩ nào cũng được. Nhưng đối với
dân Mỹ, trong văn hoá và tập quán Mỹ, mỗi người đều có bác sĩ
riêng, luật sư riêng, kế toán làm thuế riêng, … mà họ đã quen biết lâu
ngày và tin tưởng tuyệt đối. Không dễ gì thay đổi vì như vậy sẽ mất
thời giờ tái tạo lại sự tin tưởng và quan hệ cá nhân. Đặc biệt là
đối với bác sĩ vì cho dù bệnh nào đi nữa thì bác sĩ cũng cần
phải biết rõ tình trạng sức khỏe tổng quát mới chẩn bệnh và chữa
trị đúng nhất được. Một bác sĩ sẽ phải mất nhiều thời gian mới
làm quen với bệnh nhân được. Đó là chưa kể mỗi bác sĩ có thể cho
thuốc khác nhau, đổi thuốc là cả một vấn đề.<br/><br/>Bên cạnh vấn đề bác sĩ và nhà thương quen thuộc là vấn đề tiền.
Lời hứa của TT Obama có thể khiến mọi người hiểu là cái chương
trình bảo hiểm mọi người đang có sẽ không có thay đổi gì, tức là
tiền bảo phí cũng như các điều kiện và trường hợp bảo hiểm cũng
sẽ không thay đổi gì, bạn có thể giữ nguyên nó như cũ nếu bạn muốn.
Khi nói đến “you can keep your plan”, mọi người đều hiểu như vậy. Không
có gì thay đổi hết.<br/><br/>Nói trắng ra, theo như TT Obama xác định, Obamacare chỉ mở cửa đón
nhận thêm những người vì lý do bệnh tình hay tài chánh nên không có
bảo hiểm, bây giờ được cung cấp bảo hiểm và được Nhà Nước giúp đỡ
tiền bạc để có bảo hiểm. Ngoài ra, tất cả mọi người khác đều không
bị ảnh hưởng gì. Không bị đổi bác sĩ, nhà thương, không bị tăng bảo
phí, không phải đổi bảo hiểm. Chỉ là một chương trình mở rộng bảo
hiểm sức khoẻ cho toàn dân. Chỉ có “cộng” mà không có “trừ” gì hết.
Quá đẹp! Như trong mơ.<br/><br/>Đáng buồn thay, dân Mỹ có câu “too good to be true”. Quá tốt để có thể
là sự thật.<br/><br/>Mà quả đúng như vậy, chưa đầy một tháng sau khi chương trình Obamacare
được bắt đầu áp dụng trọn vẹn, thiên hạ khám phá ra Obamacare không
phải là giấc mộng đẹp mà đã là một ác mộng, cho tất cả mọi
người.<br/><br/>Các hãng bảo hiểm đồng loạt hủy bỏ các chương trình bảo hiểm hiện
hành của cả triệu người trên khắp nước. Các chuyên gia ước tính có
thể hơn 100 triệu người có nguy cơ mất bảo hiểm cũ. Dĩ nhiên là có
thể mua bảo hiểm mới chứ không phải là không có bảo hiểm. Luật
Obamacare bắt buộc tất cả 100% dân chúng phải có bảo hiểm mà. Nhưng
bảo hiểm mới mua sẽ khác xa các chương trình bảo hiểm đang có. Bảo
phí sẽ cao hơn, tiền trả trước sẽ tăng gấp mấy lần, và quan trọng
đối với dân Mỹ, một số lớn sẽ phải thay bác sĩ, nhà thương.<br/><br/>Hầu hết các chương trình bảo hiểm sức khoẻ cho ta một danh sách giới
hạn nhà thương và bác sĩ mà hãng bảo hiểm chấp nhận, và chúng ta
chỉ được lựa chọn nhà thương và bác sĩ trong danh sách đó thôi. Bây
giờ, các danh sách này thay đổi hàng loạt.<br/><br/>Vấn đề nhiều khi rắc rối hơn vì đại đa số thiên hạ mua bảo hiểm qua
các chuyên viên bán bảo hiểm –insurance agent-, mà nhiều chuyên viên lại
chỉ bán được bảo hiểm của vài hãng này mà không bán được bảo hiểm
của vài hãng khác. Nếu muốn đổi hãng bảo hiểm mà lại đổi qua một
hãng của ông agent của mình không được bán, thì lại phải đổi ông bán
bảo hiểm luôn. Đúng là một mớ boòng boong rối bù.<br/><br/>Báo “phe ta” Washington Post trong số ra ngày 4/11 vừa qua, đã có bài
viết nhìn nhận những thay đổi quan trọng do Obamacare gây ra. Bài viết
đưa ra mấy trường hợp có thực về hậu quả của Obamacare.<br/><br/>Như một gia đình, chủ một cây xăng ở Michigan, bị hủy bảo hiểm đang
có. Muốn có bảo hiểm tương tự như bảo hiểm đang có thì phải mua bảo
hiểm mới, với giá đắt hơn khoảng 30%. Muốn có bảo hiểm tương tự với
giá tương tự cũng có, nhưng mỗi lần đi nhà thương sẽ phải lái xe đi
qua một thành phố cách nhà hơn 100 dặm. Bị đứng tim khẩn cấp cũng
phải lái xe mất hai tiếng đồng hồ tới nhà thương.<br/><br/>Một bà khác, có bảo hiểm với Humana, được thông báo là bảo phí sẽ
tăng từ $300 lên đến $705, tăng hơn gấp đôi. Sau khi truy cứu, bà tìm ra
được một hãng bảo hiểm rẻ hơn chút đỉnh, $623 một tháng, nhưng bà phải
đổi bác sĩ bà đã quen thuộc từ 16 năm nay.<br/><br/>Các hãng bảo hiểm giải thích những thay đổi này, từ thay đổi điều
kiện và trường hợp bảo hiểm, đến thay đổi giá cả, là do nhu cầu
đáp ứng những đòi hỏi của luật Obamacare, không phải là các hãng tự
ý muốn đổi.<br/><br/>Đây là những “khám phá” mới lạ mà trước đây không ai biết. Nhiều đòi
hỏi có vẻ hợp lý tuy không nhất định phải là cần thiết, ví dụ như
đòi phải bảo hiểm bệnh thần kinh, bảo hiểm chống bạo lực gia đình,
cho dù người mua bảo hiểm chưa lập gia đình. Nhiều đòi hỏi khác nghe
tiếu lâm, như đòi hỏi các bà phải có bảo hiểm ngừa thai, bất kể
tuổi tác, cho dù đã qua tuổi cổ lai hy. Nhưng đạt đỉnh cao của vô lý
là đòi hỏi trong bảo hiểm của tất cả mọi người, kể cả các đấng tu
mi nam tử, phải có bảo hiểm thai nghén và sanh đẻ. Trong cuộc điều
trần trước Hạ Viện ngày 31/10 vừa qua, bà Bộ Trưởng Y Tế Kathleen
Sebelius đã bị dân biểu Renée Ellmers, Cộng Hoà của South Carolina chất
vấn về những chuyện này, nhưng bà Sebelius đã tránh né, không trả
lời. Làm sao trả lời được? Bà đâu phải là người viết luật.<br/><br/>Có hãng bảo hiểm đã biện minh tiền bảo phí tuy tăng, nhưng bây giờ
có trợ cấp của Nhà Nước trả đỡ một phần nào. Chỉ là ngụy biện.
Làm như thể trợ cấp là do TT Putin của Nga đóng góp, chứ không phải
là tiền thuế do chính người dân Mỹ phải trả. Trả qua thuế hay trả
thẳng vào bảo phí khác nhau chỗ nào? Có khác chăng là khác ở chỗ
lấy tiền người này trả cho người kia. Có phải đây lại chỉ là một
hình thức “tái phân chia lợi tức” là nguyên tắc thành đồng của xã
hội chủ nghiã?<br/><br/>Người ta cũng khám phá ra tiền bảo phí tăng đồng loạt trên khắp 50
tiểu bang, nhưng nói chung, tại những tiểu bang “xanh” là những tiểu
bang theo Dân Chủ, bầu cho TT Obama, bảo phí tăng ít hơn là bảo phí
tại các tiểu bang “đỏ” theo Cộng Hoà, bầu cho McCain hay Romney. Trung
bình thì tiền bảo phí sẽ tăng 50% tại các tiểu bang “xanh” và tăng
78% tại các tiểu bang “đỏ”. Ít ra thì các chuyên gia cũng đã nhận
định đây không phải là kết quả của một chính sách “kỳ thị” trả thù
Cộng Hòa, mà chỉ vì những tiểu bang “đỏ” theo Cộng Hoà thường có
luật lệ kiểm soát ngành bảo hiểm không khắt khe lắm nên dễ bị các
hãng bảo hiểm lợi dụng tăng giá mạnh hơn.<br/><br/>Trước thực tế cả chục hay cả trăm triệu người mất bảo hiểm cũ,
phải mua bảo hiểm mới đắt hơn, làn sóng bất mãn dâng cao. Các báo,
kể cả các cơ quan ngôn luận nổi tiếng phe ta cũng đã phải lên tiếng
phàn nàn, như bài báo trên Washington Post nêu trên, và hàng loạt các
phóng sự của các báo lớn và đài truyền hình lớn, kể cả đài NBC,
được coi như cái loa của chính quyền Obama.<br/><br/>TT Obama bị tố cáo hứa cuội, hay nuốt lời hứa. Ông buộc lòng phải
lên tiếng. Ông tuyên bố cách đây vài hôm “Tôi đã nói rõ ràng là nếu
các bạn muốn giữ bảo hiểm cũ mà bảo hiểm đó không thay đổi gì thì
bạn vẫn có thể giữ bảo hiểm đó mà”. Đây là một ví dụ điển hình
của nghệ thuật ăn nói mập mờ, ngụy biện của TT Obama. Có hai vấn
đề. Trước hết, đó không phải nguyên văn câu nói trước đây của ông.
Trước đây ông chỉ nói ngắn gọn: “Nếu bạn thích chương trình bảo hiểm
đang có, bạn có thể giữ nó”. Không có câu “mà bảo hiểm đó không thay
đổi gì”. Sau đó, ai cũng biết, nhất là TT Obama, là với những cải
cách quy mô của Obamacare, không thể nào có chuyện “bảo hiểm đó không
thay đổi gì” được. Và thực tế đã chứng minh rõ ràng tất cả các chương
trình bảo hiểm sức khỏe đều thay đổi, không có cái nào “không thay
đổi gì” hết.<br/><br/>Vấn đề đặt ra ở đây là TT Obama có biết trước là sẽ có thay đổi
không? Ông bIết trước và hứa cuội? Hay thành tâm hứa vì không biết
trước?<br/><br/>Theo một điều tra của đài truyền hình phe ta NBC, ngay từ năm 2010,
chính quyền Obama đã ước tính sẽ có 93 triệu người bị mất bảo
hiểm, hay bảo hiểm họ đang có sẽ thay đổi nhiều. Có nghiã là năm
2009, khi ông mới bắt đầu quảng bá Obamacare, có lẽ ông không biết và
hưá lung tung. Nhưng ngay năm sau, ông biết sẽ có thay đổi quy mô, nhưng
vẫn khăng khăng “không có gì thay đổi” chỉ vì đã phóng lao đành phải
theo lao, lỡ hứa không thay đổi nên phải tiếp tục “kiên định lập
trường”.<br/><br/>Nhà báo Marc Thiessen viết trên Washington Post là bài diễn văn quảng
bá Obamacacre của TT Obama năm 2009 đã được ban tham mưu Toà Bạch Ốc cân
nhắc rất nhiều về câu “không có gì thay đổi”, vì ngay trong ban tham
mưu của TT Obama, các chuyên gia kinh tế và y tế đã lên tiếng “bắt
buộc sẽ phải có thay đổi chứ không thể nào không có gì thay đổi”.
Nhưng các phụ tá chính trị áp đảo được nhóm chuyên gia, và giữ lại
câu nói đó trong bài diễn văn. Nói cách khác, chính trị mỵ dân chi
phối tuyệt đối mọi hành động và lời nói của chính quyền Obama, bất
chấp sự thật.<br/><br/>Niềm tin nơi vị lãnh đạo đất nước đã bị lung lay tận gốc rễ, khi
người ta nhìn vào những dữ kiện so với những lời tuyên bố của tổng
thống. Hàng trăm triệu người mất bảo hiểm là chuyện không thể dấu
diếm được ai nữa. Thăm dò mới nhất của Gallup cho thấy hậu thuẫn của
TT Obama đã xuống đến mức kỷ lục chưa từng thấy: 39%. Thăm dò của AP
cho thấy tỷ lệ đó là 37% từ mấy tuần trước rồi.<br/><br/>Và điều đáng nói nữa là hầu hết những người “bị hoạ” đều thuộc
thành phần trung lưu, chưa đủ giàu để không thắc mắc chuyện tiền bạc,
và không đủ nghèo để được trợ cấp, mà chỉ vừa đủ tiền để trả bảo
phí cao hơn và mai này, đóng thuế cao hơn.<br/><br/>Phát ngôn viên Toà Bạch Ốc, Jay Carney, nhắc nhở mọi người, tổng
thống, cho dù quyền hạn rất lớn, cũng có nhiều chuyện không làm gì
được. Nói cách khác, không phải lỗi của tổng thống đâu, lỗi của
người viết luật, lỗi của các hãng bảo hiểm. Lại đổ thừa. Ông Carney
chỉ quên một chuyện nhỏ: Yes, He Can! Vâng, TT Obama có thể làm được
một chuyện: thu hồi, hay ít nhất hoãn việc áp dụng Obamacare lại để
sửa đổi đôi điều.<br/><br/>Sau khi bà Sebelius điều trần trước quốc hội, Hạ Viện đã công bố một
tài liệu của bộ Y Tế xác định trang mạng Obamacare chỉ có thể tiếp
đón được 1.100 người mỗi ngày, trong khi bộ cũng ước tính sẽ có ít
ra 60.000 người lên mạng cùng lúc. Dù biết có vấn đề lớn vì chưa
sẵn sàng, bộ Y Tế vẫn tung trang mạng ra cho đúng ngày TT Obama đã
hứa hẹn. Thực tế đã có khoảng 250.000 người vào trang mạng cùng
lúc, và cả triệu người vào trong ngày đầu. Làm sao hệ thống không
kẹt cứng được? Đã vậy các chương trình cũng bị viết sai rất nhiều,
chẳng hạn như tính sai tiền bảo phí, tính sai tiền trợ cấp mua bảo
hiểm,...<br/><br/>Thiên hạ bây giờ nhìn vào Obamacare thấy ba vấn đề: 1) trục trặc kỹ
thuật quy mô, 2) mọi chuyện đảo lộn như mất bảo hiểm, đổi bác sĩ,
nhà thương, 3) bảo phí và tiền trả trước tăng hơn xa mọi dự đoán bi
quan nhất. Khác xa với tất cả mọi hứa hẹn đẹp đẽ của tổng thống.<br/><br/>Ngày 7/11 vừa qua, TT Obama trong một cuộc phỏng vấn đặc biệt dành cho
đài truyền hình NBC đã chính thức tỏ ý hối tiếc (I am sorry) về
việc cả triệu người đã bị mất bảo hiểm và hứa sẽ làm tất cả
những gì có thể để giúp họ. Không nghe ông nói gì về viễn tượng
tăng chi phí quy mô hiện nay và thiếu nhà thương, bác sĩ trong tương
lai. (10-11-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a212982/obamacare-roi-loan-lon

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/