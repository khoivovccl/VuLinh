# Huyền Thoại Kennedy – Phần II

03/12/2013

...cuối cùng thì số phận miền Nam cũng đã được quyết định từ Tòa
Bạch Ốc...<br/><br/>Đúng ra kẻ viết này không có ý định viết về huyền thoại Kennedy một
lần nữa, nhưng vì đã nhận được khá nhiều điện thư của độc giả, nêu
lên nhiều vấn đề, nên phải viết tiếp để làm sáng tỏ vài điểm nhiều
độc giả thắc mắc.<br/><br/>VẤN ĐỀ CHỦ QUYỀN<br/><br/>Trước hết là vấn đề chủ quyền của các chính phủ đệ nhất và đệ
nhị Cộng Hòa.<br/><br/>Phải nói cho rõ, nói miền Nam chúng ta không có chủ quyền không có
nghiã là miền Bắc có chủ quyền. Nếu công bằng so sánh hai miền, thì
cả hai, chẳng miền nào thực sự có chủ quyền đối với các đại cường,
nhưng dù sao, miền Nam vẫn có tiếng nói với Mỹ lớn hơn miền Bắc dám
nói với Liên Xô hay Trung Cộng. Đây không phải là lý luận theo kiểu “ta
giỏi hơn địch”, mà là sự thật có bằng chứng lịch sử.<br/><br/>Năm 1954, Hội Nghị Geneve bàn về chiến tranh Đông Dương, mở màn ngay sau
khi Việt Minh chiến thắng tại Điện Biên Phủ. Nước Pháp sa sút không
còn trong tư thế nói chuyện gì với CS hết. Tân Thủ Tướng Mendes France
long trọng hứa sẽ tìm ra giải pháp cho Đông Dương trong vài tuần, hay
nói trắng ra, sẽ tìm ra cách đầu hàng đỡ mất mặt nhất. Tất cả mọi
chính phủ tham gia đàm phán đều đồng ý chia đôi VN. Vấn đề tranh cãi
là chia đôi ở đâu. Pháp đòi vỹ tuyến 17. Việt Minh ngắm nghé vỹ
tuyến 15 để có được Huế và Đà Nẵng. Nga và Trung Cộng không muốn
lằng nhằng sợ Mỹ nhẩy vào cuộc chiến nên chấp nhận vỹ tuyến 17.
Thủ tướng Phạm Văn Đồng họp riêng với cả TT Chu Ân Lai và Ngoại
Trưởng Molotov, để vận động hậu thuẫn nhưng bị cả hai “đồng minh” bỏ
rơi, đành chấp nhận vỹ tuyến 17, rồi sau đó đã lẩm bẩm càu nhàu cho
đến sau năm 75 vẫn còn than vãn nếu có hậu thuẫn mạnh hơn của các
đàn anh thì đã chiến thắng, thống nhất VN dễ dàng hơn rồi. <br/><br/>Nói cách khác, các đàn anh đã quyết định, Việt Minh không có tiếng
nói, không làm gì khác được. Chủ quyền của Việt Minh không có gì
hết.<br/><br/>Ngay cả “chiến thắng lịch sử “ tại Điện Biên Phủ cũng đang được xét
lại. Vai trò của tướng Võ Nguyên Giáp rất có thể chỉ là bình phong,
trong khi trận đánh hoàn toàn do tướng lãnh và chính ủy Trung Cộng
quyết định. Súng ống, đại bác dĩ nhiên là của Trung Cộng tiếp viện
từ kho vũ khí khổng lồ chiếm được của Tưởng Giới Thạch. Chỉ có
hàng vạn bộ đội bị thí vào mặt trận là thanh niên Việt.<br/><br/>Trong khi đó, miền Nam, tuy cũng không có đầy đủ chủ quyền muốn làm
gì thì làm, nhưng trong cả hai chế độ đệ nhất và đệ nhị Công Hòa,
đều đã có dịp có tiếng nói cưỡng lại những quyết định quan trọng
nhất của Mỹ.<br/><br/>Dưới TT Diệm, Mỹ đã muốn mang quân tác chiến vào VN thay vì chỉ có
một số ít cố vấn quân sự, nhưng đã bị TT Diệm bác, không chấp nhận.
Ngay cả các tướng lãnh sau khi đảo chính, cũng không có thiện cảm
với chuyện lính Mỹ trực tiếp tham chiến. Phải đợi đến sau khi tình
hình chiến sự VN sa sút quá mức, sau những xáo trộn trầm trọng gây
ra bởi những chỉnh lý liên tục của các tướng, với những thay đổi tư
lệnh chiến trường không ngừng, đe dọa sự sống còn của cả miền Nam,
năm 1966, thì Mỹ mới được mang quân vào.<br/><br/>Nên nhớ là chưa khi nào có một chính quyền miền Nam nào chính thức
yêu cầu Mỹ cho quân tác chiến vào giúp. TT Diệm và các cấp lãnh đạo
dân sự và quân sự sau 63 đều tin tưởng quân lực VNCH có thể đương đầu
với quân CSBV, chỉ cần hỗ trợ vũ khí đạn dược thôi. Chỉ có các TT
Dân Chủ Kennedy và Johnson là coi quân lực VNCH không ra gì nên nhất
định phải mang lính Mỹ vào mà không cần biết đến hậu quả chính
trị. Những nhận định bất lợi nhất cho quân lực VNCH trong suốt cuộc
chiến cũng đến từ những dân biểu và nghị sĩ của đảng Dân Chủ, kể
cả thượng nghị sĩ John Kerry, bây giờ là ngoại trưởng. Ta không quên
ông Kerry đã từng ra trước quốc hội công khai tố lính VNCH chỉ giỏi ăn
cắp gà và hãm hiếp phụ nữ.<br/><br/>Dưới TT Thiệu, những thoả thuận giữa BV và Mỹ đã bị TT Thiệu bác
bỏ, không chịu ký trong mấy tháng, cho đến khi hiệp định được sửa
vài điều quan trọng nhất, và sau khi đã ép TT Nixon dội bom ào ạt Hà
Nội mùa Giáng Sinh 1972, ông mới chịu ký. Hiệp định không hoàn hảo
đưa đến chuyện mất miền Nam, nhưng đỡ hơn bản thảo đầu nhiều. Có thể
nếu không có sự chống đối của TT Thiệu thì miền Nam tự do đã bị
khai tử trước vài tháng hay một hai năm không chừng.<br/><br/>Qua cả hai câu chuyện, ta thấy ngay, cuối cùng thì số phận miền Nam
cũng đã được quyết định từ Tòa Bạch Ốc, dưới tổng thống Dân Chủ
hay Cộng Hoà cũng chẳng có gì khác, và với thân phân tiểu quốc, ta
cũng chẳng làm gì được. Nhưng dù sao thì cũng không ai có thể chối
cãi được cả TT Diệm lẫn TT Thiệu, đều đã có dịp cưỡng lại quyết
định của đồng minh, trong khi miền Bắc thì dù bất mãn đến đâu, cũng
không dám làm gì khác ngoài chuyện vâng dạ rồi lẩm bẩm cho đỡ bực.<br/><br/>VẤN ĐỀ MIỀN NAM “THUA”<br/><br/>Có nhiều độc giả vẫn thắc mắc không hiểu tại sao quân lực VNCH có
thể “thua” được.<br/><br/>Thật ra, phải định nghiã lại cho rõ thế nào là “thua”. Nếu “thua” là
hai bên ra trận đánh nhau, dốc toàn lực sống mái với nhau, rồi một
bên vì sai lầm chiến lược hay chiến thuật nên bị bên kia đánh bại,
phải tháo chạy, thì đó đúng là thua.<br/><br/>Cuộc chiến VN chấm dứt khác xa trường hợp trên.<br/><br/>Như đã nhận định trong bài viết tuần trước, “Khi Mỹ muốn đánh thì
cấp súng đạn cho ta đánh, khi Mỹ muốn tháo chạy thì mang súng đạn
về, kể cả ngòi bom CBU”. Sau khi TT Nixon đã bắt tay được với Mao thì
Mỹ thấy không còn lý do gì can dự vào cuộc chiến VN nữa, và quyết
định rút về.<br/><br/>Đây là một quyết định nằm trong chiến lược toàn cầu của Mỹ. Nhưng
cũng là một quyết định được lấy vì những nhu cầu chính trị nội bộ
Mỹ. TT Nixon bị vướng mắc vào xì-căng-đan Watergate không có lối
thoát, với hậu thuẫn quần chúng gần như mất hết, trong khi hậu thuẫn
chính trị trong giới chính khách Mỹ và trong quốc hội lung lay tận
gốc rễ. TT Nixon không còn thời giờ để lo chuyện VN, cũng như đang có
nhu cầu lấy lại phần nào hậu thuẫn để đối phó với Watergate đang đe
dọa chính cái ghế tổng thống của ông. TT Ford kế nhiệm trong tư thế
tổng thống duy nhất không được dân bầu trong lịch sử Mỹ, không có đủ
hậu thuẫn chính trị lật ngược quyết định rút, nhất là khi đó ông
lại hoàn toàn bị Kissinger thao túng.<br/><br/>Một khi đồng minh Mỹ muốn rút thì sẽ mang súng đạn rút theo. Khi đó
quân lực VNCH đánh nhau bằng gì?<br/><br/>Trong khi đó, trực diện chúng ta là miền Bắc với hậu thuẫn cụ thể
bằng tiền bạc, và súng đạn không giảm chút nào. Một nửa triệu quân
Mỹ với đầy đủ bom đạn vô giới hạn và ngân sách bạc trăm tỷ đã không
hạ được quân Bắc Việt với viện trợ quân sự hùng hậu của khối CS.
Bây giờ ai có thể nghĩ quân lực VNCH có thể ngăn được làn sóng đỏ,
với viện trợ của Mỹ trên nguyên tắc có thể “thay thế tiêu hao” như
Hiệp Định Ba Lê quy định, nhưng trên thực tế chẳng thay thế được gì,
mà chỉ vơi dần thật mau lẹ? Quân lực đó cầm cự được tới 1973 là
giỏi lắm rồi.<br/><br/>Hiển nhiên cái “thua” đó không phải là thua theo nghiã bình thường. Bị
lấy đi vũ khí, trói tay lại, đưa ra trước trận đấu, thì không còn là
trận đấu và không còn nói đến thắng hay thua được nữa.<br/><br/>Ta thất bại vì đồng minh quyết định thôi, không chơi nữa, phủi tay bỏ
đi. Chủ quyền có thể được xác định một cách tiêu cực bằng cách
phản đối không nghe theo hay làm theo một chuyện gì, nhưng không thể
xác định một cách tích cực như bắt đồng minh phải tiếp tục hậu
thuẫn, tiếp tục viện trợ được.<br/><br/>CÁI CHẾT CỦA TT DIỆM<br/><br/>Tác giả có đưa ra ý kiến có lẽ TT Kennedy đã không trực tiếp “ra
lệnh” giết TT Diệm, mà cái chết của TT Diệm chỉ là một “rủi ro”
lớn mà TT Kennedy chấp nhận. Vài độc giả cho rằng đã có tài liệu
xác nhận TT Kennedy đã đích thân chỉ thị cho các viên chức Mỹ tại VN
phải “giúp” các tướng lãnh VNCH diệt tận gốc, tức là giết TT Diệm,
không có chuyện cho TT Diệm tỵ nạn chính trị tại Mỹ hay một nước
đồng minh nào khác như Thái Lan, Phi Luật Tân hay Đài Loan.<br/><br/>Đúng ra, tác giả cũng đã được biết là đã có một nhà báo uy tín
Mỹ đang chuẩn bị ra một cuốn sách mới, đưa bằng chứng rõ ràng TT
Kennedy đã “ra lệnh” phải giết TT Diệm, chứ không phải đó là ý kiến
của một trong các phụ tá như các ông Harriman, Hilsman, hay của đại sứ
Cabot Lodge.<br/><br/>Cuốn sách chưa phát hành, chưa ai thấy những bằng chứng sẽ được đưa
ra, và tính thuyết phục của những bằng chứng đó. Do đó, tác giả
chưa thể bàn xa hơn. Nhưng có thể cuốn sách đó cũng lại sẽ rơi vào trường
hợp của không biết bao nhiêu tài liệu khác về vấn đề này. Chỉ đổ
dầu vào lửa, tạo thêm tranh cãi về vấn đề, mà vẫn chưa ai dám nói
là có câu trả lời tối hậu.<br/><br/>Chúng ta hãy chờ sau khi cuốn sách đó phát hành để có dịp nhìn lại
câu chuyện. Hy vọng cuốn sách đó sẽ có bằng chứng cụ thể không tranh
cãi được để chúng ta hiểu rõ hơn một biến cố trọng đại trong lịch
sử nước ta.<br/><br/>VẤN ĐỀ LÀO<br/><br/>Một vài độc giả nêu vấn đề Hiệp Ước Trung lập Lào do TT Kennedy chủ
xướng, có ảnh hưởng rất lớn lên cuộc chiến tại VN, nhưng lại không
thấy đề cập trong bài viết của tác giả này. Tác giả đã không đề
cập vì khuôn khổ giới hạn của bài báo.<br/><br/>Hiệp Ước Trung Lập Hoá Lào năm 1962 đại cương cũng chỉ là một thất
bại khác của TT Kennedy. Cuộc nội chiến tại Lào, khởi mào từ ngay
sau Thế Chiến Thứ Hai, được gắn liền với cuộc chiến tại VN, với
diễn biến tương tự, rối bù, và sự toàn thắng của khối cộng năm
1975.<br/><br/>Nội chiến Lào là cuộc chiến tay ba giữa lực lượng cộng sản của
đảng Neo Lao Hak Xat, thường gọi là Pathet Lào, lực lượng thân Mỹ, và
lực lượng trung lập của Hoàng Gia.<br/><br/>Pathet Lào chiếm cứ vùng đông và bắc, giáp giới VN và Trung Cộng.
Lực lượng thân Mỹ chống cộng chiếm cứ vùng tây nam, giáp giới Thái
Lan, với lực lượng H’mong là chủ yếu. Lực lượng trung lập, trung
thành với vua, kiểm soát vùng quanh thủ đô Vạn Tượng và thành phố
lớn Luang Prabang. Đây là một cuộc chiến hết sức phức tạp, với ba phe
thay phiên nhau đạt thế thượng phong, hợp tác rồi chia rẽ, với liên
minh thay đổi qua lại, chẳng khác gì thời Tam Quốc Chí bên Tầu, với các
lực lượng quân sự của nhiều nước đứng sau lưng. Trên thực tế, cả ba
phe của Lào đều hết sức yếu về mặt quân sự, mỗi phe lèo tèo vài ba
tiểu đoàn chẳng có gì là thiện chiến. Dân Lào có lẽ là dân hiền
hòa nhất thế giới, không biết đánh nhau là gì. Và cuộc chiến thật
sự là cuộc chiến giữa hai khối CS với Trung Cộng và CSVN một bên,
chống Tây Phương, trước là Pháp, sau đó là Mỹ, với sự góp sức của
Thái Lan và VNCH sau này.<br/><br/>Sau thất bại nặng nề tại Vịnh Con Heo bên Cuba, TT Kennedy quyết định
vạch lằn ranh đỏ, quyết tâm giữ Miền Nam VN. Ông nhìn thấy rõ Bắc
Việt chỉ có một con đường xâm nhập duy nhất qua ngõ Lào. Chiến lược
cơ bản của Mỹ là làm sao đóng cái cửa ngõ này. Và giải pháp theo
TT Kennedy là một hiệp ước trung lập hoá Lào, không cho các lực lượng
CSVN dùng đất Lào để chuyển quân vào Nam VN. Đưa đến sự ra đời của
giải pháp 1962.<br/><br/>Theo TT Kennedy, trường hợp lạc quan nhất thì việc trung lập hoá sẽ
đóng cửa con đường xâm nhập Lào (khi đó chưa quy mô và chưa được gọi
là đường mòn Hồ Chí Minh), giúp cô lập lực lượng CS trong miền Nam
VN. Trường hợp bi quan nhất thì ít ra, cũng giới hạn được phần lớn
sự xâm nhập của quân Bắc VN vào Nam VN qua một hiệp ước quốc tế có
Nga và Tầu ký.<br/><br/>Những diễn biến lịch sử sau đó đã cho thấy TT Kennedy tính sai hết,
chỉ vì thiếu kinh nghiệm đối phó với sự giảo hoạt của CS. Hiệp ước
trung lập Lào, cũng giống y hệt tất cả các hiệp ước được ký kết
giữa khối Âu-Mỹ với khối CS, kể cả hai hiệp ước Geneve 1954 và Paris
1973: trói tay khối Tây Phương nhưng lại chỉ là mảnh giấy vụn đối với
khối CS. Sau khi hiệp ước ra đời, Mỹ rút hết gần 1.000 cố vấn quân
sự ra khỏi Lào, VNCS rút về vài chục “cố vấn”, còn lại cả sư đoàn
chính quy được cho mặc quần áo Pathet Lào, gia nhập lực lượng Pathet
Lào, ở lại tiếp tục trấn áp các lực lượng chống cộng và trung
lập. Đường mòn Hồ Chí Minh bây giờ hoàn toàn mở rộng dưới sự kiểm
soát trọn vẹn của CSBV.<br/><br/>Lực lượng CSBV qua khối 959, thành lập tháng 9 năm 1959 để hỗ trợ
Pathet Lào, trở thành lực lượng quân sự bảo vệ “đường mòn”, khi đó
bắt đầu lớn dần cho đến khi thành “xa lộ” sau này. Mỹ vớt vát bằng
cách hỗ trợ các lực lượng H’mong của tướng Vang Pao cho đến 1975,
nhưng lực lượng này cũng chỉ là vài viên sỏi nhỏ trên đường nam tiến
của CSVN qua ngã Lào.<br/><br/>ĐỜI SỐNG CÁ NHÂN<br/><br/>Tác giả đã tránh không viết về đời sống cá nhân, nhưng có độc giả
hỏi sao không nói về đời sống cá nhân của TT Kennedy với bà vợ đẹp
và hai con ngoan, là “gương mẫu” –role model- cho xã hội Mỹ, kiểu như TT
Kennedy đã tu thân, tề gia, trị quốc, bình thiên hạ như thế nào. Vậy
xin nói qua vấn đề.<br/><br/>TT Kennedy bị bệnh đau lưng kinh niên, những năm cuối phải ngồi ghế đặc
biệt. Ngay cả hôm ông bị ám sát, trong người cũng phải mặc áo đặc
biệt, giữ lưng ông thẳng, nên khi bị bắn từ sau lưng, đã không ngã gập
người xuống phiá trước, mà lưng vẫn thẳng, ngã nghiêng người qua một
bên về phiá bà Jakqueline Kennedy. Bệnh đau lưng chính thức là do ông
bị thương ở lưng từ hồi đi hải quân trong Thế Chiến Thứ Hai.<br/><br/>Có tin cho rằng ông thật ra bị đau thận vì sắc dục quá độ. Ông bị
bệnh nghiện sex rất nặng, gần như ngày nào cũng phải làm tình, không
có không được. “Tôi sẽ bị nhức đầu nếu mỗi ngày tôi không làm tình
một lần”, đó là câu tâm sự của TT Kennedy. Ban mật vụ -Secret Services-
đặc biệt phải lo cung cấp gái cho ông mỗi khi ông đi kinh lý, hay xa bà
vợ. Có thể là tài tử hay ca sĩ thượng thặng như Marilyn Monroe và
Angie Dickinson, và ngay cả tài tử Marlene Dietrich (khi đó đã trên 60
tuổi và từng là người tình của bố TT Kennedy), hay gái gọi hạng siêu
sang. Phần lớn các cô thư ký Tòa Bạch Ốc, kể cả tùy viên báo chí
của bà Kennedy, đều đã qua đêm với ông. Ông đã từng chia sẻ một bà
đào với trùm mafia Chicago, Sam Giancana, đưa đến giả thuyết ông bị
Giancana thuê Oswald ám sát vì ghen. Bà Kennedy biết rõ nhưng làm ngơ
vì không đáp ứng nhu cầu sinh lý quá mức của ông chồng được.<br/><br/>Cả họ Kennedy, từ ông bố đến ông tổng thống và hai ông em Robert và
Ted đều nổi tiếng về chuyện trăng hoa. TT Clinton so với TT Kennedy chỉ
là anh học trò dốt, ăn vụng không biết chùi mép.<br/><br/>Truyền thông thời đó biết rất rõ, nhưng đã đồng tình lờ không đăng
những chuyện này. Hình ảnh gia đình đầm ấm của TT Kennedy cũng vẫn
chỉ là một huyền thoại khác được dàn dựng thật khéo. (1-12-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a213951/huyen-thoai-kennedy-phan-ii

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/