# Huyền Thoại Kennedy

26/11/2013

...lý do thất bại là TT Kennedy quyết định đánh một cách đánh nửa
vời, vừa đánh vừa run...<br/><br/>Tuần vừa qua đánh dấu đúng 50 năm kỷ niệm TT Kennedy bị ám sát chết.<br/><br/>Đối với người Việt chúng ta, tháng này cũng đánh dấu một cái chết
quan trọng hơn nhiều. Đó là cái chết của TT Ngô Đình Diệm và em là
ông Cố Vấn Ngô Đình Nhu. Cái chết của anh em ông Diệm là cái chết
đổi đời, thay đổi hẳn một chế độ, và đã có ảnh hưởng cực kỳ quan
trọng cho đất nước. Người ta có thể tranh luận đến vô tận, nhưng không
ai có câu trả lời nếu TT Diệm không bị đảo chánh và không bị giết
thì nước ta bây giờ như thế nào. Cuộc tranh luận này, xin nhường lại
cho các vị sử gia uyên bác. Trong bài này, chúng ta chỉ bàn về TT
Kennedy.<br/><br/>TT John Fitzgerald Kennedy là vị tổng thống đã tại chức ngắn nhất
trong lịch sử cận đại Mỹ, vỏn vẹn ba năm, nhưng lại là vị tổng thống
để lại nhiều dấu ấn lịch sử nhất. Riêng đối với vấn đề Việt Nam,
ông là người đã thay đổi cuộc diện chiến tranh Việt Nam.<br/><br/>Việc ông bị ám sát đã chấn động nước Mỹ và cả thế giới như chưa
một biến cố nào có thể có ảnh hưởng lớn như vậy, ngoại trừ đại
chiến thế giới, sự sụp đổ của chế độ CS, hay vụ 9/11.<br/><br/>Sau đó, thì có lẽ chưa có tổng thống Mỹ nào được ca tụng, thần
thánh hoá như TT Kennedy. Ông được ca tụng như một trong những tổng
thống tài giỏi nhất lịch sử Mỹ, với những bài diễn văn hùng hồn,
xúc động cả triệu người trên thế giới. “Đừng hỏi đất nước này đã
làm gì cho bạn, mà hãy tự hỏi bạn đã làm gì cho đất nước này”.
“Hãy để tất cả các nước trên thế giới này biết, cho dù họ muốn
tốt hay muốn xấu cho chúng ta, là chúng ta sẽ trả mọi giá, chịu mọi
gánh nặng, hứng mọi khổ cực để hỗ trợ mọi nước bạn, chống mọi kẻ
thù, để bảo đảm sự tồn tại và thành công của tự do”.<br/><br/>Một người đã lãnh đạo thế giới tự do đứng lên chống làn sóng đỏ
tại Cuba, Bá Linh, và Việt Nam. Một người cũng đã đi tiên phong trong
việc nới rộng cánh tay nhân đạo Mỹ, đi cứu giúp cả thế giới chậm
tiến qua chương trình Peace Corps, với cả ngàn thanh niên thiện nguyện
Mỹ đi giúp dân nghèo đói, bệnh tật khắp thế giới. Một người đã mở
rộng biên cương mới của nước Mỹ khi mở ra chương trình thám hiểm không
gian.<br/><br/>Đó là hình ảnh của TT Kennedy qua con mắt của truyền thông cấp tiến.
Sự thật như thế nào? Ta hãy xét qua vài biến cố lớn nhất dưới
triều đại Kennedy.<br/><br/>VỊNH CON HEO<br/><br/>TT Kennedy tuyên thệ nhậm chức đầu tháng Hai năm 1961. Chưa đầy hai tháng
sau, xẩy ra biến cố Vịnh Con Heo.<br/><br/>Công bằng mà nói, TT Kennedy bị đặt vào thế chuyện đã rồi, khó làm
gì khác được. Trước hiểm hoạ cộng sản sát nách tại Cuba, giữa cuộc
chiến tranh lạnh cực kỳ căng thẳng của thập niên 60, đây là một đe
dọa trực tiếp cho nước Mỹ. TT Eisenhower quyết định phải lật đổ Fidel
Castro, chấm dứt mối đe dọa thường trực trong sân sau nhà. Theo kế
hoạch, Mỹ sẽ giúp một nhóm vài ngàn chí nguyện quân trong khối dân
Cuba đang tỵ nạn tại Mỹ. Họ sẽ được Mỹ huấn luyện, tài trợ, rồi
đổ bộ lên Vịnh Con Heo tại Cuba, tấn công và lật đổ Castro. Kế hoạch
còn đang được soạn thảo khi TT Kennedy đắc cử, và ngay sau đó được
hoàn tất. Tân TT Kennedy bị đặt vào thế phải quyết định tiến hành
hay không.<br/><br/>Trong suốt cuộc tranh cử chống PTT Nixon, TNS Kennedy đã bị phe Cộng
Hòa tô vẽ như một người ngây thơ, không có kinh nghiệm chính trị quốc
tế, yếu đuối, sẽ bị Krushchev bóp mũi. Với hình ảnh đó, TT Kennedy
không có lựa chọn nào khác trước thử thách quốc tế quan trọng đầu
tiên. Ông quyết định đánh.<br/><br/>Theo kế hoạch, Mỹ sẽ cho phi cơ đánh không lực Castro trước, rồi tiếp
thả bom diệt quân của Castro, và nếu chẳng may đổ bộ thất bại, thì
đổ tàu vào cứu nhóm nghiã quân.<br/><br/>Cuộc đánh bom đầu tiên thất bại, chỉ tiêu hủy được một vài chiếc
máy bay của Castro. Cuộc đổ bộ 1.400 quân kháng chiến Cuba cũng thất
bại nặng khi Castro cho máy bay thả bom và bắn quân kháng chiến đang
nằm trơ trên bãi cát. Hai chiếc tàu lớn chở súng đạn tiếp tế đậu
ngoài khơi cũng bị đánh chìm. Kháng chiến quân bị đe dọa tiêu diệt
hoàn toàn. Cầu cứu Mỹ. TT Kennedy lên cơn rét, đổi quyết định, ra
lệnh quân lực Mỹ không được cứu giúp dưới bất cứ hình thức nào.
Toàn bộ khối quân kháng chiến hoặc bị giết, hoặc bị bắt cầm tù.<br/><br/>Truyền thông phe ta xúm lại đổ lỗi cho CIA và Ngũ Giác Đài đã cài TT
Kennedy trong thế kẹt, rồi ca tụng TT Kennedy đã không sa lầy trong cái
bẫy của CIA. Không ai nói đến chyện TT Kennedy có quyền hủy toàn bộ
kế hoặch, mà ông đã không làm vì sợ mang tiếng yếu đuối.<br/><br/>Mấy năm sau, các sử gia nghiên cứu thấy lý do thất bại là TT Kennedy
quyết định đánh một cách đánh nửa vời, vừa đánh vừa run, tìm đường
tháo chạy. Kết quả là trước thử thách đầu tiên, TT Kennedy đã hoàn
toàn thảm bại, cả trăm quân kháng chiến bị chết, cả ngàn còn lại
bị tù đầy. TT Kennedy tuyên bố hùng hồn “trả mọi giá... để bảo đảm...
tự do”: coi dzậy mà hổng phải dzậy!<br/><br/>KHỦNG HOẢNG HOẢ TIỄN NGUYÊN TỬ<br/><br/>Trước thắng lợi trọn vẹn tại Vịnh Con Heo, Castro thừa thắng xông lên,
bắt tay với Liên Sô, cho Liên Sô lập mấy dàn hỏa tiễn có đầu đạn
nguyên tử và có tầm bắn tới New York và Washington. Tình báo Mỹ chụp
hình thấy rõ ràng. Không thể ngồi yên trước đe dọa trực tiếp và cụ
thể này nữa, TT Kennedy ra lệnh phong tỏa Cuba, chặn tất cả các tầu
vào Cuba, và điều đình với Krushchev. Quân đội Mỹ khắp thế giới báo
động đỏ cấp cao nhất. Thế giới bên bờ vực của thế chiến thứ ba,
lần này khủng khiếp hơn nhiều vì là giữa hai cường quốc đều có bom
nguyên tử. Dân Mỹ xanh mặt vì nguy cơ lãnh bom nguyên tử thật sự, chứ
không còn là đánh nhau trên vài hòn đảo tuốt tuột bên kia Thái Bình
Dương như thời thế chiến.<br/><br/>Vài ngày sau, Krushchev ra lệnh tháo gỡ các dàn hỏa tiễn, mang về
Liên Sô. Truyền thông tung hô TT Kennedy như người đã đại thắng, ép được
tên điên khùng nguy hiểm Krushchev vào đường cùng phải chịu thua. Một
lãnh tụ cực tài giỏi, bình tĩnh, can đảm, cứu được nước Mỹ mà
không tốn một viên đạn, chứ đừng nói tới chuyện tránh được bom nguyên
tử.<br/><br/>Cũng chỉ mấy năm sau, những tài liệu được giải mật cho thấy thực sự
TT Kennedy đã... thua đậm. Thua vì không bứng được cái gai Castro ngay
bên hông, vẫn tồn tại cho đến ngày nay, hơn nửa thế kỷ sau. Nhưng quan
trọng hơn nhiều là thua vì ông đã nhượng bộ hai đòi hỏi của
Krushchev: 1) Mỹ phải chấm dứt chương trình không thám U-2 trên lãnh
thổ Nga và Đông Âu, và 2) Mỹ phải tháo gỡ toàn bộ dàn hoả tiễn
nguyên tử đã dựng lên từ sau thế chiến tại Thổ Nhĩ Kỳ nhắm vào các
thành phố lớn và các địa điểm chiến lược quan trọng nhất của Liên
Sô.<br/><br/>Nói cách khác, Krushchev vướng vào hai cái gai đó, không biết cách
nào gỡ được dưới thời TT Eisenhower, bây giờ mang hoả tiễn nguyên tử
vào Cuba để hù dọa và đổi chác với Kennedy, và TT Kennedy đã nhượng
bộ, đáp ứng tất cả đòi hỏi của Krushchev. Chuyện Krushchev công khai
lập dàn hỏa tiễn, chẳng dấu diếm gì là bằng chứng rõ ràng
Krushchev muốn cho Mỹ biết để có dịp đổi chác trả giá. Kết quả
cuộc khủng hoảng, Mỹ chấm dứt chương trình không thám và tháo gỡ
dàn hỏa tiễn tại Thổ Nhĩ Kỳ đang đe dọa Liên Sô, trong khi Mỹ... không
được gì ngoài việc mấy dàn hoả tiễn tại Cuba được tháo gỡ. Chẳng
ai biết vài cái hỏa tiễn được Liên Sô cố tình cho chụp hình có đầu
đạn nguyên tử thật hay không.<br/><br/>Thành tích vẻ vang nhất của TT Kennedy dường như phải nói là thành
tích lớn nhất của vua phé cáo già Krushchev.<br/><br/>CHIẾN TRANH VIỆT NAM<br/><br/>Trong vấn đề vai trò của TT Kennedy trong chiến tranh Việt Nam, có ba câu
hỏi lớn, mà cho đến nay, qua việc giải mật của hàng triệu tài liệu,
vẫn chưa có ai có kết luận cuối cùng, không tranh cãi được nữa.<br/><br/>Câu hỏi đầu tiên là tại sao TT Kennedy gia tăng cường độ tham dự vào
cuộc chiến tại Việt Nam? Để trả lời câu hỏi này, ta phải nhìn lại
thời gian tính. Đúng một ngày sau khi vụ Vịnh Con Heo thất bại và TT
Kennedy lên truyền hình nhận trách nhiệm, ông ra lệnh thành lập một
nhóm công tác đặc biệt –special task force- nghiên cứu chương trình ngăn
cản cộng sản chiếm miền Nam VN.<br/><br/>Nôm na ra, TT Kennedy quyết định can thiệp mạnh mẽ vào cuộc chiến VN
một phần vì lý tưởng can thiệp cứu giúp thiên hạ theo đúng quan điểm
cấp tiến, cũng như đáp ứng đòi hỏi của cuộc chạy đua ảnh hưởng
Mỹ-Nga thời đó, nhưng lý do chính là để cứu vớt uy tín cá nhân bị
đổ vỡ theo thất bại của Vịnh Con Heo.<br/><br/>Quyết định này mở màn cho cuộc tham chiến lâu dài, tốn kém tiền bạc
và nhân mạng, gây tranh cãi nhiều nhất, và cuối cùng là thảm bại
đầu tiên của quân đội Mỹ trong một cuộc chiến.<br/><br/>Câu hỏi thứ hai là vai trò của TT Kennedy trong cuộc đảo chánh 63, và
nhất trong cái chết của TT Diệm. Qua những tài liệu giải mật, chuyện
TT Kennedy “bật đèn xanh” cho các tướng đảo chánh đã vào lịch sử,
không ai chối cãi hay thắc mắc gì nữa. Vấn đề là TT Kennedy có đồng
ý cho giết TT Diệm hay không.<br/><br/>Ở đây, vấn đề vẫn còn đang được tranh cãi. Người thì khẳng định cái
chết của TT Diệm là một cú shock lớn lao đối với TT Kennedy và ông
đã rất bực tức các tướng lãnh VN. Người khác thì cho rằng ông đã
thông đồng với các tướng lãnh giết ông Diệm.<br/><br/>Nước Mỹ có truyền thống dân chủ, thay đổi lãnh đạo thường xuyên,
hoàn toàn trong tôn ti trật tự của thể chế dân chủ và Hiến Pháp.
Đảo chánh là chuyện khó hiểu. Giết đối lập chính trị lại càng vô
lý, không thể chấp nhận được. Trong môi trường đó, khó mà chúng ta
có thể nói TT Kennedy đã thông đồng với các tướng lãnh, hay thậm chí
“ra lệnh” cho họ giết TT Diệm. Như vậy thì có lý do để tin TT Kennedy
không can dự trực tiếp đến cái chết của TT Diệm, không biết gì và
không dính dáng gì đến cái chết này mặc dù ông chấp nhận đảo
chánh.<br/><br/>Nếu đây là sự thật thì phải nói TT Kennedy quả là tay mơ chính trị
nếu không muốn nói là ngây ngô. Mỹ có câu “muốn làm trứng chiên, phải
đập vỏ”. Nếu TT Kennedy nghĩ có thể làm một cuộc đảo chính lật đổ
một chế độ độc tài, với cả ngàn quân nhân súng ống võ trang đầy đủ
mà không đưa đến giết người, như đi ăn tiệc sinh nhật, thì TT Kennedy
chẳng hiểu biết gì về chính trị Á Đông hay về chính trị ngoài thể
chế dân chủ kiểu Mỹ. Cho dù ông không kinh nghiệm, nhưng quanh ông, vẫn
có biết bao cố vấn, làm sao họ không biết hay không đoán được nguy cơ
TT Diệm bị giết? Kẻ viết này tin là TT Kennedy đã được cảnh báo đẩy
đủ, dù ông không chủ ý nhưng đã chấp nhận cái “rủi ro” lớn là TT
Diệm có thể bị giết. Tức là ông đã chấp nhận đó là cái giá phải
trả, tức là ông không có “oan Thị Kính” gì trong vụ giết TT Diệm.
Không ra lệnh, nhưng chấp nhận rủi ro.<br/><br/>Câu hỏi thứ ba là TT Kennedy có đang tính chuyện rút ra khỏi VN trước
khi ông bị ám sát không. Ở đây có nhiều sách báo khẳng định ông đã
có ý định này. Thậm chí, còn có giả thuyết ông bị ám sát chính
vì ý định muốn rút này nên đã bị khối diều hâu/quân đội ám sát
chết để bảo đảm cuộc chiến VN sẽ tăng cường độ để bán vũ khí hay
thử nghiệm các chiến lược quân sự chống CS.<br/><br/>Đã có một cuốn sách được viết, khẳng định TT Kennedy đã có ý định
rút. Bằng cớ đưa ra là một chỉ thị của TT Kennedy ra lệnh Bộ Quốc
Phòng lập một kế hoặch rút toàn diện hết các cố vấn quân sự về. Việc
ra lệnh này chắc là có thật, nhưng nếu dựa trên lệnh đó mà nói TT
Kennedy chuẩn bị rút ra khỏi VN thì có hơi võ đoán. Trong tư thế lãnh
đạo, TT Kennedy phải có chuẩn bị cho mọi tình huống. Do đó việc ông
ra lệnh làm kế hoạch rút quân không có gì là lạ, và cũng không mang
ý nghiã đặc biệt gì. Chưa phải là lệnh rút, mà chỉ là lập kế
hoặch dự phòng có thể rút. Chắc chắc ngoài lệnh đó ra, ông cũng đã
ra lệnh làm kế hoặch đổ nửa triệu lính Mỹ vào VN hay thậm chí đổ
bộ thủy quân lục chiến vào Vịnh Hạ Long không chừng.<br/><br/>Thực tế chuyện TT Kennedy muốn rút là khó tin. TT Kennedy chỉ cần
viện lý do TT Diệm độc tài, đàn áp Phật Giáo, chấm dứt viện trợ TT
Diệm là xong. Không cần phải rắc rối phê chuẩn việc lật đổ TT Diệm,
mang tai mang tiếng là đế quốc để rồi sau đó làm kế hoặch rút ra
khỏi VN. Hậu thuẫn đảo chánh làm gì nếu đã tính rút lui? Nói cách
khác, TT Kennedy vẫn bị ám ảnh bởi thất bại hai lần tại Cuba, nên
muốn vạch lằn ranh, nhất định mạnh mẽ ngăn chặn làn sóng đỏ tại VN.
Nếu ông không bị ám sát, có nhiều triển vọng chính sách của ông
cũng sẽ như chính sách của TT Johnson sau này thôi. Ta cũng không thể
quên những tác giả của chính sách của TT Johnson tại VN là bộ trưởng
quốc phòng McNamara, ngoại trưởng Dean Rusk, cố vấn an ninh Bundy,...
đều là người của ê-kíp Kennedy.<br/><br/>Cả ba câu chuyện tuy khác nhau, nhưng tóm gọn đầy đủ câu chuyện cuộc
chiến VN, và là đáp số cho câu hỏi tại sao miền Nam thất bại, tại
sao quân lực VNCH thua. Chỉ vì chính quyền miền Nam, cho dù dưới thời
đệ nhất hay đệ nhị Cộng Hòa, chưa khi nào thực sự có chủ quyền
trọn vẹn, có quyền quyết định đánh hay không đánh, đánh theo kiểu
nào, đánh cho quyền lợi đất nước ta hay đánh vì quyền lợi Mỹ. Cũng
như quân lực VNCH, chưa bao giờ được huấn luyện và hỗ trợ theo nhu cầu
thực sự của cuộc chiến, mà chỉ là theo nhu cầu của chiến lược,
chiến thuật của Mỹ. Khi Mỹ muốn đánh thì cấp súng đạn cho ta đánh,
khi Mỹ muốn tháo chạy thì mang súng đạn về, kể cả ngòi bom CBU.<br/><br/>Nếu ta nhìn vào ba quyết định lớn của TT Kennedy nêu trên, trong cả ba
trường hợp, đều không có yếu tố Việt Nam trong đó, tức là chuyện
chính quyền VN và dân VN có cùng ý không, can dự hay không can dự có
lợi hay có hại cho nước và dân VN như thế nào,... Tuyệt đối không cân
nhắc những chuyện này, mà chỉ cân nhắc quyền lợi của Mỹ ở đâu thôi.
Trong cuộc chiến này, đồng minh chỉ tính toán theo quyền lợi của họ
thôi, chứ ít thắc mắc về sự sống còn của chúng ta. Khi Kissinger nói
chuyện được với Mao là lúc quyền lợi chiến lược Mỹ được bảo đảm,
VN thành con chốt thừa.<br/><br/>Người Việt chúng ta có quyền cảm mến cái hào hoa của TT Kennedy và
cái tài ăn nói của ông, nhưng chỉ trong tư cách tổng thống Mỹ thôi.
Còn nhìn dưới khiá cạnh Việt, ông không khác gì các TT Johnson, Nixon,
hay Ford: VN chỉ là con chốt trong thế cờ chiến lược toàn cầu của
Mỹ. Cần giữ thì giữ, cần thí là thí.<br/><br/>Nói tóm lại, hình ảnh huy hoàng đẹp đẽ của TT Kennedy chỉ là dàn
diễn do truyền thông cấp tiến dựng lên, trong khi thực tế TT Kennedy
không thần thánh như tưởng tượng. Trong 1.000 ngày nắm quyền, ông chỉ
để lại những diễn văn hùng hồn nhất, hình ảnh một tổng thống trẻ
tuổi, đẹp trai, vợ đẹp con khôn, trong khi thành quả cụ thể thì...
thất bại nhiều hơn thành công. Ông là người đã quyết định can thiệp
vào cuộc chiến VN, đi xa đến độ chấp nhận hy sinh TT Diệm khi thấy ông
này là một trở ngại cho chiến lược chống cộng của Mỹ. TT Kennedy
chết đi để lại những câu hỏi không có câu trả lời như nếu ông ngay từ
đầu không can dự vào VN, hay nếu ông sống, thì chiến tranh VN sẽ như
thế nào? (24-11-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a213632/huyen-thoai-kennedy

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/