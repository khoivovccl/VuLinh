# Bà Tổng Thống Hillary?

01/10/2013

...rất nhiều hy vọng bà Hillary sẽ vượt qua được và trở thành tổng
thống...<br/><br/>Nếu có dịp theo dõi báo Mỹ thường xuyên, người ta sẽ có dịp thấy
dạo này báo chí cấp tiến hết sức bận rộn “lăng-xê” một ngôi sao
mới, chuẩn bị cho đảng Dân Chủ phe ta tiếp tục nắm quyền cho đến năm
2024!<br/><br/>Người thừa kế cho TT Obama đã được truyền thông dòng chính chấp nhận,
công nhận, và tung hô là bà cựu đệ nhất phu nhân Hillary Clinton. Chưa
chi thì truyền thông phe ta đã mau mắn chuẩn bị hậu thuẫn bà. Cả CNN
lẫn NBC đều đã loan tin sẽ tung ra hai loạt phim bộ chiếu trong mấy kỳ
về đời bà Hillary trong năm 2016, là năm bầu tổng thống lần tới. Cả
hai hãng đều khẳng định hai bộ phim sẽ “rất công bằng và trung thực”,
không phải có mục đích cổ võ cho bà, nhưng dĩ nhiên không có một
người nào bình tâm tin được. Chuyện truyền thông dòng chính phe đảng
như thế nào với TT Obama trong hai kỳ bầu cử năm 2008 và 2012 đã quá
lộ liễu không che “mắt thánh” của dân được.<br/><br/>Bà Hillary Clinton là ngôi sao mới của đảng Dân Chủ. “Mới” mà thật ra
cũ rích. Tên tuổi bà Hillary đã được thiên hạ nghe đến từ đầu thập
niên 90, xấp xỉ hai thập niên rồi, khi ông chồng bà mới vào Tòa Bạch
Ốc. Cái tài của bà Hillary là qua bao nhiêu thăng trầm của hai chục
năm lặn lội trong chiến trường chính trị Mỹ, tên tuổi bà vẫn được
coi như sáng giá nhất, không phải chỉ trong nội bộ đảng Dân Chủ, mà
chói loà trên cả chính trường Mỹ, nhờ hàng trăm ngọn đèn sáng rực
của truyền thông dòng chính.<br/><br/>Thật ra, đây cũng không phải lần đầu tiên ngôi sao của bà Hillary rực
sáng như vậy. Những năm 2006-07, bà Hillary đã được cả nước công nhận
như tổng thống kế nhiệm ông tổng thống “cao bồi đáng ghét” Bush, sẽ
là người thế thiên hành đạo, cứu tinh của nước Mỹ sau những “tàn
phá” của Bush. Cuộc bầu cử cuối năm 2008 được coi như chỉ là một thủ
tục hành chính, làm cho có lệ, đúng sách vở như Hiến Pháp đòi hỏi.<br/><br/>Bây giờ, dường như lịch sử lại tái diễn. Bà Hillary lại xuất hiện
như là một tổng thống tương lai mà việc bầu bán năm 2016 cũng lại
chỉ là một thủ tục hành chính khác thôi.<br/><br/>Ở đây có ba vấn đề ta nên nhìn qua: ý định của bà Hillary, các đối
thủ có thể thượng đài với bà, và suy tư của dân Mỹ.<br/><br/>Ý định của bà Hillary thì dĩ nhiên, cho đến nay, bà đã rất ý tứ và
kín đáo, không hề lên tiếng nhìn nhận hay phủ nhận những tin bà sẽ
ra tranh cử. Bà cho biết sau bốn năm du hành thế giới với cả triệu
dặm bay trên trời như ngoại trưởng công du nhiều nhất lịch sử Mỹ, bà
rất mệt mỏi và chỉ muốn nghỉ ngơi. Không ai phủ nhận chuyện này và
không ai không thông cảm với bà Hillary. Với cái tuổi của bà mà phải
ngồi máy bay tới cả triệu dặm quả là một sự hành hạ thân xác quá
đáng. Nhưng có thật là bà đang nghỉ ngơi không? Nếu ta xem báo cho kỹ
thì thấy bà Hillary chẳng có nghỉ ngơi gì cả, bù đầu bù cổ đi đọc
diễn văn, đi khánh thành cái này dự lễ cái kia, đủ thứ chuyện. Còn
bận rộn hơn hồi làm ngoại trưởng nhiều. Có vẻ như chuyện chuẩn bị
ra tranh cử năm tới? Chẳng có vẻ vui thú điền viên gì hết.<br/><br/>Không ai không biết tham vọng của bà Hillary. Đã có một quyển sách
viết về một “thỏa hiệp” giữa hai ông bà Clinton ngay từ ngày còn
trẻ, khi mới lấy nhau: cả hai sẽ dốc toàn lực vào việc đưa ông chồng
vào Tòa Bạch Ốc, sau đó, cả hai sẽ lại dốc toàn lực vào việc đưa
bà vợ vào tiếp nối, sau một thời gian cho dân Mỹ “nghỉ xả hơi”, một
loại giai đoạn chuyển tiếp mà Mỹ gọi là “decent interval” cho bớt lộ
liễu.<br/><br/>Kết quả như ta đã thấy, ông chồng trở thành tổng thống năm 1992, sau
tám năm thì nhường chức lại cho ông Cộng Hoà Bush, để rồi sau tám năm
của Bush, tới phiên bà vợ ra mặt, vào năm 2008. Kế hoạch coi như tuyệt
hảo, không sai trật vào đâu được, chẳng may đã bị một anh chính khách
dấm dớ Obama chẳng biết ở đâu ra, nhẩy vào phá bĩnh. Nhưng không phải
vì vậy mà bà Hillary không còn tham vọng trở thành nữ tổng thống đầu
tiên của Mỹ.<br/><br/>Cuộc đời của bà Hillary là một chuỗi dài những quyết định chính
trị có chủ đích chuẩn bị cho hành trình vào Tòa Bạch Ốc.<br/><br/>Thử thách chính trị lớn nhất trong đời bà là khi ông chồng, TT
Clinton, dính líu vào vụ lem nhem với cô Monica Lewinsky. Bà đã mau mắn
quyết định ngậm đắng nuốt cay, khép nép đứng sau lưng ông chồng bê
bối, để bảo vệ cái ghế tổng thống của ông ta, tức là bảo vệ tương
lai chính trị của chính bà. Hơn ai hết, bà hiểu là bà chỉ cần lên
tiếng một lần là TT Clinton sẽ mất ngay tất cả hậu thuẫn, và mất
luôn chức. Và như vậy là tương lai chính trị của bà cũng chìm xuồng
theo ngay. Thái độ thông cảm và tha thứ cho chồng đã khiến không ít
người “cảm động và thông cảm” cho những khó khăn của gia đình bà
trong vụ cô Monica, và bất mãn trước sự tấn công có vẻ như quá nặng
tay của đối lập Cộng Hòa. Các thượng nghị sĩ đã cân nhắc hậu thuẫn
của quần chúng đối với TT Clinton trong vụ này, và đã lấy quyết
định theo tiếng gọi của lá phiếu: biểu quyết không cất chức TT
Clinton để bảo vệ cái ghế của chính mình.<br/><br/>Bây giờ là lúc cơ hội ngàn năm lại xuất hiện, không có lý do gì bà
Hillary quay mặt làm ngơ. Trừ phi một biến cố trọng đại bất ngờ xẩy
ra, chẳng hạn như tình trạng sức khỏe sa sút bất ngờ, hay một
xì-căng-đan vĩ đại nào trong quá khứ bị khui ra, bà Hillary sẽ ra
tranh cử tổng thống trong năm 2016. Cho dù chối cãi thế nào thì ý
định của bà, ai cũng thấy.<br/><br/>Bà Hillary sẽ phải đối đầu với ai?<br/><br/>Trong nội bộ đảng Dân Chủ, chưa có ai có đủ thế hậu thuẫn chính trị
lớn đến mức có thể tranh dành với bà Hillary. Một vài chính khách
Dân Chủ rục rịch chuẩn bị ra tranh cử, đáng chú ý nhất là thống
đốc Nữu Ước Andrew Cuomo, thị trưởng Chicago Emanuel Rahm, nữ thượng
nghị sĩ Amy Klobuchar của Minnesota, và nửa tá nhân vật khác. Nhưng
người ta có cảm tưởng những nhân vật này đang chạy đua để làm phó
cho bà Hillary thì đúng hơn.<br/><br/>Một nhân vật sáng giá hơn mấy vị này là PTT Joe Biden. Thông thường,
theo luật bất thành văn của chính trị Mỹ, phó tổng thống đương nhiên
là “thái tử” được đảng cầm quyền tiến cử làm thừa kế. Nhưng ông
phó Biden lại là người không sáng giá lắm, và cũng không có được
hậu thuẫn mạnh trong đảng. Năm 2008, ông ra tranh cử tổng thống lần
thứ hai mà vẫn chỉ kiếm được có trên 1% hậu thuẫn. Ông “thái tử”
này cũng rõ ràng là quá già, sẽ 75 tuổi khi nhậm chức năm 2017 nếu
đắc cử, trong khi bà Hillary sẽ chỉ mới 69. Ông còn già hơn cả TT già
nhất Reagan, nhậm chức khi 70 tuổi. Cho dù PTT Biden có ra tranh cử,
không ai nghĩ ông sẽ hạ được bà Hillary. Ngay cả ông Biden cũng ý thức
được chuyện này. Trong khi ông chuẩn bị tranh cử, ông cũng đã lẳng
lặng đánh tiếng ông sẽ chỉ ra tranh cử nếu bà Hillary không ra thôi.<br/><br/>Hậu thuẫn của bà Hillary trong đảng Dân Chủ rất mạnh. Theo thăm dò
mới nhất của CNN, tỷ lệ ủng hộ bà là 65% trong nội bộ đảng Dân
Chủ, một con số khó có thể cao hơn trong chính trị Mỹ. Ứng viên thứ
nhì là PTT Biden, với 10%. Việc bà Hillary nếu ra tranh cử sẽ nắm
chắc phần thắng trong nội bộ đảng là chuyện không ai có thể phủ
nhận được.<br/><br/>Nhìn về phiá đối lập Cộng Hòa, cho đến nay, chưa ai nhìn thấy được
một ngôi sao nào có thể đe dọa thế đứng của bà Hillary. Đảng Cộng
Hoà, trong nỗ lực trẻ trung hoá sau vụ thảm bại của thống đốc
Romney, đã khua chiêng trống mạnh cho vài chính khách thế hệ mới như
các thượng nghị sĩ Rubio Marco, Ted Cruz, Rand Paul, hay cựu ứng viên PTT
Paul Ryan, hay thống đốc Chris Christie của New Jersey. Tổng cộng có nửa
tá chuẩn ứng viên, nhưng không có một người nào có được tới 20% hậu
thuẫn ngay trong đảng Cộng Hòa. Tất cả đều thua bà Hillary xa lắc xa
lơ. Nếu có ra tranh cử thì chỉ có thể đưa tên tuổi mình ra để chuẩn
bị cho thời kỳ hậu Hillary thôi.<br/><br/>Dĩ nhiên có rất nhiều người, nhất là phụ nữ. Sau khi đảng Dân Chủ đi
vào lịch sử với một tổng thống da đen đầu tiên, nhiều người cho rằng
đã đến lúc đảng Dân Chủ đi vào lịch sử thêm một lần nữa với một
nữ tổng thống đầu tiên.<br/><br/>Trên thế giới, đã có rất nhiều phụ nữ lên nắm quyền trong lịch sử
cận đại. Nữ tổng thống như tại Sri Lanka, Liberia, Argentina, Brazil,
Indonesia, Philippines và mới đây, Đại Hàn. Nữ thủ tướng như tại Anh,
Đức, Sri Lanka, Ấn Độ, Do Thái, Pakistan, Thái Lan, Úc Đại Lợi,...
Nhìn vào những bà này, nước Mỹ có vẻ như còn rất hủ lậu. Năm 2008,
khi có cơ hội phải chọn giữa một bà và một ông, dân Mỹ đã chọn ông,
cho dù ông này là da màu. Đã đến lúc dân Mỹ phải bầu cho một phụ
nữ làm tổng thống.<br/><br/>Thế nhưng bà Hillary, bất kể những ưu thế vĩ đại, lại là người cũng
có rất nhiều hành trang. Năm 2008, trong cái thế không thể thua được
mà bà vẫn thua, mà thua một chính khách vô danh, tay mơ. Chỉ vì chính
khách tay mơ đó đã không có những tỳ vết nào.<br/><br/>Bà Hillary qua vụ Monica, có thể đứng khép nép sau lưng chồng để giữ
ghế cho chồng và lấy cảm tình cho mình, nhưng lại chứng tỏ là người
tính toán rất kỹ, kiềm chế được tình cảm cá nhân và dám làm mọi
chuyện để đạt được tham vọng cá nhân. Một người đàn bà sau khi thấy
đáng thương, nghĩ cho cùng thấy rất đáng sợ. Bà Hillary cũng là
người công khai tuyên bố bà không phải là thứ đàn bà ngồi nhà làm
bánh ngọt (cookie) cho con mang đi trường như những bà mẹ tiêu biểu của
xã hội Mỹ.<br/><br/>Một thăm dò trong đảng Dân Chủ cho thấy nhiều người muốn bà ra tranh
cử nhất, nhưng bà cũng bị nhiều người chống đối nhất. Chứng tỏ bà
là một người sẽ gây tranh cãi, ủng hộ rất nhiều mà chống đối cũng
rất đông.<br/><br/>Bà Hillary là một phụ nữ nổi danh trong chính trường, trong tư thế đệ
nhất phu nhân của tiểu bang, rồi đệ nhất phu nhân của cả nước, rồi
thượng nghị sĩ, và cuối cùng là ngoại trưởng. Toàn là những tư thế
nổi đình nổi đám, với những trách nhiệm thật lớn lao. Nhưng nếu
nhìn kỹ lại, thì bà Hillary, trong suốt quá trình đó, đã không để
lại một thành tích đáng kể nào cả.<br/><br/>Trong những năm làm đệ nhất phu nhân Arkansas, bà vẫn tiếp tục đi làm
luật sư kiểu bán thời cho một công ty luật lớn nhất tiểu bang. Gia
tài bà để lại là một chuỗi những giao dịch có vấn đề lớn, đưa đến
việc một công tố viện đặc biệt được bổ nhiệm để điều tra những giao
dịch liên quan đến dự án Whitewater. Bà cũng nổi tiếng qua việc đầu
tư 1.000 đô đẻ ra ngay 100.000 đô trong vài tuần qua cái mà bà cho là
đầu tư đúng chỗ, chứng khoán mua bán gia súc.<br/><br/>Bước vào Tòa Bạch Ốc, TT Clinton trao ngay dự án cải tổ y tế vĩ đại
cho bà. Một kế hoạch cải tổ tương tự như kế hoạch sau này của TT
Obama. Dự án chết trong trứng nước, vì không có được hậu thuẫn của
ngay các dân cử trong nội bộ đảng Dân Chủ. Sau thất bại đó, không còn
gì khác ngoài chuyện công khai bênh vực ông chồng trong vụ Monica, và
hàng loạt chuyện mờ ám khác như travelgate, filegate,... mà chắc chắc
ta sẽ có dịp nghe lại nếu bà ra tranh cử.<br/><br/>Rồi để chuẩn bị cho việc tranh cử tổng thống, bà tranh cử thượng
nghị sĩ tại Nữu Ước, thắng cử dễ dàng. Trong suốt tám năm, thành
tích đáng kể nhất của thượng nghị sĩ Hillary Clinton là biểu quyết
cho TT Bush đánh Afghanistan, rồi sau đó đánh Iraq, một quyết định mà
sau này bà đã tìm cách tránh né, mất không biết bao nhiêu thời giờ
giảng giải, và cũng là lý do quan trọng nhất khiến bà thua ứng viên
Obama. Không có bộ luật quan trọng nào dưới tên bà.<br/><br/>Sau khi TT Obama đắc cử, bà được bổ nhiệm làm ngoại trưởng, với ba
trách nhiệm: hàn gắn những quan hệ bị sứt mẻ với các đồng minh Âu
Châu vì vụ Iraq, lấy cảm tình khối Ả Rập Hồi Giáo để giảm đe dọa
khủng bố, và siết chặt lại giao hảo với Nga và Tầu. Công bằng mà
nói, bà đã không đạt được một kết quả đáng nói nào cho dù bay đi
công tác cả triệu dặm như đã khoe. Hay nói cho đúng hơn, bà đã “thành
công mỹ mãn” trong việc dùng chức vụ và máy bay Nhà Nước để đi tự
quảng bá mình cho khắp thế giới biết tên biết mặt.<br/><br/>Quan hệ giữa Mỹ và cả ba khối đều sa sút, tồi tệ hơn dưới thời
Bush. Quan hệ Mỹ với ba đồng minh lớn là Anh, Pháp và Đức lạnh nhạt
hẳn, hình ảnh nước Mỹ trong khối Ả Rập xấu đi, nhất là tại Ai Cập
và Syria. Cho đến nay, vai trò và thế đứng ngoại giao của Mỹ đối với
những biến cố đẫm máu tại hai xứ này vẫn là những bí ẩn không ai
biết gì. Quan hệ với Trung Cộng và Nga xuống cấp thảm hại qua chuyện
hai nước này phớt lờ những kêu gọi, dọa dẫm của Mỹ về vụ anh
Snowden xì tin bí mật của Cơ Quan An Ninh NSA, được Tàu cho chạy thoát
khỏi Hồng Kông và Nga cho tỵ nạn.<br/><br/>Quan trọng hơn cả là tuy bà đã từ nhiệm, nhưng thảm hoạ Benghazi với
đại sứ Mỹ bị giết vẫn chưa giải quyết xong. Hàng trăm câu hỏi, đặc
biệt là về vai trò của bà trong vụ này vẫn chưa có câu trả lời.<br/><br/>Rồi cuộc khủng hoảng Syria cũng không hoàn toàn tha bà, mặc dù bà
đã hết làm ngoại trưởng từ lâu rồi. Người ta còn nhớ trước đây, bà
Hillary đã công khai ca tụng TT Assad là thành phần tiến bộ
(progressist), có tư tưởng cởi mở, Mỹ có thể nói chuyện được. Nhưng
đó là lời tuyên bố trước khi cuộc nội chiến đẫm máu xẩy ra, chỉ
chứng tỏ khả năng nhận định chính trị của bà Hillary không chính xác
lắm.<br/><br/>Nhìn vào bức tranh hiển nhiên đen tối đó, câu hỏi là bà Hillary có
những thành tích gì có thể biện minh cho việc bầu bà làm tổng
thống?<br/><br/>Người ta cũng không thể quên việc dân Mỹ bầu cho bà hay không cũng tùy
thuộc một phần rất lớn vào thành quả của TT Obama. Nếu ông này được
coi như tốt hay tàm tạm được thì dân Mỹ có nhiều hy vọng tín nhiệm
đảng Dân Chủ tiếp tục và bầu cho bà. Nếu TT Obama tiếp tục đi từ
khủng hoảng này đến xì-căng-đan khác như trong mấy tháng qua, hy vọng
của bà Hillary sẽ giảm nhiều.<br/><br/>Cái tuổi cổ lai hy của bà Hillary cũng sẽ là một vấn đề không nhỏ.
Cả ba tổng thống cuối cùng đều vào Tòa Bạch Ốc ở tuổi tứ tuần,
bây giờ Mỹ hết người tài rồi sao mà lại phải nhờ đến một bà lão
gần 70 tuổi?<br/><br/>Nói cho cùng, bất kể những khó khăn, có rất nhiều hy vọng bà Hillary
sẽ vượt qua được và trở thành tổng thống. Lý do quan trọng nhất có
thể giúp bà vượt mọi khó khăn và đắc cử không phải là kinh nghiệm
hay khả năng hay thành quả gì của bà, mà chính là vì dân Mỹ muốn
có một bà tổng thống. Cũng như năm 2008, dân Mỹ muốn chứng minh cho
thế giới thấy sự tiến bộ của Mỹ đã bầu cho một ông da đen làm tổng
thống, bất kể khả năng hay kinh nghiệm. Năm 2016, dân Mỹ có thể muốn
một phụ nữ làm tổng thống, bất kể hành trang nặng nề của bà
Hillary.<br/><br/>Một diễn biến bất ngờ: bà Hillary vì lý do nào đó không ra tranh cử.
Nhìn vào cả hai đảng, chẳng thấy có người nào sáng giá hơn người
nào khác, và chẳng ai tiên đoán được ai sẽ kế nhiệm TT Obama.
(29-09-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: <i><a href="http://mce_host/siteadmin/D_CatID-3_Table-NewsArticle_LanguageID-2_SiteID-2/Vulinh11@gmail.com">Vulinh11@gmail.com</a></i>.
Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a211029/ba-tong-thong-hillary

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/