# Chuyện Dài Obamacare: Nói Cho Rõ

05/11/2013

...Obamacare là điều tốt, cần làm, nhưng cách làm hoàn toàn sai trật
đưa đến nhiều nguy hại lớn...<br/><br/>Một bài viết gần đây về Obamacare trên cột báo này đã khiến một độc
giả Việt Báo than phiền ông là “người nghèo” nhưng mà sao cứ thấy
Việt Báo đăng bài bất thuận lợi về Obamacare, có phải Việt Báo
chống lại người nghèo không? Kẻ viết xin thú thật cảm thấy hết sức
ngạc nhiên về câu trách của độc giả, và cảm thấy thật có lỗi đã
tạo hiểu lầm rất không công bằng cho Việt Báo. Đành phải lên tiếng,
gọi là để “rộng đường dư luận”. Cũng mượn cơ hội này để nói cho rõ
vài hiểu lầm khác đối với kẻ viết này.<br/><br/>Trước hết cần phải khẳng định ngay Obamacare không phải là một cái
gì hoàn toàn có lợi cho “người nghèo”, và mọi ý kiến không thuận lợi
về Obamacare đều có nghiã là “chống người nghèo”. Đây là một trong
những hiểu lầm hay huyền thoại lớn nhất về Obamacare, đã được Nhà
Nước Obama thổi phồng, tung hỏa mù che sự thật.<br/><br/>Cải tổ y tế của TT Obama, nôm na gọi là Obamacare, là một cuộc cải
cách mà chính TT Obama đã gọi là để thực hiện hai mục tiêu chính: a)
cung cấp bảo hiểm sức khoẻ cho toàn dân, bất kể giàu nghèo, trẻ
già, hay tình trạng sức khoẻ hiện hữu; và b) giúp giảm chi phí cực
cao hiện nay của ngành y tế Mỹ.<br/><br/>Cả hai mục tiêu chính mà TT Obama đề ra đều là những nhu cầu trọng
yếu mà không ai không đồng ý. Bất kể cấp tiến hay bảo thủ, giàu hay
nghèo, Dân Chủ hay Cộng Hòa, ai cũng đều đồng ý bảo hiểm toàn dân,
nhất là bảo hiểm cho những người đang có bệnh, là điều thật sự cần
thiết vì lý do nhân đạo cũng như vì nhu cầu kinh tế. Kẻ viết này
chưa bao giờ chống lại những mục tiêu này. Ở đây, cần phải nhắc lại,
tổng thống đầu tiên đưa ra dự luật bảo hiểm sức khoẻ toàn dân chính
là TT Nixon của đảng bảo thủ Cộng Hoà, nhưng không thành công vì sự
chống đối của quốc hội khi đó do đảng Dân Chủ kiểm soát. Chuyện Dân
Chủ muốn bảo hiểm toàn dân trong khi Cộng Hoà chống là một huyền
thoại khác.<br/><br/>Những mục tiêu đó phải được thực hiện như thế nào, đó chính là
khúc mắc tạo mâu thuẫn, gây nên các khuynh hướng ủng hộ hay chống
đối. Và cũng chính vấn đề thực hiện cách nào đã khiến TT Nixon
thất bại không kiếm đủ hậu thuẫn chính trị để thực hiện bảo hiểm
toàn dân cách đây gần nửa thế kỷ. Cũng như trường hợp TT Obama bây
giờ, thiên hạ không ai chống mục tiêu, mà chỉ chống cách thực hiện.<br/><br/>Nhìn vào những mục tiêu của TT Obama, người ta thấy ngay Obamacare không
phải được đưa ra để phục vụ “người nghèo”. Không phải chỉ có người
nghèo mới có những bệnh nặng bị các hãng bảo hiểm từ chối. Đa số
những người không có bảo hiểm cũng không phải là những người nghèo
nhất, vì những người nghèo nhất đều đã có Medicaid.<br/><br/>Kẻ viết này đã đề cập đến chuyện Obamacare có lợi và có hại cho
ai. Nay xin nhắc lại cho rõ ràng.<br/><br/>Đối với những người giàu, Obamacare không có một chút tác động gì
đến họ. Bất kể chuyện gì xẩy ra, họ cũng vẫn đủ tiền mua bảo hiểm
tốt nhất, đi bệnh viện tối tân nhất, khám bác sĩ giỏi nhất, và có
đầy đủ thuốc men và kỹ thuật y khoa tối tân nhất, cho dù chỉ bị cảm
cúm vớ vẩn. Nói Cộng Hòa bảo vệ người giàu nên chống lại Obamacare
là không có căn bản vì Obamacare không có hại hay lợi gì cho người
giàu hết.<br/><br/>Cái lợi lớn nhất là cho những người đang có bệnh nặng, bị các hãng
bảo hiểm từ chối. Nhờ luật Obamacare, các hãng bảo hiểm không có
quyền xua đuổi họ, và bắt buộc phải nhận họ. Dĩ nhiên ở đây có vấn
đề nhân đạo sơ đẳng, không ai có thể bác bỏ ý kiến này. Obamacare
thực hiện được chuyện này là chuyện rất đáng hoan nghênh.<br/><br/>Nhưng Nhà Nước đã có ý kiến tốt này chẳng phải thuần túy vì lý do
nhân đạo không đâu, mà còn vì lý do kinh tế có lợi cho Nhà Nước nữa.
Theo luật thì nếu có người bệnh nặng phải đến nhà thương cấp cứu
thì nhà thương vẫn phải nhận cho dù người đó không có bảo hiểm sức
khoẻ gì hết. Rồi chi phí, nhà thương sẽ đòi lại Nhà Nước, tức là
Nhà Nước gánh đủ chi phí chữa trị này. Bây giờ, Nhà Nước ra luật
bắt buộc các hãng bảo hiểm phải nhận những người bệnh nặng này,
tức là đã bớt được một gánh nặng tiền bạc rất lớn cho Nhà Nước.
Nói trắng ra, Nhà Nước là thành phần có lợi lớn thứ nhì.<br/><br/>Đối với những người cao niên, qua 65 tuổi hưu trí thì họ đã có
Medicare, trên nguyên tắc họ sẽ không bị ảnh hưởng gì nhiều bởi
Obamacare. Nhưng trên thực tế, họ sẽ không tránh được một số ảnh hưởng
bất lợi từ Obamacare.<br/><br/>Tiền đóng góp mỗi tháng cho Medicare (thường được trừ thẳng vào trong
tiền già mỗi tháng) sẽ bị tăng, tuy không nhiều, xấp xỉ khoảng 10%,
hay một vài chục đô một tháng. Họ sẽ vẫn được Medicare trả 80% và
phải bỏ tiền túi ra trả phần 20% còn lại. Cái phần 20% này trong
tương lai sẽ gia tăng vì chi phí y tế gia tăng đồng loạt. Một số rất
lớn những người có Medicare mua thêm bảo hiểm riêng để trả cái 20%
thiếu hụt này, thường qua cái gọi là Medicare Advantage, một chương
trình bảo hiểm do các hãng bảo hiểm tư chịu trách nhiệm. Vì
Obamacare, các chương trình Advantage sẽ bị ảnh hưởng bất lợi, hoặc
là tiền mua sẽ đắt hơn, hoặc là nhiều hãng bảo hiểm sẽ không nhận
Advantage, ví dụ như United Healthcare đã giới hạn chương trình Advantage
bằng cách gạt bỏ cả ngàn bác sĩ trong danh sách bác sĩ trong chương
trình Advantage, khiến hàng ngàn bệnh nhân có Medicare Advantage phải
đổi bác sĩ, hay bỏ United Healthcare qua một hãng bảo hiểm khác.<br/><br/>Đối với những người đang đi làm và có bảo hiểm của hãng, sẽ tùy
thuộc phần lớn vào các hãng. Sẽ có nhiều hãng vẫn duy trì tình
trạng như trước, không có gì thay đổi. Có nhiều hãng khác sẽ có thay
đổi qua nhiều cách như chuyển nhân viên qua bán thời để khỏi cung cấp
bảo hiểm công ty, hay bắt họ thay bác sĩ, thay hãng bảo hiểm, hay hủy
bỏ luôn chương trình bảo hiểm tập thể của công ty. Nói chung, một là
duy trì tình trạng cũ, hai là tình trạng trở nên xấu đi, không ai
thấy tình trạng khả quan tốt đẹp hơn.<br/><br/>Bây giờ, nói đến thành phần “nghèo”, là ưu tư của vị độc giả. Trước
hết, cũng tùy “nghèo” tới mức nào.<br/><br/>Một số lớn dân tỵ nạn, như các thành phần HO, hay những thành phần
khác không có lợi tức hay lợi tức thấp, họ đã được trợ giúp qua
chương trình Medicaid, hay MediCal ở Cali. Trên nguyên tắc, Obamacare sẽ
không ảnh hưởng gì đến họ, tức là có hay không có Obamacare cũng
không có gì khác, ít ra là trong nhất thời, do đó không thể nói
Obamacare có lợi cho họ và chống Obamacare là chống họ.<br/><br/>Đối với thành phần tương đối có thu nhập cao hơn, thuộc thành phần
trung lưu thấp, nếu họ đi làm mà không được công ty cung cấp bảo hiểm,
và lợi tức họ trên mức 33.000 đô, nhưng dưới 94.000 đô cho một gia đình
4 người, thì họ sẽ được trợ cấp phần nào tiền mua bảo hiểm. Họ sẽ
là khối người thứ ba thực sự có lợi với Obamacare, sau những người
đang có bệnh, và sau Nhà Nước như đã bàn ở phần trên.<br/><br/>Những gia đình bốn người với lợi tức trên 94.000 đô sẽ là những nạn
nhân lớn nhất của Obamacare. Bảo phí sẽ tăng, tiền trả trước sẽ tăng,
có thể thuế họ đóng cũng phải tăng để tài trợ cho Obamacare, chưa kể
những chuyện khác như mất bảo hiểm công ty, việc làm bị đổi qua bán
thời, đổi nhà thương, đổi bác sĩ, rồi sau này, sẽ phải chờ dài
người để được phục vụ. Đây là khối người lớn nhất, do đó giải
thích được chuyện tại sao hơn một nửa dân Mỹ (từ 55% đến 60%) chống
lại Obamacare. NBC ước lượng từ 50% đến 75% những người đang mua bảo
hiểm bình thường không có trợ cấp của Nhà Nước hay của công ty, sẽ
bị hãng bảo hiểm hủy hợp đồng bảo hiểm, không nhận họ nữa, hay thay
đổi điều kiện bảo hiểm và tăng bảo phí. Tức là hàng triệu người. Chỉ
riêng tại Cali, có thể sẽ có ít nhất 500.000 người bị mất bảo hiểm
cũ, phải mua bảo hiểm mới đắt hơn nhiều.<br/><br/>Khối “nạn nhân” thứ hai là giới trẻ. Obamacare tốn kém rất nhiều vì
có thêm những người đang có bệnh cũng như nhiều người lớn tuổi khác.
Do đó, Obamacare rất cần giới trẻ là giới đóng tiền bảo phí nhưng
không tốn kém vì ít bệnh hoạn. Luật bắt buộc phải mua bảo hiểm nếu
không sẽ bị phạt thực sự nhắm vào ép buộc giới trẻ phải mua bảo
hiểm. Obamacare cũng bắt các công ty bảo hiểm phải nhận thanh niên tới
tuổi 26 còn sống với bố mẹ. Nghe thì có vẻ nhân đạo, thực tế, chỉ
là cách ép giới trẻ phải mua bảo hiểm. Nói trắng ra, giới trẻ sẽ
là giới tài trợ bảo hiểm y tế cho giới cao niên và những người đang
có bệnh, thay thế cho Nhà Nước. Thêm một lợi điểm cho Nhà Nước.<br/><br/>Một chuyện ngoài lề nói cho vui: những “chị em ta” cũng là những
người được hưởng lợi từ Obamacare. Bây giờ các hãng bảo hiểm phải
nhận bảo hiểm sức khỏe cho họ chứ không còn xua đuổi họ được nữa,
được bảo hiểm chống bệnh hoa liễu hay AIDS, được phá thai miễn phí.
Dĩ nhiên không có “chị em” nào khai lợi tức từ nghề đứng đường nên
họ cũng sẽ xin được trợ cấp tiền để mua bảo hiểm.<br/><br/>Tóm lại, bỏ qua yếu tố nhân đạo và cảm tính, thuần túy trên phương
diện kinh tế gia đình, Obamacare sẽ có hại cho tuyệt đại đa số dân
trung lưu và giới trẻ; có lợi lớn cho Nhà Nước, những người đang có
bệnh, và giới trung lưu thấp; và không ảnh hưởng gì nhiều cho giới
đại gia và giới nghèo.<br/><br/>Kẻ viết này cũng nhận được nhiều thư độc giả chất vấn vài vấn đề
khác, xin trả lời cho rõ.<br/><br/>Vấn đề bảo phí tăng 260% bị tố là do tác giả phịa ra. Phải nói ngay
là trong tất cả các bài viết của tác giả, quan điểm của tác giả
là yếu tố chủ quan, có thể đúng, có thể sai, nhưng những dữ kiện
tác giả nêu ra đều là dữ kiện từ truyền thông Mỹ, có thể dễ dàng
truy cập trong Google. Tin bảo phí tăng 260% cho vài thành phần là từ
tạp chí Forbes đăng dựa trên nghiên cứu của hai tổ chức American Action
Forum và Manhattan Institute. Forbes là tạp chí kinh tế tài chánh lớn
và có uy tín nhất, ngang hàng với Bloomberg. Đây có lẽ là trường hợp
tệ nhất, nhưng tùy tiểu bang, bảo phí sẽ tăng trung bình từ 30% đến
80%.<br/><br/><a href="http://www.forbes.com/sites/theapothecary/2013/10/03/enrollment-in-obamacares-federal-exchange-so-far-is-in-the-single-digits/" target="_blank"><i>http://www.forbes.com/sites/theapothecary/2013/10/03/enrollment-in-obamacares-federal-exchange-so-far-is-in-the-single-digits/</i></a><br/><br/>Nhiều độc giả chỉ trích kẻ viết này “nói láo vô lý”, “không hiểu
gì về Hiến Pháp Mỹ” khi viết Obamacare đã được thông qua bằng “cửa
sau”. Có thể rất nhiều người không biết hay đã “quên” cách Obamacare
được quốc hội thông qua, xin nhắc lại.<br/><br/>Trên nguyên tắc, bất cứ dự luật nào cũng phải được Thượng Viện thông
qua với 60 phiếu để vượt qua thủ tục câu giờ filibuster mà đối lập
sẽ sử dụng để chống, và Hạ Viện thông qua với 51%, hai bản thảo
được phối hợp lại thành một nếu có khác biệt, rồi bỏ phiếu lại
tại cả hai viện. Obamacare được Thượng Viện thông qua với đúng 60
phiếu (60-39), rồi Hạ viện cũng thông qua khít nút (220-215), nhưng với
nhiều khác biệt, cho dù cả hai viện đều do Dân Chủ kiểm soát. Bản
thảo do Hạ Viện thông qua phải được đưa lại cho Thượng Viện điều
chỉnh và biểu quyết lại. Nhưng trong thời gian đó, một biến cố thay
đổi hoàn toàn tình hình. TNS Ted Kennedy qua đời, tiểu bang
Massachusetts phải bầu người thay thế. Một dân biểu tiểu bang ra tranh
cử bên Cộng Hòa và đưa ra lý do tranh cử duy nhất: “tôi sẽ là lá phiếu
để ngăn chận Obamacare”, và ông này đã thắng tại tiểu bang cấp tiến
nhất, trong ngỡ ngàng của cả TT Obama. Đảng Dân Chủ với TNS Kennedy có
đúng 60 ghế, là con số cần thiết để vượt qua chống đối của Cộng
Hòa. Với tân thượng nghị sĩ Cộng Hoà, Dân Chủ chỉ còn 59 phiếu,
Obamacare không qua được Thượng Viện và sẽ không thành luật được.<br/><br/>TT Obama và khối Dân Chủ đa số tại Thượng Viện bèn cho biểu quyết
xếp loại Obamacare lại là một luật phụ của ngân sách, và trong tư
thế đó, chỉ cần 51 phiếu là có thể thông qua được, mà Cộng Hòa
không thể dùng thủ tục filibuster để chống được. Nhờ sự xếp loại
đó, Obamacare được Thượng Viện thông qua bằng thủ tục gọi là “budget reconciliation”,
dịch nôm na là “điều chỉnh ngân sách”. Tất cả quan sát viên chính trị
đều nhìn nhận đây là một mánh khoé, lợi dụng kẽ hở thủ tục Thượng
Viện. Obamacare là một dự luật đổi đời, chứ không phải là một luật phụ,
cũng chẳng liên hệ gì đến ngân sách. Báo Mỹ gọi là thông qua bằng
“backdoor”, kẻ viết này gọi là “cửa sau”. Thủ tục quốc hội My cực
kỳ phức tạp, khó hiểu, có tra cứu Google thì chỉ rối bù thêm. Kẻ
viết này chỉ giới thiệu một bài viết tương đối giản dị dưới đây để
quý độc giả tham khảo:<br/><br/><a href="http://www.medscape.com/viewarticle/718388" target="_blank"><i>http://www.medscape.com/viewarticle/718388</i></a><br/><br/>Dù sao thì Obamacare cũng là bộ luật duy nhất trong lịch sử Mỹ được
biểu quyết với đúng một phiếu của đối lập tại cả hai viện. Lá
phiếu Cộng Hoà duy nhất ủng hộ là của ông Joseph Cao, dân biểu duy
nhất gốc Việt, sau khi ông điện đàm với TT Obama. Sau đó, khi ông Cao ra
tranh cử lại, TT Obama công khai ủng hộ ứng viên Dân Chủ da đen, khiến
ông Cao thất cử, là dân biểu đúng một nhiệm kỳ hai năm. Ông Cao tố
cáo TT Obama “phản bội”.<br/><br/>Có độc giả chỉ trích kẻ viết này “không nói đúng sự thật” khi cho
rằng có từ 55% đến gần 60% dân Mỹ chống Obamacare.<br/><br/>Thăm dò của Gallup ngày 22/8/2013 cho thấy tỷ lệ ủng hộ/chống
Obamacare là 42%-55%
(<a href="http://hotair.com/archives/2013/08/22/gallup-only-41-approve-of-obamacare/" target="_blank"><i>http://hotair.com/archives/2013/08/22/gallup-only-41-approve-of-obamacare/</i></a>).<br/><br/>Theo thăm dò của CNN: tháng 9/2013, tỷ lệ đó là 38%-57%; tháng 3/2011:
37%-59% (<a href="http://i2.cdn.turner.com/cnn/2013/images/10/21/rel12a.pdf" target="_blank"><i>http://i2.cdn.turner.com/cnn/2013/images/10/21/rel12a.pdf</i></a>)<br/><br/>Tóm lại, kẻ viết này hoàn toàn hoan nghênh hai mục tiêu mà TT Obama
đề ra trong luật cải tổ y tế. Điều mà tôi không ủng hộ là:<br/><br/>1. Tất cả đều có cái giá phải trả. TT Obama đáng lẽ ra đã phải nói
sự thật cho dân và có đủ can đảm để giải thích cho dân là muốn đạt
mục tiêu cao đẹp đó thì mọi người sẽ phải trả một giá rất đắt.
Trong khi đó, ông lại khăng khăng hứa hẹn chi phí y tế sẽ giảm, mọi
người đều có thể giữ bảo hiểm và bác sĩ cũ của mình, không ai bị
mất bảo hiểm, không có gì thay đổi. Thực tế là cả triệu người sẽ
mất bảo hiểm, hay phải đổi bảo hiểm, đổi bác sĩ, tiền bảo phí sẽ
tăng, tiền trả trước sẽ tăng,... Theo tạp chí Forbes, ngay từ năm 2010,
chính quyền Obama đã ước tính có thể có tới 93 triệu người rơi vào
những trường hợp mất hay thay bảo hiểm này, trong khi TT Obama vẫn quả
quyết không ai bị mất bảo hiểm hay phải trả thêm tiền. “TT Obama đáng
lẽ ra không nên nói láo”, đó là quan điểm của Bill Maher, một bình
luận gia truyền hình phe ta, cấp tiến nặng.<br/><br/>2. Những thay đổi quá lớn qua cải tổ cần phải được áp dụng qua một
thời gian dài, chẳng hạn 10 năm, cho nước Mỹ có thời gian thu nhận
thêm ba chục triệu người vào hệ thống y tế, có thời giờ để mở thêm
nhà thương, huấn luyện thêm bác sĩ, chế thêm thuốc. Vấn đề là TT
Obama muốn làm cho gấp rút để cải cách được thực hiện trọn vẹn
trong hai nhiệm kỳ của ông. Kết quả bây giờ Obamacare cực kỳ luộm
thuộm, đầy trục trặc kỹ thuật, trong khi chi phí tăng một sáng một
chiều quá cao.<br/><br/>3. Bất chấp bối cảnh kinh tế cũng là một sai lầm cực lớn. Nước Mỹ
đang còn trong giai đọan kinh tế hết sức yếu ớt, với thâm thủng ngân
sách thật lớn, công nợ ngút ngàn, thất nghiệp tràn lan. Cải cách y
tế của TT Obama sẽ trầm trọng hoá tất cả những vấn đề này. Lúc
này không phải là lúc thực hiện cải tổ y tế rất tốn kém này.<br/><br/>Obamacare là điều tốt, cần làm, nhưng cách làm hoàn toàn sai trật đưa
đến nhiều nguy hại lớn trong tương lai, khiến y tế Mỹ sẽ đắt hơn mà
phẩm chất lại xuống cấp nhiều. Đảng Cộng Hoà sai lầm khi khăng khăng
chống phá Obamacare. Cứ để Obamacare được áp dụng, người dân sẽ thấy
những tai hại và tự nó sẽ phải... “đóng cửa tiệm”. (3-11-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
<a href="http://mce_host/siteadmin/D_CatID-3_Table-NewsArticle_LanguageID-2_SiteID-2/vulinh11@gmail.com" target="_blank"><i>Vulinh11@gmail.com</i></a>. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a212653/chuyen-dai-obamacare-noi-cho-ro

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/