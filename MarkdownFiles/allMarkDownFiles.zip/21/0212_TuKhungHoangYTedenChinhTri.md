# Từ Khủng Hoảng Y Tế đến Chính Trị

19/11/2013

...ObamaCare đã trở thành liều thuốc hồi sinh cho đảng Cộng Hoà...<br/><br/>Sau cả tháng trời chống đỡ, bào chữa, giảng giải, vặn vẹo, trước
làn sóng bất mãn tràn lan, TT Obama cuối cùng cũng đã ra trước
truyền thông chính thức nhận trách nhiệm về cuộc khủng hoảng
Obamacare.<br/><br/>Khủng hoảng Obamacare đã trở thành một khủng hoảng chính trị nghiêm
trọng nhất cho TT Obama. Ai cũng biết nhiệm kỳ hai của ông đã là một
chuỗi dài khủng hoảng, từ đại sữ Mỹ bị khủng bố giết tại Benghazi
đến sở thuế IRS chơi xấu các tổ chức bảo thủ, từ Bộ Tư Pháp theo
dõi nhà báo trái phép đến NSA nghe lén cả triệu người, từ anh
Snowden mang hàng trăm ngàn tài liệu an ninh mật đưa cho Trung Cộng và
Nga để xin tỵ nạn đến TT Pháp và Thủ Tướng Đức đòi hỏi Mỹ chấm
dứt nghe lén điện thoại riêng của họ, từ Syria coi lằn ranh đỏ như pha
đến Iran không thèm nói chuyện với TT Obama, từ ông lãnh tụ Kim Chi
ruồi bu dọa bắn hoả tiễn vào Mỹ đến Nhà Nước đóng cửa tiệm, v.v...
Chưa kể những xì-căng-đan của cấp dưới như hai đô đốc bị ngưng chức
vì nghi ngờ ăn hối lộ, tất cả khối nhân viên cận vệ tổng thống (Secret
Services) bị điều tra vì đi đâu cũng lo thăm các xóm Bình Khang, tổng
cộng tại 17 nước mà TT Obama đã viếng thăm. Tất cả trong vòng vỏn
vẹn 9 tháng từ đầu năm nay đến giờ. Nhưng chưa có khủng hoảng nào
đạt tầm mức nguy hại của Obamacare.<br/><br/>Trong văn hoá Á Đông, khi đất nước chìm đắm trong khủng hoảng, hoạn
nạn, chinh chiến, tai ương, đó chính là lúc hoàng đế mất thiên mệnh,
vận nước thay đổi. Ngày nay, tuy không ai dám tiên đoán TT Obama sẽ theo
chân TT Nixon, nhưng những tai họa chồng chất mà ông để lại cho đảng
Dân Chủ sẽ đưa đảng vào những khó khăn khổng lồ trong các cuộc bầu
cử những năm tới. Giác mộng về một thiên niên kỷ cấp tiến lung lay
tận gốc rễ.<br/><br/>Thứ năm tuần rồi, một ngày trước khi Hạ Viện biểu quyết về vấn đề
Obamacare, TT Obama họp báo nhận lỗi, tự nhận mình “không hoàn hảo”,
“đã và sẽ làm sai lầm”. Ông nhận trách nhiệm với các đồng chí Dân
Chủ, nhìn nhận đã đặt họ vào tình huống hết sức khó khăn. Ông cũng
công bố biện pháp điều chỉnh Obamacare.<br/><br/>Ta hãy xét lại lời trần tình đó.<br/><br/>Trước hết, công bằng mà nói, việc vị lãnh đạo tối cao công khai nhận
trách nhiệm, nhận đã làm sai, là điều đáng hoan nghênh. Hơn xa cái “I
am sorry” của mấy ngày trước đây. Đó chính là biểu tượng của một
chế độ dân chủ, tôn trọng dân hơn là lo bảo vệ uy thế của đảng và
ghế ngồi cá nhân mà ta thấy trong cái xứ “đỉnh cao trí tuệ loài
người theo định hướng giời ơi đất hỡi”. Nhất định đáng phục hơn là
vỗ ngực tự xưng mình là Đấng Tiên Tri có phép màu “hạ thủy triều”.<br/><br/>Trong vấn đề này, TT Obama trước đây đã lên truyền hình tỏ ý “hối
tiếc”. Một nhà báo đã lưu ý TT Obama chỉ “hối tiếc (sorry), chứ không
phải “xin lỗi” (apology) như truyền thông phe ta đã loan tin. Chỉ “hối
tiếc” suông. Sau khi đã tìm cách mập mờ vặn vẹo giải thích câu nói
của mình theo kiểu Clinton chạy tội trong vụ cô Monica.<br/><br/>Một lý do quan trọng cho việc nhận trách nhiệm là làn sóng bất mãn
từ trong nội bộ đảng Dân Chủ. Trong mấy ngày trước đó, TT Obama đã
nhận không biết bao nhiêu than phiền, khiếu nại từ các vị dân cử Dân
Chủ, công khai cũng như kín đáo hơn trong hậu trường. Hiển nhiên,
Obamacare đã và sẽ là một sao quả tạ lớn cho đảng Dân Chủ. Nhất là
cho cuộc bầu giữa mùa cuối năm tới.<br/><br/>Hàng triệu người bị mất bảo hiểm sẽ không còn là cử tri trung kiên
của đảng Dân Chủ nữa. Chỉ một tiểu bang Cali cho đến nay đã có một
triệu người mất bảo hiểm, đó là con số chính thức đưa ra bởi ông
Dave Jones, Ủy Viên Bảo Hiểm –Insurance Commissioner- của tiểu bang. Báo
chí đã đăng không thiếu gì những mẫu chuyện về rất nhiều người
trước đây ủng hộ mạnh Obamacare bây giờ đã vỡ mộng khi thấy bảo hiểm
sức khoẻ của mình bị mất, hay bị tăng bảo phí quá cao. Đó là những
thực tế mà họ chưa từng nghĩ đến vì tin tưởng vào lời cam kết của
TT Obama là sẽ không có gì thay đổi.<br/><br/>Theo thăm dò của đại học Quinnipiac, lần đầu tiên, đa số (52%) cho rằng
TT Obama không lương thiện và không đáng tin (not honest and trustworthy).
Tất cả những gì khối bảo thủ chỉ trích về Obamacare trong khi TT
Obama cải chính, đã thành sự thật. Làm sao dân Mỹ không xét lại lòng
thành của TT Obama được?<br/><br/>Đáng ghi nhận nữa là thăm dò của cơ quan YouGov cho thấy trong vấn đề
Obamacare, 19% dân Mỹ tin vào đài FoxNews, 11% tin vào TT Obama, và 2% tin
vào các đài NBC, CBS. Như vậy, hóa ra dân Mỹ tin vào FoxNews nhiều hơn
tin vào vị quốc trưởng? Các đài truyền hình khác thì... thôi quên đi!
Khủng hoảng Obamacare đã trở thành khủng hoảng niềm tin vĩ đại.<br/><br/>Điều mang nhiều ý nghiã là mới đây, cựu TT Clinton đã lên tiếng kêu
gọi TT Obama tôn trọng lời cam kết (honor the commitment) để mọi người
đều có thể giữ chương trình y tế mình đang có, cho dù có phải sửa
luật Obamacare thì cũng phải làm. Kẻ viết này không nghĩ TT Clinton
muốn đẩy TT Obama vào chân tường, mà thật ra chỉ có thâm ý muốn giúp
tách xa bà Hillary khỏi quả bom Obamacare, càng xa càng tốt, dọn đường
cho bà ra tranh cử tổng thống. Nhắc nhở mọi người là bà Hillary không
liên hệ xa gần gì đến lời cam kết long trọng đó của TT Obama.<br/><br/>Lời kêu gọi của TT Clinton đi kèm với đòi hỏi TT Obama phải có giải
pháp gấp hay hoãn Obamacare lại của hàng loạt dân cử Dân Chủ. Năm
thượng nghị sĩ Dân Chủ cầm đầu bởi bà Mary Landrieu của Louisiana,
đang thảo dự luật tu chính lại Obamacare. Ít ra là 10 nghị sĩ Dân Chủ
đòi tu chính hoãn việc bắt buộc cá nhân phải có bảo hiểm cũng như
hoãn việc phạt lại một năm. TNS Mitch McConnell, lãnh tụ khối Cộng
Hòa, đã công bố danh sách 27 nghị sĩ Dân Chủ đã từng lập lại nguyên
văn câu nói bất hủ của TT Obama “bạn có thể giữ chương trình y tế cũ
nếu bạn thích”. TT Obama đã xin lỗi, còn những vị này thì đang lo...
tháo chạy, đòi sửa luật. Obamacare cứ tiếp tục tu chính, sửa điều
này, hủy điều kia, hoãn điều nọ thì còn lại gì? Một bộ luật luộm
thuộm chưa từng thấy trong lịch sử, với gần 3.000 trang luật và hơn
10.000 trang phụ đính.<br/><br/>Tại Hạ Viện, ngày Thứ Sáu vừa qua, 39 dân biểu Dân Chủ (20% khối Dân
Chủ Hạ Viện) đã biểu quyết cùng với khối Cộng Hòa một dự luật cho
các hãng bảo hiểm miễn phải tuân thủ những đòi hỏi mới của
Obamacare. Một phần năm các dân biểu Dân Chủ đang bấn loạn, lo sợ cho
tương lai của chính họ. Nhà báo cấp tiến Paul Waldman đã phải lên
tiếng trấn an họ, khẳng định “trời chưa xập mà” (the sky is not fallen
yet). Báo phe ta Washington Post nhận định khối nghị sĩ và dân biểu Dân
Chủ này rất có thể xé rào, nhẩy qua bên Cộng Hoà để biểu quyết thu
hồi Obamacare.<br/><br/>Cụ thể hơn hết là cuộc bầu thống đốc tại Virgiania tuần qua.<br/><br/>Lần Virginia bầu thống đốc này, bên Dân Chủ đưa ra ông Terry McAuliffe,
và bên Cộng Hòa đưa ra ông Ken Cuccinelli.<br/><br/>Ông McAuliffe là một chính khách cột trụ của đảng Dân Chủ, từng là
phụ tá quan trọng của TT Clinton, Chủ Tịch Ủy Ban Quốc Gia của đảng
Dân Chủ dưới thời TT Bush II, và Chủ Tịch Ủy Ban Tranh Cử của bà
Hillary Clinton năm 2008. Ông Cuccinelli là bộ trưởng Tư Pháp của tiểu
bang Virginia. So sánh hai người thì hiển nhiên, ông McAuliffe là nhân
vật có tầm vóc quốc gia lớn trong khi ông Cuccinelli là một ông quan
toà địa phương, tương đối ít người biết ngoài Virginia.<br/><br/>Thăm dò dư luận nói chung, ông McAuliffe dẫn đầu với tỷ lệ hậu thuẫn
hơn ông Cuccinelli trung bình 10%-12%. Coi như chắc thắng rồi. Nhưng đầu
tháng Mười là lúc cuộc khủng hoảng Obamacare nổ bùng. Obamacare trở
thành đề tài tranh cử lớn nhất. Và vị thế của ông McAuliffe lung lay
mạnh. Một tuần trước ngày bầu cử, hậu thuẫn của ông rớt xuống, còn
hơn ông Cuccinelli có 2,5%, nghiã là nằm trong sai biệt xác xuất, tức
là hai bên ngang ngửa.<br/><br/>Phe Dân Chủ hoảng hốt trước kinh nghiệm của Massachusetts sau khi TNS Ted
Kennedy qua đời và một ứng viên Cộng Hoà vô danh ra tranh cử chống
Obamacare và đại thắng giờ chót. Ông McAuliffe với sự yểm trợ tài
chánh của đảng Dân Chủ, cho tràn ngập quảng cáo trên truyền hình, chi
tiền quảng cáo gấp ba lần ông Cuccinelli trong tuần cuối. Các đại bác
lớn nhất của đảng được tung vào mặt trận. Bà Hillary là người đầu
tiên nhẩy vào tích cực vận động cho ông McAuliffe, rồi đến PTT Biden,
và cuối cùng là đích thân TT Obama. Cả ba đều đến Virginia hô hào vận
động cho ông McAuliffe.<br/><br/>Kết quả cuộc tranh cử, ông McAuliffe vẫn thắng, nhưng với tỷ lệ
48%-46%, hơn có 2%, ít hơn thăm dò cuối cùng. Bài học cụ thể: nếu
không có Obamacare thì ông McAuliffe đã thắng lớn rồi, và nếu không có
hậu thuẫn mạnh mẽ giờ chót của ba nhân vật nặng ký nhất trong đảng
Dân Chủ, thì ông McAuliffe đã thua to vì Obamacare rồi.<br/><br/>Cách đây không lâu, sau cuộc tranh cãi về ngân sách và Obamacare khiến
Nhà Nước phải đóng cửa tiệm mấy tuần, truyền thông dòng chính tưng
bừng ca khúc khải hoàn và gửi cáo phó của đảng Cộng Hoà đi khắp
nơi. Nhưng rồi đám tang của Cộng Hòa kéo dài chưa bao lâu thì xẩy ra
cuộc khủng hoảng Obamacare. Và Obamacare đã trở thành liều thuốc hồi
sinh cho đảng Cộng Hoà, đồng thời cũng là viên thuốc độc bọc đường
cho đảng Dân Chủ. Thông điệp của Virginia quá rõ ràng đối với các vị
dân cử Dân Chủ, bắt buộc TT Obama “phải làm một cái gì”.<br/><br/>Và TT Obama ra quyết định sẽ không bắt các hãng bảo hiểm phải tuân
thủ theo các quy định mới của Obamacare trong vòng một năm. Có nghiã
là những đòi hòi trong bảo hiểm mới sẽ không còn nữa, như bảo hiểm
bệnh thần kinh (có lẽ rất cần dưới thời Obama?), bảo hiểm ngừa thai
cho các cụ bà, bảo hiểm sanh đẻ cho các ông (những đòi hỏi này nghe
vô lý nhưng thực ra rất... có lý vì giúp san sẻ gánh nặng tài
chánh, đại khái các ông sẽ phải đóng góp tiền sanh đẻ của mấy bà
welfare queens ngồi nhà vui vẻ sản xuất dài dài),... Sẽ giúp cho các
hãng bảo hiểm duy trì các hợp đồng bảo hiểm hiện hành, không phải
hủy bỏ, thay thế bằng hợp đồng mới khắt khe hơn và đắt tiền hơn.<br/><br/>Ở đây, có vài vấn đề lớn.<br/><br/>TT Obama cho phép các hãng bảo hiểm không tuân thủ những điều kiện
mới không có nghiã là cấm họ tuân thủ, tức là nếu muốn, họ vẫn
tuân thủ, vẫn hủy hợp đồng cũ, và vẫn tăng giá bảo hiểm, vẫn bắt
thiên hạ đổi bác sĩ, nhà thương được. Nhà Nước cũng sẽ không ngăn
cản hay truy tố họ. TT Obama cũng không đề cập đến các hợp đồng đã
bị hủy bỏ. Các hãng bảo hiểm có cần phải rút lại quyết định hủy
bỏ không? Hay đã hủy rồi thì hủy luôn? Tùy hỷ họ làm gì có lợi cho
họ thì họ làm? Ai dám bảo đảm các hãng bảo hiểm sẽ không lợi dụng
cơ hội áp đặt hợp đồng mới đắt tiền hơn lên các khách hàng của họ?
Như vậy, ta phải chờ xem các hãng bảo hiểm tính toán gì và làm gì.
Đi xa hơn nữa, sau một năm thì sao? Tình trạng hiện nay lại tái diễn?
Tức là đá banh ra biên, câu giờ để rồi một năm sau, ta lại gặp lại
ông Vũ Như Cẩn?<br/><br/>Trong thời gian đó, những người không kịp hay không muốn ghi danh có bị
phạt không? Không nghe TT Obama nói gì về việc bắt đầu phạt từ đầu
năm tới. Nếu các hãng bảo hiểm vẫn hủy hợp đồng hiện hữu và chỉ
bán bảo hiểm theo điều kiện mới đắt hơn, người dân sẽ có lựa chọn
nào khác không? Hay là đành phải mua bảo hiểm mới với cao giá hơn,
nếu không mua sẽ bị phạt từ đầu năm tới sao?<br/><br/>Điều chắc chắn là việc thiên hạ ghi danh vào Obamacare sẽ dậm chân
tại chỗ ngay. Tâm lý bình thường, nhiều người sẽ trì hoãn việc mua
bảo hiểm chờ xem chuyện gì sẽ xẩy ra, biết đâu trong vòng năm tới sẽ
lại có thay đổi nữa? Trong khi bà dân biểu Nancy Pelosi huyênh hoang khoe
có 500.000 người đã mua bảo hiểm qua các trung tâm điều hợp, tin chính
thức do Nhà Nước công bố, trong nguyên một tháng đầu của Obamacare,
chỉ có 106.000 người ghi danh. Theo đà này thì muốn cho 300 triệu dân
Mỹ có bảo hiểm sức khoẻ hết thì sẽ cần đợi tới... 300 năm.<br/><br/>Vấn đề thứ hai là thực sự TT Obama có quyền cho các hãng bảo hiểm
miễn chấp hành Obamacare mà không cần thông qua quốc hội hay không?
Obamacare đã là bộ luật được quốc hội biểu quyết và tổng thống ký
để thành luật chính thức. TT Obama lấy quyền gì cho phép không áp
dụng luật trong một năm? Ngay cả ông Howard Dean, cựu Chủ Tịch đảng Dân
Chủ, và cựu ứng viên tổng thống năm 2004, cũng đã lên truyền hình rào
đón đặt câu hỏi không biết TT Obama có quyền áp dụng luật lệ tùy hỷ
hay không. Nếu nói tổng thống có quyền muốn làm gì thì làm, kể cả
hoãn áp dụng bất cứ luật nào ông muốn, thì có phải đại cường Cờ
Hoa đã không khác gì một nước nhược tiểu khi quân đội đảo chánh, cất
mọi luật lệ và Hiến Pháp vào kho một thời gian không? TT Obama gọi
quyết định của ông là sửa đổi hành chánh (administrative fix), không
phải là thay đổi luật. Kẻ viết này không phải luật gia để thẩm định
cách diễn giải này.<br/><br/>Thật ra, biện pháp TT Obama đề nghị chỉ là một chiêu hoãn binh để xoa
dịu chống đối và giúp các ông đồng chí Dân Chủ thoát qua cửa ải
bầu cử tháng Mười Một năm 2014 thôi. Không phải tình cờ mà ông đã
chọn một năm, để luật Obamacare sẽ phải được áp dụng trọn vẹn vào
tháng Giêng năm 2015, sau cuộc bầu giữa mùa năm tới. Tuyệt đối nó
không có thay đổi gì đối với luật Obamacare. Tất cả mọi điểu khoản
đều không có gì thay đổi. Có nghiã là những lý do căn bẳn chống đối
Obamacare, hay đúng hơn những hậu quả tai hại của Obamacare, vẫn còn
đó. Chi phí y tế của tất cả sẽ gia tăng, và sau này, lấy hẹn bác sĩ
và nhà thương sẽ vẫn trần ai, nhất là cho những người có
Medicaid–MediCal ở Cali- khi một mặt các bác sĩ rút ra khỏi chương
trình Medicaid hàng loạt, trong khi lại có thêm cả triệu người được
vào Medicaid qua việc mở rộng tiêu chuẩn Medicaid.<br/><br/>Ngay sau khi TT Obama công bố quyết định, phản ứng của khối Cộng Hoà
đã không làm ai ngạc nhiên. Họ cho rằng quyết định của TT Obama chẳng
hề đụng đến căn gốc của vấn đề vì tất cả vẫn đều còn đó, không có
gì thay đổi. Đến ngay cả khối Dân Chủ cũng đã có phản ứng tương tự.
Bà Mary Landrieu tuyên bố không có gì thay đổi cả, khối Dân Chủ trong
Thượng Viện sẽ tiếp tục thảo tu chính cho Obamacare như thường.<br/><br/>Một phát ngôn của ngành bảo hiểm đã than phiền Obamacare có tác động
rất lớn đến đời sống người dân, chẳng những phức tạp, nhiêu khê, mà
lại thay đổi tới lui, làm như trò đuà vì những người làm luật không
biết mình đang làm gì, đang muốn gì, cuối cùng sẽ chỉ gây rối loạn
hơn, khiến các hãng bảo hiểm rối trí không biệt phải làm gì và
được phép làm gì, và chi phí sẽ tăng cao hơn thôi. Và tất cả mọi
người, từ bệnh nhân đến bác sĩ đến hãng bảo hiểm đều sẽ là nạn
nhân hết. Chính sách thi hành Obamacare chỉ là một chính sách vá
víu, bít đầu này, lấp đầu kia, không có đường hướng rõ rệt gì cả.
(17-11-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a213288/tu-khung-hoang-y-te-den-chinh-tri

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/