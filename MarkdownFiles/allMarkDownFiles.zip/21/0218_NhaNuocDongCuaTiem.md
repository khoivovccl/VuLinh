# Nhà Nước Đóng Cửa Tiệm

08/10/2013

...chính sách tài chính của chính quyền Obama: sống bằng nợ, chết
qua nợ...<br/><br/>Kể từ ngày 1 Tháng 10, Nhà Nước liên bang Mỹ bắt đầu chính thức
“đóng cửa tiệm”. Báo Mỹ gọi là “shut down”. Trên nguyên tắc, Nhà Nước
không có ngân sách vì quốc hội cãi nhau, không thoả thuận được một
ngân sách cho tài khoá 2014, chính thức bắt đầu ngày 1 tháng 10 năm
2013, tức là không có tiền để guồng máy hành chánh tiếp tục chạy.
Chỉ những bộ phận thiết yếu tiếp tục hoạt động vì được tài trợ
bởi những qũy riêng, như các quỹ Medicare, Medicaid, tiền già social
security, hay quỹ dự phòng như tiền lương quân nhân, và công chức thiết
yếu. Cũng nên ghi nhận các chính quyền tiểu bang và địa phương không
bị ảnh hưởng gì và vẫn hoạt động bình thường<br/><br/>Tại sao Nhà Nước liên bang phải đóng cửa tiệm?<br/><br/>Theo luật, mỗi tài khoá đều phải có ngân sách do cả Thượng Viện lẫn
Hạ Viện thông qua. Không có thỏa thuận, không có ngân sách, Nhà Nước
không được tiêu tiền, và phải ngưng hoạt động. Đó là vấn đề căn gốc.<br/><br/>Dân Chủ theo chỉ đạo của TT Obama đã đưa ra đề nghị ngân sách mà phe
Cộng Hòa cho rằng không thể chấp nhận được vì vẫn chi tiêu quá nhiều
trong khi đòi hỏi tăng thuế quá cao, sẽ khiến các nhà đầu tư không
đầu tư, kinh tế tiếp tục không ngóc đầu lên được, thất nghiệp không
giảm được, thâm thủng ngân sách ngày một lớn, và công nợ ngày một
chồng chất.<br/><br/>Cộng Hoà cũng cực lực phản đối luật cải tổ y tế Obamacare, sẽ được
áp dụng toàn diện bắt đầu từ đầu năm tới. Lý do Cộng Hòa chống
Obamacare cũng là lý do tại sao gần 60% dân Mỹ cũng chống. Obamacare
chỉ có lợi cho một thiểu số những người chưa có bảo hiểm hay không
được các hãng bảo hiểm chấp nhận vì đã có bệnh từ trước, nhưng sẽ
đưa đến hậu quả là chi phí cho toàn thể hệ thống y tế Mỹ gia tăng,
trong đó có tiền bảo hiểm cũng như tiền nhà thương, bác sĩ, thuốc
men. Rồi Obamacare cũng sẽ tốn cả chục ngàn tỷ cho Nhà Nước. Số
tiền đó chỉ trầm trọng hoá tất cả những khó khăn tài chánh đã có.
Vấn đề cơ bản là luật Obamacare bị khối bảo thủ chẳng những chống
mà còn coi như không chính danh vì được thông qua lén lút qua kẽ hở
thủ tục quốc hội, không có gì đáng gọi là danh chính ngôn thuận.<br/><br/>Có một lý do mới nữa đã khiến Cộng Hoà chống Obamacare và đề nghị
hoãn thi hành Obamacare một năm: Obamacare chưa sẵn sàng.<br/><br/>Bài toán chính trị của Cộng Hoà là biểu quyết ngân sách và tăng
mức nợ trần là những điều tối cần thiết cho Nhà Nước Obama, do đó,
Cộng Hoà sẽ nhân nhượng phần nào, đổi lấy một nhân nhượng của Dân
Chủ về Obamacare. Đại cương, Cộng Hoà chấp nhận phê duyệt một ngân
sách tạm để Nhà Nước hoạt động đến cuối năm nay, và cũng sẽ chấp
nhận tăng mức nợ trần, với vài điều kiện quan trọng như thắng chi
tiêu Nhà Nước lại. Đổi lại, Obamacare sẽ phải được hoãn một năm, chỉ
bắt đầu áp dụng đầu năm 2015. Hạ Viện do đa số Cộng Hoà kiểm soát
đã biểu quyết một dự luật trong đó bao gồm cả ba điều trên. Cuộc
biểu quyết hầu như hoàn toàn đúng theo số ghế của hai đảng, với
khoảng gần một chục dân biểu Dân Chủ bỏ phiếu hoãn Obamacare với phe
Cộng Hòa, và khoảng gần một chục dân biểu Cộng Hòa bỏ phiếu theo
Dân Chủ chống việc hoãn Obamacare. Coi như không ảnh hưởng đến thế đa
số của Cộng Hòa.<br/><br/>Dự luật này khi lên đến Thượng Viện do đa số Dân Chủ kiểm soát đã
bị bác bỏ, vì Dân Chủ không chấp nhận hoãn Obamacare, dù một ngày.
Số phiếu ở Thượng Viện theo đúng số ghế của hai đảng: 54 Dân Chủ
bác và 46 Cộng Hoà thuận. Sau khi bị bác, Cộng Hoà ở Hạ Viện tu
chính chút đỉnh rồi biểu quyết chấp nhận lại, rồi đưa qua Thượng
Viện, để rồi Thượng Viện lại biểu quyết bác bỏ. Hai bên vờn nhau
bốn lần trong một ngày 30 tháng 9. Hạ Viện biểu quyết 4 lần, Thượng
Viện bác đủ 4 lần. Cho dù được Thượng Viện chấp nhận, thì TT Obama
cũng đã dọa sẽ phủ quyết.<br/><br/>Bế tắc đó đưa đến không có thoả thuận ngân sách và Nhà Nước... đóng
cửa tiệm.<br/><br/>Hậu quả của việc đóng cửa tiệm sẽ như thế nào?<br/><br/>Trên thực tế, Nhà Nước chưa đóng cửa hoàn toàn mà chỉ là “khép
cửa” thôi. Tất cả các cơ quan, công sở đều cho đa số nhân viên tạm
nghỉ việc không ăn lương, nằm nhà chờ lệnh. Nhưng không có cơ quan hay
công sở nào đóng cửa 100%. Chẳng hạn trong Tòa Bạch Ốc, khoảng 1.200
nhân viên, phần lớn là thư ký, tài xế,... được cho nghỉ tạm, trong khi
gần 500 nhân viên vẫn tiếp tục đi làm, có lương đầy đủ, kể cả...
những “sa hoàng” cố vấn và phụ tá cao cấp nhất, với lương cao nhất.
Chúng ta có thể yên tâm, tổng thống và phó tổng thống vẫn đi làm có
lương đầy đủ, chưa đến nỗi phải nghỉ việc, và cả năm ông đầu bếp
đều vẫn còn bận với những bữa ăn đầy đủ cao lương mỹ vị tuy chưa có
tới cả trăm món như bữa ăn của bà Từ Hy Thái Hậu. Ngoại Trưởng John
Kerry vẫn đi Nhật và Hàn Quốc như thường. Nhưng TT Obama sẽ hủy chuyến
công du Á Châu tham dự hội nghị APEC với các quốc gia ven Thái Bình
Dương. Có lý do chính đáng để hủy một chuyến công du mà Tòa Bạch Ốc
biết trước sẽ không có kết quả cụ thể nào, cũng như tránh được
đụng độ với Tập Cận Bình trong vụ lưỡi bò biển đông, lại được
tiếng ở nhà lo cho đại sự.<br/><br/>Tất cả các dân biểu, nghị sĩ cãi nhau đưa đến chuyện Nhà Nước đóng
cửa tiệm cũng đều vẫn được lãnh lương và bổng lộc đầy đủ không
thiếu xu nào để tiếp tục cãi nhau, tuy một số phụ tá, thư ký, tài
xế, tạp dịch, nhân viên phòng tập thể dục, phòng hớt tóc làm đầu,
phòng vệ sinh, … sẽ phải tạm nghỉ. Nói cách khác, chỉ có các quan
quân hạng bét và hạng vừa bị nghỉ việc, tạm mất lương, trong khi các
quan to là những vị đã tạo ra cảnh đóng cửa tiệm đều vẫn lương lậu
và bổng lộc đầy đủ. Chả trách họ không chịu thoả thuận để đến nỗi
Nhà Nước phải đóng cửa. Nói theo dân gian ta, họ là những người
“không thấy quan tài nên không đổ lệ”.<br/><br/>Tất cả các quân nhân đều vẫn còn trong quân ngũ, không ai bị giải ngũ
hết, tuy một số lớn quan chức văn phòng cấp trung và cấp thấp sẽ
được nằm nhà hay được phép đi câu cá chờ lệnh trình diện lại. Tất
cả nhân viên Cơ Quan An Ninh Quốc Gia NSA vẫn tiếp tục theo dõi i-meo và
điện thoại cả thế giới để bảo đảm an toàn cho chúng ta. Các viên
chức tại các cơ quan có tính an ninh chung sẽ không bị nghỉ việc, như
chuyên viên kiểm không tại phi trường, hải quan, cảnh sát biên giới,
FBI, … Chỉ có gần 400 công viên quốc gia là đóng cửa hoàn toàn thôi.<br/><br/>Dù sao thì những sinh hoạt hành chánh như xin thông hành, chiếu khán,
giấy tờ lặt vặt, bưu điện, tiểu thương hay sinh viên muốn mượn tiền
có Nhà Nước bảo đảm,… đều sẽ chậm lại, mất nhiều thời gian hơn.<br/><br/>Tổng cộng, có thể từ 30% đến 40% công chức liên bang, tức là gần một
triệu người, sẽ phải tạm nghỉ. Đóng cửa càng lâu thì càng nhiều
người phải tạm nghỉ. Phần lớn là công chức các bộ không thiết yếu
như Thương Mại, Giáo Dục, Năng Lượng, Bảo Vệ Môi Trường, Gia Cư và
Phát Triển Đô Thị, Nội Vụ, Giao Thông, …<br/><br/>Tin mừng lớn cho các công chức là dù nằm nhà nghỉ, sau này khi Nhà
Nước mở cửa lại thì tất cả mọi người vẫn được lãnh lương hồi tố
đầy đủ, không thiếu một xu. Coi như được nghỉ xả hơi mà vẫn ăn lương,
chỉ là lãnh lương hơi chậm chút thôi. Bởi vậy, khi Nhà Nước đóng cửa
tiệm, không có ông bà công chức nào khiếu nại hết.<br/><br/>Đây không phải lần đầu tiên guồng máy chính quyền Mỹ đóng cửa. Tổng cộng
đã đóng cửa tới 17 lần trong 35 năm qua, từ năm 1976 đến nay. Nhưng hầu
hết đều đóng cửa có vài ngày để mấy ông chính khách ngã giá với
nhau trong hậu trường thôi. Lần đóng cửa mới nhất và cũng là lâu
nhất là năm 1995 dưới nhiệm kỳ đầu của TT Clinton, đóng cửa tiệm đâu
ba tuần.<br/><br/>Thực tế, Nhà Nước Obama đã hoạt động đều đặn mà không có ngân sách
hàng năm từ năm 2009. Vẫn cầm cự lai rai nhờ quốc hội biểu quyết ngân
sách vá víu từng phần cho từng thời gian ngắn, có khi ba tháng, có
khi sáu tháng, cũng như bây giờ Cộng Hoà đề nghị ngân sách tạm đến
cuối năm vậy.<br/><br/>Bây giờ chưa ai biết được sẽ cò cưa bao nhiêu lâu. Nhưng có lẽ không
thể quá ngày 15 Tháng 10 vì nếu để quá ngày này, hậu quả sẽ trầm
trọng khó lường được. Chỉ vì ngoài vấn đề Nhà Nước hết tiền, lại
còn có chuyện nợ đã leo lên đỉnh luật định. Mức công nợ hiện hữu do
quốc hội cho phép sẽ leo tới mức tối đa 16.700 tỷ giữa tháng này,
nếu quốc hội không cho phép Nhà Nước Obama đi vay thêm, thì Nhà Nước
sẽ… kẹt to tuy chưa đến nỗi sập tiệm vì không vay thêm được tiền để
trả nợ đáo hạn. Khi đó, điểm tín dụng của Mỹ sẽ bị hạ xuống thêm
nữa, với tất cả hậu quả nghiêm trọng nhất cho kinh tế Mỹ. Chuyện
này quan trọng hơn chuyện đóng cửa tiệm nhiều. Điểm tín dụng bị hạ,
lãi suất Nhà Nước phải trả sẽ tăng, và toàn thể hệ thống lãi suất
ngân hàng sẽ tăng, gây trì trệ kinh tế thêm nữa, thất nghiệp trầm
trọng hơn, và ngân sách thâm thủng nặng hơn. Trừ phi quốc hội biểu
quyết riêng chuyện tăng mức nợ trần để tránh tình trạng mất tính
khả tín, khi vẫn chưa có được thỏa thuận ngân sách.<br/><br/>Đây là chính sách tài chính của chính quyền Obama: sống bằng nợ,
chết qua nợ. Nhà Nước vung tay xài tiền bằng tiền nợ, rồi đi vay nợ
mới để trả nợ hiện hữu, và con xoáy nợ ngày càng vút lên cao mà
không thấy có phương cách nào thắng lại. Dĩ nhiên, đa số dân Mỹ hoan
hô chính sách này vì được hưởng thêm trợ cấp đủ loại, và họ đã
bầu lại TT Obama để được tiếp tục nhận tiền trên trời rơi xuống.
Không ai thắc mắc chuyện Chúa Chỏm khi nào phải trả nợ.<br/><br/>Kinh tế nói chung sẽ bị ảnh hưởng, tai hại cỡ nào tùy việc đóng
cửa kéo dài bao lâu.<br/><br/>Kỹ nghệ du lịch, hàng không sẽ mất cả trăm triệu vì du khách không
có thông hành hay chiếu khán đi ra hay đi vào nước Mỹ. Ngành hầm mỏ
-than đá, dầu hỏa, dầu khí- do Nhà Nước khai thác sẽ ngưng hoạt
động, giá nhiên liệu có thể sẽ tăng chút đỉnh. Các nhà thầu cho các
dự án của liên bang trị giá hàng tỷ đô sẽ gián đoạn vì Nhà Nước
không trả tiền. Trợ cấp vài ngành nghề, nhất là trong canh nông, sẽ
bị tạm ngưng. Đó là chưa kể việc ngưng trả lương cho một triệu công
chức và hàng triệu người liên hệ khác sẽ giảm sức mua sắm của họ,
giảm thu nhập của các doanh nghiệp, làm kinh tế chung sẽ trì trệ thêm
nữa và thất nghiệp sẽ không thể giảm.<br/><br/>Tất cả nghe có vẻ ghê gớm, nhưng cũng chỉ là chuyện “muỗi đốt gỗ”
trong cái kinh tế khổng lồ của xứ Cờ Hoa, nhất là nhìn vào đường
dài.<br/><br/>Điều đáng nói là lý do chính đưa đến bế tắc là việc Cộng Hòa tìm
cách ngăn cản việc thực hành Obamacare, cài điều khoản hoãn Obamacare
trong dự luật ngân sách tạm, nhưng hậu quả lại là việc sinh hoạt Nhà
Nước bị gián đoạn vì không có ngân sách trong khi Obamacare vẫn “tiến
nhanh, tiến mạnh” tuy không “tiến vững chắc” chút nào.<br/><br/>Luật Obamacare sẽ có hiệu lực trọn vẹn kể từ ngày 1 Tháng Giêng năm
2014, có nghiã là đến ngày đó, người nào không có bảo hiểm sẽ bị
Sở Thuế IRS truy ra để tính tiền phạt. Tất cả những người không có
bảo hiểm của công ty có quyền kể từ ngày 1 tháng 10 vừa qua tìm mua
bảo hiểm, hoặc trực tiếp đi tìm các hãng bảo hiểm để mua, hoặc mua
qua trung gian các trung tâm điều hợp bảo hiểm, gọi là exchanges, là
những nơi tập trung thông tin, so sánh các điều khoản và giá cả của
các công ty bảo hiểm trong tiểu bang mình sinh sống, để lựa công ty và
loại bảo hiểm thích hợp cho hoàn cảnh và túi tiền mình nhất. Dĩ
nhiên, chuyện này không áp dụng cho những người đã lãnh medicaid hay
medicare rồi.<br/><br/>Bất kể việc Nhà Nước đóng cửa tiệm, các trung tâm điều hợp vẫn mở
cửa làm việc bắt đầu đúng ngày 1 tháng 10 như dự trù, phần lớn là
qua mạng –online- hay qua điện thoại. Nhưng đúng như phe Cộng Hòa lo
ngại, Obamacare chưa sẵn sàng. Ngoài chuyện bộ luật với cả chục ngàn
trang vẫn chưa viết xong hoàn toàn, có tới 36 tiểu bang chưa thiết lập
trung tâm điều hợp, vì chưa làm xong hay vì không chịu làm, khiến Nhà
Nước liên bang phải lập trung tâm thay cho chính quyền tiểu bang. Và hệ
thống điện toán liên bang chưa sẵn sàng ứng phó với hàng triệu người
tìm mua bảo hiểm trên mạng.<br/><br/>Nội trong buổi sáng ngày đầu tiên, đã có gần 3 triệu người vào trang
mạng Healthcare.gov để truy cập vấn đề mua bảo hiểm, và ít nhất là
60.000 người yêu cầu nói chuyện trực tiếp -chat- với các chuyên gia về
những thắc mắc của họ, trong khi chỉ có vài chục người phụ trách
chuyện này. Một trang mạng của trung tâm điều hợp của tiểu bang Nữu
Ước đã có tới 7,5 triệu người truy cập trong buổi sáng đó. Đưa đến
tình trạng ứ đọng, tắc nghẽn quy mô. Hầu hết mọi người đều phải
ngồi chờ trước máy, hay chờ điện thoại cả giờ đồng hồ, mà trong
rất nhiều trường hợp vẫn không giải quyết được gì, vì thiên hạ có
cả trăm cả ngàn câu hỏi mà các công chức Nhà Nước chưa có hết các
câu trả lời.<br/><br/>Theo thăm dò của Pew Research, 39% dân Mỹ cho là Cộng Hòa chịu trách
nhiệm về vụ Nhà Nước phải đóng cửa tiệm, nhưng 36% lại cho đó là
trách nhiệm của TT Obama và phe Dân Chủ, trong khi 17% cho cả hai bên
đều có lỗi ngang nhau. Khác biệt giữa 39% và 36% nằm trong sai biệt
xác xuất, có nghiã là hai bên đều bị coi như có lỗi xấp xỉ ngang
nhau. Một thăm dò của Fox News cho thấy 25% đổ lỗi cho Chủ Tịch Hạ
Viện Cộng Hòa John Boehner, và 24% cho rằng TT Obama chịu trách nhiệm.
Sự thật như người Mỹ thường nói, “it takes two to tango”, cần phải hai
người mới nhẩy điệu tango được. Chẳng bên nào vô tội như Thị Kính
hết.<br/><br/>Như đã nói qua, TT Clinton cũng đã đối đầu với một Hạ Viện do phe
đối lập kiểm soát và Nhà Nước bị đóng cửa gần một tháng. Nhưng
tình trạng hôm nay có vẻ bi quan hơn. Trước hết, cả TT Clinton và lãnh
tụ đối lập Cộng Hòa ngày đó, ông Newt Gingrich, đều có thiện chí
làm việc với nhau thường trực để giải quyết mâu thuẫn. Rồi kinh tế
khi đó đang phát triển mạnh nên hậu quả kinh tế không tai hại lắm.
Ngày nay, mâu thuẫn giữa TT Obama và lãnh tụ John Boehner của Cộng Hoà
trầm trọng hơn nhiều, trong khi kinh tế đang lúc khó khăn, và hậu quả
sẽ tai hại hơn hồi năm 1995.<br/><br/>Một cuộc đóng cửa tiệm kéo dài cả tháng sẽ không phải là chuyện
không thể có. Nhưng dù sao cũng chỉ là trò chơi ú tim của các chính
khách, chưa phải là tận thế. Lại khiến nhiều người thắc mắc: nếu
Nhà Nước “khép cửa” như vậy mà vẫn không có tận thế, thì sao không
khép như vậy luôn đi, tiết kiệm được biết bao nhiêu trăm tỷ mỗi năm,
bớt thuế má cho cả triệu người. Như vậy có tốt hơn không? (06-10-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a211347/nha-nuoc-dong-cua-tiem

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/