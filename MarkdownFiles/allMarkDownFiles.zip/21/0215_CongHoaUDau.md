# Cộng Hòa U Đầu

29/10/2013

...cả hai đều... đá trái banh ra biên, chờ đầu năm tới đấu tiếp...<br/><br/>Trong những ngày qua khi Nhà Nước đóng cửa tiệm, một vài độc giả lo
xa đã gửi điện thư cho kẻ viết này, hỏi thăm nguy cơ ra sao, ảnh hưởng
thế nào đối với dân tỵ nạn ta. Đành phải trấn an. Như đã viết trên
cột báo này, tất cả chỉ là trò xiếc chính trị của mấy ông chính
khách đang tranh dành ảnh hưởng. Nhà Nước đóng cửa tiệm sẽ chẳng
chết anh tây đen hay anh tây trắng nào, trước sau rồi cũng mở cửa lại.
Và khi đó thì chúng ta cần bịt tai để tránh nghe những bài ca chiến
thắng hay đổ thừa từ cả hai phiá. Dĩ nhiên là bên chính quyền Obama,
với sự hậu thuẫn mạnh mẽ của truyền thông dòng chính, sẽ khua chiêng
trống ồn ào hơn bên Cộng Hoà nhiều.<br/><br/>Quả đúng như vậy. Nhà Nước đóng cửa rồi mở cửa, thiên hạ chẳng ai
thấy có gì khác biệt, ngoại trừ một ít du khách đi thăm các công
viên quốc gia, trước đây bị đóng cửa không vào thăm được, bây giờ thì
được vào lại rồi.<br/><br/>Nhưng tiếng ca hát thì ồn ào đến ù tai luôn. Nếu ta đọc báo chí
dòng chính hay nghe các đài truyền hình lớn như ABC, CBS, NBC, và CNN,
nhất là MSNBC, ta sẽ thấy tương lai đảng Cộng Hoà u tối hơn đêm ba
mươi, và sẽ... đóng cửa tiệm trong vài ngày nữa. Theo họ thì Cộng
Hoà muốn đóng cửa tiệm Nhà Nước, kết quả sẽ phải tự đóng cửa
chính đảng của mình. Mấy đài truyền hình cấp tiến này quên mất
muốn đóng cửa Nhà Nước, một đảng Cộng Hoà chẳng làm gì được mà
phải cần tới cả hai đảng, qua hai viện quốc hội, cùng với một ông
tổng thống, tất cả cùng nhau đồng ý là... tiếp tục không đồng ý
với nhau mới đóng cửa Nhà Nước được.<br/><br/>Các cơ quan truyền thông dòng chính, từ đông sang tây, đều nhất loạt
đăng cáo phó cho đảng Cộng Hòa. Thậm chí, nhiều chính khách Cộng
Hòa cũng lên tiếng, hoảng hốt tìm cách cứu vớt đảng.<br/><br/>Theo các bản tin và bài bình luận của truyền thông dòng chính thì
đảng Cộng Hoà:<br/><br/>- chống lại việc tăng mức nợ trần của công nợ; chống lại việc biểu
quyết ngân sách; muốn hoãn Obamacare lại một năm; chấp nhận Nhà Nước
đóng cửa tiệm.<br/><br/>Trong khi TT Obama thì:<br/><br/>- cương quyết không điều đình gì hết với Cộng Hòa; nhất quyết đòi
tăng mức nợ trần không giới hạn; đòi có ngân sách theo như Tòa Bạch
Ốc đề nghị; không hoãn Obamacare; đòi mở cửa Nhà Nước lại.<br/><br/>Kết quả sau hai tuần Nhà Nước đóng cửa là:<br/><br/>- TT Obama đại thắng; mức nợ trần được tăng đến 7 tháng 2 năm 2014;
ngân sách được thỏa thuận tới 15 tháng Giêng năm 2014; Obamacare không
hoãn gì hết; và Nhà Nước mở cửa lại.<br/><br/>Cuối cùng như vậy là TT Obama đã đạt được mọi ý nguyện trong khi
Cộng Hòa không đạt được bất cứ điều gì, thất bại hoàn toàn. Như
nhà báo Jon Terbush đã viết trên diễn đàn điện tử Yahoo! News, Cộng
Hoà đã “không thắng được gì và mất hết”. Tệ hơn vậy nữa, khối Tea
Party thất bại thê thảm và coi như đã đi vào “thùng rác lịch sử” giống
như chủ nghiã cộng sản trước đây vậy.<br/><br/>TT Obama tuyên bố “không có bên thắng cuộc”, nhưng rồi cư xử như kẻ
“đại thắng mùa thu”. Ông thách thức “bạn không thích một chính sách
hay một tổng thống nào ư? Hãy ra tranh cử và thắng cuộc bầu cử đi”
(You don't like a particular policy or a particular president? … Go out there
and win an election). Không còn chuyện đại đoàn kết toàn dân nữa, mà
chỉ còn chuyện tranh cử với bên thắng làm vua và bên thua làm giặc.<br/><br/>Thực tế hậu quả Nhà Nước đóng cửa là như thế nào?<br/><br/>Trên căn bản, TT Obama thắng và Cộng Hoà thua là chuyện không sai, chỉ
là phóng đại hơi quá mức thôi. Sau hai tuần đóng cửa vì không có ngân
sách hoạt động, Nhà Nước đã mở cửa lại sau khi Cộng Hoà chấp nhận
một ngân sách tạm thời cho đến cuối năm nay. Mức nợ trần cũng đã
được chấp thuận cho gia tăng cho qua đầu năm tới. Obamacare sẽ không bị
hoãn lại ngày nào hết, vẫn tiến hành như thường. Tất cả đều có vẻ
rất tốt đẹp cho TT Obama.<br/><br/>Nhưng nếu nhìn kỹ lại một chút, hình như câu chuyện có hơi khác.<br/><br/>Khi Cộng Hòa chấp nhận các biện pháp để giúp mở cửa Nhà Nước lại
thì rõ ràng những mục tiêu chính của họ đã đạt được. Theo ông Julian
Zelizer, giáo sư sử học của Đại Học Princeton, Cộng Hòa đã thành công
trong mục tiêu duy trì những vấn đề như thâm thủng ngân sách và công
nợ cao trên những trang đầu của truyền thông để dân Mỹ khỏi quên, không
cho chính quyền Obama lập lờ chôn dấu những vấn đề đó. Ngân sách
được biểu quyết cũng như mức trần công nợ được bỏ, nhưng chỉ là
những biện pháp tạm thời, ngắn hạn đến đầu năm tới thôi. Rồi khi
đó, một là TT Obama nhượng bộ những đòi hỏi của Cộng Hòa thì sẽ
có những giải pháp lâu dài, hai là TT Obama nhất định không chịu cắt
giảm chi tiêu, thì chúng ta sẽ lại thấy đe doạ Nhà Nước đóng cửa
tiệm, để rồi cuối cùng cũng lại vẫn chỉ là những giải pháp nhất
thời, ngắn hạn, cho vài tháng thôi. Và cứ như vậy, Cộng Hòa sẽ bảo
đảm những vấn đề này vẫn là đề tài trên trang nhất của báo chí
trong năm tới là năm bầu cử giữa muà. Trong khi đó, những chương trình
lớn khác của TT Obama đã bị hoàn toàn lãng quên, hay nói cho đúng
hơn, không có cơ hội mang ra bàn nữa, chẳng hạn như các vấn đề cư dân
bất hợp pháp và kiểm soát súng đạn.<br/><br/>Ngoài chuyện này ra, ta thấy Cộng Hoà cũng đã nêu ra được vài điểm
quan trọng:<br/><br/>1. Nước Mỹ có thể sống trong tình trạng một Nhà Nước nhỏ hơn mà
không sao cả. Có nghiã là khối bảo thủ chống lại mọi bành trướng
của Nhà Nước vú em đã có thể chứng minh cho thiên hạ thấy Nhà Nước
nhỏ bé đi, cánh tay Nhà Nước ngắn bớt lại, đã và sẽ không có tai
hại gì cả. Mọi chuyện vẫn ổn. Không ai cần một Nhà Nước vú em bao
đồng tất cả mọi chuyện mà khối cấp tiến và TT Obama vẫn quảng bá.<br/><br/>2. Chứng minh họ nói đúng khi chỉ trích Obamacare chưa sẵn sàng. Ở đây
khối đối lập đã được chính TT Obama giúp đỡ khi tung ra một chương
trình bị lủng lỗ tứ phiá, xác nhận Cộng Hòa đã chỉ trích không
sai: Obamacare chưa sẵn sàng. Theo những thăm dò mới nhất, 60% dân Mỹ
cho việc tung ra Obamacare với vô số lủng củng là một “trò đùa” (a
joke). Mới đây, 10 thượng nghị sĩ Dân Chủ đã chính thức viết thư yêu
cầu TT Obama hoãn thi hành Obamacare lại từ ba tháng đến một năm vì
những trục trặc kỹ thuật khổng lồ, và phát ngôn viên Tòa Bạch Ốc
cũng đã không quyết liệt bác bỏ đòi hỏi này, mà đã để cánh cửa
ngỏ khi xác nhận Obamacare có thể sẽ phải hoãn lại “vì lý do kỹ
thuật”. Dĩ nhiên, không ông bà Dân Chủ nào dám nói việc hoãn lại
phần nào đã được tác động bởi đòi hỏi của phe Cộng Hòa, và đó
chính là cái giá TT Obama và phe cấp tiến đã thoả thuận trong hậu
trường với phe Cộng Hòa để mở cửa Nhà Nước lại?<br/><br/>3. Những “trục trặc kỹ thuật” khổng lồ của Obamacare đã đánh tan
hình ảnh một tổng thống “hiện đại” nhất, chuyên gia về các phương
tiện thông tin điện toán đại chúng, cũng như niềm tin vào một Nhà
Nước toàn năng. Những tắc nghẽn của trang mạng Healthcare.gov cũng như
hệ thống điện thoại đã biến khẩu hiệu “Yes, We Can” thành “No, We
Can’t”. Chưa kể chuyện báo chí mới khám phá ra việc Phó Tổng Giám
Đốc của CGI Federal được trao dự án làm trang mạng Healthcare.gov mà
không cần qua thủ tục đấu thầu, Toni Townes Whitley, là một bà bạn
học tâm giao của Đệ Nhất Phu Nhân tại đại học Princeton năm 1985. Cả
hai bà đều là hội viên tích cực của Hội Cựu Sinh Viên Da Đen Princeton
(Association of Black Princeton Alumni).<br/><br/>Nhà báo Elliot McLaughlin viết trên diễn đàn phe ta CNN cũng đã nhìn
thấy việc đóng cửa Nhà Nước là thông điệp của khối đối lập Cộng
Hoà là họ sẽ không ngồi yên cho TT Obama tự tung tự tác muốn làm gì
thì làm, và trong những ngày tháng còn lại của nhiệm kỳ hai, nếu TT
Obama muốn làm được chuyện gì thì bắt buộc phải cần có thỏa hiệp
với đối lập. Ba năm còn lại của TT Obama sẽ nhiều chông gai hơn bao
giờ hết. Những vấn đề gai góc như cư dân bất hợp pháp hay kiểm soát
súng đạn sẽ khó có được giải pháp. Một tờ báo đã gọi ngay TT Obama
là “vịt què”. “Vịt què” (lame duck) là danh từ thông dụng của Mỹ để
chỉ một chính khách dân cử sắp sửa mãn nhiệm, ngồi chờ ngày bàn
giao mà không còn làm gì được nữa.<br/><br/>Nhìn dưới những khiá cạnh nêu trên, làm sao có thể nói TT Obama toàn
thắng và Cộng Hòa đại bại? Cùng lắm thì có thể nói cả hai đều...
đá trái banh ra biên, chờ đầu năm tới đấu tiếp.<br/><br/>Nhưng rồi nếu ta nhìn vấn đề dưới một khiá cạnh khác, khiá cạnh
chiến thuật “đấu tranh chính trị”, ta sẽ thấy một vài chuyện đáng
bàn.<br/><br/>Đảng Dân Chủ và TT Obama quá chú tâm vào việc đánh đối lập để rồi
sau khi “chiến thắng” chuyện Nhà Nước đóng cửa, chỉ lo ca khúc khải
hoàn quá sớm trong khi nước Mỹ vẫn đang ngụp lặn trong những khó khăn
cực lớn, mà không có khó khăn nào do Cộng Hoà gây nên. Trái lại toàn
những khó khăn xuất phá từ các chính sách của chính TT Obama như thâm
thủng ngân sách và công nợ quá mức, thất nghiệp không giảm, và
Obamacare vẫn đầy lủng củng luộm thuộm, chưa kể chuyện gần 60% dân Mỹ
và một nửa số tiểu bang không chấp nhận.<br/><br/>TT Obama khua chiêng trống rất lớn về cái gọi là “chiến thắng” của
mình, vừa để đánh Cộng Hòa, vừa để khoả lấp những ưu tư lớn của
thiên hạ về thâm thủng ngân sách và công nợ quá mức. Theo TT Obama,
tất cả đều là lỗi của phe Cộng Hòa với những yêu sách vô lý, và
họ thua là lẽ đương nhiên. Thật ra thì ai chiến thắng?<br/><br/>Phe Cộng Hoà tuy không thể nói đại bại nhưng chắn chắn đã u đầu
nặng. Tỷ lệ hậu thuẫn của Cộng Hòa đã xuống thấp nhất trong lịch
sử cận đại Mỹ, đâu khoảng 25%. Hy vọng chiếm lại Thượng Viện trong
cuộc bầu năm tới coi như tiêu tan thành mây khói. Và hy vọng giữ thế đa
số tại Hạ Viện cũng đã lung lay mạnh. Với cả hệ thống truyền thông
dòng chính khua chiêng trống đả kích ầm ĩ, tỷ lệ hậu thuẫn cao hơn
mới là chuyện lạ. Nội bộ Cộng Hoà cũng hục hặc chia hai xẻ ba, với
thế hệ trẻ diều hâu đụng độ với thế hệ già ôn hòa hơn.<br/><br/>Nhưng TT Obama cũng không thoát nạn hoàn toàn trong an toàn. Tỷ lệ hậu
thuẫn của ông đã xuống dưới mức của TT Bush cùng thời kỳ này, sau 19
tam cá nguyệt. Theo AP, tỷ lệ hậu thuẫn của TT Obama đã xuống đến
mức không tưởng là 37%.<br/><br/>Cựu Giám Đốc CIA và Bộ Trưởng Quốc Phòng của TT Obama, ông Leon
Panetta đã nhận định “chính quyền này đã đi từ khủng hoảng này đến
khủng hoảng khác, đây không thể gọi là chính quyền có đường hướng
lãnh đạo được”. Ông cũng nhận định cuộc khủng hoảng đưa Nhà Nước
đến đóng cửa tiệm là lỗi của tất cả mọi phiá, nhưng với tư cách
tổng thống lãnh đạo quốc gia, TT Obama đáng lẽ ra phải “tích cực săn
tay áo, nghe đối lập nói, tìm hiểu xem họ muốn gì, đó mới là trị
nước” chứ không thể “đợi khủng hoảng đến rồi bỏ khỏi bàn họp” (walk
away from the table) và đổ lỗi cho đối lập. Chuyện đổ lỗi suốt ngày
đã khiến nhà báo Nolan Finley của Detroit News cho TT Obama luôn luôn là
“một nạn nhân, chưa bao giờ là một nhà lãnh đạo” (Obama Always a
Victim, Never a Leader).<br/><br/>Một sự kiện khác liên quan đến các nhóm Tea Party. Theo phe TT Obama và
truyền thông cấp tiến, khối Tea Party đã chủ động trong những biến cố
mới đây đưa đến đóng cửa Nhà Nước. Tất cả đều do thái độ cực đoan
quá khích của khối này, đã lũng đoạn và tạo chia rẽ trầm trọng
trong đảng Cộng Hoà. Thất bại của Cộng Hoà sau khi Nhà Nước mở cửa
lại do đó cũng là thất bại do khối quá khích Tea Party gây ra.<br/><br/>Việc chỉa mũi dùi vào khối Tea Party chỉ là một chiến thuật “chia
để trị” hết sức cổ điển. Tìm cách tách Tea Party ra khỏi đảng Cộng
Hòa, kết luận mọi chuyện đều chỉ là do nhóm thiểu số Tea Party
khuynh đảo. Như đã trình bày trong cột báo trước, Tea Party chỉ là
một nhúm chưa tới một tá dân cử tại Thượng Viện và Hạ Viện, không
tài nào chi phối được cả đảng Cộng Hòa, khoan nói tới toàn thể
chính quyền.<br/><br/>Nếu đảng Dân Chủ lo đăng cáo phó cho đảng Cộng Hòa thì đối với các
nhóm Tea Party, đảng Dân Chủ coi như các nhóm này đã chết từ lâu rồi.
Chỉ là một “con sâu làm rầu nồi canh”. Nhưng điều truyền thông cấp
tiến quên hay không muốn nhắc đến là thượng nghị sĩ Ted Cruz của
Texas, tiếng nói tiêu biểu cho quan điểm Tea Party, khi về lại Texas, đã
được đón tiếp như người hùng cứu tinh dân tộc. Trong một buổi gặp
mặt với cử tri địa phương, ông Cruz đã được cử tọa nhất loạt đứng
lên vỗ tay hoan nghênh trong gần 10 phút.<br/><br/>Trong cuộc chiến, phe cấp tiến đã tô vẽ Cộng Hòa như tổ chức quá
khích cực đoan nếu không muốn nói là cuồng tín, với những chiến
thuật tệ không thua gì “tiêu thổ kháng chiến” của Việt Minh ngày xưa.
TT Obama chỉ trích Cộng Hoà cực đoan, “cướp của tống tiền” (extortion
and blackmail). PTT Biden gọi Cộng Hòa là “khủng bố” (terrorists).
Truyền thông dòng chính thì dùng những hình ảnh như “kê súng vào
đầu”, “bắt con tin”, “đeo bom vào ngực”, “đòi tiền chuộc mạng”. Làm
như thể việc sử dụng những từ ngữ như vậy là cách nói chuyện “ôn hoà”,
không phải ngôn từ quá khích cực đoan vậy. Nhìn qua cách sử dụng từ
ngữ, bên nào là quá khích, cực đoan?<br/><br/>Như cột báo này đã bàn, tại sao tìm cách ngăn cản cái vung tay xài
tiền của TT Obama để cân bằng lại ngân sách lại là hành động quá
khích? Làm sao chấp nhận ngân sách thâm thủng bạc ngàn tỷ, nợ nần
chồng chất cũng bạc ngàn tỷ lại có thể là những hành động đứng
đắn, ôn hoà, phải lẽ?<br/><br/>Ngay cả New York Times cũng đã nhìn nhận TT Obama là tổng thống thiên
tả nhất lịch sử Mỹ, đứng phiá tả của các tổng thống cấp tiến
Jimmy Carter và Bill Clinton.<br/><br/>Một cách nhìn khác: trong 4 năm nhiệm kỳ đầu, TT Obama đã chi 3.700 tỷ
cho 15 chương trình trợ cấp an sinh của liên bang, đưa đến tình trạng
một nửa dân Mỹ (49% hay 151 triệu người) hiện đang nhận trợ cấp dưới
hình thức nào đó. Một kỷ lục tuyệt đối, chỉ thua các nước cộng
sản đã xụp đổ cách đây hơn hai thập niên. TT Obama đã biến một nửa
dân Mỹ thành nô lệ của Nhà Nước. Nhưng nhiều người sẽ hoan hô “tổng
thống của dân nghèo”, trong khi không thắc mắc tiền ở đâu ra? Những
ngàn tỷ nợ ai trả, chừng nào trả, và trả bằng gì? Chuyện gì sẽ
xẩy ra? Muốn biết câu trả lời, chỉ cần nhìn vào Hy Lạp trong những
năm tháng vừa qua. Khi đó, những nạn nhân lớn nhất không phải là các
ông tỷ phú như Bill Gates, mà chính là những người đang nhận trợ cấp
khi họ mất hết, và con cháu họ khi chúng phải đóng thuế ngập đầu
để Nhà Nước trả nợ. (27-10-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a212333/cong-hoa-u-dau

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/