# Thực Tế Obamacare

22/10/2013

...cùng những điều kiện chữa trị như trước, tiền bảo phí tăng 260%,
tức là tăng gần gấp 4 lần...<br/><br/>Cuộc tranh cãi đưa đến chuyện Nhà Nước đóng cửa tiệm có liên quan
đến ba vấn đề: ngân sách cho tài khoá 2014, mức công nợ, và Obamacare.
Cột báo này tuần trước đã bàn qua về vấn đề công nợ. Lần này ta
bàn qua vấn đề Obamacare.<br/><br/>Câu hỏi đặt ra là tại sao Cộng Hòa đòi hoãn việc áp dụng Obamacare?
Trên căn bản, vì Cộng Hoà chống Obamacare. Một bộ luật được thông qua
bằng “cửa sau” với tổng cộng 0 phiếu của Cộng Hòa và gần 60% dân Mỹ
chống đối chắc chắn không thể nào tránh được phản kháng. Nhưng vì
không đủ sức mạnh chính trị thu hồi lại luật, nên đành phải tìm mọi
cách “chống phá” như 1) thưa kiện Obamacare vi hiến, 2) không thành lập
các trung tâm phối hợp (exchanges) là nơi mà thiên hạ có thể tham khảo
để tìm mua bảo hiểm thích hợp với điều kiện sức khoẻ và tài chánh
của mình nhất, 3) không mở rộng trợ cấp y tế Medicaid cho những thành
phần lợi tức thấp, và 4) không phê chuẩn ngân sách cho Obamacare.<br/><br/>Những phương thức này đều đã không đưa đến kết quả gì đáng nói. Tối
Cao Pháp Viện đã nhìn nhận Obamacare hợp hiến. Đối với các tiểu bang
không chịu thành lập các trung tâm phối hợp, chính quyền liên bang
nhẩy vào thành lập những trung tâm này. Đối với chuyện không mở rộng
thêm Medicaid thì cho đến nay, chưa có nhu cầu này vì chưa có bao nhiêu
người ghi danh mua bảo hiểm. Việc không cấp ngân sách cho Obamacre cũng chưa
đến giai đoạn quan yếu, nhất là trong khi bây giờ ngân sách cả nước
vẫn chưa có, nói chi đến ngân sách Obamacare. Do đó phe Cộng Hoà chỉ
còn cách ra chiêu cuối cùng: đòi hoãn một năm việc áp dụng luật bắt
buộc mọi cá nhân phải có bảo hiểm sức khoẻ, chỉ áp dụng từ đầu
năm 2015 thay vì đầu năm 2014, dựa trên nhận định Obamacare chưa sẵn
sàng.<br/><br/>Trước hết, bộ luật khổng lồ này cho đến nay đã được viết ra thành
hơn 10.000 trang, gồm gần 12 triệu chữ, nhưng lạ lùng thay, vẫn chưa
viết xong. Chẳng những vậy, người ta lại khám phá ra nhiều chi tiết
sơ đẳng mà thiên hạ hỏi khi tìm mua bảo hiểm, vẫn chưa có câu trả
lời. Nếu chưa có hết các câu trả lời thì dĩ nhiên chưa thể áp dụng
trọn vẹn được, và quan trọng hơn nữa, sẽ khó thoát khỏi các con mắt
cú vọ của hàng ngàn luật sư đang tìm kẽ hở để lách luật, hay lợi
dụng luật. Luật sư Mỹ toàn là những siêu chuyên gia về những kỹ thuật
này.<br/><br/>Obamacare cũng chưa sẵn sàng để có thể được áp dụng vì trang mạng
chính Healthcare.gov do Nhà Nước liên bang phụ trách đã kẹt và không
hoạt động được ngay từ ngày đầu, 1 tháng 10 vừa qua, với cả triệu
người ngồi chờ dài người cả tiếng đồng hồ mà cuối cùng vẫn chưa
ghi danh được vì đủ loại lý do, lý do kỹ thuật điện toán cũng như
lý do thiếu tin tức, thiếu dữ kiện vì các chuyên viên đã không trả
lời được nhiều câu hỏi của khách hàng, thậm chí dữ liệu sai như con
thì ghi thành chồng, vợ thành con gái,... Tính đến nay, cả triệu
người đã vào các trang mạng tìm mua bảo hiểm, nhưng số người mua bảo
hiểm chưa tới 1%. Một hệ thống điện toán hết sức luộm thuộm cho một
vấn đề cự kỳ phức tạp.<br/><br/>Theo báo chí, Nhà Nước Obama đã trả gần 100 triệu đô cho hệ thống
này. Nhưng rồi báo chí cũng khám phá ra việc chọn công ty để điều
hành chương trình Obamacare này đã không được thực hiện theo thể thức
đấu thầu công khai giữa nhiều công ty đúng theo thủ tục cấp thầu cho
các dự án liên bang, mà công ty CGI Federal là công ty duy nhất được
trao trách nhiệm. Một vài dân biểu đã lên tiếng yêu cầu Bộ Y Tế giải
thích tại sao công ty này đã được chọn, dựa trên những tiêu chuẩn
nào, và tại sao không có đấu thầu công khai, nếu không sẽ phải lập
ủy ban điều tra. Hiện nay, người ta chỉ biết Tổng Giám Đốc CGI, bà
Donna Ryan, đã “viếng thăm” Tòa Bạch Ốc 6 lần trước khi CGI được trao
dự án gần 100 triệu này, và ít nhất là hai giám đốc CGI là những
người đã tích cực vận động và đóng tiền ủng hộ cuộc tranh cử của
TT Obama năm 2008.<br/><br/>Các hệ thống điện toán của các trung tâm phối hợp của tiểu bang
cũng lủng củng không kém. Trong những hệ thống điện toán của các
trung tâm phối hợp cấp tiểu bang, chỉ có đúng 7 hệ thống chạy một
cách khá trôi chẩy. Một số trung tâm tạm ngưng hoạt động vì danh sách
các bác sĩ, nhà thương chưa cập nhật xong.<br/><br/>Những trục trặc này thể hiện sự luộm thuộm của guồng máy hành
chánh Mỹ. Chỉ khiến người ta lo ngại làm sao khối cấp tiến có thể
cứ nằng nặc đòi tăng cường vai trò của Nhà Nước trên đủ mọi phương
diện khi mà các công chức Mỹ thiếu khả năng như vậy. Nhiều dân biểu
đã yêu cầu bà bộ trưởng Y Tế Sebellius từ chức.<br/><br/>Một bằng chứng nữa về sự chưa sẵn sàng. Hệ thống kiểm tra lợi tức
của những người xin trợ cấp bảo phí chưa làm xong. Do đó, Nhà Nước
Obama đã quyết định chấp nhận trợ cấp theo đơn khai báo của thiên hạ
mà không cần kiểm chứng mức lợi tức thật sự. Không ai tin có chuyện
tất cả những người xin trợ cấp đều “thành thật khai báo với Nhà
Nước”.<br/><br/>Obamacare cũng đã hiện hình như một luật áp dụng cho bàn dân thiên
hạ, nhưng lại không áp dụng cho những người … làm ra luật. Vì ảnh
hưởng tài chánh nặng nề của Obamacare, một số rất lớn công ty hủy
bỏ các chương trình bảo hiểm tập thể cho tất cả các nhân viên, để
nhân viên phải tự túc đi mua bảo hiểm cá nhân, đắt hơn nhiều. Trước
tình trạng đó, khối Cộng Hòa tại Hạ Viện cũng đề nghị áp dụng
biện pháp tương tự trong quốc hội. Cho đến nay, tất cả nhân viên lưỡng
viện quốc hội, từ thượng nghị sĩ, dân biểu, đến các trợ tá, thư
ký, … đều được xếp hạng như công chức liên bang và được chính phủ liên
bang trả 75% chi phí mua bảo hiểm sức khoẻ tập thể. Khối Cộng Hoà
đề nghị trong dự luật ngân sách tới, Nhà Nước sẽ hủy bỏ việc tài
trợ cho quốc hội này, và các nhân viên quốc hội sẽ phải tự túc đi
tìm mua bảo hiểm riêng rẽ cho mình và gia đình. Phe Dân Chủ kiểm soát
Thượng Viện đã bác bỏ ý kiến này và được TT Obama hậu thuẫn, ra
lệnh các nghị sĩ và dân biểu vẫn tiếp tục được hưởng đặc quyền về
việc trợ cấp bảo hiểm này. Các ông bà dân cử Dân Chủ làm luật cho
thiên hạ nhưng luật đó không áp dụng cho chính mình. Thật là tiện.<br/><br/>Một hiện tượng có thể nói là “lạ lùng” trong Obamacare. Theo luật,
kể từ đầu năm tới, tất cả mọi cá nhân đều bắt buộc phải mua bảo
hiểm, và tất cả các công ty với trên 50 nhân viên cũng bắt buộc phải
cung cấp bảo hiểm cho tất cả nhân viên. Ai vi phạm, cá nhân hay công ty,
đều sẽ bị phạt nặng. Ngoại trừ trường hợp được Nhà Nước Obama chấp
thuận cho đặc miễn, nghiã là luật bắt buộc này sẽ không áp dụng
với sự cho phép của TT Obama.<br/><br/>Ở đây có hai vấn đề được đặt ra.<br/><br/>Trước hết, người ta không hiểu TT Obama lấy tư cách gì có thể miễn
áp dụng một đạo luật theo ý của ông, tùy hỷ. Theo Hiến Pháp Mỹ,
tổng thống cũng phải chịu sự chi phối của luật nước, tại sao bây
giờ TT Obama lại có quyền ký giấy miễn áp dụng luật theo ý của ông?
Câu hỏi này không ai nêu ra vì lý do giản dị: phe Dân Chủ nhất hô bá
ứng với tất cả các quyết định của ông tổng thống phe ta nên không
khiếu nại; trong khi phe Cộng Hoà cứ thấy Obamacare không được thi hành
là mừng rỡ, không khiếu nại luôn.<br/><br/>Trong tình trạng đó, gần 800 đại công ty với hàng trăm hay hàng ngàn
nhân viên đã được miễn áp dụng Obamacare, tức là không cung cấp bảo
hiểm cho nhân viên mà không bị phạt gì hết. Tuyệt đại đa số các công
ty này là các công ty có nhân viên đều là thành viên các nghiệp đoàn.
Các nghiệp đoàn hiểu rất rõ nếu bắt ép các đại công ty này cung
cấp bảo hiểm cho tất cả nhân viên thì sẽ có rất nhiều nhân viên hoặc
là bị sa thải, hoặc là bị xuống cấp cho làm việc bán thời không được
bảo hiểm. Vì nhu cầu bảo vệ việc làm của các thành viên, các
nghiệp đoàn bắt tay với các chủ công ty, yêu cầu Nhà Nước Obama miễn
áp dụng Obamacare. Và vì cần nghiệp đoàn, nên chính quyền Obama đã
mau mắn chấp nhận đòi hỏi này. Có nhiều trường hợp việc đặc miễn
này được áp dụng thẳng với các nghiệp đoàn. Chẳng hạn như nghiệp
đoàn các giáo chức: tất cả những thành viên nghiệp đoàn giáo chức
đều được hưởng quy chế đặc miễn, không áp dụng Obamacare, bất kể đang
dạy học ở đâu, tiểu bang nào. Cho đến nay, đã có 450 nghiệp đoàn
được hưởng đặc miễn.<br/><br/>Nhìn vào những đặc miễn nêu trên, người ta không khỏi ngạc nhiên:
Obamacare được áp dụng cho hết cả thiên hạ, ngoại trừ các dân biểu,
nghị sĩ là những người làm luật Obamacare, ngoại trừ các đại công ty
mà TT Obama vẫn nêu đích danh để chỉ trích đủ mọi tội, nhất là tội
trốn thuế để chi trả cho Obamacare và tất cả các chi tiêu khác của
Nhà Nước, và ngoại trừ các nghiệp đoàn. Thế thì Obamacare áp dụng
cho ai? Câu trả lời: Obamacare áp dụng cho các doanh nghiệp nhỏ, cho
các nhân viên thấp cổ bé họng của các doanh nghiệp đó, cho các cá
nhân không phải trong nghiệp đoàn, và cho thành phần trung lưu là những
đối tượng ưu tiên trong việc è cổ đóng thuế tài trợ cho Obamacare.<br/><br/>Chưa hết, trước quá nhiều đơn xin đặc miễn của các công ty, TT Obama
mới đây đã đơn phương quyết định hoãn một năm việc bắt buộc các công
ty mua bảo hiểm cho nhân viên. Có nghiã là các công ty không bị bắt
buộc phải mua bảo hiểm cho tất cả các nhân viên trong một năm nữa.
Nhưng vì TT Obama không hoãn điều khoản bắt buộc mọi cá nhân phải có
bảo hiểm, nên kết quả là các công ty có quyền từ chối không cung cấp
bảo hiểm cho nhân viên, nhưng mấy ông bà nhân viên này lại bị luật bắt
buộc phải có bảo hiểm, tức là phải bỏ tiền túi mua bảo hiểm cá nhân
đắt hơn bảo hiểm tập thể nhiều. Phe Cộng Hòa đang mạnh mẽ chỉ trích
điều tréo cẳng ngỗng này và đang đòi hỏi TT Obama hoãn Obamacare cho
các cá nhân cũng một năm luôn. Nhưng TT Obama đã khẳng định điều này
không chấp nhận được. Hoãn cho đại công ty, hoãn cho nghiệp đoàn, nhưng
không hoãn cho cá nhân và không hoãn cho tiểu thương. Tại sao? Quý độc
giả nào muốn có câu trả lời có thể hỏi thẳng các vị dân biểu hay
nghị sĩ Dân Chủ trong tiểu bang của mình. Hay hỏi các vị nhân sĩ,
nhà báo trong cộng đồng tỵ nạn đang ủng hộ đảng Dân Chủ và
Obamacare.<br/><br/>Cho dù TT Obama đã hoãn việc áp dụng Obamacare cho các công ty, nhiều
công ty lớn vẫn bắt đầu lấy những biện pháp chống đỡ dài hạn. Công
ty Home Depot, lớn nhất trong ngành vật liệu xây cất, đã ra quyết định
hủy bỏ bảo hiểm sức khoẻ cho hơn 20.000 nhân viên làm việc bán thời.
UPS, công ty gửi bưu kiện, thông báo cho 15.000 nhân viên là người phối
ngẫu của họ sẽ không còn được công ty cung cấp bảo hiểm sức khỏe
nữa. Hãng IBM hủy bỏ chương trình bảo hiểm cho toàn thể 110.000 nhân
viên, và trả cho họ một số tiền nhất định để họ tự đi tìm mua bảo
hiểm. Chỉ là một vài thị dụ trong cả ngàn trường hợp.<br/><br/>Công ty dịch vụ Towers Watson ước lượng 40% các công ty lớn nhỏ sẽ thay
đổi chính sách bảo hiểm sức khỏe cho nhân viên, hủy bỏ hay cắt giảm
bảo hiểm sức khỏe. Điều chắc chắn là tất cả các công ty sẽ bỏ bảo
hiểm cho nhân viên quá 65 tuổi đã về hưu vì họ đã có Medicare.
Medicare vẫn chỉ trả 80% chi phí và mọi người sẽ phải mua thêm bảo
hiểm cho 20% còn lại. Sẽ đắt hơn nhiều và ít bác sĩ để lựa chọn hơn.<br/><br/>Một số không ít người đã bất ngờ khám phá ra những vấn đề thật sự
của Obamacare. Trước hết, trái với những hứa hẹn của TT Obama, không
phải ai muốn giữ bác sĩ cũ đều có thể làm được. Trái lại, đa số
người mua bảo hiểm đã khám phá ra là họ sẽ bị bắt buộc phải đổi
bác sĩ vì bác sĩ cũ của họ không có trong danh sách bác sĩ tham gia
vào chương trình bảo hiểm mà họ lựa chọn. Hầu hết các chương trình
bảo hiểm mới đều có những danh sách bác sĩ, nhà thương giới hạn.<br/><br/>Nhưng vấn đề lớn nhất của Obamacare hiện nay là trái với những cam
kết của TT Obama, chi phí bảo hiểm và dịch vụ y tế đã gia tăng một
cách chóng mặt. Rải rác trên báo Mỹ là rất nhiều trường hợp điển
hình. Đại khái, nhiều khách hàng đã thấy trong các chương trình do
các trung tâm phối hợp đề nghị những tăng giá lạnh người: cho cùng
những điều kiện chữa trị như trước, tiền bảo phí tăng 260%, tức là
tăng gần gấp 4 lần; tiền trả mỗi khi đi bác sĩ hay nhà thương (co-pay)
tăng 40%, trong khi tiền túi phải trả trước (deductible) tăng từ 500 đô
lên tới... 12.600 đô! Báo Chicago Tribune cũng cho biết qua 22 chương
trình bảo hiểm của tiểu bang Illinois, tiền bảo phí nói chung tăng
chút đỉnh, nhưng số tiền trả trước tăng từ vài trăm lên đến trung
bình 8.000 đô cho một gia đình.<br/><br/>Nhiều người thấy chi phí bảo hiểm quá đắt đã quyết định sẽ không
mua bảo hiểm và chịu đóng phạt. Để rồi họ khám phá ra nếu không
đóng tiền phạt thì Sở Thuế IRS sẽ coi như… trốn thuế và có quyền
sai áp nhà cửa, xe cộ, giữ lương, khoá trương mục ngân hàng, và cuối
cùng bắt đi tù như một kẻ phạm tội lớn. Người ta còn nhớ TT Obama
đã khẳng định tiền phạt không phải là thuế, nhưng Tối Cao Pháp Viện
đã xác nhận đó chính là một loại thuế trá hình. Bây giờ thì Sở
Thuế IRS đã công bố áp dụng các biện pháp thu thuế và trừng phạt
như trốn thuế.<br/><br/>Theo thăm dò, trong ba người, vẫn có một người tin lời hứa hẹn của TT
Obama là Obamacare sẽ không tăng bảo phí. Bây giờ sự thật đã rõ. Trong
tương lai không xa, họ sẽ còn khám phá ra Obamacare sẽ bắt họ chờ dài
người mới lấy được hẹn với bác sĩ và nhà thương, và mua thuốc.<br/><br/>Không kể những vấn nạn lâu dài nêu trên, Obamacare hiện đang còn nhiều
trục trặc như tất cả các luật mới. Nhiều người rộng lượng cho rằng
Obamacare cần hai hay ba năm mới vận hành uyển chuyển trơn tru được,
cần thông cảm. Thực tế, dân Mỹ không có tính khoan dung đó. Hai hay ba
năm có nghiã là qua khỏi kỳ bầu cử giữa mùa năm 2014, hay thậm chí
dính vào năm bầu cử tổng thống 2016 không chừng. Trong những mùa tranh
cử đó, nếu Obamacare chưa ổn định, thì đó sẽ là đề tài tranh cử
lớn và phe đối lập Cộng Hòa sẽ không bỏ qua cơ hội. TT Obama và đảng
Dân Chủ cần phải hoàn chỉnh Obamacare trong vòng vài tháng tới nếu
không muốn gặp đại họa trong hai mùa tranh cử tới.<br/><br/>Obamacare dù luộm thuộm, đầy lỗ hổng, và có nhiều hậu quả thật tai
hại, cũng đã thành luật và mọi cố gắng để thu hồi luật đều có
rất ít hy vọng thành công. Đảng Cộng Hòa cần nhìn nhận sự thật này
và cố gắng tranh đấu cho những sửa đổi nhỏ hơn nhưng thiết thực hơn,
giúp kềm chế bớt những tác hại của Obamacare, thay vì khăng khăng đòi
thu hồi hay không phê duyệt ngân sách cho Obamacare, là những chuyện
không thể có được cho đến khi Cộng Hoà chiếm được Tòa Bạch Ốc,
Thượng Viện và Hạ Viện luôn.<br/><br/>Thực tế là Obamacare đã hoàn toàn thay đổi hệ thống y tế Mỹ. Trong
tương lai, chi phí y tế sẽ cao hơn cho tất cả mọi người, kể cả những
người đang lãnh Medicare và Medicaid, phẩm chất dịch vụ y tế (bác sĩ,
nhà thương, thuốc men) sẽ sa sút. Đó là cái giá phải trả để có bảo
hiểm y tế toàn dân. (20-10-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a212007/thuc-te-obamacare

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/