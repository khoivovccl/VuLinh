# Câu Chuyện Ông Phó Biden

21/10/2014



### Nguồn:

Viet Bao: https://vietbao.com/a228452/cau-chuyen-ong-pho-biden

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/