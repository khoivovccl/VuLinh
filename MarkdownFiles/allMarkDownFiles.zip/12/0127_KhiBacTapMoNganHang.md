# Khi Bác Tập Mở Ngân Hàng

14/07/2015



### Nguồn:

Viet Bao: https://vietbao.com/a240224/khi-bac-tap-mo-ngan-hang

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/