# Cách Biệt Giàu Nghèo

14/01/2014

...Bolsa từ một bãi tha ma trước 75 đã thành một trong những khu phố
phồn vinh nhất Mỹ...<br/><br/>Cách đây hơn một tuần, TT Obama từ Hawaii đả kích các vị dân cử Cộng
Hoà đã tỉnh bơ đi nghỉ lễ không cần biết cả triệu người sẽ mất
tiền trợ cấp thất nghiệp qua đầu năm mới, rồi mới đây, ông tiếp tục
tấn công đối lập Cộng Hoà là mấy ông bà nhà giàu bất cần biết số
phận của dân nghèo, vui vẻ chấp nhận cách biệt giàu nghèo ngày một
lớn trên xứ Mỹ này.<br/><br/>Những đả kích này khó có thể… giả dối hơn được. TT Obama chỉ trích
đối lập đi nghỉ hè không lo việc nước đúng lúc chính ông và gia đình
đang tắm biển tại Hawaii. Ông cũng quên là chẳng phải chỉ có mấy ông
bà dân cử Cộng Hoà đi nghỉ mà các ông bà dân cử Dân Chủ cũng đi
nghỉ lễ và cả quốc hội đóng cửa. Cả nước nghỉ lễ, năm nào cũng
vậy. Ông đả kích mấy ông Cộng Hoà “nhà giàu” không lo cho dân nghèo trong
khi ông và gia đình đi nghỉ lễ hai tuần tốn sơ sơ có tám triệu đô
tiền thuế do rất nhiều người nghèo hơn ông đã đóng góp (không kể ông
trả tiền túi 50.000 đô thuê một biệt thự trong hai tuần).<br/><br/>Quý độc giả theo dõi tin thời sự để ý sẽ thấy Nhà Nước Obama mới
tung ra một chủ đề chính trị: san bằng cách biệt giàu nghèo, tạo
công bằng xã hội. Đây là một chủ đề mới được tung ra sau khi Đức
Giáo Hoàng nêu lên vấn đề bất công xã hội trên thế giới. Chủ đề này
mau mắn được chính quyền Obama ôm chầm lấy.<br/><br/>Đức Giáo Hoàng Francis, từ hành động, lời nói, đến chính sách đã
khác xa các vị giáo hoàng tiền nhiệm. Ông có tư tưởng cấp tiến khá
mạnh so với các vị tiền nhiệm, cũng như là so với giáo lý Thiên
Chúa Giáo. Đến độ đã bị nhiều người cho là có tư tưởng thiên tả,
theo xã hội chủ nghiã –socialism- và thậm chí gần với mác-xít.<br/><br/>Những chỉ trích này dĩ nhiên đã đi quá xa, khiến Đức Giáo Hoàng đã
phải phủ nhận và giải thích. Và ông đã giải thích bằng cách xác
nhận chủ nghiã mác-xít là sai lầm lớn, và chủ nghiã tư bản cũng
chẳng khá hơn nhiều, và thế giới ngày nay có nhu cầu phải làm giảm
cách biệt giàu nghèo ngày một lớn hiện nay.<br/><br/>TT Obama đã nhận ra ngay một chủ đề có thể rất ăn khách và đã ca
tụng Đức Giáo Hoàng ngay, cũng như đã không bỏ lỡ cơ hội nêu lại vấn
đề cách biệt giàu nghèo hiện nay của Mỹ. Bất công trong lợi tức
chắc chắn sẽ trở thành chủ đề của đảng Dân Chủ trong cuộc vận động
tranh cử năm nay. Có thể là qua hình thức cuộc chiến chống nghèo,
-war on poverty-. Trong thông điệp Tình Trạng Liên Bang -State of the Union-
mà TT Obama sẽ đọc trước lưỡng viện tháng tới, chắc chắn cuộc chiến
chống nghèo sẽ là chủ đề chính.<br/><br/>Thật ra, cuộc chiến giảm cách biệt giàu nghèo đã được TT Johnson khai
sinh ra chứ không phải mới lạ gì. Cuộc chiến có tính “đấu tranh giai
cấp” mỵ dân cũng luôn luôn được các ứng viên tổng thống Dân Chủ lôi ra
làm chủ đề mỗi khi có bầu tổng thống, từ ông chủ đồn điền đậu
phộng Jimmy Carter, đến các chính khách chuyên nghiệp Al Gore, John
Edwards, John Kerry, và Hillary Clinton. Người nào cũng là triệu phú
nhưng người nào cũng vỗ ngực tự cho là đấu tranh cho dân nghèo.<br/><br/>Từ nửa thế kỷ qua, Nhà Nước Mỹ đã chi ra hơn 16.000 tỷ cho cuộc
chiến này. Riêng trong một năm 2012, dưới TT Obama, Nhà Nước liên bang
đã chi 680 tỷ qua 126 chương trình chống nghèo, trong khi các chính
quyền tiểu bang và điạ phương chi 285 tỷ, vị chi gần 1.000 tỷ.<br/><br/>Kết quả? Năm 1964 khi TT Johnson phát động cuộc chiến chống nghèo, 19%
dân Mỹ được xếp hạng “nghèo”; ngày nay, con số chỉ hạ xuống được
tới 15%. Gần 2 triệu gia đình sống với $2 một ngày trong khi ông Bill
Gates nằm ngủ cũng đẻ ra mỗi ngày 45 triệu đô. Hơn thế nữa, ngày nay,
con số những người lãnh trợ cấp dưới hình thức này hay hình thức
khác, nhất là lãnh phiếu thực phẩm (thẻ EBT), đã lên đến những mức
cao nhất lịch sử hiện đại Mỹ. Năm 2012, 47 triệu gia đình sống một
phần hay toàn phần bằng phiếu thực phẩm trong khi cả nước Mỹ có
khoảng 115 triệu gia đình, tức là 40% dân Mỹ lệ thuộc vào foodstamps.
Hơn 600.000 người vô gia cư. Ai nói nước Mỹ giàu nhất thế giới?<br/><br/>Điều đáng nói là sau nửa thế kỷ mà đảng Dân Chủ vẫn phải hô hào
chống nghèo thì chỉ chứng tỏ các chính sách của Nhà Nước Mỹ từ
nửa thế kỷ qua chỉ là một chuỗi thất bại. Đúng ra họ phải thấy là
càng hô lớn thì lại càng chứng minh họ đã thất bại. Nếu họ thành công
thì xứ Mỹ này đã hết nghèo, hết bất đồng đều lợi tức, đâu cần
“cuộc chiến chống nghèo” gì nữa.<br/><br/>Tại sao thất bại? Câu trả lời thật giản dị. Không kể việc các công
chức xài vung vít và sự thiếu hiệu nghiệm của guồng máy thư lại
Nhà Nước, lý do thất bại chính là phe cấp tiến và đảng Dân Chủ đã
lấy giải pháp sai. Thay vì giảm nghèo bằng cách giải quyết căn gốc
của vấn đề thì họ đã giải quyết bằng cách vung tiền trợ cấp đủ loại.
Một người bị nóng lạnh, thay vì tìm đúng bệnh để uống thuốc cho
lành thì các chính quyền Dân Chủ chỉ biết đắp thêm mền cho người
bệnh đỡ lạnh.<br/><br/>Căn gốc của nghèo là ba vấn đề ai cũng biết: giáo dục, gia đình, và
việc làm.<br/><br/>Giáo dục là chià khoá mở cửa cho thiên hạ có dịp tiến thân, leo
những nấc thang xã hội. Nguyên lý này khỏi bàn thêm. Điều đáng nói
là chính sách giáo dục của Mỹ đã là một thất bại vĩ đại. Mỹ có
một số đại học hết sức uy tín đã đào tạo được không biết bao nhiêu
vĩ nhân. Nhưng đa số các đại học khác cũng như đại đa số các trường
trung học đều là thảm họa. Một thăm dò gần đây cho biết một phần tư
học sinh tốt nghiệp trung học nhìn vào bản đồ thế giới mà không
biết nước Mỹ ở đâu. Đại đa số các sinh viên đại học có học bổng để
chơi thể thao cho trường –basketball, baseball, football- đều có khả năng
đọc –reading skill- của một học sinh tiểu học.<br/><br/>TT Bush mà bà vợ là cô giáo, đã từng bắt tay với TNS cấp tiến Ted
Kennedy để đưa ra một kế hoạch cải tổ giáo dục, dựa trên việc cải
tiến thành quả của các trường. Học sinh có điểm cao, tỷ lệ tốt
nghiệp cao thì trường sẽ được Nhà Nước giúp tài trợ, thấp thì sẽ
mất tài trợ và nếu có phải đóng cửa thì... ráng chịu. Thầy giáo
cũng vậy, nếu học trò bết bát thì phải bị sa thải, có học trò
giỏi thì có thể được tăng lương.<br/><br/>Nhưng cuối cùng thì cuộc cải tổ đó đã không có kết quả như mong
đợi, vì hai lý do: Nhà nước thiếu tiền vì chi quá nhiều cho cuộc
chiến chống khủng bố trong nước cũng như ngoài nước; và sự chống
đối của các nghiệp đoàn giáo chức, không chấp nhận chuyện thưởng
phạt thầy cô qua thành tích mà chỉ muốn duy trì tính thâm niên, ngồi
lâu lên lão làng bất cần thành quả dạy học.<br/><br/>Ngày nay, dưới áp lực của các nghiệp đoàn là khối cử tri rường cột
của TT Obama, cuộc cải tổ giáo dục của TT Bush và TNS Kennedy chỉ còn
trên giấy tờ. Phong trào hợp pháp hoá ma túy –marijuana- hiện đang
bành trướng dưới sự cổ võ của các chính khách cấp tiến không giúp
gì cho việc giáo dục con em chúng ta. Việc bộ trưởng Tư Pháp Eric
Holder kêu gọi nới lỏng kỷ luật học đường nhất là đối với học sinh
da đen lại sẽ càng mang nền giáo dục Mỹ xuống dốc thêm.<br/><br/>Gia đình là nền tảng của xã hội, gia đình ổn định thì xã hội ổn
định, giá trị gia đình còn thì giá trị xã hội vững mạnh. Các
chính quyền bảo thủ coi trọng những giá trị luân lý nền tảng này
bao nhiêu thì các chính quyền cấp tiến coi nhẹ và muốn thay đổi bấy
nhiêu. Từ thời TT Clinton qua những lem nhem với cô Monica đến thời TT
Obama, nền tảng luân lý gia đình đã lung lay tận gốc rễ. Gia đình Mỹ
ngày nay không còn là một “gia đình” với bố mẹ con cái theo định
nghiã cổ điển "hủ lậu”, mà có thể là gia đình với hai bố mà
không có mẹ, hay hai mẹ mà không có bố, con cái nếu không là con nuôi
thì cũng là con cấy ghép hay mang bầu mướn. Liên hệ máu mủ ruột
thịt có hay không chẳng quan trọng nữa. Kẻ viết này vẫn bù đầu thắc
mắc không biết những đứa trẻ này lớn lên sẽ nghĩ thế nào về chuyện
hai bố hay hai mẹ này, và chuyện này sẽ ảnh hưởng lâu dài đến tâm
lý chúng như thế nào. Thắc mắc này sẽ cần ít ra hai chục năm nữa
mới có câu trả lời.<br/><br/>Thống kê chính thức cho thấy năm 1964 khi chương trình chống nghèo được
phát động, chỉ có hơn 6% trẻ em sinh ra mà không có bố. Ngày nay, tỷ
lệ này đã lên tới 40% nói chung, và 70% cho các trẻ em da đen. Việc
Nhà Nước sẵn sàng tung tiền trợ cấp nuôi các đứa con không bố này
chỉ có tác dụng khuyến khích các bà ham vui cứ tiếp tục sản xuất,
đã có Nhà Nước nuôi. Một điều mà mọi người đều quên: Nhà Nước có
thể nuôi nhưng chẳng thể nào dạy mấy trẻ em này, trong khi bố chúng
không có và mẹ chúng thì vẫn bận … ham vui.<br/><br/>Việc làm là nguồn lợi tức, không có việc làm là không có tiền vào,
mà không có tiền vào thì dĩ nhiên không thể … hết nghèo. Nguyên lý
ABC. Đáp số của các chính quyền Dân Chủ cấp tiến là cứ việc dúi
tiền trợ cấp vào tay thiên hạ. Từ trợ cấp thất nghiệp đến đủ loại
trợ cấp an sinh. Trong 5 năm cầm quyền, TT Obama đã chủ trì một tỷ lệ
thất nghiệp cao và lâu nhất lịch sử cận đại Mỹ. TT Obama có quyền
đổ thừa lên TT Bush, lên đối lập, lên tsunami Nhật, lên bất ổn chính
trị Trung Đông, lên đủ mọi thứ, nhưng sự thật là ông đã hoàn toàn
thất bại trong chính sách kinh tế, không vực kinh tế lên lại được, và
không tạo việc làm được cho thiên hạ.<br/><br/>Nền tảng gia đình mất, kỷ luật gia đình lỏng lẻo, giáo dục gia đình
không có, giáo dục nhà trường thiếu sót, trẻ con như vậy, làm sao ra
đời kiếm việc làm để tiến thân? Xã hội nói chung làm sao giảm nghèo
trong những điều kiện đó được? Có tung bao nhiêu tiền trợ cấp thì
cũng chỉ làm giảm bớt những khó khăn của người nghèo chứ không thể
làm họ giàu có lên được. Đắp thêm mền thì họ được ấm một chút
nhưng không thể hết bệnh. Chưa kể việc tung tiền như vậy chỉ khuyến
khích tính ỷ lại hay làm biếng của người nhận tiền thôi.<br/><br/>Chiến lược của đảng Dân Chủ trong cuộc vận động tranh cử năm nay sẽ
dựa trên cuộc chiến này, và thật sự đã bắt đầu với hai “chiến
dịch”: triển hạn trợ cấp thất nghiệp, và gia tăng mức lương tối
thiểu. Cũng vẫn là những giải pháp tiêu biểu cho cấp tiến: dúi tiền
cho thiên hạ.<br/><br/>Phiá Dân Chủ đòi gia hạn trợ cấp thất nghiệp thêm ba tháng, tốn sáu
tỷ rưỡi. Trợ cấp này, trên nguyên tắc luôn luôn có giới hạn theo thời
gian chứ không phải là loại trợ cấp vô hạn định. Nhưng trong suốt năm
năm qua, chính quyền Obama đã không giải quyết được nạn thất nghiệp
khi tỷ lệ thất nghiệp luôn luôn trên mức 7% theo cách thống kê chính
thức và trên 15% trên thực tế. Cao hơn nữa khi ta nhìn vào từng khối
dân, ví dụ như hơn 50% trong giới thanh niên da đen. Do đó, chính quyền,
với sự đồng ý của quốc hội, đã liên tục gia hạn trợ cấp thất
nghiệp không ai biết là bao nhiêu lần rồi. Lần cuối gia hạn cho đến
31/12/2013, tức là bây giờ lại phải gia hạn nữa. Phe Cộng Hoà chấp
nhận đề nghị này với điều kiện phải cắt giảm chi tiêu nơi nào khác
để có tiền chi trả mà khỏi gây thêm thâm thủng ngân sách. Phe Dân Chủ
không chịu cắt chi tiêu gì, đưa đến tranh cãi và bế tắc.<br/><br/>Mặt khác, khối Dân Chủ cũng đòi tăng mức lương tối thiểu từ $7.25 lên
$10.10. Phe Cộng Hoà chống lại vì quan điểm tăng lương tối thiểu sẽ
tăng gánh nặng lương lên các tiểu thương đang gặp khó khăn kinh tế, sẽ
khiến họ sa thải nhân viên, chỉ trầm trọng hoá nạn thất nghiệp và
trì trệ kinh tế.<br/><br/>Nhìn chung, quan điểm của khối cấp tiến là cứ tiếp tục vung tiền
trợ cấp dưới hình thức này hay hình thức khác cho “dân nghèo” mà
không cần biết hậu quả kinh tế tài chánh gì hết. Đó là cách mua
phiếu hiệu nghiệm nhất trong năm tranh cử, nhất là khi Nhà Nước Obama
không có thành tích nào khác để khoe trong khi Obamacare lại trở thành
một của nợ vĩ đại gây bất mãn tràn lan. Bù lại, phe Cộng Hoà bị kẹt
trong cái thế chống lại những biện pháp trên thì chỉ xác định lại
hình ảnh một đảng của nhà giàu không lo cho dân nghèo.<br/><br/>Nếu kẻ viết này có tiếng nói, sẽ “giới thiệu” cho chính quyền Obama
một phương thức, hay đúng hơn, một cái gương, giảm nghèo hiệu quả
nhất. Không cần nhìn đâu xa, chỉ nhìn vào cộng đồng người Việt chúng
ta thôi.<br/><br/>Tuyệt đại đa số dân tỵ nạn chúng ta đến đất Mỹ này với hai bàn tay
trắng, tức là thuộc hạng cùng đinh, nhưng bây giờ đại đa số thế hệ
tỵ nạn đầu đã bước vào giai cấp trung lưu, một số đã thành đại gia.
Chỉ một số ít, đặc biệt là trong giới HO, vẫn hoàn toàn tùy thuộc
vào trợ cấp của Nhà Nước, hệ quả tất yếu của cả chục năm tù cải
tạo bởi các “đỉnh cao trí tuệ loài người” đã khiến họ không còn
sức mạnh tinh thần và thể xác để tự lực cánh sinh. Đến thế hệ tỵ
nạn thứ hai, trẻ con tỵ nạn đã thành công một cách khó lường, từ
đứng đầu trong lớp –valedictorian- đến thành tài trong xã hội Mỹ đầy
chông gai cho dân thiểu số. Khu Bolsa từ một bãi tha ma trước 75 đã
thành một trong những khu phố phồn vinh nhất Mỹ.<br/><br/>Sự thành công của cộng đồng tỵ nạn Việt chúng ta không phải là
chuyện mèo khen mèo, mà là một thực tế mà các nhà xã hội học nên
lấy đó mà phân tích, mà nghiên cứu.<br/><br/>Chúng ta thành công vì đã trực diện đúng cách với ba cái căn gốc
lớn của nghèo đói: giáo dục, gia đình và việc làm. Gia đình tỵ nạn
chúng ta không bị đảo lộn bởi những tư tưởng “tiến bộ” quá mức, kỷ
luật gia đình vẫn còn rất mạnh. Trẻ con tỵ nạn vẫn còn được duy
trì trong kỷ luật, nề nếp gia đình, học hành chăm chỉ, do khuyến
khích hay áp lực mạnh của gia đình. Con người Việt ta cũng có tính
cần cù siêng năng, chăm chỉ làm việc, cũng như mang nặng cá tính độc
lập, thà làm việc cật lưng hay làm hai ba jobs, rất khó chịu khi phải
sống nhờ trợ cấp.<br/><br/>Trợ cấp liên tục của Nhà Nước không thể là giải pháp giảm nghèo vì
giải pháp đó chỉ tiếp tục giam hãm thiên hạ trong vòng tay của Nhà
Nước vú em bất tài. Nhà Nước có thể giúp cho mọi người có cơ hội
đồng đều, không có cảnh cá bé bị cá lớn nuốt, nhưng tự lực cánh
sinh, tự túc tự cường phải là mấu chốt của vấn đề. Và cái khả
năng tự lực đó tùy thuộc phần lớn vào các yếu tố chính đã nêu
trên: giáo dục, gia đình và việc làm. Vai trò của Nhà Nước là ban
hành các chính sách giúp nền giáo dục trở nên hữu hiệu hơn, giúp
củng cố những giá trị gia đình và vai trò của gia đình trong việc
giáo dục con em, và giúp vực lại kinh tế, tạo công ăn việc làm cho
mọi người. Đó là những giải pháp mà TT Obama cần chú tâm vào.<br/><br/>Đã đến lúc người Mỹ nên học cách thoát cảnh nghèo của dân tỵ nạn
ta thay vì trông cậy vào hết trợ cấp này đến trợ cấp khác, tức là
đòi tái phân chia lợi tức, lấy tiền “người giàu” chia lại cho “người
nghèo” nhân danh công bằng xã hội. Cái chủ nghiã chủ trương tái phân
chia lợi tức đã cáo chung từ hơn 20 năm rồi. (12-01-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: <a href="mailto:Vulinh11@gmail.com" target="_blank"><i>Vulinh11@gmail.com</i></a>. Bài của
tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a215349/cach-biet-giau-ngheo

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/