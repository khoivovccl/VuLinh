# Cộng Hoà Tự Đào Huyệt

28/01/2014

...phe cấp tiến coi như trúng số, được dịp đánh hội đồng TĐ Christie mệt nghỉ...<br/><br/>Tuy còn ba năm mới tới bầu cử tổng thống, nhưng cuộc chạy đua coi như đã bắt đầu.
Trong khi thế giới chạy đua tranh cử vài tuần hay vài tháng trước ngày bầu, thì
nước Mỹ luôn luôn khởi chạy từ ít ra là cả mấy năm trước. Cuộc vận động tranh cử
cho năm 2016 đã mở màn. Và mở màn một cách không mấy đẹp mắt, bằng một màn
“đánh hội đồng” những chuẩn ứng viên có triển vọng, dù chưa ai chính thức đăng
đàn.<br/><br/>Trong khi bên đảng Dân Chủ nhìn đi nhìn lại vẫn chỉ thấy một “danh sách” với
đúng một người, bà Hillary Clinton, thì bên đảng Cộng Hoà, danh sách thăm dò
nào cũng có ít ra là một tá chuẩn ứng viên, mà nhìn tới nhìn lui, không ông bà
nào đạt được 20% hậu thuẫn trong nội bộ đảng. Trong khi cả thế giới biết
Hillary là ai, thì hầu hết dân Mỹ giỏi lắm chỉ biết đến hai người trong danh
sách Cộng Hòa. Dân tỵ nạn ta chắc chẳng ai biết được một người nào. Tất cả một
tá chuẩn ứng viên đó đều là các chính khách Mỹ trắng, không có bà nào, cũng
không có ông da đen nào, và chẳng ai nghèo hết. Trong thời buổi “tiến bộ” ngày
nay khi mà mốt thời thượng là bầu cho ứng viên thiểu số như phụ nữ, dân da màu
hay nhà nghèo, đảng Cộng Hoà coi bộ không có nhiều hy vọng chiếm lại được Tòa Bạch
Ốc.<br/><br/>Đã vậy, đảng Cộng Hoà lại vẫn vướng mắc cái “bệnh” tự đào huyệt chôn mình. Hay
nói cho chính xác hơn, là đưa súng cho người ta bắn mình.<br/><br/>Ví dụ mới nhất là trong cuộc bầu tổng thống năm 2012 vừa qua. Trong cái khuynh
hướng “tiến bộ” vừa nêu ở trên, đảng Cộng Hoà đưa ra một ông chính khách da trắng,
chẳng những triệu phú mà lại còn ăn nói hàm hồ, tự nhiên phạng ra những câu khó
nghe kiểu như 47% dân Mỹ là dân sống nhờ oeo-phe chắc chắn sẽ bầu cho Obama để
tiếp tục ăn oeo-phe. Chưa cần đến truyền thông phe ta tiếp sức đánh hội đồng,
câu nói này bảo đảm ông Romney đã mất ít nhất 50% phiếu rồi. Hay hai ông ứng
viên thượng nghị sĩ, đang nắm chắc phần thắng trong tay, tự nhiên mở miệng nói
bậy bạ về chuyện phá thai, đi đến thảm bại trong cuộc bầu, làm Cộng Hòa mất cơ
hội chiếm đa số tại Thượng Viện.<br/><br/>Bây giờ thì... chuyện cũ tái diễn. Đảng Cộng Hoà lại một lần nữa, cố làm con
thiêu thân.<br/><br/>Đây là câu chuyện của Thống Đốc New Jersey, Chris Christie. Ông Christie là một
chính khách hiếm có, trên nhiều phương diện.<br/><br/>Ông là một người mà theo các thầy tướng Á Đông, không có tướng chút nào. Béo
phì, mà lại béo phì trong cái xứ mà “mình dây” như Obama mới là đúng mốt. Ông
cũng là một thống đốc bảo thủ Cộng Hoà trong cái tiểu bang cấp tiến Dân Chủ nặng.
Nhưng ông thành công vì tuy là bảo thủ, nhưng tương đối ôn hoà. Mà cách xử thế
cũng rất “uyển chuyển”. Trong Đại Hội Đảng Cộng Hoà tháng 8 năm 2012, ông là
người đọc bài diễn văn chính, mạt sát TT Obama không còn chỗ chê trước sự hò
hét hoan hô của cả ngàn đảng viên. Nhưng sau khi bão Sandy tàn phá New Jersey
và TT Obama mang tiền trợ cấp đến cho tiểu bang tháng Chạp năm 2012, thì ông ôm
chầm TT Obama như bạn tri kỷ từ kiếp trước, chứng minh cho thiên hạ thấy TT
Obama thật sự lo cho dân và được sự biết ơn của ông thống đốc Cộng Hoà, làm ông
ứng viên tổng thống Cộng Hoà Mitt Romney đau đầu mà không dám phàn nàn.<br/><br/>New Jersey là một trong những tiểu bang thành đồng của đảng Dân Chủ, luôn luôn
bầu cho Dân Chủ trong các cuộc bầu tổng thống. Cả hai thượng nghị sĩ đều là Dân
Chủ. Cuối năm 2009, đương kim thống đốc Dân Chủ, Jon Corzine, bất ngờ bị đánh bại
bởi ứng viên Cộng Hoà, ông Chris Christie.<br/><br/>Cuối năm 2013, ông Christie tái tranh cử, và thắng dễ dàng với tỷ lệ gần 61%
phiếu, một con số rất hiếm thấy trong các cuộc bầu cử Mỹ. Chiến thắng của ông
Christie mang rất nhiều ý nghiã cho tương lai của đảng Cộng Hoà cũng như tương
lai của cá nhân TĐ Christie.<br/><br/>Trước hết, chiến thắng này có nghiã là cáo phó do đảng Dân Chủ gửi đi khắp nơi
về cái chết của đảng Cộng Hoà có vẻ quá sớm. Đảng Cộng Hoà vẫn còn thu được hơn
60% phiếu, mà lại trong một tiểu bang thành đồng của Dân Chủ. Nhìn vào chi tiết
thắng cử, người ta nhận thấy TĐ Christie đã thu được 57% phiếu của phụ nữ, 51%
của dân gốc la-tinh, 64% của sinh viên đại học, 21% phiếu của dân da đen, 66%
phiếu của khối độc lập không theo đảng nào, và đặc biệt là tới 32% phiếu của cử
tri Dân Chủ. Toàn là những con số trong ước mơ của các ứng viên Cộng Hòa. Nếu đảng
Cộng Hoà đã bị khai tử thì làm sao có được những con số này?<br/><br/>Một điểm đáng chú ý: ông Christie đòi hỏi cải tổ sâu rộng Obamacare, nhưng
không tấn công Obamacare quá mạnh như đa số các chính khách Cộng Hoà.<br/><br/>Cho dù đây là chiến thắng của cá nhân ông Christie thì chiến thắng này cũng đã
mang về cho đảng Cộng Hoà một ngôi sao mới, có nhiều triển vọng tranh cử tổng
thống cuối năm 2016. Ngay sau khi ông Christie chiến thắng, một thăm dò của
Rasmussen cho thấy bà Hillary chỉ thắng ông Christie có 2%, trong vòng sai biệt
xác xuất. Dĩ nhiên, chúng ta không nên đặt quá nhiều ý nghiã vào cuộc thăm dò
này khi cả hai người đều chưa ai tuyên bố sẽ ra tranh cử và chưa ai đi vận động
gì hết, và nhất là còn ba năm nữa mới bầu.<br/><br/>Vấn đề lớn của ông Christie là tuy ông có thể có nhiều triển vọng trong cuộc bầu
cử tổng thống toàn quốc, nhưng khúc mắc là ông có đi xa tới đó được hay không.<br/><br/>Như ta biết, muốn trở thành ứng viên của đảng trong cuộc bầu toàn quốc, các ứng
viên đều phải qua cửa ải chạy đua nội bộ trong đảng, gọi là primaries, tức là bầu
sơ bộ.<br/><br/>Kinh nghiệm bầu cử chính trị Mỹ cho thấy phần lớn những người đi bầu trong các
cuộc bầu sơ bộ trong nội bộ đảng đều là những thành phần tương đối cực đoan của
đảng. Tham gia bầu sơ bộ tức là phải lặn lội đi bầu hai ba lần trong mùa đông
giá rét. Không phải là chỉ đến bỏ phiếu rồi về, mà phải tranh luận và biểu quyết
nhiều lần, vừa rắc rối vừa mất thời giờ. Các doanh nhân, những người đầu tắp mặt
tối đi làm, giới cao niên, phụ nữ, thành phần ít quan tâm đến chính trị,... thường
không có rảnh tham gia bầu sơ bộ. Ít khi một ứng viên ôn hòa có thể kích động
dân đi bầu sơ bộ cho họ, do đó, ứng viên ôn hoà khó có thể thắng trong các cuộc
chạy đua sơ bộ.<br/><br/>Vấn đề khá rắc rối trong đảng Cộng Hoà là hiện nay, các chính sách cấp tiến khá
nặng của TT Obama đã kích động khối bảo thủ đối lập và đưa ảnh hưởng của khối
Tea Party lên rất cao. Họ nhất định bằng mọi giá chống đối lại các chính sách cấp
tiến đó, trong đó đặc biệt là Obamacare. Đến độ họ đã biến thành những người
tranh đấu cho lý tưởng bảo thủ của họ một cách gần như quá khích, bất kể hậu quả
của các cuộc bầu cử.<br/><br/>Ông Christie là thành phần tương đối ôn hòa nếu so sánh với các “ngôi sao” khác
của đảng Cộng Hoà hiện nay như các TNS Marco Rubio, Ted Cruz, Rand Paul, là những
người trong khối Tea Party, hay dân biểu Paul Ryan (đứng cùng liên danh với TĐ
Romney năm ngoái). Ông Christie không phải là thần tượng của khối bảo thủ sẽ đi
bầu sơ bộ trong đảng Cộng Hòa.<br/><br/>Trong bối cảnh đó, người ta thấy rất khó cho ông Christie thắng trong cuộc chạy
đua nội bộ để trở thành ứng viên đại diện cho Cộng Hoà năm 2016. Ông sẽ bị áp lực
rất nặng nề của khối bảo thủ cực đoan. Nếu ông vẫn ôn hoà, sẽ không thắng được
cuộc bầu nội bộ, ngược lại, nếu chuyển hướng qua bảo thủ mạnh thì có thể thắng
nội bộ, trở thành ứng viên Cộng Hòa, nhưng sẽ mất phiếu trong cuộc bầu toàn quốc.<br/><br/>Dù sao thì ông Christie cũng đã nổi bật lên như ngôi sao sáng, có nhiều triển vọng
nhất trong đảng Cộng Hoà. Ít ra trong mắt của phe cấp tiến, vì họ đã bắt đầu mở
cuộc tấn công ông Christie.<br/><br/>Một cuốn sách mới phát hành, viết về cuộc tranh cử tổng thống giữa TT Obama và
TĐ Mitt Romney đã tiết lộ ông Romney đã từng cứu xét rất kỹ chuyện mời ông
Christie đứng chung liên danh làm ứng viên phó tổng thống, nhưng cuối cùng phải
bỏ ý định vì có khá nhiều vấn đề trong quá khứ chính trị của ông Christie.<br/><br/>Rồi tạp chí Time, ngay sau chiến thắng của ông Christie đã đưa ông lên mặt báo
và gọi ông là “con voi”, là biểu tượng của đảng Cộng Hòa, cũng là hình ảnh chế
riễu cái thân mập phì của ông Christie. Chiến lược gia Steve Murphy của đảng
Dân Chủ đã nhanh nhảu mô tả chính sách của TĐ Christie chỉ là “chính sách
Bush-Romney”, một chỉ trích bâng quơ chẳng có căn bản nghiêm chỉnh gì. Một cựu
phụ tá của TT Obama, Ben LaBolt, khuyên đảng Dân Chủ nên “đầu tư sớm” vào việc
tấn công TĐ Christie ngay từ bây giờ. Theo ông này, thà đánh sớm còn hơn để quá
trễ.<br/><br/>Trong khi phe cấp tiến dàn trận đánh phủ đầu ông Christie, thì ban tham mưu của
chính ông Christie lại tự dưng bưng cỗ cho họ xơi một cách lãng xẹc.<br/><br/>Tháng Chín năm ngoái, trong khi TĐ Christie đi vận động tái tranh cử thống đốc,
thì ban tham mưu của ông tìm đủ cách vận động hậu thuẫn của các chính khách Dân
Chủ như các dân biểu, nghị sĩ, và thị trưởng trong tiểu bang New Jersey. Thật
ra, ai cũng biết ông Christie đang được hậu thuẫn rất mạnh, chẳng cần hậu thuẫn
của mấy ông bà chính khách Dân Chủ này cũng dư sức thắng. Nhưng ông Christie muốn
chuẩn bị cho tương lai ra tranh cử tổng thống của mình, muốn có sự hậu thuẫn của
các chính khách Dân Chủ để chứng mình là người có thể thu hút được phiếu của khối
Dân Chủ, có triển vọng đắc cử tổng thống nhiều hơn là mấy ông bà chính khách bảo
thủ cực đoan của Cộng Hòa.<br/><br/>Trong các thị trưởng Dân Chủ, có ông thị trưởng thành phố nhỏ Fort Lee sát nách
New York, nối liền với New York bằng một cây cầu lớn lúc nào cũng kẹt xe qua lại
cho dù có 4 làn xe mỗi chiều. Ông thị trưởng Dân Chủ này từ chối không tuyên bố
ủng hộ ông Christie. Bà phụ tá chánh văn phòng của TĐ Christie liền liên lạc với
ông Giám Đốc lo về giao thông của tiểu bang, bàn chuyện trừng phạt ông thị trường
ngoan cố này. Ông Giám Đốc này, bạn thâm giao của TĐ Christie, hưởng ứng ngay,
ra lệnh cho cảnh sát giao thông đóng ba làn xe lưu thông trên cầu từ Fort Lee
qua New York trong bốn ngày cho dù chẳng có lý do sửa đường, hay tai nạn lưu
thông, hay bất cứ lý do gì khác, cốt ý để thiên hạ bị kẹt xe, tức giận, chửi
ông thị trưởng chơi. Đưa đến tình trạng ứ động xe khủng khiếp, hàng triệu người
ở Fort Lee đi làm, đi học, đi công chuyện tại New York bị trễ giờ tới ba bốn tiếng
trong bốn ngày đó.<br/><br/>Câu chuyện qua lâu rồi. Nhưng trong cái xứ dân chủ cởi mở nhất thế giới này,
trước sau gì thì những chuyện mờ ám, nhất là chuyện có tác động tai hại lên cả
triệu người, trước sau gì cũng lòi ra ánh sáng. Người ta khám phá ra hành động
của bà phụ tá và ông giám đốc. Nội vụ đổ bể, báo chí làm rùm beng. TĐ Christie
mau mắn họp báo tuyên bố không hay biết gì về việc làm của các viên chức của
ông, xin lỗi thiên hạ, đích thân đến văn phòng ông thị trưởng Fort Lee xin lỗi,
sa thải bà phụ tá và ép ông giám đốc từ chức.<br/><br/>TĐ Christie làm được một chuyện đáng khen là mau mắn nhận lỗi và lấy quyết định
trừng phạt phụ tá, không loay hoay chối cãi, trì kéo. Nhưng dù sao thì ông cũng
là người phải chịu trách nhiệm cho những hành động của các phụ tá, cho dù ông
không hay biết gì.<br/><br/>Và dĩ nhiên là phe cấp tiến coi như trúng số, được dịp đánh hội đồng TĐ
Christie mệt nghỉ. Tất cả các báo lớn như New York Times và Washington Post, và
các đài truyền hình lớn như ABC, CBS, NBC, CNN đều xúm lại khai thác. Đài truyền
hình MSNBC bỏ ra cả mấy ngày liền sỉ vả ông Christie từ sáng đến tối. Đối với
khối truyền thông phe ta, vụ kẹt xe này dĩ nhiên là chuyện tầy trời, lớn hơn gấp
bội những xì-căng-đan của chính quyền Obama như vụ Benghazi khi khủng bố giết
chết đại sứ và ba viên chức Mỹ, lớn hơn vụ NSA nghe lén cả triệu người dân, và
cũng lớn hơn cả vụ sở thuế IRS trù ẻo các tổ chức bảo thủ để giúp TT Obama tái
đắc cử.<br/><br/>Một vài chính khách Dân Chủ yêu cầu điều tra xem trong thời gian kẹt xe đó có
người bệnh nào vì kẹt xe cứu thương mà bị chết hay không để truy tố TĐ Christie
về tội giết người. Vài người khác đòi truy cứu luật lệ và Hiến Pháp tiểu bang để
xem TĐ Christie có vi phạm tội gì đáng bị đàn hạch và truất phế không.<br/><br/>Trong chính trị Mỹ hay bất cứ xứ nào khác cũng vậy, trả đũa những người chống đối
mình nằm trong “luật chơi”. Từ các TT Johnson và Nixon cho đến ngày nay. Cả bà
Hillary Clinton cũng mới bị khui có một danh sách những chính khách Dân Chủ, được
chấm điểm rõ ràng, với 1 điểm là đồng minh đáng tin hoàn toàn, và 7 điểm là phản
thùng, phải có biện pháp. TĐ Christie khẳng định không hay biết gì về quyết định
của đàn em, nhưng cho dù có biết thì cũng không có gì đáng ngạc nhiên. Cái đáng
ngạc nhiên là cái biện pháp làm kẹt xe thật vớ vẩn và ngu xuẩn.<br/><br/>Câu chuyện còn chưa ngã ngũ, nhưng hiển nhiên là TĐ Christie đã bị một đòn nếu
chưa phải là chí tử thì cũng đã thành một vết đen khổng lồ, sẽ bị khai thác đến
ngày tận thế. Thế đứng của ông trong cuộc chạy đua vào Toà Bạch Ốc đã lung lay
mạnh. Một thăm dò mới nhất cho thấy hậu thuẫn của TĐ Christie ngay trong tiểu
bang New Jersey, đã rớt gần 20 điểm, từ 65% xuống còn 46%. Người ngồi rung đùi
cười là bà Hillary Clinton.<br/><br/>Chưa hết.<br/><br/>Làm như thể chuyện này chưa đủ chôn đảng Cộng Hoà, một ngôi sao khác của Cộng
Hoà cũng vừa “xung phong” tự đào huyệt chôn mình luôn.<br/><br/>Đó là cựu Thống Đốc Virginia, ông Bob McDonnell, đã vừa bị công tố viện tiểu
bang truy tố ra toà về tội tham nhũng, nhận hối lộ khi còn làm thống đốc.<br/><br/>Tiểu bang Virginia là một tiểu bang “xôi đậu”, rất quan trọng trong cuộc bầu tổng
thống. Tiểu bang lúc sau này có khuynh hướng ngả về Dân Chủ. Bất ngờ, năm 2009,
ông Cộng Hoà McDonnell đắc cử thống đốc, mau mắn đưa tên tuổi ông lên như là một
ngôi sao sáng mới của Cộng Hoà, có nhiều hy vọng trở thành ứng viên tổng thống
năm 2016.<br/><br/>Nhưng rồi vụ truy tố tham nhũng xẩy ra. Thật ra, ngay cả báo Washington Post
cũng nhìn nhận việc truy tố này không có căn bản vững chắc, vì dựa trên sự kiện
ông McDonnell và bà vợ có nhận vài món quà. Nhưng nhận quà chỉ là tội nếu đó là
một trao đổi để người tặng quà có được một đặc quyền hay đặc lợi nào thôi. Và
việc này cho đến nay, chưa có chứng cớ vững chắc. Rất có thể ông McDonnell sẽ
trắng án như Washington Post tiên đoán. Nhưng dù sao thì câu chuyện cũng đã
thành một vết đen khổng lồ trong quá trình chính trị của ông McDonnell. Nếu ông
ra tranh cử tổng thống, câu chuyện sẽ bị truyền thông cấp tiến khai thác triệt
để, và sẽ khó tránh được chuyện cử tri nghi ngại, không bỏ phiếu.<br/><br/>Cuộc vận động tranh cử tổng thống năm 2016 chưa chính thức bắt đầu mà ta đã thấy
hai ngôi sao sáng của đảng Cộng Hoà, nếu chưa tắt ngúm thì cũng đã phai mờ rất
nhiều. (26-01-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com.
Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a216494/cong-hoa-tu-dao-huyet

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/