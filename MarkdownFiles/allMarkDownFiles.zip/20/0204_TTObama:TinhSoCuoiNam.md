# TT Obama: Tính Sổ Cuối Năm

31/12/2013

Đấng Tiên Tri đã lộ rõ mất hết phép màu rồi...<br/><br/>Không cần phải là chuyên gia chính trị hay sử gia gì, ai cũng có thể
nhận định năm 2013 đã là một năm đại họa chưa từng thấy cho TT Obama,
đưa đến việc tỷ lệ hậu thuẫn của TT Obama xuống thấp hơn cả tỷ lệ
của ông tổng thống “cao bồi đáng ghét” Bush. Từ tổng thống tái đắc
cử xuống thấp hơn ông cao bồi trong chưa tới một năm: chuyện khó tin
nhưng có thật. Chỉ vì quá nhiều chuyện xẩy ra đã phơi bày ra khả
năng thực của Đấng Tiên Tri. Nói chung, 5 biến cố lớn trong năm qua đã
định vị lại thế đứng của TT Obama.<br/><br/>VỤ SNOWDEN<br/><br/>Anh chuyên gia tình báo NSA Snowden bất ngờ đào ngũ, mang năm cái laptop
chứa đầy tin bí mật về việc cơ quan an ninh quốc gia NSA theo dõi cả
triệu người, đi bán cho Trung Cộng và Nga. Trên thực tế, an ninh theo
dõi dân là chuyện bình thường, cho dù là trong các chế độ tự do dân
chủ Mỹ và Tây Âu, không có gì lạ. Cái đáng nói là tầm mức quy mô
vĩ đại chưa từng thấy dưới chế độ Obama, vượt xa gấp trăm gấp ngàn
lần dưới thời Bush.<br/><br/>Với khả năng tân tiến cực kỳ của tin học Mỹ, Nhà Nước Obama đã có
thể nghe lén bất cứ cuộc điện đàm nào của bất cứ ai từ bất cứ nơi
nào, ghi lại tên của bất cứ người nào lên trang mạng nào, và đọc
được bất cứ i-meo nào của bất cứ ai. Mỗi ngày hàng tỷ mẫu tin được
ghi lại, lưu trữ trong các dàn máy chứa dữ liệu trong các nhà kho
lớn hơn các sân đá banh của NSA.<br/><br/>Trên căn bản, đó là cách Nhà Nước theo dõi và ngăn chặn mọi tấn công
của khủng bố để tránh một 9/11 thứ hai. Đây là chuyện tất cả chúng
ta cần tri ân Nhà Nước đã tích cực bảo vệ chúng ta. Bin Laden chỉ vì
một sơ xuất nhỏ của một cận vệ, nói chuyện điện thoại chỉ trong
vòng vài phút cách nơi trú náu của Bin Laden cả chục cây số, là đã
bị thu thanh và Mỹ đã truy ra ngay chỗ trốn và bị giết chết.<br/><br/>Nhưng vấn đề là Nhà Nước đã lợi dụng nước đục thả câu, bành trướng
một chương trình theo dõi khủng bố thành một chương trình theo dõi cả
nước. Làm như thể cả nước, cả ba trăm triệu dân Mỹ đều là khủng bố
đáng nghi, cần theo dõi. Khi mà cả nước trở thành tình nghi thì quả
là nước Mỹ đã có vấn đề lớn.<br/><br/>Không những vậy, cả các nhà báo cũng bị theo dõi rất kỹ. Rõ ràng
đây không còn là chuyện đề phòng khủng bố nữa. Ngày xưa, TT Nixon cho
thiết lập một danh sách vài nhà báo không có thiện cảm với chính
quyền để theo dõi, và vấn đề trở thành một xì-căng-đan, biểu tượng
cho tính mánh mung độc tài của Nixon. Bây giờ lịch sử tái diễn, TT Obama
theo dõi nhà báo, nhưng lạ lùng thay, câu chuyện đã không thành
xì-căng-đan vì được các cơ quan truyền thông lớn giúp khỏa lấp rồi
ém nhẹm luôn.<br/><br/>Vụ Snowden còn đưa ra ánh sáng chuyện Nhà Nước Obama theo dõi dân và
chính quyền của cả chục quốc gia khác, kể cả các nước đồng minh
truyền thống như Anh, Pháp, Đức,... Rồi còn đặt máy nghe lén các
quốc trưởng hay thủ tướng các nước đồng minh lớn và cấp lãnh đạo
của không biết bao nhiêu nước khác.<br/><br/>Cũng như những chuyện theo dõi dân, việc theo dõi các chính phủ đồng
minh thật ra cũng không phải là chuyện mới lạ vì đã có từ ngàn xưa.
Nhưng dưới thời Obama, đã bành trướng đến mức thu lén điện thoại
riêng –chứ không phải điện thoại trong văn phòng- của những nhân vật
như bà Merkel, thủ tướng Đức. Bà có thủ thỉ tâm sự gì với chồng
con, hay gọi cho bác sĩ xin thuốc táo bón cũng bị Obama nghe hết. Đã
vậy Nhà Nước Mỹ không biết “chùi mép” cho kỹ, lại còn để lộ cho cả
thiên hạ biết. Từ trước đến giờ, các nước đồng minh đều hiểu ngầm
là có theo dõi lẫn nhau, nhưng im lìm, hiểu ý nhau, không quá lộ
liễu, không ai mất mặt quá đáng. Bây giờ bà Merkel bị đặt trong cái
thế hết sức mất mặt, chứng tỏ an ninh Đức rất tồi tệ, đồng minh soi
mói đời tư của mình, và bà không thể nào không lên tiếng phản đối.<br/><br/>Mối quan hệ giữa Mỹ và đồng minh chưa bao giờ sứt mẻ trầm trọng như
bây giờ. Hơn xa thời TT Bush là người thường bị truyền thông phe ta tố
cáo là cao bồi một mình một ngựa không coi đồng minh ra gì.<br/><br/>Vụ Snowden cũng phơi ra ánh sáng quan hệ ngày càng tồi tệ với các
“đối tác chiến lược” Trung Cộng và Nga. Bất chấp mọi phản đối, áp
lực, vận động hậu trường của chính quyền Obama, TC và Nga đều bất
hợp tác với Mỹ trong vụ Snowden. TC giữ anh này tại phi trường Hồng
Kông một thời gian, đổi lấy không biết bao nhiêu tin bí mật an ninh Mỹ,
rồi cho anh ta lên máy bay đi Nga. TT Putin đi xa hơn nữa, cho anh ta tỵ
nạn chính trị tại Nga. Không còn gì mỉa mai hơn là ông KGB Putin cho
một công dân Mỹ tỵ nạn chính trị tại Nga để “bảo vệ quyền tự do ngôn
luận” của anh này.<br/><br/>Cái nguy hại là không ai biết rõ anh Snowden này có bao nhiêu bí mật
trao cho Nga đổi lấy quyền tỵ nạn. Bất cứ người nào đã từng xài
laptop đều biết khả năng lưu trữ dữ liệu của một laptop không phải là
nhỏ, mà laptop của anh Snowden là laptop của NSA chứ không phải loại
bán ở chợ trời. Mà anh mang theo tới 5 cái. Báo Anh The Guardian, là
báo đã xì hàng loạt tin bí mật của anh Snowden cho biết những tin họ
xì ra là chưa tới 10% những tin họ đã được anh Snowden cung cấp. Hơn
thế nữa, họ cũng không biết những tin họ có là bao nhiêu phần trăm
của những tin anh Snowden đang có, và có thể cung cấp cho Nga.<br/><br/>Vụ anh Snowden đã có những hậu quả cực kỳ tai hại trong phạm vi an
ninh tình báo, liên hệ đối ngoại với đồng minh cũng như với các nước
ít thân thiện hơn, nhưng quan trọng nhất, đã phá tan lời hứa và khẩu
hiệu “một Nhà Nước trong sáng” –transparent- của TT Obama, cũng như
khiến cả nước lo sợ chuyện mất hết quyền bảo vệ chuyện riêng tư
–privacy right- của mỗi người, một ưu tư không nhỏ của người dân Mỹ.<br/><br/>VỤ IRS<br/><br/>Sở thuế IRS trên nguyên tắc là một cơ quan của Nhà Nước, nhưng tuyệt
đối không dính dáng vào các chuyện chính trị phe đảng, từ hồi nào
đến giờ. Chỉ có nhiệm vụ thu thuế theo đúng luật thôi.<br/><br/>Bây giờ, dưới chính quyền Obama, sở thuế đã trở thành công cụ chính
trị, hay nói cho đúng hơn, công cụ tranh cử tổng thống để bảo đảm
tổng thống đương nhiệm được lợi thế trong cuộc bầu tổng thống.<br/><br/>Trên nguyên tắc theo luật pháp, một số các tổ chức chính trị có mục
đích vận động tiền bạc để giúp các ứng viên tranh cử các chức vụ
chính trị phải ghi danh và được sở thuế IRS nhìn nhận thì mới được
hoạt động, tức là đi thu tiền vận động mà không bị đóng thuế, và
những người góp tiền có thể khấu trừ tiền đóng góp mà không phải
công khai hoá tên tuổi cũng như được quyền khấu trừ thuế cá nhân của
mình.<br/><br/>Dưới chính quyền Obama, sở thuế IRS làm đủ cách để không cho các tổ
chức chính trị bảo thủ, đặc biệt liên quan đến phong trào Tea Party
có cơ hội hoạt động gây qũy. Các tổ chức này bị tra hỏi đủ chuyện,
bị bắt khai báo những người đóng tiền, đơn xin bị ngâm tôm cả mấy năm
trời, và dĩ nhiên không hoạt động được, không thu tiền và vận động
chống TT Obama được khi ông ra tái tranh cử năm 2012.<br/><br/>Một vi phạm Hiến Pháp và luật pháp không thể lộ liễu hơn.
Xì-căng-đan nổ ra, một vài viên chức hạng hai, hạng ba bị làm con
thiêu thân, mất chức, nhưng chỉ là thuyên chuyển qua việc khác, chẳng
mất quyền lợi gì đáng kể. Chẳng ai ra tòa, chẳng ai đi tù.<br/><br/>Quan trọng hơn nữa, dân Mỹ nhìn thấy Obama còn nguy hiểm hơn xa Nixon
ngày xưa. Dù sao Nixon chưa bao giờ dám nghĩ đến dùng IRS làm công cụ
tranh cử.<br/><br/>VỤ SYRIA<br/><br/>Trong chính trị Mỹ, đảng Dân Chủ từ xưa đến giờ vẫn nổi tiếng là
đảng rất yếu trong các vấn đề quốc phòng và quân sự. Khi nào ta yếu
hay nhát thì địch sẽ đánh, đó là bài học chính trị của lớp mẫu
giáo. Các cuộc chiến lớn trong lịch sử Mỹ do một nước địch phát
động đều xẩy ra dưới các thời tổng thống Dân Chủ. Từ Đệ Nhất Thế
Chiến (TT Wilson) đến Đệ Nhị Thế Chiến (TT Roosevelt), chiến tranh Cao
Ly (TT Truman), chiến tranh Việt Nam (TT Kennedy, TT Johnson). Đôi khi vì
nhu cầu thực tế, tổng thống Dân Chủ cũng bắt buộc phải đánh trước,
nhưng chỉ dám đánh bằng hoả tiễn hay máy bay từ trên mấy chục ngàn
bộ không chết một anh lính nào (TT Clinton ở Bosnia, Sudan, và
Afghanistan, TT Obama ở Yemen và Pakistan), hay đánh mà chết độ một
chục anh lính là tháo chạy ngay (TT Carter ở Iran, TT Clinton ở
Somalia).<br/><br/>Hình ảnh đó lại một lần nữa đã được TT Obama tô đậm cho rõ nét thêm
qua cuộc thử lửa tại Syria. Khi TT Assad đàn áp dân chống đối bằng xe
tăng, đại pháo, chết hàng chục ngàn người, dư luận thế giới bất
bình, áp lực các cường quốc Mỹ và Tây Âu phải có thái độ, như đã
từng làm ở Libya. Nhưng Syria không phải là Libya. Syria có quân lực
hùng hậu và thiện chiến, với dầy dặn kinh nghiệm chiến trường đánh
nhau với Do Thái từ mấy chục năm nay. Mỹ và các cường quốc đứng
ngoài viện cớ, viện lẽ đủ kiểu.<br/><br/>TT Obama cũng bị áp lực nặng, nghĩ ra kế hay: vạch lằn ranh đỏ, hăm
dọa nếu Syria sử dụng vũ khí hoá học thì Mỹ mới trừng phạt, hy
vọng Syria sẽ không dám làm gì. Không ngờ Syria coi như pha, sử dụng
vũ khí hoá học giết hàng ngàn dân. TT Obama loay hoay, luống cuống,
tiến thoái lưỡng nan, đánh không dám, không đánh không được. Thế giới
chứng kiến tận mắt cảnh bối rối, với những câu tuyên bố trống đánh
xuôi kèn thổi ngược, nay thế này mai thế khác. Chẳng ai hiểu Mỹ sẽ
làm gì, hay không làm gì. Đưa thế cờ vào tay cáo già KGB Putin để anh
này cầm cờ hoà bình phất lên, trở thành người hùng cứu thế giới
khỏi một cuộc chiến đẫm máu nữa, trong khi giữ được cái ghế tổng
thống cho anh tà lọt trung thành Assad. TT Obama vớ được cái phao: Mỹ
không cần phải đánh vì Syria sẽ hủy tất cả vũ khí hoá học, dưới
sự kiểm soát quốc tế.<br/><br/>Mọi người hoan hỷ. Chỉ có dân Syria tiếp tục bị đàn áp và giết mà
không ai dòm ngó tới nữa. Rồi chuyện kiểm soát và phá hủy vũ khí
hoá học thì... chẳng ai biết có đang diễn ra hay không nữa. Truyền
thông phe ta đã âm thầm chôn dấu chuyện Syria dùm cho TT Obama rồi. Không
ai còn thấy tin tức gì về Syria trên mặt báo hay trên tin tức truyền
hình nữa.<br/><br/>Dù sao, thiên hạ cũng đã nhìn thấy rõ bộ mặt thật và khí phách
của người hùng Obama khi đụng phải lửa.<br/><br/>VỤ NHÀ NƯỚC ĐÓNG CỬA TIỆM<br/><br/>Ứng viên Obama ra tranh cử với chiêu bài đại đoàn kết dân tộc, không
phân biệt Cộng Hoà hay Dân Chủ, trắng hay đen, cấp tiến hay bảo thủ,
nghèo hay giàu. Không bao lâu sau khi đắc cử, người ta đã thấy một
tổng thống Obama huyênh hoang tuyên bố “Chúng tôi thắng” để rồi sau đó,
ông được báo phe ta Washington Post nhận xét là “tổng thống tạo phân
hoá nhất lịch sử hiện đại Mỹ”.<br/><br/>Chỉ hai năm sau khi chiếm được Tòa Bạch Ốc, Thượng Viện, và Hạ Viện,
đảng Dân Chủ đã mất ngay thế đa số tại Hạ Viện, đưa đến bế tắc toàn
diện của guồng máy chính quyền Mỹ. Từ năm 2011 sau khi Hạ Viện lọt
vào tay Cộng Hoà, không còn một luật lớn hay một chương trình, kế
hoạch lớn nào được ra đời.<br/><br/>Phe chính quyền đổ lỗi cho đối lập phá đám. Mà quên rằng vai trò
của đối lập chính là “phá đám” chứ không phải là “gọi dạ bảo vâng”
như trong các chế độ “đỉnh cao trí tuệ loài người”. Và trong cái chế
độ dân chủ của Mỹ đó, vai trò của lãnh đạo là phải khôn khéo tìm
được giải pháp đủ ôn hoà để tạo được đồng ý và hợp tác của đối
lập. Và trong vai trò đó, TT Obama đã thất bại hoàn toàn.<br/><br/>Lần đầu tiên từ gần hai chục năm qua, Nhà Nước lại bị “đóng cửa
tiệm” mất mấy tuần vì không tìm được thoả thuận về ngân sách, tốn
mất sơ sơ có gần nửa tỷ đô trong vài tuần đó.<br/><br/>VỤ OBAMACARE<br/><br/>Đây là câu chuyện của năm 2013. Không có chuyện nào lớn hơn và cũng
không có chuyện nào thảm hại hơn. Ngay từ đầu thì đã hơn một nửa dân
Mỹ không ủng hộ luật đổi đời này rồi. Khi luật bắt đầu chập chững
những bước đầu tiên thì “trục trặc kỹ thuật” đã phá ngay huyền
thoại của một tổng thống và ê-kíp chuyên gia trẻ, tài giỏi, sẽ mang
nước Mỹ vào kỷ nguyên tin học tân tiến nhất. Một đòn nặng, nhưng lại
chỉ là món điểm tâm nhẹ. Món ăn chính là việc cả triệu người bật
ngửa ra khi thấy mình mất bảo hiểm đang có, phải mua bảo hiểm mới
đắt hơn, với điều kiện khó khăn hơn, có khi phải đổi nhà thương, bác
sĩ và thuốc luôn.<br/><br/>Tổng thống đã cam đoan là không ai bị mất bảo hiểm đang có mà? Một
là tổng thống không biết mình đang nói gì. Hai là tổng thống đã nói
láo. Cả hai giả thuyết, chẳng cái nào nghe được hay chấp nhận được.
“Bộ máy diễn giải và bào chữa” hoạt động toàn thời, nhưng cũng
chẳng có tác động gì. Lần đầu tiên đa số dân Mỹ cho rằng tổng thống
không còn đáng tin cậy được nữa.<br/><br/>Một tờ báo ở Tampa có một mục nổi tiếng trong làng báo Mỹ: mục
“Politifact”, chuyên lật tẩy những lời nói láo của các chính khách
bất kể thuộc đảng nào hay khuynh hướng nào. Tờ báo này đã “tuyên
dương” câu tuyên bố của TT Obama “Nếu bạn thích chương trình bảo hiểm y
tế của bạn, thì bạn có thể giữ nó” là “Câu Nói Láo Của Năm”, The
Lie of the Year! Báo phe ta Washington Post cũng có một mục tương tự,
tặng hình anh chàng Pinocchio mũi dài cho mỗi câu nói láo của chính
khách, 1 Pinocchio cho lời nói láo nhẹ, 4 Pinocchio cho lời nói láo
nặng. Câu tuyên bố của TT Obama được tặng 4 anh Pinocchio, hạng nhất.
Không hiểu làm sao TT Obama có thể giữ uy tín của một tổng thống sau
những giải thưởng này được? Mà đây là những giải thưởng dựa trên
thành tích có thật, chứ không giống như giải Nobel Hoà Bình có tính
kỳ vọng, chẳng dựa trên thành quả thực tế nào.<br/><br/>Thành quả để đời của TT Obama đã trở thành bộ luật bị chống đối
nhiều nhất lịch sử Mỹ. Theo thăm dò của CBS, trong 100 người, chỉ có
7 người muốn giữ luật y nguyên như TT Obama đề xuất. Người ta cũng
không nhớ nổi chính TT Obama đã thay đổi cũng như dời hạn áp dụng
Obamacare không biết bao nhiêu lần nữa. Một chuyện hy hữu trong lịch sử
lập pháp Mỹ. Một chứng tích hiển hiện cho khả năng thực của Đấng
Tiên Tri.<br/><br/>Ở đây có một câu chuyện đáng nghe. Bà Barbara Walters là một nhà báo
kỳ cựu, nổi tiếng trên các đài truyền hình lớn của Mỹ. Năm 2008, bà
công khai lên tiếng ca tụng và ủng hộ ứng viên Barack Obama, tăng uy tín
của ông này lên vài chục bực. Cách đây vài tuần, bà lên truyền hình
phân trần đại khái “tôi đã lầm, trước đây tôi tin Obama quả là một
Đấng Tiên Tri, -a messiah- đến cứu độ nước Mỹ, nhưng bây giờ mới thấy
tổng thống với khả năng thật kém”.<br/><br/>Điều lạ lùng là bà Walters đã dám công khai và rõ ràng nhận sai
lầm, nhưng điều lạ lùng hơn nữa là một người có nhiều hiểu biết và
kinh nghiệm chính trị như bà lại có thể đã có lúc tin Obama là một
Tiên Tri được. Thế mới hiểu được cái tài thôi miên thiên hạ của chính
khách Barack Obama. Và năm 2013, Đấng Tiên Tri đã lộ rõ mất hết phép
màu rồi. (29-12-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a215838/tt-obama-tinh-so-cuoi-nam

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/