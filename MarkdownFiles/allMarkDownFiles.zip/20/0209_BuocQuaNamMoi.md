# Bước Qua Năm Mới

07/01/2014

...bi quan nhất thì đối lập Cộng Hoà vẫn đủ sức giữ thế đa số tại
Hạ Viện...<br/><br/>Năm mới 2014 sẽ là một năm quan trọng trong chính trường Mỹ. Cuối năm
sẽ có cuộc bầu “giữa mùa”, bầu lại một phần ba thượng viện, hết
cả hạ viện, hàng loạt thống đốc cũng như dân biểu, nghị sĩ, và vô
số chức vụ cấp tiểu bang, từ cảnh sát trưởng đến quan tòa. Kết quả
những cuộc bầu này sẽ cho biết cử tri Mỹ vẫn còn ủng hộ TT Obama
và đảng Dân Chủ hay không, đến mức nào. Đi xa hơn nữa, kết quả bầu
bán cũng sẽ tác động mạnh lên cuộc bầu tổng thống năm 2016. Năm 2014
cũng sẽ là năm các ứng viên tổng thống của cả hai chính đảng sẽ
bắt đầu lộ diện, thăm dò dư luận và mở màn vận động tranh cử nếu
thấy có triển vọng.<br/><br/>Tuần trước, ta đã có dịp nhìn lại năm 2013 để thấy đó là một năm
thật đáng quên đối với TT Obama vì quá nhiều khó khăn. Nhìn về phiá
trước, năm 2014 không có vẻ gì là sáng sủa hơn, chỉ vì nhiều khó
khăn của năm qua vẫn còn đó, chưa giải quyết được, cộng thêm nhiều
vấn đề khác. Năm cái gai lớn của năm qua vẫn còn nguyên đó, chờ
quyết định cuối cùng:<br/><br/>- Vụ anh Snowden xì tin NSA theo dõi cả thế giới: cuộc tranh luận bước
qua ưu tư của chính quyền Obama là không biết anh này có những tin gì
đã bán cho Nga, không biết NSA có kẽ hở nào, có bí mật nào Nga đã
biết. Cũng không biết anh Snowden sẽ tung ra báo chí chuyện bí mật gì
nữa trong năm mới. Bây giờ, đang có tranh luận mới về vụ này: nên ân
xá anh Snowden để anh trở về Mỹ, đổi lấy việc chấm dứt cung cấp tin
mật cho Nga, hay không ân xá vì chẳng ai biết anh này đã cung cấp
những tin mật nguy hại đến mức nào cho Nga. Đúng là chuyện vớ vẩn
vì chẳng thấy anh Snowden có ý định muốn xin được ăn xá và trở về
Mỹ sống, hay ngưng xì tin bí mật.<br/><br/>- Vụ sở thuế IRS: Nhà Nước hứa sẽ điều tra kỹ và cải tổ nếu thấy
có sai lầm hay lạm dụng, nhưng cho đến nay, câu chuyện hình như đã bị
“lãng quên”, chẳng ai biết chuyện gì đang xẩy ra, và truyền thông phe
ta thông cảm, cũng không đăng tin gì nữa.<br/><br/>- Vụ Syria: TT Obama được Putin cứu thoát nạn và truyền thông giúp dấu
nhẹm luôn khúc gân gà Syria nên chẳng ai biết chuyện gì đang xẩy ra.
Chỉ thấy vài tờ báo loan tin Syria đã không tuân theo lịch trình phá
hủy vũ khí hoá học trước hạn 31/12/2013, trong khi TT Assad tiếp tục
giết quân chống đối trước sự im lặng của cả thế giới. Chưa ai biết
qua năm 2014, cuộc nội chiến sẽ ngã ngũ như thế nào và vấn đề vũ
khí hóa học có được giải quyết hay không, và nếu không thì TT Obama
sẽ làm gì? Không ai muốn bị kẹt vào thế tiến thoái lưỡng nan trước
đây nữa nên tốt hơn hết là cả thế giới tiếp tục... quay mặt ngó lơ.<br/><br/>- Vụ Nhà Nước đóng cửa tiệm: Hai bên Dân Chủ và Cộng Hoà đã thoả
thuận được một dự luật ngân sách cho hai năm tới, và TT Obama đã vừa
ký thành luật. Nhưng đó chỉ là cái khung ngân sách. Hàng ngàn chi
tiết sẽ còn được tranh cãi và có thể lại đưa đến bế tắc và... Nhà
Nước đóng cửa tiệm nữa.<br/><br/>- Vụ Obamacare: Trên căn bản, những trục trặc kỹ thuật đã được giải
quyết phần lớn, nhưng Obamacare sẽ trực diện những vấn đề lớn hơn
nhiều trong năm mới. Ta sẽ bàn nhiều hơn dưới đây.<br/><br/>Năm 2014 là năm đầu tiên Obamacare được áp dụng trọn vẹn. Tuy TT Obama
cho phép gia hạn việc áp dụng luật mới cho các bảo hiểm cá nhân và
bảo hiểm tập thể, nhưng phần lớn thiên hạ sẽ có bảo hiểm mới, cũng
như hầu hết các dịch vụ y tế cũng sẽ tuân thủ theo Obamacare, với hệ
quả bắt buộc là giá cả y tế sẽ gia tăng trong năm mới này, tuy không
tăng đều nhau, nhưng cũng đủ để gây bất mãn lớn trong khối cử tri
trung lưu.<br/><br/>Nhiều người có tính vị tha, bênh vực Obamacare bằng câu nói “tôi suy
nghĩ giản dị, chỉ thấy chúng ta hy sinh vài đồng để giúp cả chục
triệu người có an toàn y tế là điều tốt, thế thôi”. Một lý luận
không sai lắm trên lý thuyết chung chung, nhưng cũng không đúng hẳn trên
thực tế. Những người nói được câu nói này là những người tương đối
khá giả, có ít nhiều tiền dư của thừa, có khả năng làm... mạnh
thường quân. Không phải ai cũng vậy. Đối với đại đa số dân gọi là
“trung lưu”, đủ tiền sống đến cuối tháng không phải vay đầu này, mượn
đầu kia, là chuyện đáng mừng rồi. Bây giờ khi chi phí bảo hiểm tăng
gấp đôi, và chi phí nhà thương, bác sĩ tăng không biết tới đâu, thì
chuyện “hy sinh vài đồng” không còn là chuyện nói chơi nữa. Như đã
trình bày nhiều lần, không ai chống lại chuyện cung cấp bảo hiểm và
dịch vụ y tế cho những chục triệu người đang cần, nhưng với phương
cách của Obamacare, cái giá phải trả quá lớn trong khi kết quả chẳng
có gì bảo đảm. Trái lại.<br/><br/>Cả triệu người đã mất bảo hiểm y tế cá nhân đang có và sẽ phải mua
bảo hiểm mới đắt gấp đôi, gấp ba. Giá bảo phí (premium) tăng trong khi
tiền trả trước (deductible) và tiền phải trả mỗi lần (co-pay) cũng
tăng nhất loạt. Đắt gấp đôi, gấp ba không phải là “hy sinh vài đồng”.<br/><br/>Cả triệu người sẽ không mua bảo hiểm mà chịu đóng thuế (phạt) cho
Nhà Nước vì rẻ hơn. Trong khi Nhà Nước tăng thu nhập thuế phạt thì
các hãng bảo hiểm sẽ mất thu nhập bảo phí, và bắt buộc phải bù
đắp bằng cách lại gia tăng tất cả, từ bảo phí đến tiền đóng trước
hay trả mỗi lần. Gia tăng kiểu này không phải là chuyện “hy sinh vài
đồng”.<br/><br/>Cả triệu người nữa sẽ mất bảo hiểm tập thể của công ty để phải mua
bảo hiểm cá nhân đắt hơn nhiều. Không biết bao nhiêu người cũng sẽ bị
sa thải, hay giảm cấp xuống nhân viên bán thời. Mất việc là mất nồi
cơm gia đình, không phải là chuyện “hy sinh vài đồng”.<br/><br/>Đầu năm nay, ngoài Obamacare ra, TT Obama sẽ trực diện hai vấn đề cần
phải giải quyết sớm nhất: hết trợ cấp thất nghiệp và thiết lập
ngân sách liên bang.<br/><br/>Trợ cấp thất nghiệp từ ngày TT Obama nhậm chức đã được gia hạn liên
tục chẳng ai nhớ rõ bao nhiêu lần khi TT Obama không giải quyết được
nạn thất nghiệp. Cuối năm 2013, trợ cấp này lại hết hạn một lần
nữa cho hơn một triệu người vẫn thất nghiệp. Dĩ nhiên là không có
cách nào khác hơn là lại gia hạn nếu không muốn thấy cả triệu người
thất nghiệp này bị chết đói. Nhưng vấn đề là cứ tiếp tục biện
pháp vá víu này bao lâu? Làm sao chấm dứt nạn thất nghiệp để thiên
hạ không còn phải chià tay xin Nhà Nước tiền để sống qua ngày?<br/><br/>Nhìn xa hơn một chút là các vấn đề di dân, kiểm soát súng đạn, và
Trung Đông.<br/><br/>Câu chuyện di dân và súng đạn, một thời nổi đình nổi đám, lại một
lần nữa, chìm vào lãng quên, không khác gì thời TT Clinton, rồi TT
Bush. Đây là những vấn đề gai góc mà chưa ai có giải pháp.<br/><br/>Cả chục triệu di dân ở lậu chẳng những là một vấn đề luật pháp,
xã hội, y tế to lớn, mà cũng là một khối cử tri khổng lồ mà chính
khách nào cũng thèm thuồng. Đồng thời cũng là một đề tài tạo tranh
cãi lớn, một cục than hồng mà ai thò tay vào bốc chắc chắn bị
phỏng ngay. Bế tắc đưa đến tình trạng quái gở là ở Cali, một anh
gốc Mễ ở lậu, không có giấy phép cư trú chính thức, nhưng đậu bằng
luật và được cấp giấy hành nghề luật sư. Nói cách khác, theo luật
tiểu bang thì anh này không phạm tội gì, được làm luật sư, nhưng theo
luật liên bang thì anh ta là một tội phạm, có thể bị FBI của liên
bang bắt và trục xuất ngay. Ta sẽ có dịp xem TT Obama giải quyết tình
trạng tréo cẳng ngỗng này như thế nào. Có nhiều hy vọng là TT Obama
sẽ... quay mặt ngó lơ thôi.<br/><br/>Chuyện kiểm soát súng đạn, từ mấy chục năm qua, vẫn dậm chân tại
chỗ. Mỗi lần có một vụ tàn sát tập thể bằng súng, báo chí làm
rùm beng, dân biểu và nghị sĩ cũng không chịu thua, la ó om sòm, tổng
thống cũng nhẩy vào cuộc khua chiêng trống. Nhưng trăm lần đều như
một, vài tuần hay vài tháng sau là chuyện đâu lại vào đấy. Chẳng có
gì xẩy ra. Hầu hết các dân biểu, nghị sĩ, kể cả các tổng thống,
ông bà nào cũng được hội những người sở hữu súng (NRA) đấm mõm rất
kỹ, nên chỉ dám hò hết suông thôi.<br/><br/>Rồi lò lửa Trung Đông, với những lò thuốc súng Iran, Syria, Palestine,
Do Thái, Libya, Ai Cập, Iraq, Afghanistan, Pakistan có thể nổ tung bất
cứ lúc nào, trong khi chính sách đối ngoại của chính quyền Obama
chẳng có gì sáng tỏ, chân trong chân ngoài. Vì trách nhiệm đại
cường, trách nhiệm với Do Thái, và trách nhiệm của nước tạo ra bất
ổn tại Iraq và Afghanistan, Mỹ không thể phủi tay đứng ngoài, nhưng
nhập cuộc thì tình trạng quá phức tạp, vượt xa khả năng và ý định
của TT Obama. Đúng là tiến thoái lưỡng nan.<br/><br/>Một thành tích được TT Obama rầm rộ quảng bá là thỏa thuận với
chính quyền Iran về việc kiểm soát chương trình phát triển hạt nhân
của Iran. Chưa biết hai bên sẽ tuân thủ đến mức nào, chỉ biết hai
đồng minh lớn nhất của Mỹ ở Trung Đông là Do Thái và Ả Rập Saudi đã
lên tiếng cực lực chống đối thỏa hiệp này, mà Do Thái gọi là đã
“bán đứng” Do Thái. Ông tổng thống đắc cử nhờ suốt ngày hứa hẹn đã
tin vào những lời hứa hẹn của mấy thầy pháp Iran.<br/><br/>Ta cũng chưa quên vụ khủng bố tấn công toà lãnh sự Mỹ tại Benghazi,
cho đến nay vẫn còn... trong vòng điều tra. Chưa ai biết chính quyền
Obama tính câu giờ đến chừng nào, nhưng càng muộn tức là càng gần
ngày bầu cử cuối năm thì càng phiền, giúp cho Cộng Hoà có chuyện
tấn công.<br/><br/>Một vấn đề TT Obama hứa hẹn sẽ là trọng tâm của 2014 là nguy cơ hâm
nóng địa cầu. Đây là chuyện kiểu khoa học giả tưởng chẳng mấy ai
hiểu rõ, chỉ thấy hết bão tuyết lạnh cóng người này đến bão tuyết
lạnh cóng người khác trong khi các nhà khoa học tiếp tục cãi nhau.<br/><br/>Nhìn lại xã hội Mỹ, điều miả mai lớn là dưới một tổng thống mà
bình đẳng xã hội và đại đoàn kết dân tộc là mục tiêu lớn, nước Mỹ
lại trở thành một nước mà khoảng cách giàu nghèo đã leo lên mức
lớn chưa từng thấy. Trong khi gia tài của các tỷ phú tăng vọt 30%-40%
thì số người sống dưới lằn ranh nghèo, lãnh phiếu thực phẩm cũng
tăng lên mức cao nhất lịch sử Mỹ.<br/><br/>Với chính sách kinh tế của TT Obama, tỷ lệ thất nghiệp vẫn cao chót
vót, mức tăng trưởng kinh tế lẹt đẹt ở những tỷ lệ thấp nhất, trong
khi thị trường chứng khoán, là nơi phản ánh tài sản của khối nhà
giàu, lại tăng lên hơn 30% trong năm 2013. Nhà giàu ngày một giàu hơn.
Gia tài của tỷ phú Bill Gates tăng gần 16 tỷ trong năm, lên đến gần 80
tỷ. Nói cách khác, gia tài ông Gates tăng sơ sơ có... 45 triệu đô mỗi
ngày, kể cả trong những ngày cuối tuần ông nằm vắt cẳng ngủ nguyên
ngày.<br/><br/>Trong một bài diễn văn mới nhất, TT Obama đã ca tụng tân Giáo Hoàng
Francis đã có ưu tư về cách biệt giàu nghèo và bất công bằng xã
hội. Ta chờ xem trong năm tới hay ba năm tới, TT Obama sẽ làm được gì
để giảm khoảng cách này, ngoài việc tuyên bố mình chia sẻ ưu tư của
Đức Giáo Hoàng.<br/><br/>Tất cả những vấn đề trên, nếu chưa có giái pháp thoả đáng, bảo đảm
phe đối lập Cộng Hoà sẽ không bỏ qua trong các cuộc vận động bầu cử
kéo dài cả năm nay.<br/><br/>Những khó khăn của TT Obama thật ra là những khó khăn mà bất cứ tổng
thống Mỹ nào cũng gặp phải trong khi “quản trị” một nước lớn và
phức tạp như Mỹ. Vấn đề là những khó khăn này đã không được TT Obama
giải quyết thỏa đáng.<br/><br/>Diễn đàn Politico tham khảo ý kiến của cả chục tổng giám đốc các
đại công ty, cũng như các chuyên gia về quản trị, và kết luận chung
của họ là TT Obama đã không giải quyết được những khó khăn lớn của
ông vì thiếu kinh nghiệm và khả năng quản trị một guồng máy hành
chánh vĩ đại. Ông là một chính khách “dẻo miệng”, có thể dùng lời
lẽ, ngôn ngữ thu phục lòng người, nhưng khi đụng phải vấn đề thì
không biết giải quyết như thế nào. Trong lịch sử cận đại Mỹ, ông là
người ít kinh nghiệm nhất, nếu không muốn nói là không có chút kinh
nghiệm nào. Vấn đề trở thành trầm trọng hơn khi chung quanh ông, phần
lớn lại là những phụ tá và cố vấn với những kinh nghiệm và khả
năng tương tự như ông, tức là chính trị mồm mép giỏi nhưng khả năng
quản lý không có. Những trục trặc kỹ thuật của Obamacare là một
bằng chứng không thể rõ ràng hơn.<br/><br/>Vấn đề đi xa hơn chuyện kỹ thuật quản lý bộ máy hành chánh. TT Obama
cũng đã thất bại trong các chính sách: đối nội quá cấp tiến, xa hơn
những quan điểm nền tảng của dân Mỹ, đối ngoại quá luộm thuộm và
sai lầm, không có một “thành quả” nào đáng khoe khi thù chưa giảm mà
bạn lại bớt.<br/><br/>Những khó khăn trong năm tới có thể không phải là những cái nhức đầu
lớn cho TT Obama vì dù sao thì ông cũng đã được bảo đảm một phòng
ngủ trong Tòa Bạch Ốc cho tới đầu năm 2017. Nhưng sẽ là những đau đầu
lớn cho hàng ngàn chính khách của đảng Dân Chủ sẽ phải đối đầu với
cử tri trong năm mới này.<br/><br/>Obamacare dĩ nhiên là một đại hoạ sẽ giết cả đảng nếu cuộc bầu cử
được tổ chức trong tháng này. Một thăm dò mới nhất của CNN cho thấy
55% cử tri có ý định bỏ phiếu cho bất cứ chính khách nào chống lại
TT Obama, trong khi chỉ có 40% cử tri sẵn sàng bỏ phiếu cho các chính
khách ủng hộ TT Obama. Trong đảng Dân Chủ, chỉ có 22% cử tri cảm thấy
hăng hái muốn đi bầu, so với gần 40% cử tri Cộng Hòa sốt sắng.<br/><br/>Tỷ lệ hậu thuẫn chung của TT Obama, theo thăm dò của khoảng một tá
tổ chức, lảng vảng trong vòng từ 38% đến 43%, thua xa tỷ lệ đắc cử
52% cách đây một năm. So với hậu thuẫn cùng thời điểm này của các
tổng thống tiền nhiệm thì TT Obama thấp thứ nhì, chỉ cao hơn TT Nixon,
và thấp hơn TT Bush con.<br/><br/>May thay cho đảng Dân Chủ, còn cả năm nữa mới tới ngày bầu. Chính
quyền Obama hy vọng sẽ có đủ thời giờ chỉnh sửa những “trục trặc
kỹ thuật” của Obamacare, cũng như vận động lấy hậu thuẫn lại cho
Obamacare. Nhưng trục trặc kỹ thuật chỉ là chuyện nhỏ. Chuyện lớn là
việc thiên hạ mất bảo hiểm, bảo hiểm cá nhân và nhất là bảo hiểm
tập thể do công ty cung cấp. TT Obama đã mánh mung, miễn áp dụng
Obamacare trong một năm, cho tới đầu năm 2015, tức là sau cuộc bầu
tháng Mười Một 2014. Nhưng xảo thuật này chỉ khỏa lấp được một phần
nhỏ những hậu quả tai hại của Obamacare.<br/><br/>Các chuyên gia chính trường Mỹ ước đoán trong tình trạng bi quan nhất
thì đối lập Cộng Hoà vẫn đủ sức giữ thế đa số tại Hạ Viện, và
nếu lạc quan hơn thì có nhiều hy vọng chiếm luôn được đa số tại
Thượng Viện. Cho dù không chiếm được đa số tại Thượng Viện thì Cộng
Hoà cũng có thể sẽ chiếm được thêm 5 hay 6 ghế tại Thượng Viện, sẽ
trói tay TT Obama thêm một chút.<br/><br/>Đảng Cộng Hoà đang cố gắng tập trung mọi nỗ lực để đoạt thế thượng
phong tại quốc hội, chẳng những có thể ngăn cản được các chính sách
cấp tiến của TT Obama trong hai năm cuối của ông, mà còn có thể giữ
thế cân bằng chính trị lâu dài nếu bà Hillary Clinton đắc cử tổng
thống kế nhiệm TT Obama như nhiều người dự đoán. (05-01-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a214309/buoc-qua-nam-moi

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/