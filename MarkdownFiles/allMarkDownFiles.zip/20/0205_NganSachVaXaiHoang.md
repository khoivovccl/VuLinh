# Ngân Sách Và Xài Hoang

24/12/2013

...dự luật ngân sách mới cũng không khác gì... món cháo lòng.<br/><br/>Đại Cường Cờ Hoa từ ba năm nay đã ở trong một tình trạng quái lạ
hết sức: cả nước không có ngân sách hàng năm gì cả. Trên căn bản,
không có tổ chức kinh doanh nào có thể hoạt động mà không có ngân
sách, và dĩ nhiên quan trọng hơn nữa, không có quốc gia nào có thể
hoạt động mà không có ngân sách. Nhưng đó lại là tình trạng của
nước Mỹ dưới triều đại Obama. Từ mấy năm qua, giữa hành pháp và lập
pháp, cũng như giữa hai chính đảng Dân Chủ và Cộng Hòa, đã không có
được sự thỏa thuận để Nhà Nước có được một ngân sách đàng hoàng
hàng năm. Kết quả là mấy phe cò cưa, điều đình, trả giá, trong tình
trạng thường trực để có được những ngân sách kiểu chắp nối, vá
víu, cho qua ngày, mỗi lần giằng co qua lại, lòi ra được một ngân sách
tạm cho ba tháng, bẩy tháng, năm tháng,...<br/><br/>Đã vậy, Nhà Nước Obama ngay từ những ngày đầu đã chi xài rất mạnh
tay, mà toàn là bằng tiền vay mượn. Mỗi lần xài là đi vay, vay vài
lần là đụng trần quốc hội cho phép, bị đe dọa không được vay nữa,
có nguy cơ không đủ tiền trả nợ, bị hăm giảm điểm tín dụng và tăng
lãi suất đồng loạt, lại điều đình giằng co, nâng mức nợ lên chút
ít, rồi lại mau mắn đụng trần lại. Chu kỳ tái diễn, lập đi lập lại.
Một chính sách tài chánh quốc gia không chính sách gì hết. Tùy cơ
ứng biến, từ đe dọa này nhẩy qua khủng hoảng nọ.<br/><br/>Một trò đùa chính trị cực kỳ tốn kém và nguy hại vì Nhà Nước và
cả ngàn cơ quan của Nhà Nước không thể thiết lập được chương trình
hay kế hoạch dài hạn nào hết. <br/><br/>Vấn đề then chốt cản đường cho mọi thỏa thuận là quan điểm về vai
trò của Nhà Nước trong việc quản trị cả nước. Và ở đây, ta cần lui
lại vài bước để nhìn vấn đề dưới khiá cạnh hệ tư tưởng.<br/><br/>Khuynh hướng bảo thủ chủ trương Nhà Nước đóng vai cảnh sát hay trọng
tài, bảo đảm guồng máy chạy trơn tru, không có những lạm dụng quá
mức, không có tình trạng cá lớn nuốt cá bé quá đáng, không có ai
bị chết đói hay chết nghèo hay chết bệnh mà không được cứu, hay nôm
na ra là bảo đảm một mạng lưới an toàn và ổn định tối thiểu. Trong
quan điểm này thì vai trò của Nhà Nước cần duy trì ở mức càng thấp
càng tốt, từ đó chi tiêu của Nhà Nước cũng giới hạn, và tiền thuế
của dân phải đóng cũng ở mức tối thiểu.<br/><br/>Khuynh hướng cấp tiến thì chủ trương thiết lập một Nhà Nước càng vú
em nhiều càng tốt, lo cho dân từ ngày lọt lòng đến ngày xuống huyệt
nếu có thể. Vì vai trò quan trọng này nên Nhà Nước cần tiền tối đa,
để chi tiêu tối đa cho dân, do đó, cũng cần phải thu thuế tối đa, kèm
với đủ loại phí cho các dịch vụ do Nhà Nước cung cấp. Một cách
gián tiếp, phân chia lại tài sản cả nước, lấy bớt tiền của những
người dư thừa, gọi là “giàu”, để chu cấp cho những người thiếu thốn,
gọi là “nghèo”.<br/><br/>Một bên tin tưởng vào khả năng và sáng kiến của mỗi người, mỗi cá
nhân, tôn trọng tự do cá nhân. Một bên tin vào khả năng và trách nhiệm
của guồng máy hành chánh, của các công chức và quan chức, mưu tìm
công bằng xã hội.<br/><br/>Cần phải nói ngay là quan điểm cấp tiến đi đến cực đoan đã được áp
dụng trong các chế độ cộng sản, còn được gọi là “xã hội chủ
nghĩa” theo văn chương mới sau khi bức màn sắt xụp đổ cuối thập niên
80 và danh từ “cộng sản” đã trở thành một ác mộng cho nhân loại.<br/><br/>Thật ra, công bằng mà nói, cấp tiến không phải là một cái tội, hay
một cái gì xấu xa. Trái lại, đại đa số những người có tư tưởng cấp
tiến là những người có lòng nhân ái hơn người, muốn lo cho thiên hạ
chứ không muốn hại ai.<br/><br/>Đức Giáo Hoàng Francis là người có tư tưởng cấp tiến rõ ràng, đến
độ nhiều người cực hữu đã tố ông là người có tư tưởng mác-xít.
Khiến ông không những phải lên tiếng phủ nhận ông không phải là thành
phần mác-xít, mà còn bênh vực và xác nhận tuy hệ tư tưởng mác-xít
sai lầm, nhưng cũng có nhiều người “tốt” trong số những người theo
mác-xít.<br/><br/>Đức Giáo Hoàng chẳng qua chỉ nói lên một sự thật hiển nhiên. Trong
cả triệu triệu người tin tưởng vào mác-xít, không phải tất cả đều
là người xấu hết. Cũng như trong cả triệu triệu người tin tưởng vào
chủ nghiã tư bản, không phải tất cả đều là người tốt hết. Vấn đề
không phải là cá nhân, mà là hệ tư tưởng. Và đúng như Đức Giáo
Hoàng nhận định, cái sai là chủ thuyết mác-xít với tất cả những
cái cực đoan của nó.<br/><br/>Vấn đề ở đây không phải là lý thuyết mơ hồ, cần công bằng xuông. Mà
là làm sao thực hiện được sự công bằng đó? Đến mức nào thì đạt
được thành công và đến mức nào thì thành thất bại, hay tệ hơn nữa,
trở thành nguy hại chung cho tất cả mọi người.<br/><br/>Câu trả lời, lịch sử đã cho ta thấy: cuối thập niên 80, toàn thể
khối CS sụp đổ. Còn lại lèo tèo vài nước CS thì cũng đã phải mau
mắn “đổi mới”, cắt giảm mức can thiệp của Nhà Nước tối đa, để rồi
biến thành một thứ quái thai, “kinh tế thị trường theo định hướng xã
hội chủ nghiã”, mà chẳng ai hiểu là gì, chỉ thấy các đại cán mau
mắn trở thành đại gia, trong khi nước vẫn nghèo, dân vẫn đói, chính
quyền vẫn nắm quyền bằng súng đạn và nhà lao.<br/><br/>Công bằng xã hội là điều không ai không mê, nhất là trong giới lợi
tức thấp. Ngay cả các trọc phú Mỹ như Bill Gates hay Warren Buffett
cũng muốn thấy công bằng xã hội nhiều hơn trong cái thành trì tư bản
Mỹ này. Dù sao thì đi xa hơn tính nhân đạo, công bằng xã hội cũng là
phương thức bảo đảm ổn định xã hội vững chắc nhất cho mấy ông trọc
phú yên ổn kiếm thêm tiền, chứ cũng chưa chắc mấy ông trọc phú đó
tốt lành gì đâu.<br/><br/>Nhưng cũng như bất cứ thứ gì trên cõi đời này, công bằng xã hội
cũng có mặt trái của nó, và cái giá phải trả, cho dù là chưa đến
mức cực đoan như trong các chế độ CS. Ta chỉ cần nhìn vào những xáo
trộn kinh tế và chính trị bên Âu Châu trong vài năm qua thì sẽ thấy.<br/><br/>Nhân danh công bằng xã hội, những chính sách cấp tiến nhất đã được
ban bố từ nhiều thập niên qua trên hầu hết các nước Tây Âu, kể cả
các đại cường Anh, Pháp, Đức,... Nhà Nước thu thuế xấp xỉ trên một
nửa lợi tức của thiên hạ (so với trung bình một phần năm ở Mỹ) để
chu cấp cho một hệ thống y tế gần như miễn phí cho tất cả mọi
người, chu cấp cho một chế độ an sinh rộng rãi về tiền thất nghiệp,
tiền hưu, tiền trợ cấp nuôi con, … Kết quả là hiện nay, hầu như toàn
thể Âu Châu đang trên bờ phá sản kinh tế, tuột hậu xa lắc so với phát
triển của Mỹ từ mấy thập niên qua.<br/><br/>Trở về câu chuyện nước Mỹ, đối với TT Obama, chính sách cấp tiến
của ông một mặt đã thu hút được cảm tình và phiếu bầu của hàng
triệu người thuộc giai cấp lợi tức thấp vì họ tin ông sẽ lo cho họ
như đã hứa hẹn; mặt khác cũng đã khiến ông bị tố là có khuynh
hướng “xã hội chủ nghiã” (socialist), tuy chưa đến mức mác-xít.<br/><br/>Thật ra, khuynh hướng cấp tiến của Mỹ không đi quá xa như vậy, còn
thua xa các chế độ cấp tiến Tây Âu. Chưa bao đồng đến độ cả nước
ngộp thở, chưa lấy thuế tới hơn một nửa lợi tức của ai hết. Nhưng
cũng đang “tiến nhanh, tiến mạnh”, tuy không “vững chắc” lắm về hướng
cực tả dưới sự lãnh đạo của TT Obama.<br/><br/>Tuy vẫn thua xa các chế độ khuynh tả Tây Âu, nhưng đó chính là nhờ
vào thể chế chính trị Mỹ đã không cho phép ông đi quá xa. Chỉ trong
hai năm nắm Tòa Bạch Ốc và được sự hậu thuẫn của đảng Dân Chủ kiểm
soát cả Thượng Viện lẫn Hạ Viện, TT Obama đã đi khá xa, khiến dân Mỹ
hoảng sợ, trao ngay Hạ Viện cho đảng đối lập Cộng Hòa năm 2010 để
thắng bớt chính sách cấp tiến của TT Obama lại.<br/><br/>TT Obama muốn gì và đối lập muốn gì?<br/><br/>Công bằng mà nói, TT Obama thừa hưởng một gia tài kinh tế và chính
trị không mấy hấp dẫn. Hai cuộc chiến cực kỳ tốn kém vẫn còn đó,
cộng thêm một cuộc khủng hoảng kinh tế và tài chánh lớn nhất kể từ
cuộc khủng hoảng đầu thập niên 30. Dĩ nhiên ông cần phải tung tiền ra
cứu nguy kinh tế, không có tam thập lục chước. Nhưng rồi ta cũng phải
nhớ lại câu nói của cựu cố vấn/chánh văn phòng Rahm Emanuel, “không
thể bỏ lỡ cơ hội khủng hoảng”. Lợi dụng chuyện cứu nguy kinh tế, TT
Obama tung ra hàng loạt biện pháp vú em, tăng chi tiêu Nhà Nước, tăng
trợ cấp đủ loại,... Thâm thủng ngân sách và mức nợ công tăng đến
chóng mặt như thể đến cuối nhiệm kỳ của Đấng Tiên Tri thì sẽ là
tận thế, không cần ai phải thắc mắc gì đến chuyện năm mười năm nữa,
ai sẽ trả nợ, trả bằng cách nào.<br/><br/>Thật ra, trong bài toán của TT Obama, quan điểm cấp tiến Nhà Nước bao
đồng là căn bản, nhưng ngoài ra, cũng còn yếu tố tranh cử lần thứ
hai, năm 2012. Và tung tiền trợ cấp ra cho thiên hạ dĩ nhiên là cách
mua phiếu hiệu quả nhất. Nước Mỹ ngày nay đã trở thành lệ thuộc
vào Nhà Nước hơn bao giờ hết. Những con số về người lãnh tiền thất
nghiệp, lãnh phiếu thực phẩm, lãnh trợ cấp, hay có medicaid, đều đã
đạt những kỷ lục chưa từng thấy. Người ta có thể nhìn vấn đề dưới
hai mặt: hoặc là chưa bao giờ dân Mỹ nghèo như bây giờ; hoặc là chưa
bao giờ Nhà Nước Mỹ rộng rãi như bây giờ. Cả hai cách nhìn đều không
có gì đáng mừng rỡ, phấn khởi gì, mà chỉ đưa ra một bức tranh về
tương lai không mấy tốt đẹp.<br/><br/>Vung tiền trợ cấp có thể di hại cho cả nước về lâu về dài, nhưng ít
ra bảo đảm ông sẽ tái đắc cử với lá phiếu của hàng triệu người
đang lãnh tiền trợ cấp, tiền an sinh, tiền già, tiền bảo hiểm y
tế,... Và đúng như vậy, ông đã tái đắc cử.<br/><br/>Nhưng như đã nói, cái gì cũng có cái giá phải trả. Nhà Nước tung
tiền trợ cấp đủ loại cho thiên hạ không phải không có hại, kể cả cho
những người đang lãnh trợ cấp. Đến một ngày nào đó, Nhà Nước sẽ
đụng đáy, không còn tiền để trợ cấp, không còn khả năng đi vay mượn,
kinh tế không thể sản xuất đủ để nuôi dân, trả lương công chức,... Khi
đó là lúc sẽ phải thắt lưng buộc bụng chặt nếu không muốn cả nước
phá sản. Hãy nhìn vào Hy Lạp. Câu hỏi cho những người đang thoải mái
và vui vẻ lãnh trợ cấp: khi đó, ai sẽ là nạn nhân lớn nhất? Ai sẽ
mất phần lớn quyền lợi mà không có gì bù đắp? Ai sẽ gặp khó khăn
lớn nhất? Câu trả lời ngắn gọn: thành phần giai cấp thấp nhất, càng
thấp thì càng bị thiệt hại, và hoàn cảnh càng khó khăn. Đối với
các ông trọc phú Bill Gates và Warren Buffett, có mất vài chục triệu
hay đóng thêm vài triệu bạc tiền thuế, cũng chỉ là... muỗi đốt gỗ.
Nhưng đối với gia đình sống bằng phiếu thực phẩm, mất vài chục đô
một tháng cũng đủ là chuyện đau đầu nhói tim.<br/><br/>Đó chính là cái lo lớn của đối lập Cộng Hoà. Họ không thể khoanh
tay đứng nhìn, hay thậm phỉ bỏ phiếu cho TT Obama tiếp tục vung tay
xài vô hạn. Họ đã có những đề nghị cụ thể: họ sẽ cấp ngân sách
dài hạn cho chính quyền Obama, nhưng phải có giới hạn, phải có kèm
theo cắt giảm chi tiêu.<br/><br/>Chính quyền Obama không chịu thua, khẳng định không thể cắt giảm thêm
được gì nữa. Có thật là không thể cắt giảm gì nữa không? Tuần qua,
TNS Tom Coburn, Cộng Hòa của Oklahoma, đã công bố bạch thư hàng năm của
ông, liệt kê những chi tiêu vô lý nhất của chính quyền, cho thấy Nhà
Nước đã phung phí ít ra là 30 tỷ trong năm rồi. Một vài ví dụ:<br/><br/>- 1,5 tỷ tiền điện cho các cơ quan, cao ốc Nhà Nước, không xài, bỏ
hoang nhưng vẫn lên đèn mỗi tối;<br/><br/>- 400 triệu lương hồi tố cho các công chức nghỉ làm khi Nhà Nước đóng
cửa hai tuần mới đây;<br/><br/>- 3 triệu cho nhân viên NASA học tập về thủ tục bầu bán quốc hội Mỹ,
mà không ai giải thích được vì mục đích gì;<br/><br/>- 2 triệu để tu sửa một trang trại đổ nát, di tích của cuộc nội
chiến cách đây một thế kỷ;<br/><br/>- Và không biết bao nhiêu chi tiêu lặt vặt khác, như gần nửa triệu để
nghiên cứu về bộ phận sinh dục của vịt.<br/><br/>Đưa đến những bế tắc chính trị hiện nay. Lỗi tại ai? Câu trả lời:
lỗi tại khối ba trăm triệu dân Mỹ. Họ đã bầu cho một tổng thống cấp
tiến cực đoan nhất, hoan hỷ lãnh đủ thứ trợ cấp, nhưng rồi lại sợ
và bầu cho khối bảo thủ kéo giữ tay tổng thống lại phần nào. Người
dân Mỹ hy vọng vì quyền lợi đất nước, quyền lợi chung, hai bên sẽ
tương nhượng nhau, thoả hiệp với nhau một cái gì đó để chuyện nước
được trôi chẩy hơn, trên một con đường ít cực đoan hơn. Nhưng thực tế
là chẳng bên nào chịu thua bên nào. Tổng thống thì... đường ta ta cứ
đi, đối lập thì ngăn cản vẫn ngăn cản. Bế tắc kéo dài, cho đến tuần
qua, khi mà Hạ Viện do Cộng Hoà kiểm soát thông qua được một đề nghị
hai năm ngân sách tương đối dung hoà được cả hai khuynh hướng cấp tiến
và bảo thủ, do dân biểu Paul Ryan, cựu ứng viên phó tổng thống cùng
liên danh với TĐ Romney, và một dân biểu Dân Chủ, cùng đưa ra. Thượng
Viện sau khi cò cưa chỉnh sửa đôi chút cũng đã thông qua, để rồi có
nhiều hy vọng TT Obama sẽ ký thành luật. Ít ra, hy vọng tránh được
chuyện Nhà Nước lại đóng cửa cuối Tháng Giêng tới khi Nhà Nước
lại... hết tiền.<br/><br/>Đại cương thì dự luật ngân sách mới cũng không khác gì... món cháo
lòng. Đủ cả: thịt, gan, tim, mề, thận, ruột già, ruột non, bao tử,
huyết, kèm thêm ít rau, giá, hành, nước lèo, bột ngọt, vân vân... Mỗi
thứ một chút cho vừa lòng càng nhiều người càng tốt, miễn sao thu
đủ phiếu thông qua là được.<br/><br/>Lần đầu tiên từ nhiều năm nay, hai bên đã có được một sự thoả thuận
nào đó. Trên căn bản, đó là sự thoả thuận về mức chi tiêu của Nhà
Nước, đại khái là sẽ “chỉ” chi tiêu sơ sơ có hơn một ngàn tỷ mỗi năm
trong hai năm tới 2014-2015. Tức là trong hai năm tới, Nhà Nước sẽ chi
tiêu trung bình có gần 3 tỷ mỗi ngày.<br/><br/>Giải pháp hoàn hảo? Thưa không. Có hai vấn đề lớn với hàng loạt câu
hỏi chưa được đề cập:<br/><br/>- Lấy đâu ra ba tỷ đô một ngày? Đi vay mượn? Ở đâu? Chừng nào trả?
Trả bằng cách nào? Bao giờ trả? Tăng thuế? Tăng thuế ai? Bao nhiêu?<br/><br/>- Ba tỷ đô đó chi vào đâu, việc gì? Trả bớt nợ hay là tăng thêm trợ
cấp?<br/><br/>Chưa ai có câu trả lời. Đây sẽ tiếp tục là đề tài tranh cãi, vẫn có
thể đưa đến chuyện Nhà Nước đóng cửa tiệm được như thường.<br/><br/>Chỉ biết là Nhà Nước Obama ngày càng lớn, ngày càng bao đồng, mà
lại chẳng được tin tưởng hơn. Thăm dò mới nhất của Gallup cho thấy
trong ba người Mỹ thì hiện nay đã có hai người cho rằng Nhà Nước bao
đồng xài tiền quá mức đã trở thành đe dọa lớn nhất cho nước Mỹ,
lớn hơn khủng bố Al Qaeda rất xa.<br/><br/>Trong khi đó, TT Obama và gia đình ung dung đi nghỉ Giáng Sinh hai tuần
tại Hạ Uy Di. Tổng thống và gia đình thuê một dinh thự của một đại
gia địa phương với giá 25.000 đô một tuần, trả bằng tiền túi. Nhưng
hàng trăm phụ tá, tùy tùng, an ninh, đều ở khách sạn thượng hạng
200-300 đô một đêm do chúng ta chi trả qua tiền thuế. Những ai có dịp
du lịch Hawaii đều biết giá khách sạn ở đây cao nhất Mỹ. Tiền tàu
bay gần bốn triệu, chí phí tùy tùng, an ninh, linh tinh đủ thứ hơn
bốn triệu nữa, vị chi tám triệu đô. Chuyện nhỏ. (22-12-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a215430/ngan-sach-va-xai-hoang

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/