# Hiện Tượng Obama

17/12/2013

TT Obama sư phụ về tài thề non hẹn biển, hứa trăng vẽ bánh...<br/><br/>Đúng ra, nói “hiện tượng Obama” có phần thất kính đối với vị quốc
trưởng của Hiệp Chủng Quốc, nhưng ở đây cần hiểu là kẻ viết này
tuyệt đối không có ý đó, mà chỉ muốn nhấn mạnh đến TT Obama như một
“hiện tượng” thật đặc biệt của chính trị Mỹ, và chỉ có ở Mỹ mới
có hiện tượng này.<br/><br/>TT Obama, dù thích hay ghét, sẽ đi vào lịch sử Mỹ với những dấu ấn
đặc biệt nhất, chứ không phải như là một chú thích bên lề những
trang sử Mỹ. Chẳng những ông là tổng thống da đen đầu tiên và là
người đã thay đổi hoàn toàn chế độ y tế Mỹ tác động lên cả trăm
triệu dân Mỹ trong hiện tại cũng như vài thế hệ nữa, mà còn là một
biểu tượng của chế độ dân chủ Mỹ, với tất cả những cái hay và cái
dở của nó.<br/><br/>Lịch sử sẽ mất rất nhiều bút giấy nghiên cứu về sự thành công của
TT Obama, một sự thành công thật khó hiểu và khó tin. Chẳng những ông
phải vượt qua hàng rào ngăn cách màu da thật kiên cố, mà ông còn
phải hạ cả hai guồng máy chính trị vĩ đại của cả hai đảng Dân Chủ
rồi Cộng Hoà với hai ứng viên hết sức uy tín, có khả năng và kinh
nghiệm, và hậu thuẫn mạnh mẽ. Một người là cựu đệ nhất phu nhân
được sự hậu thuẫn mạnh mẽ của ông chồng, một trong những tổng thống
được ái mộ nhất, và một là một thượng nghị sĩ kỳ cựu, một người hùng
quân sự và một chính khách có tiếng nói rất lớn trong chính trường
từ hơn ba chục năm qua. Và ông Obama phải vượt qua những ngọn núi đó
với kinh nghiệm của tờ giấy trắng, khả năng của một anh tổ chức
cộng đồng, không có một xu dính túi, xuất thân từ một gia đình không
có gì đáng hãnh diện, có cái tên không có gì là... Mỹ, với cái tên
đệm mà dân Mỹ nghe đến là phát run sau vụ 9/11.<br/><br/>Người ta chỉ có thể giải thích sự thành công qua việc TT Obama là
thiên tài rất “thính mũi” trên phương diện chính trị, đã “ngửi” thấy
rõ tâm lý quần chúng Mỹ, và đã đánh đúng tâm lý đại chúng đó, đáp
ứng đúng nguyện vọng của họ, gãi đúng chỗ ngứa của họ.<br/><br/>Dân Mỹ là dân nổi tiếng thiếu kiên nhẫn. Họ hoan hô sự thành công rất
hăng hái, nhưng sẽ mau chóng quay lưng lại ngay khi thấy thất bại.
Chiếc áo đang mặc bị rách một chút hay có vết bẩn, vứt ngay, không
có gì luyến tiếc, không chút tình cảm, ơn nghiã gì hết. Tỷ lệ hậu
thuẫn của TT Bush sau vụ 9/11 leo lên đến mức vô tiền khoáng hậu, tới
xấp xỉ 90%, nhưng bẩy năm sau, dân Mỹ nghe đến tên Bush là phải rùng
mình, muốn thay đổi đảng cầm quyền.<br/><br/>Khi tranh cử, ứng viên Obama công kích “mô thức Washington” là mô thức
chính trị lươn lẹo cổ điển, mánh mung, đặt quyền lợi cá nhân và phe
đảng lên trên quyền lợi tổ quốc, các chính khách bề mặt nói một
đàng, trong hậu trường, tụ năm tụ bẩy đổi chác, trả giá theo đòi
hỏi của các nhóm ảnh hưởng lobby groups. Đã vậy, nhìn qua hai ứng
viên chính của cả hai đảng, dân Mỹ thấy những tên tuổi lớn thật,
nhưng dù sao thì cũng vẫn là những chính khách quá quen thuộc, không
có gì mới lạ, không có gì khiến cho họ cảm thấy hồ hởi, hăng say
hơn, hay tin tưởng vào tương lai hơn. Họ muốn một cái gì mới lạ, hoàn
toàn khác với mẫu chính khách cổ điển Vũ Như Cẩn. Họ muốn thay đổi
kiểu chính trị gia.<br/><br/>Đó là lý do cơ bản đưa TNS Obama đến thành công.<br/><br/>Một lý do hết sức quan trọng là màu da của ứng viên Obama. Một
nghịch lý vĩ đại trong việc ông Obama đắc cử tổng thống là trong khi
ông tranh cử với tư cách một công dân Mỹ, nhấn mạnh bà mẹ trắng, và
nhắc đi nhắc lại chuyện ông được bà ngoại trắng nuôi, khẳng định
không ra với tư cách một người da đen, thì dân Mỹ lại bầu cho ông phần
lớn vì cái nửa da đen của ông. Đại đa số dân da trắng Mỹ đã mang
nặng mặc cảm với thế giới và với dân da màu là nước Mỹ đã đối xử
tàn nhẫn với dân nô lệ da đen trước đây trong khi cho đến bây giờ vẫn
đầy chứng tích kỳ thị. Họ cho rằng cách rõ ràng nhất để chứng minh
họ không kỳ thị là bầu cho một chính khách da đen làm tổng thống.
Họ cũng hy vọng việc bầu này sẽ chấm dứt mọi tàn dư của nạn kỳ
thị, và nước Mỹ cuối cùng sẽ được đại đoàn kết như ứng viên Obama
đã hứa.<br/><br/>Nhưng lý do hết sức then chốt vẫn là khả năng cá nhân của ông ứng
viên mới toanh này.<br/><br/>Chẳng những ông xuất sắc hơn người trong vấn đề lượng giá tâm lý và
nhu cầu quần chúng, ông còn là một chính khách với tài ăn nói ít
người sánh kịp. Từ cách dùng chữ đến cách diễn đạt, nói nhanh
chậm, nhỏ lớn, dùng danh từ mỹ miều mát tai hay danh từ dao to búa
lớn tạo ấn tượng,... TT Obama là một bậc thầy. Ông cũng là sư phụ
về tài thề non hẹn biển, hứa trăng vẽ bánh. Bất kể tính hão huyền
lộ liễu của những lời ứng viên Obama hứa, cả triệu người Mỹ đã
nhắm mắt tin để bầu cho ông. Mà cũng phải nói ngay, không bầu cho ông
ta vì những lời hứa ngọt ngào thì cũng chẳng còn lý do nào để bầu
cho ông nữa. Không thể nói bầu cho ông Obama vì kinh nghiệm hay khả năng
vì thực tế ông là tờ giấy trắng. Cũng chẳng thể thú nhận đã bầu
cho ông Obama vì mặc cảm kỳ thị. Chỉ còn cách bám víu và nhắm mắt tin
vào những lời hứa hẹn.<br/><br/>Đó là chuyện bầu bán và đắc cử của TT Obama.<br/><br/>Năm năm sau, ta đã có một chút gì cụ thể để bàn về khả năng và con
người thật của Barack Obama. Cột báo này đã bàn quá nhiều về những
thành quả yếu kém của TT Obama, chỉ cần tóm gọn lại vài điểm
chính.<br/><br/>- Đối nội nói chung, bất chấp những lời hứa ôn hòa, đã thi hành
chính sách cấp tiến cực đoan nhất; 5 năm sau khi nhậm chức vẫn chưa
vực kinh tế lên lại cũng như vẫn trực diện tỷ lệ thất nghiệp cao
nhất từ hơn 30 năm kể từ thời TT Carter.<br/><br/>- Đối ngoại, nước Mỹ không chiếm lại được cảm tình của khối Ả Rập
Hồi Giáo; không làm gì được với Iran, Bắc Hàn, Venezuela, Syria, chỉ
thành công “lãnh đạo sau lưng” Pháp và Anh để hạ được Khaddafi của
Libya; tăng hiềm khích với Nga và Trung Cộng; mất hậu thuẫn của các
đồng minh Tây Âu, Úc, và Nhật; chấm dứt hai cuộc chiến Iraq và
Afghanistan theo mô thức Việt Nam tức là tháo chạy bỏ mặc hai xứ này
đối đầu với cuộc nội chiến dai dẳng.<br/><br/>- Cuộc chiến chống khủng bố được ổn định. Sự thành công này có
được chính nhờ vào việc tiếp tục thi hành những biện pháp do TT Bush
đã phát động mặc dù trong khi tranh cử ứng viên Obama đã lớn tiếng
đả kích tính cao bồi của Bush. Trại tù Guantanamo vẫn còn đó, chưa
một tên khủng bố nào được đưa ra tòa lãnh án gì hết; các phi vụ
không người lái lùng giết khủng bố không chấm dứt mà còn tăng cường
độ; các vụ theo dõi qua điện thoại, internet, v.v... gia tăng gấp cả
chục lần, từ theo dõi tình nghi khủng bố lan qua theo dõi đối lập Tea
Party, theo dõi nhà báo, theo dõi cả dân Mỹ, rồi cả chính quyền đồng
minh luôn.<br/><br/>- Thành quả để đời Obamacare đã trở thành bài học mẫu về thảm hoạ
của chính sách Nhà Nước bao đồng cũng như về khả năng của guồng máy
thư lại.<br/><br/>Trong phạm vi bài này, chúng ta sẽ không bàn lại những thất bại đó
nữa, mà nhận định về con người của TT Obama.<br/><br/>Năm 2008, dân Mỹ quá chán chường các chính khách cổ điển, mánh mung
thủ đoạn, hứa nhăng hẹn cuội, phe đảng, do đó đã bỏ các chính khách
tên tuổi, kinh nghiệm như Hillary Clinton rồi John McCain để dồn phiếu
cho ứng viên Obama, một mẫu chính trị gia mới mà “chúng ta có thể
đặt hy vọng vào”. Một người mới, một kỷ nguyên mới.<br/><br/>Nhưng 5 năm qua đã phơi bày ra hình ảnh một tổng thống... không có gì
khác lạ, vẫn những chiêu thức cổ điển, mà lại có phần tệ hơn
nhiều.<br/><br/>TT Obama là người duy nhất đã long trọng lấy đại đoàn kết toàn dân
là chủ trương quan trọng nhất, nhưng lại mau mắn trở thành tổng thống
tạo phân hoá lớn nhất lịch sử Mỹ.<br/><br/>Ứng viên Obama hứa sẽ cấm các nhóm ảnh hưởng lobbyist bén mảng đến
Tòa Bạch Ốc. Bây giờ, nội các và ban tham mưu của ông có nhiều chuyên
gia lobbyist hơn tất cả các chính quyền trước, Cộng Hòa hay Dân Chủ.<br/><br/>Câu chuyện Obamacare được thông qua quốc hội cũng đã trở thành bài
học mẫu cho những mánh mung chính trị, từ trả giá đổi chác trong
hậu trường đến lươn lẹo thủ tục quốc hội, rồi đến vặn vẹo Hiến
Pháp, từ thất hứa đến diễn giải chơi chữ lòng vòng. Tất cả đều là
những thứ ứng viên Obama chỉ trích thậm tệ khi tranh cử, nhưng sau khi
đắc cử lại áp dụng mạnh bạo hơn ai hết.<br/><br/>Tất cả chính khách đảng nào cũng vậy, nước nào cũng thế, đều hứa
cuội như nhau. TT Obama có làm vậy cũng không khác gì. Cũng vẫn chỉ
là hình ảnh của một chính khách cổ điển chẳng có vẻ gì là “người
mới”, mang lại “hy vọng mới”.<br/><br/>Công bằng mà nói, rất nhiều điều thất hứa không thực hiện được vì
đủ loại lý do, và thiên hạ cũng dễ thông cảm. Lời hứa phục hồi kinh
tế mau chóng không thực hiện được vì có cả triệu yếu tố khách quan
mà một tổng thống cho dù uy quyền đến đâu cũng không khắc phục hay
kiểm soát hết được. Chuyện thất hứa này phần nào thông cảm được,
cho dù TT Obama đã huyênh hoang tạo cho thiên hạ cảm tưởng mình chính
là Đấng Tiên Tri toàn năng có phép màu hơn người, hạ được cả thủy
triều. Có thể những tín đồ của ông thật sự tin, nhưng kẻ viết này
chưa bao giờ tin ông có bùa phép gì.<br/><br/>Nhưng thất hứa vì hứa quá trớn, không có cách nào thực hiện được
may ra có thể thông cảm được, chứ nói láo trắng trợn thì khó mà
hiểu và chấp nhận được. Vậy mà TT Obama đã hơn một lần nói láo
thật lộ liễu, bất chấp chuyện bất cứ câu nói nào của ông cũng đều
được thu hình, thu thanh, ghi nhận qua không biết bao nhiêu phương tiện
tân tiến nhất. Phạm vi bài này không thể cho phép điểm lại tất cả
những lời nói láo của TT Obama, hay những lời nói láo của các phụ
tá mà ông cho phép. Chỉ xin đơn cử vài thí dụ mới đây, rất cụ thể.<br/><br/>Trong vụ Syria, cách đây hơn một năm, ông long trọng cảnh cáo việc Syria
sử dụng vũ khí hoá học giết người tập thể là không thể chấp nhận
được: ông vạch ra lằn ranh đỏ mà nếu Syria vượt qua, sẽ phải chịu
hậu quả. Vài tháng trước đây, khi Syria vượt lằn ranh đỏ đó, thì TT
Obama khẳng định ‘tôi không phải là người vạch lằn ranh đỏ đó”. Cho
đến khi báo chí phát thanh lại nguyên văn câu nói trước đây của ông
thì ông mới... im, chứ không xin lỗi.<br/><br/>Rồi đến vụ bảo hiểm Obamacare, ông đã tuyên bố “ai thích bảo hiểm
của mình đều có thể giữ”. Sau khi cả triệu người bị mất bảo hiểm,
thì ông sửa lại “tôi đã nói ai thích bảo hiểm cũ thì vẫn giữ được
nếu bảo hiểm đó không thay đổi”. Cái đoạn chót, “nếu bảo hiểm đó
không thay đổi” ông không hề nói đến trước đây. Làm sao không thay đổi
khi Obamacare thay đổi toàn bộ hệ thống y tế Mỹ? Báo Wall Street
Journal mới đây đã loan tin TT Obama và toàn thể ban tham mưu ngay từ
đầu đã biết sẽ có thay đổi quy mô và cả triệu người sẽ mất bảo
hiểm, nhưng quyết dấu nhẹm chuyện này và nói láo, vì sợ nói thật
là cả triệu người sẽ mất bảo hiểm sẽ tạo ra chống đối Obamacare
ngay từ đầu khiến cho luật này không qua lọt quốc hội được.<br/><br/>Rồi một chuyện mới xẩy ra, tuy chỉ là chuyện nhỏ, nhưng mang ý nghiã
tiêu biểu.<br/><br/>TT Obama có một ông chú hay bác gì đó, anh hay em ruột của bố TT
Obama. Cuối năm 2011, ông lái xe say rượu, bị bắt. Và người ta khám
phá ra ông này ở lậu, đã có trát trục xuất từ tám năm trước. Cảnh
sát tiến hành thủ tục trục xuất. Ông này bèn lớn tiếng hăm doạ tôi
là chú (tạm gói là chú) của TT Obama, đã từng nuôi Obama trong nhà khi
Obama còn đi học đại học. Cảnh sát nghe cũng rét, hỏi lại Toà Bạch
Ốc. Phát ngôn viên Tòa Bạch Ốc khẳng định TT Obama chưa bao giờ gặp
hay nói chuyện với ông chú này, chưa hề sống chung một ngày. Trong hai
người, phải có một người nói láo. Thiên hạ phân vân không biết nên tin
tổng thống hay tin anh say xỉn thất nghiệp, ở lậu? Dĩ nhiên phải tin
tổng thống chứ. Ông chú này bị đưa ra tòa làm thủ tục trục xuất.
Nhưng thủ tục này, lạ lùng thay, cứ bị trì hoãn vì đủ lý do, kéo
dài đến hơn hai năm sau mới xong, và cuối cùng, cách đây vài tuần,
quan toà quyết định cho anh ta ở lại hợp pháp, vì lý do… ở lậu lâu
quá rồi. Phạm tội lâu quá rồi thành… hết tội. Một lý do thật mới
lạ trong tư pháp Mỹ. Không biết có “bàn tay vô hình” nào xiá vô hay
không.<br/><br/>Anh này vừa được tha lại huyênh hoang xác nhận ngay là đã từng nuôi TT
Obama. Báo chí hỏi lại Toà Bạch Ốc, và lần này ông phát ngôn viên
cho biết TT Obama xác nhận, đúng sinh viên Obama đã có sống chung một
thời gian với ông chú này tại Boston. Lời giải thích của ông phát
ngôn viên: hồi đó, chúng tôi chỉ tìm tài liệu và đọc hồi ký của TT
Obama, không thấy có ghi gì về ông chú này, nên nghĩ là TT Obama không
biết ông chú này. Một lời giải thích nói dối quanh ngớ ngẩn chẳng
lừa được ai. Ta nên nhớ là phát ngôn viên Tòa Bạch Ốc là người mỗi
ngày đều họp với tổng thống để chuẩn bị cho việc trả lời họp báo
mỗi ngày. Sự thật là tổng thống nói láo trong khi anh thất nghiệp
say xỉn, ở lậu mới là người nói thật. Ông tổng thống nói láo vì
khi đó đang là mùa tranh cử, có những sự thật cần phải dấu.<br/><br/>Và còn biết bao nhiêu điều nói láo khác như TT Obama khẳng định chỉ
biết sơ sơ không liên hệ gì nhiều với mục sư quá khích Jeremiah Wright,
để rồi người ta khám phá ra mục sư này chủ trì hôn lễ của Obama và
rửa tội cho hai cô con gái luôn. TT Obama cũng chối không thân thiết gì
với tên khủng bố Bill Ayers để rồi bị lòi ra là ông đã phát động
cuộc tranh cử thượng nghị sĩ Illinois tại nhà ông Ayers này. TT Obama
cũng chối không quen biết gì nhiều với tài phiệt Tony Rezko, đến khi
lòi ra vụ tay Rezko bán một miếng đất cho TT Obama với giá tượng
trưng, một hình thức đấm mõm không hơn không kém.<br/><br/>Nhà báo Liz Peek của The Fiscal Times nhận định TT Obama còn tệ hơn TT
Carter nhiều: cả hai đều dở như nhau, nhưng ít ra TT Carter không biết
nói láo.<br/><br/>Chẳng trách hiện nay, lần đầu tiên, đa số dân Mỹ đã coi TT Obama không
còn đáng tin cậy nữa. (15-12-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.<br/><br/>GHI CHÚ:<br/><br/>Trả lời Obamacare: Sau bài báo tuần trước, một độc giả có hỏi vấn
đề bệnh nhân bệnh nặng như ung thư đang được chữa trị sẽ bị ảnh
hưởng thế nào. Nếu hãng bảo hiểm thông báo hủy bỏ chương trình bảo
hiểm đang có kể từ đầu tháng Giêng tới, người bệnh có quyền tiếp
tục mua lại bảo hiểm của hãng đó, nhưng với giá mới và điều kiện
mới, hoặc cũng có thể đi tìm mua bảo hiểm khác bằng cách tự mình
đi tìm, hay qua các trung tâm phối hợp exchanges. Theo luật mới, không
có hãng bảo hiểm nào có quyền từ chối bán bảo hiểm cho người đó.
Nhưng không có gì bảo đảm người bệnh sẽ được tiếp tục chữa trị như
trước, có thể phải đổi bác sĩ, đổi nhà thương và đổi thuốc.<br/><br/>Xin giới thiệu một trang mạng có thể trả lời rất nhiều câu hỏi về
Obamacare cho quý độc giả:<br/><a href="http://apps.washingtonpost.com/g/page/politics/all-your-obamacare-questions-answered/564/" target="_blank"><i>http://apps.washingtonpost.com/g/page/politics/all-your-obamacare-questions-answered/564/</i></a><br/>

### Nguồn:

Viet Bao: https://vietbao.com/a214936/hien-tuong-obama

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/