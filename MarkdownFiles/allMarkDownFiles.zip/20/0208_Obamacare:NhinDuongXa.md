# Obamacare: Nhìn Đường Xa

10/12/2013

...Các trường bây giờ có hai lựa chọn, một là tính bảo phí rất cao,
hai là hủy bỏ bảo hiểm cho sinh viên...<br/><br/>Obamacare đang gặp khủng hoảng nặng, nhưng TT Obama và những người ủng
hộ ông đều khẳng định rồi sẽ vượt qua được mọi lủng củng. Vạn sự
khởi đầu nan. Ta cần kiên nhẫn điều chỉnh rồi cũng sẽ xong. Obamacare
là liều thuốc tốt và cần thiết để chữa căn bệnh nan y của y tế Mỹ.<br/><br/>Câu chuyện thường tình là bác sĩ chẩn bệnh giỏi và đúng, nhưng
nhiều khi lại cho thuốc sai, khiến con bệnh từ bị thương đến chết.
Bác sĩ Obama đã chẩn bệnh đúng vì cái bệnh chi phí y tế quá đắt
trong khi cả chục triệu người không có bảo hiểm của Mỹ cả thế giới
đã nhìn thấy từ lâu rồi. Nhưng rồi bác sĩ Obama cho thuốc hình như
không đúng. Con bệnh đang yếu đuối, uống thuốc vào, lên cơn đau quặn,
và có nhiều triển vọng bệnh lan ra khắp người. Khi đó, sống hay
chết, chưa ai biết được.<br/><br/>Những chuyện lủng củng ta đang thấy tuy có tính nhất thời, nhưng đã
hé lộ ra những vấn đề nghiêm trọng nhất nước Mỹ sẽ trực diện trong
những tháng năm tới.<br/><br/>TRỤC TRẶC ĐIỆN TOÁN?<br/><br/>TT Obama khẳng định những trục trặc kỹ thuật trên trang mạng của các
trung tâm phối hợp –exchanges- là những vấp váp nhỏ, nhất thời mà
các chuyên gia điện toán đang điều chỉnh, không có gì quan trọng. Thật
ra, không phải vậy.<br/><br/>Những khó khăn “kỹ thuật” cho đến nay chỉ liên quan đến phần ghi danh
mua bảo hiểm. Theo ông Henry Chao, người phụ trách chương trình điện
toán của Obamacare, 40% chương trình chưa được viết xong, trong đó có
chương trình về sổ sách kế toán, tính tiền trợ cấp, tiền bồi
hoàn,... Tức là chưa ai bảo đảm được trong tương lai đúng số tiền sẽ
được trả cho đúng người qua đúng hãng bảo hiểm.<br/><br/>CNN loan tin trường hợp của bà Jessica Sandford, đã viết thư cám ơn TT
Obama sau khi bà đã lên trang mạng của tiểu bang Washington mua được bảo
hiểm tốt, rẻ, mà lại còn được trợ cấp nữa. TT Obama đi đâu đọc diễn
văn cũng khoe bà Sandford là hình ảnh của sự thành công của Obamacare.<br/><br/>TT Obama đã khoe hơi sớm. Sau khi lên báo, lên truyền hình nhờ được TT
Obama giới thiệu, bà Sandford nhận được thông báo là trung tâm điều
hợp “tính nhầm” số tiền bảo phí của bà, vì vậy bà sẽ phải đóng
bảo phí cao hơn số tiền đã được thông báo. Không phải một lần, mà
bà đã nhận được liên tục ba lần thông báo, tức là bà bị tăng giá ba
lần. Chưa hết. Sau đó, bà nhận được thông báo nữa là bà sẽ không
được trợ cấp gì hết vì một điều kiện nào đó trong luật. Bà
Sandford cho biết sau ba lần tăng giá và sau khi mất trợ cấp, bà đã
không còn bảo hiểm nữa. Bảo phí đã tăng quá cao, và vì không còn
trợ cấp, bà không đủ tiền mua bảo hiểm nữa. Bây giờ bà chưa biết
phải làm gì, có thể sẽ chịu đóng phạt thay vì mua bảo hiểm. TT
Obama đã ngưng không quảng bá trường hợp bà Sandford nữa.<br/><br/>Một “khám phá” mới. Một số nhà thương lớn ở New York đã từ chối
không nhận một số chương trình bảo hiểm được bán qua hệ thống phối
hợp của tiểu bang New York vì những nhà thương này không hề tham gia
vào chương trình “exchange” của Nhà Nước. Cái exchange đó ghi nhầm!
Bệnh viện Memorial Sloan-Kettering Cancer Center, bệnh viện trị ung thư uy
tín và lớn nhất thế giới đã giải thích những hãng bảo hiểm do exchange
giới thiệu đều là hãng “dởm” không hội đủ điều kiện kinh nghiệm, uy
tín và tài chánh của bệnh viện đặt ra. Có nghiã là mọi người ghi
danh qua exchange cần phải kiểm chứng lại xem bác sĩ, nhà thương, và
hãng bảo hiểm, tất cả sẽ nhận mình hay không trước khi trả tiền mua
bảo hiểm qua exchange.<br/><br/>Sự thật, các hệ thống tính sai trật lung tung, đủ thứ, không phải
chỉ là vấn đề viết sai công thức tính bảo phí, tiền trợ cấp, hay
ghi nhầm nhà thương, bác sĩ,... mà ngay trong 3.000 trang luật Obamacare
và hơn 10.000 trang phụ đính, do cả trăm người tham gia viết dưới áp
lực của hàng mấy chục nhóm ảnh hưởng –lobby groups, đã đầy rẫy điều
luật tương phản lẫn nhau, tuân theo điều này thì nghịch lại điều kia.<br/><br/>Đưa đến hệ quả là dù TT Obama long trọng cam kết –lại một cam kết
nữa- là hệ thống điện toán sẽ được chỉnh sửa hoàn hảo cuối tháng
11 này, các chuyên gia cho rằng những rắc rối đi xa hơn vấn đề máy
móc rất nhiều, và giờ này, không ai tiên đoán được khi nào luật
Obamacare mới ổn định. Sáu tháng, một năm? Hay hơn nữa?<br/><br/>THAY ĐỔI TOÀN DIỆN NỀN Y TẾ MỸ<br/><br/>Điều đầu tiên thiên hạ sẽ thấy là cải tổ Obamacare không chỉ giới
hạn ở chuyện cung cấp bảo hiểm cho những người trước đây không có
bảo hiểm. Nó sẽ thay đổi toàn diện ngành bảo hiểm y tế cũng như
ngành cung cấp dịch vụ y tế của Mỹ.<br/><br/>Như cột báo này đã viết nhiều lần, giới trẻ, đặc biệt là giới sinh
viên đại học, ủng hộ Obama mạnh nhất, sẽ lãnh đủ hậu quả của
Obamacare. Trước đây, hầu hết các trường đại học đều cung cấp bảo
hiểm cho sinh viên với giá rất rẻ, nhưng cũng chỉ bảo hiểm tối
thiểu, rất sơ sài vì sinh viên phần lớn khỏe mạnh, ít bệnh. Nhưng
với luật Obamacare, các chương trình bảo hiểm tối thiểu này không hợp
pháp nữa, các trường phải cung cấp bảo hiểm đầy đủ, để san sẻ chi
phí rất cao của các hãng bảo hiểm. Các trường bây giờ có hai lựa
chọn, một là tính bảo phí rất cao, hai là hủy bỏ bảo hiểm cho sinh
viên.<br/><br/>Tại Bowie State University của Maryland, các sinh viên trước đây đóng bảo
phí một nửa năm (semester) 100 đô, bây giờ phải đóng 1.800 đô, tăng gấp
18 lần.<br/><br/>Trường Bethany College tại Kansas trước đây cấp bảo hiểm với giá 445 đô
một nửa năm, và sinh viên phải trả 10.000 đô tối đa tiền túi,
out-of-pocket. Bây giờ họ phải đóng bảo phí 2.000 đô trong khi tiền túi
tối đa phải trả là 100.000 đô, gấp 10 lần. Sau khi cứu xét vấn đề,
trường Bethany quyết định bỏ bảo hiểm sinh viên.<br/><br/>Hàng loạt đại học khác cũng đã chọn giải pháp này, để sinh viên tự
lo đi kiếm mua bảo hiểm cho mình, với giá cao, hay chạy về xin vào
bảo hiểm của bố mẹ, dĩ nhiên khiến bảo hiểm của bố mẹ sẽ đắt hơn
nhiều.<br/><br/>Thăm dò của đại học Harvard cho thấy chỉ có 22% giới sinh viên có ý
định mua bảo hiểm sức khỏe, 57% chống Obamacare.<br/><br/>Đáng kinh ngạc hơn nữa là 52% giới trẻ trong khoảng 18-25 tuổi muốn...
bãi nhiệm (recall) TT Obama cho dù đó là lực lượnhg nồng cốt của TT
Obama qua hai kỳ bầu qua.<br/><br/>Theo các chuyên gia, đợt hủy bảo hiểm bây giờ chỉ là đợt đầu, liên
quan đến bảo hiểm cá nhân. Qua mùa thu năm tới (10/2014), đợt hủy bảo
hiểm sẽ trầm trọng hơn nhiều vì sẽ liên quan đến bảo hiểm tập thể
các công ty cung cấp cho nhân viên. Ta còn nhớ TT Obama trước đây đã gia
hạn tới 2015 mới bắt buộc các công ty phải cung cấp bảo hiểm tập
thể cho nhân viên. Từ 50 đến 100 triệu người sẽ là nạn nhân. Không
bệnh hoạn gì mà phải đổi bảo hiểm, bác sĩ, nhà thương đã phiền,
nếu bệnh nặng đang chữa trị thì trở thành một mối nguy lớn.<br/><br/>Nói chung, tiền bảo hiểm, bác sĩ, nhà thương, thuốc men, tiền trả
trước deductible, tiền trả góp co-payment, và tiền túi out-of-pocket,
tất cả sẽ đồng loạt leo thang trong những năm tháng tới. Ngay cả
những người lãnh Medicare và Medicaid cũng sẽ không thoát vì ngân sách
hai qũy này ngày một nhỏ đi trong khi số người được trợ cấp sẽ tăng
mạnh. Các chuyên gia ước tính hai phần ba khối 30 triệu người mới
được bảo hiểm sẽ tham gia vào Medicare hay Medicaid. Một cái bánh ngày
một nhỏ đi trong khi số người ăn ngày càng đông, kết quả như thế nào,
không cần bàn thêm.<br/><br/>Tình trạng đợi dài người để lấy hẹn bác sĩ, nhà thương sẽ ngày
càng trầm trọng, đã dài người sẽ ngày càng dài thêm. Về lâu về
dài, y tế Mỹ sẽ không còn phẩm chất hàng đầu và sẽ hết đóng vai
trò tiên phong, tuy sẽ vẫn đứng cao, nhưng ngang hàng với Canada, kèm
theo tất cả những vấn đề của Canadacare, đại khái kiểu muốn thay
xương chậu, phải uống thuốc giảm đau, đi cà nhắc cả năm trời trong khi
chờ đợi đi mổ. Muốn soi ruột, không phải ngày mai là có hẹn, mà
phải chờ vài tháng, lâu hơn nếu là khách hàng của Medicare hay
Medicaid, chờ lâu quá, trở thành ung thư ruột thì đó là… số xui.<br/><br/>Nói trắng ra, với Obamacare, trả tiền đắt hơn cho một món hàng xấu
hơn.<br/><br/>Giới trung lưu gọi là “cao”, không được Nhà Nước tài trợ tiền mua bảo
hiểm sẽ thấy chi phí bảo hiểm và chữa trị chiếm một phần lớn lợi
tức gia đình. Tất cả các chi tiêu gia đình sẽ bị ảnh hưởng, phải ở
nhà nhỏ hơn, đi xe cũ hơn, đi chợ bớt đi, du hý xét lại, du lịch dẹp
qua, … Đây là khối đại đa số dân Mỹ.<br/><br/>Việc thắt lưng buộc bụng này sẽ có hậu quả xã hội lâu dài như thế
nào, thật khó đoán. Bây giờ những khó khăn kinh tế, chưa thoát qua,
lại còn bị trầm trọng hoá bởi Obamacare, sẽ đưa xã hội Mỹ về đâu?
Bạo động nhiều hơn, trộm cướp nhiều hơn, điên khùng nhiều hơn? Biết
đâu Obamacare bắt buộc mọi người phải có bảo hiểm bệnh thần kinh và
chống bạo lực gia đình là chuyện đúng? TT Obama đã tiên đoán sẽ có
những vấn nạn này trong tương lai qua những cải cách của ông?<br/><br/>VAI TRÒ CỦA NHÀ NƯỚC<br/><br/>Chế độ tư bản có nhiều điều tốt, nhưng không hoàn hảo. Trái lại,
nếu thả lỏng sẽ đưa đến tình trạng cá lớn nuốt cá bé. Do đó rất
cần Nhà Nước làm cảnh sát. Chẳng những vậy, trước suy trầm kinh tế,
chỉ có Nhà Nước mới có phương tiện tung tiền vào kinh tế, tạo công
ăn việc làm qua đủ loại dự án, cũng như có tiền để trợ giúp những
người đang gặp khó khăn. Đó là lý luận của khối cấp tiến.<br/><br/>Lý luận này trên căn bản không sai. Nhưng làm sao giải thích sự xụp
đổ của các chế độ cộng sản, là nơi mà vai trò của Nhà Nước bao
trùm cả vũ trụ? Làm sao giải thích những khó khăn của Âu Châu khi
Nhà Nước là vú em chăm sóc cho dân từ ngày lọt lòng mẹ đến ngày về
với ông bà? Lời giải thích đơn giản nhất: công chức vẫn là công
chức, làm cho qua ngày, khó có sự hăng say, dấn thân, hay sáng tạo để
làm cho guồng máy Nhà Nước chạy tốt. Động cơ thúc đẩy không có. Làm
tốt hay làm dở, không có gì khác biệt, chẳng có thưởng cũng không
có phạt. Công chức hay tư chức, không ai lười hơn ai, không ai dốt hơn
ai, chỉ là vấn đề động cơ. Con người vẫn là con người, có động cơ
thì hăng say hơn, không động cơ thúc đẩy thì lè phè cho qua ngày. Đã
vậy, tiền bạc của công lại không bao giờ là vấn đề. Nhà Nước vung
tay xài tiền như không có ngày mai. Cho đến khi cả nước vỡ nợ.<br/><br/>TT Obama là người tin tưởng tuyệt đối vào vai trò vú em của Nhà
Nước. Ông tin là Nhà Nước Obama sẽ không vấp phải những khó khăn trên
vì có sự lãnh đạo tuyệt hảo của ông, vì ông biết cách kích động
sự hăng say, khả năng, và óc sáng tạo của công chức, nhờ tài ăn nói
cũng như nhờ vào khả năng tổ chức guồng máy hành chánh của ông.<br/><br/>Kết quả, những trục trặc “kỹ thuật” của Obamacare trong thời gian qua
đã phơi bày ra ánh sáng tính thiếu khả năng lộ liễu của guồng máy
hành chánh Obama. Hàng triệu người bực mình sẽ xét lại luận cứ của
TT Obama, đặt lại vấn đề khả năng của guồng máy thư lại quy mô. Không
dễ gì tạo lại niềm tin cho họ. Từ đó, ta có thể nhìn thấy những
khó khăn lớn trong tương lai cho khuynh hướng cấp tiến vì khó mà thiên
hạ có thể tiếp tục trông cậy vào khả năng của Nhà Nước bao đồng.
Mọi người sẽ nhớ lại câu nói của TT Reagan: “chính quyền không phải
là giải pháp cho các vấn đề, chính quyền chính là vấn đề”.<br/><br/>UY TÍN VÀ QUYỀN HẠN CỦA TT OBAMA<br/><br/>Một khiá cạnh quan trọng khác với hệ quả lâu dài là quyết định mới
nhất cùa TT Obama, cho phép các hãng bảo hiểm không tuân thủ luật
Obamacare sẽ mở màn cho một cuộc duyệt xét lại toàn bộ quyền hạn
của Hành Pháp trong cấu trúc tam quyền phân lập Mỹ. Trong khi khối
bảo thủ đối lập ồn ào tố giác, thì khối Dân Chủ cũng phải dè dặt
đặt vấn đề không biết TT Obama có quyền lấy quyết định muốn thi hành
luật thì thi hành, không thì miễn hay không?<br/><br/>Còn nữa. Trung tâm phối hợp –exchange- của Cali, Covered California, xác
nhận sẽ không thi hành quyết định của TT Obama cho phép các hãng bảo
hiểm không phải tuân thủ các đòi hỏi của Obamacare, tức là Cali vẫn
bắt buộc các hãng bảo hiểm phải sửa đổi, tức là hơn một triệu
người bị hủy bảo hiểm sẽ phải mua bảo hiểm mới. Quyết định của
tổng thống coi như pha. Cho tới bây giờ, ít nhất 12 tiểu bang lớn đã
không chấp hành, các tiểu bang còn lại thì đang thảo luận. Thiên hạ
tranh cãi về quyền hạn của TT Obama khi ra quyết định mới, bây giờ
phải coi lại quyền hạn của tiểu bang khi không thi hành quyết định
của tổng thống. Hiến Pháp Mỹ bây giờ chao đảo, ai muốn hiểu thế nào
thì hiểu.<br/><br/>Đi xa hơn, Obamacare đã tạo ra nhiều vấn đề khác. Trường đại học công
giáo Notre Dame của Indiana và nhiều giáo phận đã thưa Obamacare ra tòa
vì điều khoản bắt bảo hiểm phải trả tiền mua thuốc ngừa thai, nghiã
là tất cả mọi người kể cả những người công giáo phải đóng bảo
hiểm ngừa thai tức là tài trợ cho ngừa thai trong khi ngừa thai đi
ngược lại rao giảng của Thiên Chúa Giáo, do đó vi phạm tự do tín
ngưỡng, và nguyên tắc Nhà Nước không được can dự vào tín ngưỡng. Toà
phá án Washington đã phán Obamacare vi phạm Hiến Pháp về điểm này. Nội
vụ sẽ ra trước Tối Cao Pháp Viện.<br/><br/>Báo chí đã đặt nhận định đây là những khủng hoảng Hiến Pháp lớn
nhất từ thời TT Nixon đến giờ. Miả mai thay, lại xẩy ra dưới thời
một tổng thống đã từng làm phụ giảng về luật Hiến Pháp.<br/><br/>Nhìn vào khủng hoảng Obamacare, hình ảnh một Đấng Tiên Tri toàn năng
với giải pháp cho mọi vấn đề, một vị lãnh đạo đáng tin tưởng, một
người với viễn kiến của thiên niên kỷ mới,... đã biến mất, hay ít ra
thì cũng bị phai mờ gần hết. Chỉ còn lại hình ảnh một anh tổ chức
cộng đồng, lúng túng trước hết thất bại này đến khủng hoảng nọ.<br/><br/>Theo CNN, đa số dân Mỹ hiện nay cho rằng TT Obama không thành thật và
không còn đáng tin tưởng (53%), không có khả năng (60%), không là một
người lãnh đạo quả quyết (53%).<br/><br/>Một thăm dò của báo phe ta Washington Post mới đây cho thấy nếu có bầu
tổng thống bây giờ, TĐ Romney sẽ thắng TT Obama với tỷ lệ 49%-45%.<br/><br/>Một số lớn dân Mỹ đang bực mình vì TT Obama đã không giữ lời hứa
hẹn ai thích chương trình y tế của mình vẫn có thể giữ. Nhưng còn
một thất hứa không kém quan trọng mà ít người để ý vì sự thất hứa
đã được chôn dấu kỹ hơn. Đó là lời hứa sẽ không tăng một xu thuế
nào, ngoại trừ giới đại gia. Sự thật, việc tăng giá bảo hiểm của
đại đa số giới trung lưu chính là một hình thức đóng góp tài trợ
cho Nhà Nước để trả tiền bảo hiểm cho những người khác. Không chịu
trả bảo hiểm cao hơn thì đóng “tiền phạt” thay thế. Đó nếu không
phải là một hình thức thuế thì là gì? “Tiền phạt” được Tối Cao
Pháp Viện định nghiã là “thuế”, hiểu theo nghiã đóng góp tiền cho
Nhà Nước xài.<br/><br/>Thực tế Obamacare đã thay đổi toàn diện y tế Mỹ, ngắn hạn cũng như
dài hạn, mà cũng thay đổi hoàn toàn suy nghĩ của dân Mỹ về giải
pháp của TT Obama. Thăm dò mới nhất của CBS cho thấy 93% dân Mỹ muốn
thay đổi hay thu hồi Obamacare, so với 55%-60% trước đây. Tức là trong
100 người, bây giờ chỉ có 7 người muốn giữ luật như TT Obama đề ra.
Ngay trong đảng Dân Chủ, 84% cũng muốn thay đổi hay thu hồi. Một chuyện
chưa từng có trong lịch sử lập pháp Mỹ. (1-12-13)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a214522/obamacare-nhin-duong-xa

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/