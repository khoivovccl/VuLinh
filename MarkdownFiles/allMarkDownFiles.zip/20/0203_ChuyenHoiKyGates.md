# Chuyện Hồi Ký Gates

21/01/2014

...Hầu hết dân cử, Dân Chủ hay Cộng Hoà, đều bất tài, giả dối...
chỉ lo cho cái ghế của mình thôi...<br/><br/>Truyền thông cả tuần nay xôn xao vì cuốn hồi ký của ông Robert Gates,
vừa được phát hành tuần trước, nhưng các báo đã có bản thảo từ
trước nên đã trích dẫn nhiều đoạn cho thiên hạ biết trước, cũng như
chính ông Gates cũng đã viết vài bài báo và lên truyền hình để giới
thiệu cuốn sách.<br/><br/>Ông Gates là cựu bộ trưởng Quốc Phòng, được TT Bush bổ nhiệm thay thế
ông Donald Rumsfeld năm 2007, sau đó được TT Obama lưu nhiệm cho đến 2011.
Mặc dù là đảng viên Cộng Hoà đã từng giúp việc đắc lực các chính
quyền Cộng Hoà từ Reagan đến Bush cha và con trong những trách nhiệm
lớn như giám đốc CIA, nhưng ông là người nổi tiếng không phe đảng, có
uy tín lớn trong chính trường. Sự bổ nhiệm của ông dưới cả hai thời
Bush và Obama đã được Thượng Viện thông qua dễ dàng do hậu thuẫn của
thượng nghị sĩ của cả hai chính đảng. Sau khi từ chức, ông đã được
TT Obama tuyên dương và tưởng thưởng với huy chương Medal of Freedom, là
huy chương cao quý nhất dành cho một nhân vật dân sự.<br/><br/>Hồi ký của ông Gates dầy hơn 600 trang, hiện còn đang được truyền thông
và các sử gia nghiên cứu từng chi tiết. Kẻ viết này chưa được đọc.
Nhưng một số chi tiết chính đã được phổ biến và bàn tán rất rộng
rãi.<br/><br/>Hồi ký gây náo động chính trường mấy ngày qua vì đã có những lời
bàn bất lợi rất nặng cho TT Obama và nội các của ông. Đại khái, xin
liệt kê một số chuyện ông Gates tiết lộ dưới đây.<br/><br/>- TT Obama được tư lệnh chiến trường Afghanistan khẩn báo cần đôn quân.
Sau khi câu giờ cả mấy tuần, mới lấy được quyết định đôn quân tương
tự như TT Bush đã đôn quân tại Iraq trước đây. Nhưng lại chỉ là quyết
định kiểu nửa chừng xuân, cung cấp cho vị chỉ huy tại Afghanistan thêm
30.000 quân thay vì 60.000 như được yêu cầu. Ông Gates nhận định TT Obama
“không tin tưởng ở các tướng chỉ huy chiến trường, không chịu được TT
Karzai của Afghanistan, không tin tưởng vào chính chiến lược của mình,…
Đối với tổng thống, tất cả chỉ là chuyện làm sao rút ra cho nhanh”.<br/><br/>- TT Obama đã từng phân chia hai cuộc chiến: một cuộc chiến mà ông gọi
là “sai lầm” ở Iraq mà ông muốn rút ra càng sớm càng tốt bằng mọi
giá, và cuộc chiến “cần thiết” tại Afghanistan để tiêu diệt Al Qaeda
bảo vệ nước Mỹ. Nhưng ngay cả cuộc chiến tại Afghanistan này cũng đi
ngược lại quan điểm chủ hoà chống mọi chiến tranh của TT Obama. Do đó
đây là một cuộc chiến miễn cưỡng, cho dù ông hô hào cần diệt Al Qaeda
và chấp nhận đôn quân, chủ đích thật sự của TT Obama vẫn là … tháo
chạy.<br/><br/>- Thái độ của TT Obama trong nội bộ lộ rõ nét đến độ đại sứ Mỹ
tại Afghanistan, tháng Chạp năm 2012 đã tuyên bố “chúng tôi có một
chính sách rõ ràng tại Afghanistan, nhưng cái không rõ ràng là không
biết chúng tôi có đang áp dụng chính sách đó hay không” và “tôi cũng
không thể khẳng định chúng tôi thật sự muốn xây dựng một quân lực
Afghanistan hùng mạnh, hay chỉ muốn có một khoảng thời gian coi được
–decent interval- để rút”. Đọc đến câu “decent interval” chắc không ít
người Việt chúng ta sẽ nhớ đến cuốn sách của một cựu CIA ở VN mô
tả chính sách của Kissinger đối với cuộc chiến tại VN và hiệp định
Paris.<br/><br/>- TT Bush là người có tư tưởng dứt khoát, tin tưởng tuyệt đối vào
chính nghiã và sự cần thiết của cả hai cuộc chiến. Do đó, đối với
các quân nhân tham chiến, TT Bush thật sự có sự quan tâm và tình cảm
của ông thể hiện rõ ràng khi ông tiếp cận với các quân nhân đang
chiến đấu và các thương binh, cũng như gia đình các quân nhân bị tử
thương. Trong khi đó, vì không hoàn toàn tin vào cuộc chiến, TT Obama
lộ rõ sự thiếu nhiệt tình với các quân nhân. TT Bush cũng gần như tin
tưởng tuyệt đối vào ý kiến của các tư lệnh chiến trường, nhưng TT
Obama thì tuy tôn trọng các tướng lãnh chỉ huy chiến trường, nhưng luôn
để tâm nghi ngờ họ đã không báo cáo tình hình một cách trung thực,
mà báo cáo theo kiểu có lợi cho họ nhất. Dưới thời TT Obama, viên
tướng tư lệnh McChrystal đã có thái độ bất kính đến độ bị TT Obama
cách chức.<br/><br/>- Trên phương diện quản trị bộ máy chính quyền, TT Obama cầm đầu một
guồng máy mà ngay từ đầu chỉ có mục đích tối hậu là bảo đảm TT
Obama tái đắc cử trong cuộc bầu lại năm 2012. TT Obama là người tính
toán rất kỹ, mọi quyết định đều phải được cân nhắc dưới khiá cạnh
chính trị này. Tất cả guồng máy chính quyền được kiểm soát cực kỳ
chặt chẽ và chi tiết nhất từ Tòa Bạch Ốc. Tất cả mọi quyết định
của nhân viên nội các đều phải thông qua Toà Bạch Ốc. Ngay cả cuộc
chiến tại Iraq và Afghanistan cũng được điều hành từ Toà Bạch Ốc.
Vấn đề là ban tham mưu của TT Obama hầu hết đều là tay mơ, chẳng chút
kinh nghiệm chính trị hay quân sự thực tiễn nào. Bộ trưởng Gates lên
tiếng rất ngỡ ngàng khi thấy các phụ tá trẻ măng không một ngày đi
lính của TT Obama bốc điện thoại ra lệnh hay thậm chí sỉ vả các
tướng lãnh ba bốn sao, tư lệnh chiến trường, một chuyện mà dưới bất
kỳ tổng thống nào khác, mấy anh phụ tá đó sẽ mất job ngay.<br/><br/>- Ông Gates có nhận định chung về các tổng thống mà ông đã phục vụ.
Ông cho rằng tất cả các tổng thống Nixon, Ford, Carter, Reagan, Bush cha,
và Clinton đều là những người thật tâm có lòng đối với đất nước,
cho dù chính sách họ có khác biệt. TT Bush con là một lãnh tụ chín
chắn –mature leader- có can đảm lấy quyết định đôn quân tại Iraq trước
sự chống đối của các cố vấn, nội các và ngay cả các tướng tại Bộ
Quốc Phòng, vì ông có lòng tin vào các tư lệnh chiến trường và tin
vào chính nghiã của cuộc chiến. Ông sẵn sàng mang uy tín cá nhân, sự
nghiệp chính trị, tên tuổi trong sử sách ra đánh cuộc với quyết định
đôn quân tại Iraq mà ông cho là đúng. Riêng TT Obama, có vẻ như chỉ lo
cho chuyện tái đắc cử của mình.<br/><br/>- PTT Biden bị chỉ trích nặng nhất, vì được mô tả như một người đã
“sai lầm trong tất cả các chính sách đối ngoại quan trọng trong suốt
hơn 40 năm qua”. Tháng Chạp 2011, PTT Biden buột miệng tuyên bố “Taliban
không phải là kẻ thù của Mỹ”, khiến một viên chức cao cấp của
Afghanistan lên tiếng thắc mắc “vậy thì lính Mỹ đến đây làm gì, sao
lại tấn công chính quyền Taliban của Afghanistan?”. Ngay cả một sĩ quan
Mỹ đang tham chiến tại đây cũng đặt câu hỏi “vậy tại sao ra lệnh
chúng tôi bắn giết họ? Tại sao chúng tôi phải chấp nhận mạng sống
bị đe dọa?”.<br/><br/>- Cựu Ngoại Trưởng Hillary Clinton cũng bị kể lại là bà đã quyết
định chống lại cuộc đôn quân của TT Bush tại Iraq vì khi đó bà đang
tranh cử tổng thống tại Iowa và bà có nhu cầu lấy hậu thuẫn của
cánh tả phản chiến trong đảng Dân Chủ. Nói cách khác, tất cả cũng
chỉ có mục tiêu kiếm phiếu chứ không phải vì quyền lợi của nước Mỹ
hay vì sự thành bại của cuộc chiến và mạng sống của quân nhân Mỹ.
Bà Hillary đã đích thân nói thẳng thừng ý kiến này với TT Obama
trước mặt bộ trưởng Gates, khiến ông này bối rối không biết phản ứng
như thế nào. Điểm này chắc chắn sẽ được mang ra tranh cãi khi bà
Hillary quyết định ra tranh cử tổng thống trong kỳ bầu tới.<br/><br/>- Những chỉ trích nặng nề nhất của ông Gates được dành cho các vị
dân biểu và nghị sĩ, mà theo ông, tất cả chỉ là mần tuồng trống
rỗng, nói một đằng làm một nẻo. Đặc biệt, trong khi tất cả các vị
dân cử lớn tiếng chỉ trích các chi tiêu phung phí, kêu gọi giảm chi,
kể cả giảm chi phí quốc phòng, đóng cửa bớt các căn cứ quân sự
không cần thiết hay cắt bỏ một vài loại vũ khí quá tốn kém, nhưng
khi phải lấy quyết định cụ thể thì chẳng ông bà nào chấp nhận
những cắt xén đụng đến cử tri của mình. Trái lại, ông bà nào cũng
không bỏ qua cơ hội điện thoại riêng áp lực lên bộ trưởng quốc phòng
để giúp cử tri của mình, tức là giúp chính mình, kể cả hai lãnh
tụ Cộng Hoà và Dân Chủ trong thượng viện, các ông Harry Reid và Mitch
McConnell.<br/><br/>- Ông Gates mô tả những cuộc điều trần trước quốc hội như những vụ
hành hình vô bổ, chỉ là nơi các vị dân cử biểu diễn trước máy
truyền hình, nói dông dài chuyện không đâu chỉ cốt lấy điểm với cử
tri. Hầu hết các vị dân cử, Dân Chủ hay Cộng Hoà cũng vậy, đều bất
tài, thiếu khả năng, giả dối, bất lịch sự, không lo cho quyền lợi
đất nước mà chỉ lo cho cái ghế của mình thôi. Đã có nhiều lần ông
Gates chỉ muốn cắt ngang các cuộc điều trần, từ chức tại chỗ vì
bực mình.<br/><br/>- Ông Gates tuy là bộ trưởng Quốc Phòng, nhưng lại nhận định đối thủ
khó trị nhất của ông chính là Bộ Quốc Phòng, một guồng máy thư lại
cực kỳ nặng nề, trong đó quyền lợi phe nhóm trấn áp mọi quyết
định. Các dân biểu, nghị sĩ từ liên bang đến địa phương, thống đốc,
các đại diện các khối áp lực, các tướng lãnh,... đấu tranh chống
nhau quyết liệt vì quyền lợi phe nhóm khi ngân sách của Bộ Quốc
Phòng chiếm phần lớn nhất trong ngân sách quốc gia.<br/><br/>- Liên quan đến tin quốc tế, ông Gates cũng tiết lộ TT Obama đã ngăn
không cho TT Đại Hàn Lee Myung Bak thả bom Bắc Hàn trả đũa vụ Bắc Hàn
dội bom một hòn đảo Nam Hàn năm 2010 vì sợ gây ra chiến tranh tại đây.<br/><br/>Phải nói ngay, hồi ký của ông Gates đầy mâu thuẫn. Trong một cố gắng
quân bằng quan điểm, ông đã nhiều lần ca tụng tất cả những người ông
chỉ trích, từ TT Bush đến TT Obama, PTT Biden và bà Hillary luôn. Trong
khi ông chỉ trích TT Obama đủ chuyện thì ông lại khẳng định ủng hộ
tất cả những quyết định của TT Obama và khen quyết định đột kích
giết Bin Laden là quyết định can đảm nhất ông đã thấy nơi một tổng
thống. Trong khi ông chê PTT Biden sai lầm liên tục, thì ông lại xác
nhận ông chia sẻ quan điểm với PTT Biden trên hầu hết mọi vấn đề. Ông
chỉ trích bà Hillary chỉ biết lo đếm phiếu, nhưng lại ca tụng bà sẽ
là một tổng thống giỏi. Ông chỉ trích quốc hội nặng nề, nhưng lại
khen đa số các vị dân cử đối xử rất tử tế với ông. Người ta chỉ có
thể hiểu quan điểm thực của ông Gates qua những chuyện cụ thể ông nêu
ra, chứ không thể tin được những lời ca tụng chung chung, có vẻ như là
những lời nói vớt vát không mấy ý nghiã.<br/><br/>Dĩ nhiên, chuyện các chính khách Mỹ hấp tấp viết hồi ký bôi bác
các thượng cấp hay đồng sự của mình để thu tiền bán sách, hay để
tự biện minh trong khi chuyện thời sự còn nóng hổi, là chuyện thường
tình trong hý trường chính trị Mỹ. Trước đây, TT Bush đã lãnh đủ hồi
ký của cựu bộ trưởng Tài Chánh Paul O’Neill, cựu phát ngôn viên Scott
McClellan, cựu cố vấn chống khủng bố Richard Clarke,… TT Clinton cũng
lãnh đủ từ phụ tá thân cận nhất George Stephanopoulos. Nhưng hồi ký
của ông Gates có điểm đặc biệt là ông là người phục vụ cho 8 vị
tổng thống, cả Cộng Hoà lẫn Dân Chủ, tức là tính phe đảng ít nhất,
không như mấy người phụ tá vừa nêu của các TT Bush và Clinton.<br/><br/>Chính vì uy tín cá nhân rất lớn của ông Gates nên những chỉ trích
của ông trở thành nặng ký nhất. Và dĩ nhiên truyền thông phe ta cũng
đã tấn công ông Gates mạnh hơn bao giờ hết. Họ chiả mũi dùi vào sự
kiện hồi ký của ông Gates chỉ trích TT Obama được xuất bản khi TT
Obama vẫn còn tại chức, và cho đó là hành động thiếu tự trọng
–dishonorable. Truyền thông dòng chính quên một điều là cả ba cuốn hồi
ký của ba phụ tá của TT Bush nêu trên đều được phát hành khi TT Bush
cũng còn đang tại chức. Hồi ký của các ông O’Neill và Clarke phát
hành năm 2004 trong khi hồi ký của ông McClellan phát hành đầu 2008. Cả
ba người đều mạt sát TT Bush không nương tay. Khi đó, không thấy báo phe
ta nào chê mấy ông đó là “dishonorable” mà chỉ thấy ca ngợi họ đã
dám nói lên sự thật. Thế mới thấy truyền thông dòng chính phe đảng
như thế nào.<br/><br/>Được hỏi về cuốn hồi ký, TT Obama, qua phát ngôn viên Tòa Bạch Ốc,
chỉ vắn tắt đề cao những đóng góp trước đây của bộ trưởng Gates,
cũng như giải thích TT Obama chủ trương dùng các phụ tá có khác biệt
ý kiến để có thể thu thập ý kiến một cách rộng rãi. Chưa thấy PTT
Biden và cựu ngoại trưởng Hillary Clinton có phản ứng gì.<br/><br/>Nói chung, thái độ của TT Obama đối với hai cuộc chiến tại Iraq và
Afghanistan, theo như sự trình bày của ông Gates, không có gì đáng ngạc
nhiên, mà chỉ là xác nhận những gì mọi người đã nghĩ. TT Obama trong
thâm tâm, bất kể những lời tuyên bố đủ kiểu, chỉ muốn chấm dứt hai
cuộc chiến này, và đã tìm đủ mọi cách chấm dứt và rút lính Mỹ
về, càng sớm càng tốt.<br/><br/>Những người chủ hoà sẽ hoan hô thái độ này của TT Obama dĩ nhiên.
Nhưng có lẽ họ quên rằng vấn đề không giản dị như vậy.<br/><br/>Trong cuộc chiến tại Việt Nam, dù sao thì quân CSBV cũng không đe dọa
lãnh thổ Mỹ hay quyền lợi gì của Mỹ tại Đông Nam Á hay bất cứ nơi
nào khác. Mỹ có rút quân ra khỏi Việt Nam thì chỉ có dân Việt là
bị thiệt hại nặng thôi, không sứt móng chân nào của Mỹ, ngoài việc
mất uy tín chính trị dĩ nhiên. Nhưng hai cuộc chiến tại Trung Đông
hoàn toàn khác. Đây là hai cuộc chiến chống khủng bố, nhằm tiêu diệt
các lực lượng khủng bố, hay ít ra không cho các lực lượng này đất
dung thân, luyện tập quân khủng bố, chế tạo vũ khí, làm bàn đạp để
trực tiếp tấn công vào Mỹ như vụ 9/11.<br/><br/>Nếu như Mỹ không diệt hoàn toàn hay phần lớn sức mạnh của các lực
lượng khủng bố thì các lực lượng này lúc nào cũng là một đe dọa
trực tiếp lên an ninh của lãnh thổ Mỹ và an toàn cho dân Mỹ.<br/><br/>Việc TT Obama bằng mọi giá hấp tấp chấm dứt hai cuộc chiến, rút quân
về đã để lại những hậu quả mà cho đến nay chưa ai dám xác định sẽ
là tốt hay xấu cho nước Mỹ trong những năm tháng tới. Chỉ biết là
hai cuộc chiến này, tuy đã biến mất khỏi trang nhất các báo phe ta,
nhưng thật sự chỉ chấm dứt đối với Mỹ thôi, chứ chưa chấm dứt đối
với hai xứ này. Trái lại, hai cuộc chiến có khuynh hướng ngày càng
bộc phát mạnh.<br/><br/>Tin mới nhất cho thấy lực lượng Al Qaeda đã chiếm hoàn toàn thành
phố Falluja, một trong những cứ điểm chiến lược quan trọng nhất nhì
tại Iraq mà quân Mỹ đã tốn không biết bao nhiêu xương máu để bảo vệ,
trong khi khủng bố tung bom giết chết hơn 40 người tại hai nơi ngay tại
thủ đô Bagdad trong một ngày 13/1 vừa qua. Nội trong một năm 2013, hơn
8.000 người đã thiệt mạng trong cuộc chiến kéo dài này. Chính quyền
Iraq, từ thủ tướng Maliki đến đại sứ Iraq tại Mỹ, đã lên tiếng “phàn
nàn” về sự phủi tay của chính quyền Obama.<br/><br/>Ngoại trưởng John Kerry đã thẳng thừng tuyên bố “đây là chuyện nội bộ
Iraq”. Hãy đợi xem đến khi Al Qaeda lật đổ được các chính quyền yếu
ớt của Iraq và Afghanistan xem đây có còn là chuyện “nội bộ” của hai
xứ này không, hay lại trở thành một đe dọa trực tiếp lên an ninh Mỹ
khi một trong hai xứ này, hai cả hai xứ này, biến thành căn cứ mới
của một Al Qaeda tái sinh.<br/><br/>Hy vọng là sẽ không có ngày một tổng thống Mỹ nào đó lại phải ra
lệnh thủy quân lục chiến Mỹ trở lại Iraq và Afghanistan để diệt
khủng bố. Khi đó, TT Obama có viết bao nhiêu hồi ký để biện giải
cũng khó tránh được trách nhiệm với lịch sử. (19-01-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ
Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a216185/chuyen-hoi-ky-gates

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/