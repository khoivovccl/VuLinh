# FOX Phỏng Vấn TT Obama

11/02/2014

...truyền thông dòng chính đã chui vào ngủ chung giường với Obama từ
lâu rồi...<br/><br/>Tối chủ nhật 2/2 tuần rồi, cả nước Mỹ bị hút hồn bởi trận Super
Bowl, là trận chung kết bóng đá kiểu Mỹ (football) giữa hai đội của
hai thành phố Denver và Seattle. Cả thế giới –ngoại trừ anh láng
giềng Canada- chẳng biết, chẳng coi, và chẳng hiểu football Mỹ, nhưng
đó chính là môn thể thao “quốc hồn quốc túy” của Mỹ. Hơn xa baseball
(ở Việt Nam gọi là “bóng chầy”) và basketball (bóng rổ). Trận đấu
hôm đó đã thu hút được con số kỷ lục hơn 111 triệu người theo dõi.<br/><br/>Dĩ nhiên với số lượng người coi lớn như vậy thì mấy ông chính khách
khó mà bỏ qua, nhất là TT Obama. Trận Super Bowl đã sinh ra một thông
lệ mới từ vài năm qua: phỏng vấn tổng thống trước khi trận đấu mở
màn, và cuộc phỏng vấn được dành cho ký giả hàng đầu của đài
truyền hình được trình chiếu trận đấu. Trận Super Bowl năm nay do đài
Fox chiếu, nên nhà báo và bình luận gia hàng đầu của Fox là ông Bill
O’Reilly được trao cho trách nhiệm. Đây là lần thứ hai ông O’Reilly
phỏng vấn TT Obama qua trận Super Bowl.<br/><br/>Thật ra, cuộc phỏng vấn trong trận Super Bowl chỉ là phần đầu, phần
hai của cuộc phỏng vấn được trình chiếu tối ngày hôm sau, Thứ Hai
3/2, thu hút được đâu hơn bốn triệu người coi.<br/><br/>Cái đáng phiền cho TT Obama là cái ông O’Reilly này có lẽ là anh nhà
báo bảo thủ chống TT Obama khá mạnh ngay từ đầu khi ứng viên Barack
Obama mới xuất hiện vận động tranh cử tổng thống cách đây sáu năm.
Hơn thế nữa, ông này cũng là bình luận gia thu hút nhiều người coi
nhất trên truyền hình Mỹ, qua một đài truyền hình với nhiều người
coi nhất luôn.<br/><br/>Trong tuần lễ cuối tháng Một, 2014, trong giờ cao điểm, trung bình đã
có 2,3 triệu người coi Fox, trong khi chỉ có chưa tới 900 ngàn người
coi MSNBC và 600 ngàn người coi CNN. Chương trình The O’Reilly Factor của
ông O’Reilly thu hút trung bình trên 3 triệu người coi mỗi lần, một con
số mà các bình luận gia khác chỉ có thể mơ mộng.<br/><br/>Dân Mỹ có quyền tự do tuyệt đối lựa chọn báo để đọc và đài truyền
hình để xem. Khó có thể giải thích được sự thành công của đài Fox
nếu cứ khăng khăng cho là đài Fox tuyên truyền một chiều hay chuyên môn
phịa chuyện, đả kích chính quyền Obama một cách vu vơ. Ta cũng để ý
thấy chuyên gia chính trị James Carville cũng đã mới đầu quân đài Fox.
Ông Carville là tác giả thành công của hai lần tranh cử của TT Bill
Clinton, từng là cố vấn chính trị của TT Clinton, là một người có tư
tưởng cấp tiến cực đoan, nổi tiếng mạnh miệng, chống Cộng Hòa kịch
liệt. Oái ăm thay, ông Carville cũng là chồng của bà Mary Matalin, là
người bảo thủ cực đoan, chuyên mạt sát đảng Dân Chủ, đã từng là cố
vấn chính trị của PTT Dick Cheney. Thế mới thấy được cái hay của tự
do dân chủ của Mỹ. Hai người là hai thái cực về quan điểm chính trị,
nhưng vẫn là vợ chồng. Một chuyện mà dân Việt ta cần suy gẫm.<br/><br/>Để đáp lễ lại cái thiếu thiện cảm của ông O’Reilly, đài Fox cũng là
đài thường bị chính quyền Obama tố cáo là có thiên kiến muốn chống
phá Nhà Nước Obama. TT Obama đã từng nêu đích danh đài Fox để chỉ
trích, một chuyện mà chưa một tổng thống nào làm trước đây.<br/><br/>Dựa trên bối cảnh đó, cuộc phỏng vấn TT Obama lần này đã diễn ra
trong không khí “đối nghịch” khá nặng nề. Ông O’Reilly gay gắt chất
vấn TT Obama về những xì-căng-đan của năm qua, trong khi TT Obama chỉ
trích ông O’Reilly và đài Fox đã phóng đại cũng như nuôi dưỡng những
xì-căng-đan đó theo kiểu mà tổng thống Thiệu vẫn thường nói, “có ít
xít ra nhiều”.<br/><br/>Cuộc đối thoại cũng có vài phần “lịch lãm” khi hai bên ca tụng nhau.
Ông O’Reilly ủng hộ quyết định tăng lương tối thiểu, cũng như những
quyết định giúp đỡ các cựu chiến binh của chính quyền Obama. Ngược
lại, TT Obama cũng khẳng định dù sao ông cũng “thích” ông O’Reilly (“but
I like you anyway”).<br/><br/>Đại khái thì có ba vấn đề được ông O’Reilly chú tâm đến.<br/><br/>VỤ BENGHAZI<br/><br/>Người ta còn nhớ đúng ngày 11 tháng 9, 2012, kỷ niệm 9/11 và đúng hai
tháng trước ngày bầu cử tổng thống Mỹ, tòa lãnh sự Mỹ tại Benghazi
bị tấn công bằng súng đạn, toà lãnh sự bị đánh bom, cháy thiêu rụi,
đại sứ Mỹ tại Libya và 3 nhân viên bị thảm sát. Ngay sau đó, chính
quyền Obama phổ biến tin đây là cuộc biến động tự phát, do dân chúng
Benghazi bất mãn vì một cuốn phim ngắn phổ biến trên YouTube, có nội
dung phỉ báng Đấng Tiên Tri Mohammed, không liên quan gì đến khủng bố.
Sau đó, tin tức lòi ra chẳng có dân chúng nào tự phát biểu tình gì
hết, mà là một cuộc đột kích bằng bom và súng có kế hoạch chu đáo
của khủng bố liên hệ đến Al Qaeda.<br/><br/>Chuyện biểu tình tự phát không liên hệ đến khủng bố là một chuyện
rất quan trọng, vì trước đó vài tuần, TT Obama đã công khai tuyên bố
trước Đại Hội Đảng Dân Chủ là Al Qaeda đã bị khống chế, bây giờ nếu
loan tin đây là khủng bố Al Qaeda tấn công giết được đại sứ Mỹ thì
thông điệp của TT Obama hoá ra là thất thiệt, sẽ ảnh hưởng rất tai
hại cho cuộc tranh cử của TT Obama.<br/><br/>Cho đến nay, chính quyền Obama vẫn khẳng định tin tức đầu tiên Hoa
Thịnh Đốn nhận được là biểu tình tự phát từ cuốn phim, biến thái
thành tấn công bạo động, và chính quyền Obama tuyệt đối không hề có
ý định bóp méo tin tức để giúp cuộc tranh cử của TT Obama.<br/><br/>Cuộc điều tra của quốc hội cho đến nay vẫn chưa kết thúc vì cả
chính quyền Obama lẫn các nghị sĩ và dân biểu Dân Chủ đều tìm cách
câu giờ, cản trở, ngăn cản các cuộc điều trần và không cung cấp cho
quốc hội các tài liệu mật liên quan đến vụ này. Nhưng cho đến nay,
nhiều viên chức Bộ Quốc Phòng và CIA đã lên tiếng xác định là cả
hai cơ quan này đều biết ngay từ giây phút đầu đây là cuộc tấn công
quy mô của khủng bố liên hệ đến Al Qaeda, đã báo cáo ngay lên tổng
thống, và họ đã ngỡ ngàng khi thấy chính quyền Obama lôi ra chuyện
cuốn phim gây ra biểu tình tự phát.<br/><br/>Câu chuyện đến nay vẫn chưa ngã ngũ.<br/><br/>Ông O’Reilly đã đặt thẳng vấn đề này lên TT Obama, nhưng câu trả lời
của TT Obama vẫn chẳng có gì đặc biệt, vẫn chỉ là lập lại chuyện
Nhà Nước Obama không có ý che dấu sự thật, và những tuyên ngôn đầu
của chính quyền phản ảnh đúng những hiểu biết lúc đó của chính
quyền và chính quyền Obama không hề có gian ý để giúp cuộc tranh cử
của TT Obama. Một câu trả lời dĩ nhiên chẳng trả lời gì hết và
chẳng thuyết phục được ai. Dĩ nhiên là như vậy, chứ không lẽ TT Obama
lại tuyên bố “chúng tôi cần nói vậy để có thể đắc cử lại”?<br/><br/>VỤ IRS<br/><br/>IRS là cơ quan thuế vụ liên bang. Cơ quan này đã bị tố cáo cố tình
làm khó dễ, không cho các tổ chức bảo thủ liên quan đến Tea Party có
giấy phép hoạt động miễn thuế, khiến họ không vận động gây quỹ yểm
trợ tài chánh cho TĐ Romney hay chống TT Obama trong cuộc tranh cử năm
2012 được. Nhiều bằng chứng rõ rệt đã xác nhận chuyện này. Nhiều
viên chức cao cấp của IRS đã thành vật tế thần, bị sa thải.<br/><br/>Vấn đề là nguyên nhân nào thúc đẩy IRS làm chuyện này. Phe bảo thủ
tố giác đây nằm trong kế hoạch bí mật của chính quyền Obama để tạo
lợi thế cho TT Obama trong cuộc tranh cử. Phe chính quyền khẳng định
không có gian ý, mà đây chỉ là kết quả của sự tắc trách hay thiếu
khả năng của các viên chức IRS, và họ đã bị sa thải.<br/><br/>Viện dẫn chuyện tắc trách và thiếu khả năng nghe không có lý gì lắm
khi mà hậu quả của sự tắc trách và thiếu khả năng đó lại hoàn
toàn có lợi cho phiá tổng thống và có hại cho đối lập của tổng
thống. Một trùng hợp thật khó tin. Tại sao các tổ chức cấp tiến
thân thiện với phe TT Obama lại được cấp giấy phép một cách mau mắn,
không có gì “tắc trách” hay “thiếu khả năng”?<br/><br/>Những cố gắng của phe Cộng Hoà để mang chuyện này ra trước quốc hội
đã chẳng đi đến đâu, dĩ nhiên vì chính quyền Obama chống đối, với sự
hậu thuẫn của phe Dân Chủ trong quốc hội.<br/><br/>Ông O’Reilly chất vấn về vấn đề này, và TT Obama đã trả lời ngắn
gọn là không có chuyện gian ý gì hết, chỉ là vài quyết định ngu
xuẩn (bone-headed decisions). Trả lời cũng như không. Sự thật về vụ IRS
có lẽ sẽ chẳng bao giờ ai biết được, ngoại trừ một vài người trong
cuộc. Dù sao thì gạo cũng đã thành cơm rồi, TT Obama đã tái đắc cử
rồi.<br/><br/>VỤ OBAMACARE<br/><br/>Ông O’Reilly hỏi TT Obama ông có nghĩ là câu tuyên bố “ai cũng có thể
giữ được bảo hiểm của mình” là sai lầm lớn nhất của tổng thống
không? TT Obama đã tránh né không trả lời mà chỉ nói “tôi biết là anh
có một danh sách rất dài những sai lầm của tôi”.<br/><br/>Ông O’Reilly cũng chất vấn tại sao bộ trưởng Y Tế Kathryn Sebellius đã
không bị mất chức sau thảm hoạ “trục trặc kỹ thuật” với Obamacare
xẩy ra? Tại sao không có ai chịu trách nhiệm? TT Obama cũng đã không
trả lời thẳng, mà chỉ nói bâng quơ tất cả nội các của ông đều phải
chịu trách nhiệm về việc làm của họ.<br/><br/>Phần hai của cuộc phỏng vấn được dành nhiều cho vấn đề cách biệt
giàu nghèo ở Mỹ, và vài vấn đề thời sự như việc lập ống dẫn dầu
từ Canada qua tới Texas.<br/><br/>Đặc biệt là ông O’Reilly đã hỏi thẳng TT Obama “ông có nghĩ tôi không
công bằng không”, và được TT Obama trả lời không kém thẳng thắn là
“có, tôi nghĩ ông không công bằng”. Khi được ông O’Reilly hỏi thẳng tổng
thống có thể nêu chính xác một thí dụ về chuyện không công bằng
không, thì TT Obama đã trả lời ông O’Reilly đã tuyệt đối không công
bằng trong cách đối xử với TT Obama và chính quyền của ông khi đã cố
kéo dài cuộc bàn cãi về những sai lầm và trục trặc để biến chúng
thành những xì-căng-đan khủng khiếp.<br/><br/>Công bằng mà nói, đài Fox và ông O’Reilly vẫn nhắc lại những chuyện
này trong khi các đài truyền hình và báo phe ta khác đều đã bỏ qua
từ lâu rồi. Nhưng vấn đề là chính quyền Obama cho đến nay thực sự
vẫn chưa đưa ra những câu trả lời rõ rệt, giải tỏa hẳn tất cả những
khúc mắc. Chỉ khiến thiên hạ có thể hiểu là chính quyền Obama vẫn
có cái gì đang dấu diếm mọi người.<br/><br/>Nói chung, tuy cuộc phỏng vấn là câu chuyện thời sự hàng đầu vì đây
là sự đối đầu của TT Obama với một nhà báo chỉ trích ông mạnh
nhất, nhưng cuối cùng thì cuộc phỏng vấn cũng chẳng đưa ra ánh sáng
chuyện gì mới lạ hết. Những lập luận chống TT Obama của ông O’Reilly,
cũng như những câu trả lời tránh né của TT Obama, đều thuộc loại tin
“đường mòn” mà ai cũng đều biết từ lâu rồi.<br/><br/>Phản ứng của truyền thông dĩ nhiên rất dễ tiên đoán được. Báo phe ta
Washington Post viết bài dài đả kích ông O’Reilly đã thiếu lễ độ với
tổng thống, liên tục cắt ngang tổng thống, với giọng điệu gay gắt.
Trong khi đó, những báo bảo thủ thì hoan nghênh những câu hỏi thẳng
thắn chưa có câu trả lời của ông O’Reilly, cho dù những câu hỏi đó
vẫn chưa có câu trả lời rõ rệt.<br/><br/><div align="center"><b>* * *<br/></b></div><br/>Câu chuyện quan hệ giữa TT Obama và truyền thông đã được bàn thảo sâu
rộng từ lâu rồi. Điều hiển nhiên không thể chối cãi được là nếu
không có sự tích cực hậu thuẫn mạnh mẽ của truyền thông cấp tiến
thì người ngồi trong Tòa Bạch Ốc ngày nay rất có thể đã không phải
là ông Barack Obama, mà có thể là ông McCain, hay ông Romney rồi. Trong
suốt sáu năm qua, nhất là trong hai mùa tranh cử tổng thống của năm
2008 và 2012, truyền thông dòng chính đã đóng vai trò làm ống loa cho
ứng viên Obama, cũng như đã đóng vai trò bảo vệ ông, thổi phồng những
thành quả “ảo” và ém nhẹm những tin bất lợi, trong khi luôn tiếp tay thổi
phồng những tin bất lợi cho đối lập Cộng Hòa.<br/><br/>Một ví dụ tiêu biểu của thái độ thiên cấp tiến của truyền thông
dòng chính gần đây là việc truyền thông cấp tiến triệt để khai thác
chuyện kẹt cầu giao thông tại New York của Thống Đốc New Jersey Chris
Christie, một người của Cộng Hòa. Như đài truyền hình MSNBC đã loan
tin, bình luận, tranh luận, … về vụ này liên tục suốt ngày trong mấy
ngày liền.<br/><br/>Sau khi bị đánh tơi bời, TĐ Christie đã họp báo khẳng định tuy không
hay biết gì về chuyện đóng ba làn xe trên cầu gây ra kẹt cầu vĩ đại,
nhưng vẫn thẳng thắng nhận trách nhiệm và công khai xin lỗi dân chúng
và xin lỗi thị trưởng Fort Lee, sa thải những viên chức liên hệ. Nhưng
câu chuyện vẫn chưa chấm dứt. Báo New York Times mới đây chạy tít lớn
“Christie knew” cho một bài viết tố TĐ Christie biết rõ quyết định
đóng làn xe, dựa trên một bức thư của luật sư đại diện cho ông Giám
Đốc Giao Thông New Jersey, người đã lấy quyết định đóng các làn xe
trên cầu. Trong thư, ông luật sư nói bâng quơ trong hai dòng là ông “có
bằng chứng là TĐ Christie biết trước mọi chuyện”. Chỉ như vậy là đủ
cho NYT chạy tít lớn tố ông Christie “knew” mà không cần kiểm chứng gì
hết.<br/><br/>Một ngày sau bài báo của NYT, ông chủ tịch ủy ban đặc nhiệm của
quốc hội New Jersey điều tra về vụ này, một dân biểu Dân Chủ, đã
tuyên bố ông có trong tay hơn 3.000 trang tài liệu về vụ này, mà không
hề thấy tài liệu nào chứng minh TĐ Christie biết trước. Dĩ nhiên cuộc
điều tra của quốc hội chưa kết thúc và chưa ai biết sự thật như thế
nào. Nhưng chuyện NYT nhẩy nhổm lên khẳng định TĐ Christie biết trước,
dựa trên một câu trong thư của một luật sư khiến người ta có cảm
tưởng như NYT rất khát tin và háo hức muốn đánh một “ngôi sao” của
Cộng Hòa. Người ta cũng còn nhớ năm 2008, NYT cũng loan tin về chuyện
TNS John McCain... ăn vụng với đào nhí. Để rồi sự thật lòi ra là chỉ
là... tin vịt, nhưng cũng đã để lại vết đen cho ông ứng viên tổng
thống Cộng Hoà khi đó đang tranh cử chống ứng viên Obama.<br/><br/>NYT đã không còn là tờ báo nghiêm chỉnh và quan trọng nhất Mỹ từ lâu
lắm rồi. Bây giờ chỉ giống như mấy tờ báo lá cải trong siêu thị,
luôn khát tin nóng bỏng giựt gân thôi. Có thể vì nhu cầu nuôi dưỡng
tờ báo, khi ai cũng biết ngành báo chí Mỹ đang bị khủng hoảng tài
chánh lớn, đã khiến Newsweek đóng cửa, và các báo lớn như NYT,
Washington Post, Time, … đang vất vả sống qua ngày.<br/><br/>Tính thiên vị của truyền thông dòng chính cũng ngày càng lộ liễu.<br/><br/>Mới đây nhất, CNN tung tin “điều tra đặc biệt” cho biết là đảng Cộng
Hoà đã tung ra hàng loạt trang mạng giả dưới tên các ứng viên quốc
hội Dân Chủ khiến nhiều người không để ý tưởng là trang mạng thật
của mấy ứng viên này. Trên các trang mạng đó, dĩ nhiên là có nhiều
tin thất thiệt và bất lợi cho ứng viên đó. CNN chạy tít lớn và viết
kiểu như mới khám phá ra một hành động gian trá ghê gớm của Cộng
Hòa. Một tin giựt gân lớn!<br/><br/>Nghe thì cũng đáng bực mình với cái tiểu xảo của Cộng Hòa thật.
Nhưng nếu đọc kỹ bài viết đến gần cuối bài thì sẽ thấy... đảng Dân
Chủ cũng làm y chang như vậy! Điều khác biệt là bên Cộng Hoà, chiến
thuật này do Ủy Ban Quốc Gia của đảng –National Committee- điều hợp,
trong khi bên Dân Chủ thì do các Ủy Ban cấp tiểu bang chủ động. Nói
cách khác, cả hai đảng đều chơi trò này, vậy tại sao CNN lại chạy
tít lớn và viết bài dài thoòng để bôi bác Cộng Hoà? Vì nhu cầu có
tin giựt gân? Hay vì tính phe đảng?<br/><br/>Như trên cột báo này đã viết, truyền thông dòng chính đã chui vào
ngủ chung giường với chính quyền Obama từ lâu rồi. Muốn có cái nhìn
khác, chỉ còn đài Fox. Đó là lý do giải thích tại sao số người xem
Fox bằng tổng cộng số người coi tất cả các đài MSNBC, CNN, ABC, CBS,
và NBC gộp lại. (09-02-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a217171/fox-phong-van-tt-obama

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/