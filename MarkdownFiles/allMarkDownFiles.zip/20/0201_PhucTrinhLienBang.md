# Phúc Trình Liên Bang

04/02/2014

...chẳng có báo cáo thành quả nào, mà chỉ lập lại những hứa hẹn viễn vông và cũ
mèm...<br/><br/>Tối thứ ba vừa qua, TT Obama đọc phúc trình thường niên về Tình Trạng Liên
Bang. Đây là lần thứ năm TT Obama báo cáo trước lưỡng viện, nội các, Tối Cao
Pháp Viện, và toàn thể quốc dân qua trực tiếp truyền hình.<br/><br/>Bài diễn văn này được tung hô như có lẽ quan trọng hàng nhì sau bài diễn văn đầu
tiên năm 2009 khi TT Obama mới đắc cử và đề ra chương trình hành động của ông.
Năm nay, báo cáo được coi là quan trọng vì nhu cầu kích động lại vai trò của
chính quyền Obama sau 5 năm hoạt động èo uột và nhất là sau năm đại họa 2013.<br/><br/>Khách quan mà nhận định, TT Obama trong suốt thời gian cầm quyền vừa qua, đã chỉ
làm được vài ba chuyện đáng nói, mà vài ba chuyện đó cũng chẳng phải là những
thành công huy hoàng gì.<br/><br/>Quan trọng nhất dĩ nhiên là Obamacare thay đổi toàn diện hệ thống y tế Mỹ,
nhưng đã được bung ra trong lủng củng thảm hại, và đã bị rời hoãn liên tục.
Trong tương lai sẽ còn nhiều điều chỉnh, sửa đổi vì quá nhiều sai sót và hậu quả
tai hại, bị đa số dân chống.<br/><br/>Cải cách tài chánh thì chẳng ai biết cũng chẳng ai thấy tác động gì. Chương trình
kích động kinh tế thất bại vì chẳng phục hồi được kinh tế trong khi tỷ lệ thất
nghiệp vẫn cao chót vót.<br/><br/>Hai cuộc chiến tại Iraq và Afghanistan đối với Mỹ đã chấm dứt, nhưng hiển nhiên
đây là hai cuộc tháo chạy kiểu mang con bỏ chợ, bỏ mặc hai nước này vật lộn với
nội chiến ngày càng đẫm máu.<br/><br/>Năm vừa qua là năm đại nạn với hàng loạt xì-căng-đan như khủng bố tấn công
Benghazi, NSA nghe lén thiên hạ, anh Snowden đào ngũ qua Trung Cộng rồi Nga,
mang theo không biết bao nhiêu bí mật an ninh quốc gia lớn nhất, Bộ Tư Pháp
theo dõi nhà báo, sở thuế đì các tổ chức bảo thủ Tea Party, chiến dịch Fast and
Furious (Bộ Tư Pháp và FBI bán súng cho băng đảng ma túy để có thể theo dõi
chúng, nhưng rốt cuộc mất dấu vết, và cả trăm súng đủ loại đã được bán cho
chúng, rồi được sử dụng để bắn chết lính biên phòng Mỹ) và cao điểm là khủng hoảng
Obamacare.<br/><br/>Vài kế hoạch được khua chiêng trống rất mạnh như giải quyết thất nghiệp, mang
việc làm từ ngoài nước về lại, di dân ở lậu, kiểm soát súng, kiểm soát sự bành
trước của vũ khí hạt nhân tại Iran và Bắc Hàn, ổn định Trung Đông, nhất là tại
Ai cập, Syria và dĩ nhiên Iraq và Afghanistan, cải thiện bang giao với các “đối
tác chiến lược” Nga và Tàu, … chẳng chuyện nào ra được kết quả cụ thể nào.<br/><br/>Tất cả đã biến TT Obama thành tổng thống rớt dù nhanh nhất trong các tổng thống
hiện đại: từ 52% đắc cử cách đây hơn một năm xuống dưới 40% hiện nay. Rồi đa số
dân Mỹ cũng cho rằng TT Obama thiếu khả năng và không còn đáng tin nữa.<br/><br/>Trong tình trạng đó, bài diễn văn có tính bào chữa và hứa hẹn cho năm tới nhiều
hơn là báo cáo về thành tích năm qua.<br/><br/>Tâm điểm của bài diễn văn dĩ nhiên vẫn là… đổ thừa, theo đúng mô thức Obama. Đổ
thừa cho TT Bush từ 5 năm qua không còn ai tin nữa, nên TT Obama quay qua đổ thừa
quốc hội, mà quên không nhắc đến chuyện đảng Dân Chủ phe ta nắm đa số tại Thượng
Viện từ ngày ông nhậm chức đến giờ. Đại khái, TT Obama cho rằng ông đã không
làm gì quan trọng được trong thời gian qua vì bị quốc hội bó tay, và do đó,
trong năm tới, ông sẽ dùng quyền của Hành Pháp để lấy quyết định, không cần
thông qua quốc hội nữa nếu cần thiết. Ông nhấn mạnh ông có “cây bút”, có thể ký
những luật ông muốn bất cần quốc hội.<br/><br/>Năm 2008, TT Obama tranh cử trên chiêu bài đại đoàn kết dân tộc. Đoàn kết chính
trị giữa bảo thủ và cấp tiến, Dân Chủ và Cộng Hòa. Đoàn kết xã hội giữa giàu và
nghèo, giữa da trắng và da màu. Năm 2012, chỉ bốn năm sau, chiêu bài tranh cử
đã biến thành cấp tiến chống bảo thủ, 99% nghèo chống 1% giàu, da màu chống da
trắng, và qua Obamacare, là cuộc chiến giữa người bệnh nghèo chống các đại gia
bảo hiểm, hãng thuốc, nhà thương và bác sĩ. Bây giờ, 2014, chiến lược “chia để
trị” của 2012 tiếp tục triển khai dưới hình thức mới, Hành Pháp của hành động
chống Lập Pháp của trì trệ, Nhà Nước Obama chống bất quân bình lợi tức,... Thời
buổi của đại đoàn kết dân tộc quả đã qua từ lâu lắm rồi. Bây giờ là thời đại của
đấu tranh giai cấp mới dưới mọi khiá cạnh. “Ta” chống lại “chúng”.<br/><br/>Để chứng minh quyết tâm hành động, TT Obama đã đơn phương quyết định tăng lương
tối thiểu lên tới $10.10 cho các giới lao động có khế ước với Nhà Nước liên
bang mà không cần thông qua quốc hội. Đây là bước tiến mà TT Obama cho là quan
trọng trong cuộc chiến chống nghèo, tiến tới quân bình lợi tức –income
equality- mà ông bắt đầu hô hào gần đây. Nghe thì có vẻ ghê gớm, nhưng thực tế,
lao động có khế ước với Nhà Nước liên bang chỉ có một vài trăm ngàn người trong
số mấy chục triệu dân lao động Mỹ. Chỉ là vài hạt cát trong sa mạc nhưng được
TT Obama hô hoán ầm ĩ, càng chứng tỏ sự bất lực của tổng thống, không thực hiện
chuyện gì lớn lao hơn được.<br/><br/>Việc TT Obama, một cựu phụ giảng về luật Hiến Pháp, quyết định qua mặt quốc hội
là một ngạc nhiên cho các luật gia chính trường Mỹ, nhưng thật ra là chuyện
không có gì lạ nếu nhìn lại cách hành động của TT Obama trong thời gian qua.<br/><br/>Nhà báo Linda Feldmann đã viết một bài dài trên báo Christian Science Monitor,
liệt kê những quyết định rất đáng quan ngại của TT Obama vì có thể đã vi phạm
Hiến Pháp:<br/><br/>- Đơn phương thay đổi việc áp dụng luật Obamacare là luật đã được quốc hội phê
chuẩn;<br/><br/>- Đơn phương quyết định luật chống đồng tính là vi phạm Hiến Pháp;<br/><br/>- Đơn phương cấm trục xuất một số dân cư trú bất hợp pháp;<br/><br/>- Đơn phương nhìn nhận luật hôn nhân đồng tính tại Utah, mặc dù vấn đề còn đang
được Tối Cao Pháp Viện Utah cứu xét;<br/><br/>- Đơn phương bành trướng các công tác theo dõi thiên hạ của NSA;<br/><br/>- Đơn phương cho phép bắn giết khủng bố tại Trung Đông, kể cả khủng bố có quốc
tịch Mỹ mà không cần tòa án xét xử gì hết.<br/><br/>Ngoài ra, trong thời gian qua, TT Obama đã bổ nhiệm một số viên chức cao cấp
theo kiểu lén lút, trong khi quốc hội nghỉ hè.<br/><br/>Trên đây chỉ là vài ví dụ lớn, không bao gồm tất cả các hành động lấn quyền của
TT Obama. Ta cũng cần ghi nhận một vài quyết định nêu trên đã bị thưa ra tòa,
như quyết định bổ nhiệm vài viên chức cao cấp nêu trên, các toà án còn đang
truy cứu vấn đề, và do đó, có thể bị lật ngược hay thu hồi. Có nhiều triển vọng
nhiều vấn đề sẽ lên tới Tối Cao Pháp Viện. Khi đó, ta sẽ nhìn thấy rõ ràng hơn
giới hạn quyền hành giữa Hành Pháp và Lập Pháp.<br/><br/>Theo GS Jonathan Turley, chuyên gia về Hiến Pháp của đại học George Washington,
TT Obama đã vượt xa TT Bush về chuyện lấn quyền cho dù trước đây ứng viên tổng
thống Obama đã từng lớn tiếng chỉ trích TT Bush đã lộng hành coi thường Hiến
Pháp. Theo GS Turley, TT Obama chính là “ước mơ của TT Nixon” thành sự thật (TT
Nixon từng bị tố là có tham vọng muốn áp đặt một chế độ tổng thống với uy quyền
của một hoàng đế).<br/><br/>Hiển nhiên, lời dọa qua mặt quốc hội của TT Obama có tính trình diễn vì theo Hiến
Pháp, Hành Pháp có một số quyền thật, nhưng chỉ liên quan đến những quyết định
nhỏ hay cục bộ thôi, chứ không quyết định chuyện gì lớn được. Những vấn đề như
ngân sách, bổ nhiệm viên chức cao cấp, các chính sách lớn không thể không thông
qua lưỡng viện. Quan trọng hơn cả, quốc hội nắm hầu bao, nghiã là bất cứ quyết
định nào của Hành Pháp mà cần đến tiền thì đương nhiên phải có quốc hội chuẩn
chi. Ngay cả việc tăng lương công chức hợp đồng TT Obama đưa ra cũng phải nằm
trong phạm vi ngân sách của Hành Pháp đã được quốc hội phê chuẩn.<br/><br/>Với những thành tích lấn quyền vừa nêu trên, quốc hội sẽ khó tiếp tục ngồi yên
cho TT Obama đi xa hơn nữa trong năm tới, nhất là khi đảng Cộng Hoà bảo đảm sẽ
giữ thế đa số tại Hạ Viện trong khi có nhiều triển vọng chiếm đa số tại Thượng
Viện trong cuộc bầu giữa mùa cuối năm nay.<br/><br/>Nói cách khác, nếu TT Obama giữ lời hứa sẽ phớt lờ quốc hội, thì bảo đảm ta sẽ
thấy một năm với vài chuyện lắt nhắt được thực hiện, không có gì ghê gớm, để đời
cả.<br/><br/>Báo Washington Post nhận định đây rõ ràng không phải là loại diễn văn của một
Barack Obama cách đây 5 năm, với những chương trình vĩ đại và khẩu khí dao to
búa lớn.<br/><br/>Đương nhiên là khẩu khí của TT Obama vẫn còn phần nào khi ông tuyên bố năm 2014
sẽ là “năm của hành động” –year of action-, nhưng lại chỉ làm nhiều người thắc
mắc như vậy có nghiã là mấy năm trước đây đều là những năm của... ngồi chơi xơi
nước hay ngủ gật sao? TT Obama cũng hứa hẹn năm nay sẽ là năm “đột phá”
–breakthrough year- cho nước Mỹ, một hứa hẹn chẳng có ai tin nổi khi nhìn vào
những chương trình lắt nhắt được đề ra cho năm nay.<br/><br/>Thật ra, chương trình của “năm hành động” theo tất cả các chuyên gia Dân Chủ
cũng như Cộng Hoà, có vẻ yếu xìu xìu, gồm những kế hoạch nhỏ, không còn tính
cách đổi đời gì như thời Đấng Tiên Trí mới giáng trần những năm 2007-08. Kiểu
như kêu gọi các đại học nhận nhiều sinh viên nghèo hơn, cải tổ để nhiều trẻ em
được vào nhà trẻ sớm, lo nhiều hơn về sức khoẻ tinh thần của các cựu chiến
binh, phát hành một loại phiếu tiết kiệm mới để bán cho những người lĩnh tiền
hưu trí, ấn định tiêu chuẩn xăng mới cho các xe tải lớn, sửa luật thuế để giảm
bớt lỗ hổng,... Hay ca tụng chương trình giảm béo phì trong giới học sinh của Đệ
Nhất Phu Nhân. Hay đề cao những nỗ lực của hai bà Đệ Nhất và Đệ Nhị Phu Nhân
kêu gọi các cơ sở kinh doanh mướn các cựu chiến binh. Toàn là loại kế hoạch lí
nhí kiểu Clinton sau khi ông bị vụ xì-căng-đan Monica tước hết uy quyền.<br/><br/>Một số những kế hoạch lớn được đề cập nhưng đều là những chương trình cũ rích
đã được nêu lên trong mấy bài diễn văn của mấy năm trước mà vẫn chưa có tiến
triển gì như cải tổ luật di trú, xây dựng hạ tầng cơ sở, tăng lương tối thiểu,
đồng đều lương nam nữ, giúp đỡ giới trung lưu, kiểm soát súng đạn, đóng cửa trại
tù Guantanamo (đã là quyết định đầu tiên của TT Obama, ký một ngày sau khi
tuyên thệ nhậm chức cách đây đúng 5 năm).<br/><br/>Chủ đề mới của TT Obama, cách biệt giàu nghèo, cũng đã được nhấn mạnh khi ông
báo cáo những thành quả lớn của thị trường chứng khoán khiến cho những người
giàu nhất ngày một giàu thêm trong khi mức lương trung bình hầu như không nhúc
nhích gì hết, đưa đến việc trầm trọng hóa cách biệt giàu nghèo. Ông khẳng định
job của ông là lật ngược tiến trình này.<br/><br/>TT Obama khi đề cập đến Obamacare đã nói ông không hy vọng có thể thuyết phục đối
lập Cộng Hoà ủng hộ Obamacare. Điều ông cố tình khỏa lấp là không phải chỉ có Cộng
Hòa chống Obamacare, mà theo thăm dò của CBS, 93% dân Mỹ muốn hoặc là thu hồi
hoặc là sửa đổi Obamacare. TT Obama cũng quên rằng một lý do rất quan trọng dân
Mỹ bất mãn với Obamacare là những cái gọi là “trục trặc kỹ thuật” khi luật này
bắt đầu được áp dụng, và những trục trặc này không hề do lỗi của đối lập phá,
mà chính là do sự bất tài của các công chức Bộ Y Tế của nội các Obama. Điều
đáng ngạc nhiên là cho dù hầu hết dân Mỹ có vấn đề với Obamacare, TT Obama
không hề đả động đến chuyện có thể sửa đổi luật để được hậu thuẫn nhiều hơn, mà
chỉ chú tâm đả kích đối lập chống đối.<br/><br/>Nhìn chung, tất cả những hứa hẹn, lớn hay nhỏ, đều ít hy vọng đạt được kết quả
gì. Chuyện dễ hiểu khi hậu thuẫn của TT Obama chưa tới 40%, và khi Cộng Hoà đe
dọa chiếm đa số tại cả hai viện cuối năm nay.<br/><br/>Có thể kế hoạch cải tổ luật cư trú cho các di dân sẽ đạt được ít nhiều tiến bộ
khi phe bảo thủ Cộng Hoà cũng ý thức cần phải làm cái gì để thoát khỏi bế tắc.
Việc cả chục triệu người sống bất hợp pháp không thể tiếp tục kéo dài vô hạn mà
không có giải pháp gì.<br/><br/>Vắng bóng trong báo cáo tình trạng liên bang là những vấn đề thời sự lớn hiện
nay: tăng trưởng kinh tế vẫn èo uột, tỷ lệ thất nghiệp vẫn cao chót vót (chính
thức đã giảm xuống dưới 7% chỉ vì càng ngày càng nhiều người thất nghiệp chán nản
không tìm việc làm nữa nên bị loại ra thống kê lao động, trong khi thực tế có
hơn 15% dân Mỹ thất nghiệp), mức nợ trần sắp sửa lại phải tăng trong vài tuần nữa,
NSA nghe lén cả triệu người, tình trạng suy đồi nặng tại Iraq và Afghanistan,
quan hệ với Nga, Trung Cộng và ngay cả các đồng minh Âu Châu và Do Thái ngày
càng căng thẳng.<br/><br/>Nói tóm lại, Phúc Trình Tình Trạng Liên Bang chẳng có báo cáo về thành quả nào,
mà chỉ là lập lại những hứa hẹn viễn vông và cũ mèm. Thật ra không phải là phúc
trình gì mà chỉ là một loại diễn văn vận động tranh cử để tìm lại hậu thuẫn đã
mất, chẳng có gì cụ thể, chỉ là hứa non hẹn biển chung chung, đổ thừa, kèm theo
vài lời than vãn cũng cũ mèm: không có gì dễ dàng cả, cái gì cũng khó quá
(America has never come easy), hay những câu dao to búa lớn mà chẳng có nghiã
gì như “ngày nay nước Mỹ có lợi thế hơn bất cứ nước nào trên trái đất này để bước
vào thế kỷ 21”. Thế nghiã là gì?<br/><br/>Công bằng mà nói, TT Obama với tỷ lệ hậu thuẫn ngang mức của các tổng thống
Nixon Carter và Bush con, khó mà có thể làm gì khác hơn là hứa hẹn chung chung
và than vãn.<br/><br/>Truyền thông làm rùm beng, quảng bá từ cả tuần trước, hết chương trình bình luận
đặc biệt đến phỏng vấn giờ chót, phân tách tính xác thực cũng như tính khả thi,
các nhà báo, bình luận gia viết bài khen chê (trong đó có kẻ viết này), v.v… Thật
ra, chẳng có gì đáng bàn vì chẳng có gì mới lạ.<br/><br/>Không trách bài diễn văn năm nay đã đạt một kỷ lục mới: kỷ lục về… ít người
theo dõi nhất. Dân Mỹ háo hức chờ trận đấu Super Bowl, không rảnh nghe diễn văn
Báo Cáo Tình Trạng Vũ Như Cẩn của Liên Bang. (02-02-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: <a href="mailto:Vulinh11@gmail.com" target="_blank"><i>Vulinh11@gmail.com</i></a>.
Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a216806/phuc-trinh-lien-bang

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/