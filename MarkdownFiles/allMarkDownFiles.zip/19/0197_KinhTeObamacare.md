# Kinh Tế Obamacare

04/03/2014

...kể từ năm 2016, từ 6 đến 7 triệu người sẽ mất bảo hiểm tập thể do công ty
cung cấp...<br/><br/>Trên cột báo này, chúng ta đã có dịp bàn rất sâu rộng về những hậu quả trên
phương diện y tế của cuộc Cải Tổ Y Tế của TT Obama, được gọi nôm na là
Obamacare. Cũng dễ hiểu vì quan trọng nhất trong cải tổ y tế là những hậu quả y
tế. Nhưng trên thực tế cải tổ y tế này dĩ nhiên là sẽ có những ảnh hưởng vượt
xa khỏi phạm vi y tế. Chẳng hạn như cột báo này đã bàn ít nhiều về tác động của
Obamacare lên thị trường lao động qua việc các công ty sẽ sa thải hay thay đổi
quy chế làm việc từ toàn thời qua bán thời để tránh khỏi phải chịu chi phí bảo
hiểm y tế cho nhân viên.<br/><br/>Lý luận này không phải là lý luận kiểu bài bác khơi khơi cho có, mà là một lý
luận cơ bản trong luật kinh tế thị trường. Nhưng dù sao thì cho đến nay vẫn chỉ
là... lý luận, chưa được chứng minh bằng những con số thống kê thực tế hay
nghiên cứu chi tiết.<br/><br/>Nhưng mới đây cơ quan CBO, tức là Văn Phòng Ngân Sách Quốc Hội, một cơ quan
chính thức không phe đảng của quốc hội Hoa kỳ, đã chính thức phổ biến nghiên cứu
của họ.<br/><br/>Từ trước đến nay, kể cả trên cột báo này, đã có nhiều lý luận cho rằng việc luật
Obamacare sẽ đòi hỏi tất cả các công ty có trên 50 nhân viên toàn thời phải mua
bảo hiểm sức khỏe tập thể cho tất cả các nhân viên, nếu không sẽ bị phạt nặng,
sẽ đưa đến tình trạng một số không ít công ty nhỏ của giới trung và tiểu thương
sẽ phải hoặc là sa thải nhân viên xuống dưới mức 50, hoặc là thay đổi quy chế
nhân viên toàn thời, ép một số nhân viên phải qua làm việc bán thời để chỉ giữ
dưới 50 nhân viên làm toàn thời. Ở đây, xin nhắc lại các công ty không bị bắt
buộc phải cung cấp bảo hiểm y tế tập thể cho nhân viên làm bán thời.<br/><br/>Hệ quả đầu tiên và hiển nhiên là Obamacare sẽ không giúp giải quyết nạn thất
nghiệp mà trái lại, còn gia tăng nạn thất nghiệp. Đó là một hậu quả cực kỳ
nghiêm trọng trong tình trạng kinh tế èo uột của Mỹ hiện nay, với tỷ lệ thất
nghiệp ngất ngưởng ở mức cao nhất và lâu dài nhất lịch sử cận đại Mỹ.<br/><br/>Kinh tế Mỹ bình thường chỉ có khoảng 3%-4% thất nghiệp. Cao lắm và gây nhiều
khó khăn là 5%-7%. Nhưng từ ngày TT Obama nhậm chức, tỷ lệ thất nghiệp đã leo lên
lên xấp xỉ 10%. Lúc gần đây, tỷ lệ này đã hạ xuống dưới 7%. Nhưng con số 7% này
mang một ý nghiã hoàn toàn sai lệch. Con số này xuống thấp như vậy chỉ vì hàng
triệu người dân trong tuổi lao động đã bị loại ra khỏi thống kê của thị trường
lao động vì họ đã thất nghiệp quá lâu, hay vì họ nản chí không ghi tên thất
nghiệp hay đăng ký xin việc làm nữa. Con số thực tế của tỷ lệ thất nghiệp hiện
hành, theo nhiều thống kê chính thức của Nhà Nước cho biết là… 15%.<br/><br/>Tỷ lệ thất nghiệp cao trên căn bản kinh tế học dĩ nhiên có tác dụng không tốt
cho phát triển kinh tế. Càng ít người đi làm thì trên căn bản, sản xuất nói
chung càng thấp kém. Cũng may là cái nguyên lý cơ bản này ngày một mất đi ý
nghiã, chỉ vì thế giới ngày nay càng ngày cơ giới hoá, hay nói cho chính xác
hơn, ngày một vi tính hoá. Một phần rất lớn các công tác ngày xưa đòi hỏi nhân
viên, nhân sự, bây giờ đã được thay bằng máy vi tính, computer. Bởi vậy, ta thấy
hiện tượng tỷ lệ thất nghiệp thật cao, nhưng kinh tế Mỹ vẫn phát triển ào ào,
các công ty ngày một lời to, chỉ số Dow Jones, NASDAQ ngày một leo thang. Chỉ tổ
làm giàu thêm cho các đại gia sở hữu chủ các công ty, trong khi nhân viên làm
công cho những công ty đó thì … chưa bị sa thải là may, đừng mong chờ được tăng
lương theo chỉ số Dow Jones.<br/><br/>Con số 15% thất nghiệp là nói chung cho cả nước. Nhưng nếu nhìn vào từng giới
dân số thì con số còn kinh hoàng hơn nhiều, chẳng hạn như tỷ lệ thất nghiệp của
thanh niên da đen là trên dưới 40%. Ta chỉ cần lái xe dạo qua các khu da đen tại
các thành phố lớn sẽ thấy các thanh niên da đen lang thang đứng đầy ngoài đường,
chẳng có chuyện gì làm.<br/><br/>Tệ nạn xã hội cũng từ đó mà ra. Đặc biệt hiện nay mới phát sinh ra một “phong
trào tiêu khiển” mới, rất thịnh hành trong các khu dân thiểu số da màu, gọi là
“knock-out game”. Một đám thanh niên tụ tập một chỗ, hay cùng đi lang thang một
nhóm, thấy một người lạ đi tới, bất ngờ vô cớ nhẩy ra đánh người đó chơi, rồi cả
đám cười lăn ra rồi đi tìm mục tiêu khác. Người bị đánh, chẳng cần biết là ai,
lớn bé, già trẻ, trai gái, ông già bà lão, hầu hết là da trắng, có khi da vàng,
da nâu. Chẳng hận thù, chẳng quen biết, chẳng gây hấn hay xích mích gì. Đối với
đám thanh niên, chán quá không biết làm gì, chỉ là một thú tiêu khiển mới phát
minh ra cho vui. Và họ cũng hiểu với ông tổng thống là “người anh em” (bro), lại
đã từng tuyên bố “cảnh sát đều là ngu xuẩn” (cops are stupid) thì việc bị bắt
và trừng phạt cũng có thể nhẹ tay phần nào.<br/><br/>Những ông bà cấp tiến đã mau mắn chỉ trích các đại công ty, cho rằng họ là những
người tham tiền, chỉ biết hành xử vì tiền bạc, sẵn sàng sa thải nhân viên mà
không nghĩ gì đến vấn đề con người, số phận lao đao của những người bị sa thải.
TT Obama đã nhiều lần lên tiếng kêu gọi các đại công ty nên có chính sách tích
cực giúp giải quyết nạn thất nghiệp bằng cách thuê thêm nhân viên. Ngay cả Đệ
Nhất Phu Nhân Michelle cũng đã lên tiếng kêu gọi các công ty nên có chính sách
giúp các cựu quân nhân có việc làm.<br/><br/>Qua những lời hò hét kêu gọi của các chính khách cấp tiến thì tất cả là lỗi từ
phiá cung, tức là từ phiá các công ty, không chịu thuê thêm nhân viên để tiết
kiệm chi phí bảo hiểm.<br/><br/>Nhưng rồi mới đây, Văn Phòng Ngân Sách Quốc Hội đã tạt một gáo nước lạnh, lay tỉnh
thiên hạ về một thực tế khác xa hình ảnh của khối cấp tiến đưa ra mà nhiều người
cho là đúng. Theo văn phòng này, thì nghiên cứu của họ cho thấy là tỷ lệ thất
nghiệp cao dĩ nhiên một phần nào là hậu quả kinh tế của Obamacare, dồn một số
công ty vào việc cắt giảm nhân viên, nhưng yếu tố quan trọng hơn lại là chuyện
một số lớn nhân viên tự ý... nằm nhà nghỉ khỏe, ăn oeo-phe, nhận trợ cấp bảo hiểm,
có lợi hơn đi làm nhiều! Ta cần lưu ý đây là chuyện họ tự ý nghỉ làm chứ không
phải công ty sa thải họ.<br/><br/>Trước hết phải khẳng định ngay văn phòng này là một văn phòng chuyên gia không
đảng phái, không phải do đảng Dân Chủ hay đảng Cộng Hòa bổ nhiệm và chi phối.<br/><br/>Đặc biệt văn phòng này cho biết là theo nghiên cứu của họ, luật Obamacare không
khuyến khích các chủ hãng sa thải nhân viên nhiều như dự đoán, mà trái lại, luật
đó đã tạo ra kẽ hở để thiên hạ có dịp nghỉ làm, nằm nhà ăn oeo-phe, lãnh trợ cấp
để có bảo hiểm trọn vẹn, có lợi hơn.<br/><br/>Hàng triệu người đã hoặc là nghỉ làm luôn, hoặc là tự ý đi tìm việc làm bán thời,
cốt sao cho mức lợi tức xuống tới mức có thể hưởng trợ cấp Medicaid trọn vẹn,
hay hưởng trợ cấp tiền mua bảo hiểm y tế. Đó là những người có mức lợi tức cao
hơn mức tối thiểu lãnh Medicaid một chút, họ nghỉ làm để lợi tức tuột xuống hạng
Medicaid để nhận tiền Medicaid. Hay hạng người trong giới trung lưu thấp nghỉ
làm, hay làm ít giờ đi để lợi tức tuột xuống mức để họ có thể nhận trợ cấp bảo
hiểm y tế. Theo văn phòng này, Obamacare sẽ khiến ít nhất là hai triệu rưởi người
tự ý nghỉ làm hay tự ý kiếm việc làm bán thời từ giờ cho đến năm 2017.<br/><br/>Bất cứ một người bình thường nào cũng thấy đây là một tình trạng bất thường,
không thể có lợi cho đất nước. Cả triệu người không đi làm tất nhiên sẽ giảm mức
sản xuất kinh tế cho quốc gia, và hơn nữa sẽ tăng gánh nặng của Nhà Nước qua việc
tăng tiền trợ cấp đủ loại cho họ. Và dĩ nhiên người phải trả chi phí gia tăng
đó là những người vẫn tiếp tục đi làm, đóng thuế cho Nhà Nước có thêm tiền nuôi
những người không đi làm.<br/><br/>Và bất cứ một Nhà Nước bình thường nào cũng sẽ cảm thấy có cái gì không ổn, cần
phải thay đổi chính sách để gia tăng việc cung cấp nhân lực cho thị trường lao
động.<br/><br/>Nhưng oái ăm thay, đó không phải là thái độ của Nhà Nước Obama và khối cấp tiến
phe ta. Khối này có vẻ lấy làm hãnh diện vì việc thiên hạ tự ý nghỉ làm phản
ánh một chính sách đã cho phép họ có sự “tự do” –freedom- lựa chọn cuộc sống của
họ, không bị lệ thuộc vào việc làm, và lại giúp cho những người này có “thời giờ
dành cho đời sống gia đình”.<br/><br/>Kẻ viết này bóp trán suy nghĩ nát óc vẫn không hiểu được phản ứng này của chính
quyền Obama là phản ứng “nói chơi” hay phản ứng “nói thiệt”. Thiên hạ thất nghiệp
ào ào mà Nhà Nước cho rằng đó là điều tốt vì chứng tỏ Nhà Nước đã giúp họ có khả
năng tự do lựa chọn lối sống –đi làm hay nằm nhà ăn trợ cấp- và có nhiều thời
giờ dành cho gia đình??? Mọi chuyện đã có Nhà Nước lo.<br/><br/>Trên căn bản, lý luận kiểu này tuyệt đối nằm trọn trong nhân sinh quan “vú em”
của chủ thuyết Obama. Và phần nào giải thích được việc Nhà Nước Obama chưa bao
giờ thật sự quan tâm đến việc giải quyết nạn thất nghiệp tại nước này cả.<br/><br/>Đi đến tận cùng của lý luận này thì toàn dân cả nước sẽ có “tự do” được ngồi
nhà, ăn tiền trợ cấp Nhà Nước để vợ chồng vui vẻ, du hý và sanh đẻ đầy nhà, rồi
Nhà Nước lo hết. Nghe cũng có vẻ hấp dẫn, nhưng rồi câu hỏi là “thế thì ai là
những người ngu muội đâm đầu đi làm? Nhà Nước lấy tiền đâu ra để nuôi cả nước
ngồi nhà?”<br/><br/>Hay là Nhà Nước dự tính lột hết tiền của khối 1% “nhà giàu” đi làm cật lưng để
nuôi 99% “nhà nghèo” ngồi mát ăn bát vàng? Kẻ viết này hiển nhiên thuộc thành
phần 99% nên nghe chuyện này cũng thấy mát tai. Nhưng thực tế, đứa trẻ lớp mẫu
giáo cũng hiểu tình trạng này không bao giờ có thể xẩy ra. Khối 1% không thể
nào đủ giàu để nuôi khối 99% được. Và cái khối 1% chắc chắn không ngu đến độ tự
ý tiếp tục cong lưng đi làm kiếm tiền nuôi khối 99%. Nếu ngu như vậy thì làm
sao họ có thể trở thành giàu có được? Mà có muốn cũng không được. Cả triệu nhà
máy, công ty, cửa hàng nuôi sống kinh tế cả nước nếu 99% nằm nhà thì lấy ai điều
hành?<br/><br/>Thực tế mà nói, sẽ không bao giờ có chuyện 99% dân Mỹ quyết định nằm nhà sống bằng
oeo-phe theo kiểu này. Chỉ là một thiểu số người thiếu tinh thần trách nhiệm, lợi
dụng một kẽ hở của luật mới thôi. Do đó, hậu quả tài chánh không mấy quan trọng.
Con số hai triệu người làm ít giờ đi sẽ không có tác dụng gì ghê gớm trên nền
kinh tế vĩ đại của đại cường Cờ Hoa. Vấn đề không phải là những mất mát tiền bạc
vật chất.<br/><br/>Vấn đề ở đây là thái độ của chính quyền Obama. Một sự lạm dụng kẽ hở của luật
đáng lẽ nên bị chỉ trích và Nhà Nước cần làm một cái gì để ngăn chặn hay bít lỗ
hổng. Nhưng Nhà Nước Obama trái lại, công khai bênh vực và ca tụng việc làm
này. Đây là một hành động chẳng những cố tình lợi dụng kẽ hở luật pháp, mà lại
là một thái độ cố tình trốn tránh nghiã vụ công dân để đùn gánh nặng tài chánh
của mình lên đầu người khác. Trên căn bản, vừa bất hợp pháp, vừa vi phạm nguyên
tắc đạo đức cũng như tính công bằng. Vậy mà lại được sự cổ võ của chính quyền
Obama?!<br/><br/>Dĩ nhiên ai cũng hiểu lời biện giải cua chính quyền Obama chỉ là một cách ngụy
biện chạy tội, tìm cách khỏa lấp thất bại (tăng số người thất nghiệp) bằng một
kiểu giải thích tích cực (tự do và có thời giờ lo cho gia đình), nhưng vô hình
chung, Nhà Nước Obama đã khuyến khích hay ít nhất cũng đã bao che cho dân lách
luật và trốn tránh nghiã vụ công dân. Có phải đó là cách lãnh đạo đúng không? Nếu
cả nước nghe theo khuyến khích của Nhà Nước thì chuyện gì sẽ xẩy ra?<br/><br/>Một kết luận khác đáng ghi nhận hơn nữa là vẫn theo nghiên cứu của Văn Phòng
Ngân Sách Quốc Hội, kể từ năm 2016, từ 6 đến 7 triệu người sẽ mất bảo hiểm tập
thể do công ty cung cấp. Một số lớn công ty cấp tiểu và trung thương sẽ hủy bỏ
chính sách cung cấp bảo hiểm tập thể cho nhân viên, và dĩ nhiên những người này
sẽ bị bắt buộc phải mua bảo hiểm y tế cá nhân riêng rẽ đắt hơn nhiều.<br/><br/>Và cái đinh của bản nghiên cứu mới thật là đáng ghi nhận: 10 năm nữa, đến năm
2024, con số người không có bảo hiểm sức khỏe tại Mỹ sẽ lên đến ít nhất 30 triệu
người.<br/><br/>TT Obama viện dẫn chuyện nước Mỹ hiện có khoảng 30 triệu người không có bảo hiểm,
và ông tung ra Obamacare với lý do chính là để chấm dứt tình trạng này và bảo đảm
tất cả dân Mỹ đều có bảo hiểm y tế. Nhưng theo nghiên cứu mới này của quốc hội,
10 năm nữa, sẽ vẫn có 30 triệu người không có bảo hiểm. Nói cách khác,
Obamacare với phí tổn bạc ngàn tỷ, và với những xáo trộn vĩ đại trong cuộc sống
của thiên hạ cũng như trong chế độ y tế Mỹ, chỉ là chuyện… công cốc, chẳng thay
đổi được gì hết.<br/><br/>Một viện nghiên cứu lớn khác, Brookings Institution, cho biết trên phương diện
lợi tức, Obamacare sẽ giúp tăng lợi tức cho giai cấp lợi tức thấp nhất, những
gia đình lãnh dưới 21.000 đô một năm, nhờ gia tăng tiền Medicaid khoảng gần
2.000 đô một năm. Tất cả những gia đình thuộc mức lợi tức cao hơn, và nhất là
những người trong lớp tuổi từ 65 trở lên, sẽ thấy lợi tức hàng năm của mình bị
giảm, từ 1% đến 2% một năm.<br/><br/>Một luật cải tổ y tế mà kết quả cuối cùng là vẫn có 30 triệu người không có bảo
hiểm, hàng triệu người tự ý ngồi nhà ăn trợ cấp, và lợi tức của đại đa số dân bị
giảm bớt. Chưa kể chuyện gây xáo trộn vĩ đại trong hệ thống y tế và tăng toàn
diện chi phí bảo hiểm cũng như chi phí bác sĩ, nhà thương, thuốc men, và chữa
trị. Đó là luật tốt hay xấu, có cần điều nghiên và chỉnh sửa hay không?
(02-03-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com.
Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a218112/kinh-te-obamacare

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/