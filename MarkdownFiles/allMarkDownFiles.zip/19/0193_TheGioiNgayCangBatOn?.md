# Thế Giới Ngày Càng Bất Ổn?

01/04/2014



### Nguồn:

Viet Bao: https://vietbao.com/a219409/the-gioi-ngay-cang-bat-on

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/