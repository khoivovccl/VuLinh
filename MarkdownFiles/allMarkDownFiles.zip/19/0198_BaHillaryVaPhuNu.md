# Bà Hillary Và Phụ Nữ

25/02/2014

...Bảo vệ phụ nữ là phải chỉ trích hay trừng trị ông chồng chứ không phải bênh
ông chồng...<br/><br/>Trên cột báo này cách đây ít tuần, ta có bàn về chuyện các “ngôi sao” của đảng
Cộng Hoà tự đào huyệt chôn mình. Câu chuyện tiếp tục với các “ngôi sao” bên đảng
Dân Chủ.<br/><br/>Trước hết phải nói cho rõ về định nghiã “ngôi sao”. Ở đây, ta không bàn về ngôi
sao theo kiểu ngôi sao Hồ Ly Vọng, được thật nhiều người biết đến và mến mộ,
như những Brad Pitt và Angelina Jolie. Mà phải hiểu theo nghiã chính trị, tức
là những chính khách có triển vọng đắc cử vào các chức vụ quan trọng, đặc biệt
là chức tổng thống.<br/><br/>Trong chính trị, nếu nói về chuyện nổi tiếng, được nhiều người biết đến, thì
chưa chắc đã có nghiã là thu được nhiều phiếu nhất. Nói cho rõ, “ngôi sao”
trong bài viết này mang ý nghiã tương đối có nhiều triển vọng đắc cử vào Tòa Bạch
Ốc. Phải là ứng viên tương đối ôn hoà, có khả năng thu phiếu của những cử tri độc
lập và ngay cả các cử tri thuộc đảng đối lập. Như TT Bush năm 2000 đã đắc cử vì
được hậu thuẫn mạnh của khối Dân Chủ tại tiểu bang Texas lúc đó đang kiểm soát
quốc hội Texas, đưa ra hình ảnh một người có khả năng hợp tác được với đối lập,
cũng như có được hậu thuẫn lớn của khối dân gốc La-Tinh thường là cử tri của
Dân Chủ. Hay TT Obama đã đắc cử dựa trên chiêu bài đại đoàn kết dân tộc.<br/><br/>Dĩ nhiên tranh cử là chuyện khác xa với hành xử quyền lực. Cả hai TT Bush và TT
Obama sau khi nắm quyền đều trở thành những tổng thống tạo chia rẽ rất lớn giữa
hai chính đảng.<br/><br/>Trở lại câu chuyện “ngôi sao” bên Dân Chủ, vấn đề giản dị hơn nhiều vì chung
quy chỉ có đúng một ngôi sao là bà Hillary Clinton.<br/><br/>Vấn đề đặt ra là 1) bà Hillary sẽ ra tranh cử hay không, và 2) nếu ra tranh cử,
bà có hy vọng thắng trong nội bộ để làm đại diện cho đảng Dân Chủ không, và 3)
nếu đắc cử làm đại diện cho đảng Dân Chủ, bà có hy vọng thắng ứng viên Cộng Hòa
không?<br/><br/>Trước hết, ta bàn lại chuyện bà Hillary có muốn ra tranh cử lại không. Câu trả
lời giản dị là “có”. Dĩ nhiên cho đến nay, bà Hillary đã tránh né không trả lời
dứt khoát, mà chỉ trả lời kiểu ẫm ờ của mấy cô em gái “em chả…”, để mọi người đều
hiểu là “em muốn lắm”. Bà muốn là chuyện 100%. Bà ra hay không là chuyện khó biết
hơn vì dĩ nhiên có những yếu tố bà cần cân nhắc mà chúng ta không biết hết được.<br/><br/>Cả cuộc đời bà Hillary, tất cả những hành động, ngay từ chuyện lấy ông chính
khách trẻ nhiều tham vọng và nhiều triển vọng Bill Clinton, cho đến việc ra
tranh cử thượng nghị sĩ, ra tranh cử tổng thống, rồi nhận làm ngoại trưởng, tất
cả đều thể hiện một phụ nữ có tham vọng, có chí lớn, có kế hoạch quy củ, và có
tính toán cũng như kỷ luật thép đối với chính mình. Bà cũng là người có quan điểm
chính trị cấp tiến dứt khoát, rõ ràng hơn ông chồng nhiều và có quyết tâm thực
hiện ý nguyện của mình. Mục tiêu lớn nhất của bà là “giải phóng” phụ nữ, mà bà
gọi là “đập vỡ cái kính trên trần” –breaking the ceiling glass- để phụ nữ có thể
leo lên những nấc thang cao nhất. Việc bà có cơ hội đập vỡ kính đó năm 2008 nhưng
lại bị ông Obama phá bĩnh là nỗi đau lớn nhất của đời bà. Bây giờ cơ hội lại
đang ở trước mặt, và không còn ai làm kỳ đà cản mũi nữa thì làm sao bà bỏ được?<br/><br/>Vấn đề thứ hai, nếu bà ra tranh cử, có hy vọng thắng trong nội bộ đảng Dân Chủ
hay không?<br/><br/>Tất cả các thăm dò dư luận đều cho thấy bên Dân Chủ, bà Hillary được hậu thuẫn
của trên dưới … 70% đảng viên. Người đứng thứ nhì là PTT Biden với khoảng 10%,
rồi sau đó là khoảng nửa tá chính khách khách chia nhau 20% còn lại. Giống như
mặt trời Hillary bên cạnh các ngôi sao lốm đốm đó đây.<br/><br/>Ở đây, chẳng những bà Hillary hơn trội vì kinh nghiệm và tên tuổi, nhưng quan
trọng hơn nữa là chuyện bà là phụ nữ. Đảng Dân Chủ đã đi vào lịch sử như đảng đầu
tiên có tổng thống da đen, bây cũng cũng muốn vào lịch sử lần thứ hai như đảng
có tổng thống phụ nữ đầu tiên.<br/><br/>Tất cả chỉ là quyết định của bà Hillary. Nếu bà ra tranh cử thì các cuộc tranh
cử nội bộ sơ khởi –primaries- bên đảng Dân Chủ có thể được hủy bỏ hết để khỏi mất
thời giờ và tốn tiền bạc vô ích.<br/><br/>Bây giờ nói về khả năng hạ ứng viên Cộng Hòa và đắc cử tổng thống.<br/><br/>Trên căn bản, chưa ai thấy một nhân vật Cộng Hòa nào đủ nặng ký hạ bà Hillary,
kể cả những “ngôi sao” khá nổi như các ông Rand Paul, Ted Cruz, hay những dân
biểu Paul Ryan (ứng viên phó tổng thống của TĐ Romney), hay TNS Marco Rubio của
Florida. Tất cả những thăm dò dư luận đều cho thấy bà Hillary hạ đo ván tất cả
các đấng mày râu Cộng Hòa, kể cả TĐ Christie sau vụ xì-căng-đan kẹt cầu ở Nữu Ước.<br/><br/>Nếu nói về kinh nghiệm chính trị, không có ông bà nào trong cả hai đảng có thể
so sánh được với bà Hillary, người đã từng là vợ của một tổng thống –hay chính
xác hơn đã từng là “đồng tổng thống” (co-president) trong 8 năm, và sau đó là
cánh tay mặt của một tổng thống khác trong 5 năm làm ngoại trưởng, sau gần 10
năm làm thượng nghị sĩ,<br/><br/>Nói về hậu thuẫn, bà là con cưng của giới cấp tiến và dĩ nhiên của khối phụ nữ,
nhưng đồng thời lại được sự ca ngợi của giới quân sự bảo thủ như cựu bộ trưởng
quốc phòng Robert Gates, và nhất là của người hùng David Petraeus, cựu tư lệnh
chiến trường Trung Đông, Iraq và Afghanistan. Khối chính khách và cử tri da đen
bỏ bà chạy theo Obama năm 2008 đã công khai trở về hậu thuẫn bà, ít ra cũng để
chuộc lỗi. Khối lao động da trắng vẫn chưa bỏ bà. Chưa một chính khách Dân Chủ
nào dám lên tiếng chống bà. Hàng loạt đại gia Dân Chủ đã chuẩn bị bạc triệu để
yểm trợ bà. Cơ quan thăm dò Gallup cho biết bà đứng đầu danh sách phụ nữ được mến
phục nhất Mỹ 18 năm qua, hơn xa bà Michelle Obama và Oprah Winfrey.<br/><br/>Nhưng như vậy không có nghiã là có thể hủy cuộc bầu cử cho xong chuyện. Vì bà
Hillary vẫn có triển vọng thua vì chính bà, vì những vấn đề từ chính bà.<br/><br/>Điều đầu tiên là tuổi tác. Nếu bà đắc cử năm 2016, bà sẽ nhậm chức năm 2017 khi
bà 70 tuổi, cái tuổi cổ lai hy của tổng thống già nhất lịch sử Mỹ, Ronald
Reagan. Thiên hạ đều còn nhớ những hình ảnh TT Reagan thường xuyên… ngủ gật, chẳng
hạn như khi viếng thăm Đức Giáo Hoàng tại La Mã. Người ta cũng chưa quên TT
Reagan đã bắt đầu có triệu chứng của bệnh lãng trí hai năm cuối của nhiệm kỳ
hai. Mà TT Reagan khi đắc cử lần đầu khỏe hơn bà Hillary bây giờ nhiều. Cách
đây không lâu, đã có lần bà Hillary đang đọc diễn văn bị té xỉu phải vô bệnh viện
khẩn cấp vì kiệt sức.<br/><br/>Nhiều người lo ngại làm sao bà có thể chịu đựng nổi những đòi hỏi khủng khiếp về
thể xác trong cuộc vận động tranh cử kiểu Mỹ, nhất là đối với một phụ nữ ở tuổi
gần 70. Dòng dã trong cả hai năm trời, một ngày đọc diễn văn tại hai ba thành
phố cách nhau cả trăm dặm, thăm hỏi, bắt tay cười nói với cả chục ngàn người.
Nói huyên thuyên cả chục giờ mỗi ngày, gặm hamburger hay hot dog, và ngủ khách
sạn hay trên máy bay liên tục ngày này qua tháng kia năm nọ. Mà dù mệt mỏi cỡ
nào cũng không thể không tươi cười và nhất là không nói hớ một câu nào hết.<br/><br/>Đã vậy, đại đa số cử tri Mỹ là giới trẻ trong tuổi 20-30-40. Đó là giới cử tri
đã công kênh ông Obama vào Tòa Bạch Ốc. Người ta khó có thể tưởng tượng giới cử
tri đó lại có thể hồ hởi bầu cho một bà cụ 70 tuổi. Mà không có khối cử tri đó
thì đảng Dân Chủ khó thắng được.<br/><br/>Vấn đề nữa là cái tên “Clinton”. Nước Mỹ, tính ra từ năm 1980 cho đến giờ, gần
35 năm qua, đã phải nghe đến hai cái tên Bush và Clinton liên tục đến ù tai
luôn. Nếu bà Clinton ra làm tổng thống, ta sẽ thấy tình trạng Bush – Clinton –
Bush – Clinton làm tổng thống Mỹ. Nước Mỹ không có người nào với cái tên nào
khác hơn sao? Hơn ba trăm triệu dân Mỹ mà chỉ có hai cha con và hai vợ chồng đó
thôi sao?<br/><br/>Với lại cái tên Clinton nghe cũng rất khó chịu đối với nhiều người, nhắc lại một
giai đoạn không đẹp của chính trường Mỹ. Nhiều người lo ngại ông Clinton trở về
lại Tòa Bạch Ốc theo chân bà vợ, không chừng lại sẽ mang theo vài bà tình nhân
vào theo.<br/><br/>Ở đây có một chuyện đáng nói. Cựu TT Clinton mới có một trợ tá mới, Tina
Flournoy, một phụ nữ da đen từng làm việc trong ban tham mưu của bà Hillary.
Các quan sát viên đã mau mắn nhận định bà này là trợ tá, nhưng đồng thời cũng
là “lính gác chồng” của bà Hillary đưa vào.<br/><br/>Một vấn đề quan trọng hơn nhiều: đó là thành tích của bà Hillary. Không ai chối
cãi, bà Hillary có một quá trình dầy cộm gấp ngàn lần quá trình của TT Obama
khi mới ra tranh cử, nhưng nếu nói về thành quả cụ thể thì bà còn tệ hơn TNS
Obama. Ít ra, TNS Obama không có thành tích gì, nhưng cũng không có thất bại
nào.<br/><br/>Khi làm Đệ Nhất Phu Nhân, bà được trao trách nhiệm cầm đầu nhóm soạn thảo cải tổ
y tế quy mô, và bà đã thất bại trọn vẹn khi đề nghị của bà chết trong trứng nước.
Trong 9 năm làm thượng nghị sĩ, ba biểu quyết quan trọng nhất của bà là chấp nhận
cho TT Bush giảm thuế, đánh Afghanistan và đánh Iraq. Cả ba quyết định bà đều bị
phe cấp tiến chống đối kịch liệt khiến bà hối tiếc và mất không biết bao công sức
biện giải. Trong 5 năm làm ngoại trưởng, bà đạt được thành tích chu du thế giới
nhiều nhất lịch sử, nhưng kết quả chẳng có một thành tích cụ thể nào.<br/><br/>Bình luận gia bảo thủ Charles Krauthammer đã lên tiếng thách các nhà báo ủng hộ
bà Hillary hãy nêu ra được một thành quả cụ thể nào đó của ngoại trưởng Hillary
Clinton, và cho đến nay, chưa ai làm được chuyện này một cách thỏa đáng.<br/><br/>Nhiều quan sát viên chính trị nhận định chức Ngoại Trưởng mà bà điều đình trước
với ứng viên Obama đổi lấy hậu thuẫn mạnh của vợ chồng bà trong cuộc tranh cử
Obama-McCain, chỉ là cách bà mang tên tuổi bà ra khỏi cái dù của ông chồng.<br/><br/>Nói tóm lại, bà Hillary là một chính khách tuy có nhiều hành trang, với thật ít
thành tích cụ thể, nhưng lại là người khó có thể đánh bại được nếu bà quyết định
ra tranh cử. Nhìn cho kỹ, có lẽ lý do quan trọng nhất khiến thiên hạ có thể bầu
cho bà Hillary: bà là một phụ nữ, sẽ trở thành nữ tổng thống đầu tiên của Mỹ,
và sẽ giúp “giải phóng” phụ nữ Mỹ. Đây là chiêu bài phe cấp tiến Dân Chủ đang
chuẩn bị khi họ đồng thanh khua chiêng trống báo động “cuộc chiến chống phụ nữ
của Cộng Hòa”.<br/><br/>Nhưng vấn đề này cần xét lại. Bà Hillary có thật sự là biểu tượng cho phụ nữ và
sẽ giúp giải phóng phụ nữ Mỹ không?<br/><br/>Bà Hillary trước đây có một bà bạn cố tri mà bà thường tâm sự, để xả hơi khi có
chuyện ấm ức, hay để có dịp phân trần giải thích. Bà bạn Diane Blair, giáo sư
chính trị học, chăm chỉ ghi chép lại hết trong nhật ký của bà. Bà này qua đời
năm 2000, những tài liệu cá nhân của bà được tặng cho đại học Arkansas, và bây
giờ nhật ký của bà được tiết lộ trọn vẹn.<br/><br/>Qua những trang nhật ký đó, người ta thấy một bà Hillary mưu mô, thủ đoạn, tính
toán và cứng rắn thẳng tay –ruthless-. Một người từng chê quốc hội toàn là dân
làm biếng chẳng làm gì, chê cả Toà Bạch Ốc chẳng có ai đủ cứng rắn, chê TT
Clinton không dám sa thải ai, thiếu kỷ luật, không có chiến lược, không biết tổ
chức, không dám lấy quyết định, làm chuyện ngu xuẩn (vụ Monica),... Một đệ nhất
phu nhân với một ngôn ngữ đanh đá, thậm chí thô tục, sẵn sàng có biện pháp mạnh
trừng trị đối thủ chính trị của bà và của ông chồng. Không có gì là hình ảnh của
một một nữ nhi liễu yếu đào tơ, hay một phụ nữ tề gia nội trợ cổ điển.<br/><br/>Trong vụ ông chồng lem nhem với cô Monica cũng như với biết bao bà khác, bà
Hillary đã quyết tâm ngậm bồ hòn, đóng vai hiền thê tha thứ cho những phút yếu
lòng của ông chồng bay bướm, chịu đựng sóng gió vì bà hiểu rõ bỏ con thuyền
Bill Clinton thì bà cũng sẽ bị chết chìm theo luôn. Chỉ có bám vào đó thì mới
còn tương lai. Và bà đã tính toán đúng, cho đến nay vẫn còn tương lai huy
hoàng.<br/><br/>Đã có rất nhiều lời bàn về chuyện bà Hillary có thể sẽ không ra tranh cử. Lý dó
đầu tiên là sự mệt mỏi. Bà đã lăn lộn trong chính trường Mỹ từ 40 năm qua, từ
ngày bà là một luật sư trẻ trong khối luật sư của khối dân biểu Dân Chủ truy tội
TT Nixon trong vụ Watergate từ đầu thập niên 70 đến nay. Bây giờ lại còn phải
tiếp tục vật lộn thêm 10 năm nữa (2 năm tranh cử và hai nhiệm kỳ tổng thống tổng
cộng 8 năm nữa). Bà có muốn và có chịu nổi không?<br/><br/>Đối với một phụ nữ bình thường, có thể là không muốn và không chịu nổi. Nhưng
bà Hillary tuyệt đối không phải là một nữ nhi bình thường.<br/><br/>Một lý do khác là chuyện con gái bà Hillary đã thành hôn. Đối với rất nhiều phụ
nữ, việc trở thành bà nội, bà ngoại là điều thật quan trọng. Thời trẻ, có con
nhưng lại phải đi làm, không có thời giờ ôm con, bây giờ về già rảnh rỗi, có thời
giờ ôm cháu, đó là giấc mộng của hầu hết phụ nữ bình thường. Nhưng rồi bà
Hillary lại không phải là một phụ nữ bình thường.<br/><br/>Điều miả mai lớn nhất là bà Hillary luôn lớn tiếng bênh vực chồng, là người đã
lợi dụng quyền thế, lạm dụng tình dục hàng lô phụ nữ ngay từ những ngày ông mới
lên làm Thống Đốc Arkansas, và cô Monica nhỏ hơn ông ta cả hai con giáp. Bảo vệ
phụ nữ là phải chỉ trích hay trừng trị ông chồng chứ không phải bênh ông chồng,
đánh các phụ nữ nạn nhân của ông này. Bà Kathleen Willey, một trong những nạn
nhân tình dục của TT Clinton và nạn nhân trả thù của bà Hillary đã nhận định bà
Hillary chính là người chống phụ nữ mạnh nhất.<br/><br/>Ngoài ra, ta cũng phải đặt câu hỏi nếu bà Hillary phải được coi như là mẫu mực
cho phụ nữ thì việc bà chấp nhận ông chồng lăng nhăng để bà có dịp tiến thân có
phải là thái độ đúng cho phụ nữ không? Mà chẳng phải chỉ có bà Hillary có thái
độ như vậy trong thế giới của bà Clinton, mà bà Huma Abedin, trợ tá tay mặt của
bà cũng vậy. Bà này có ông chồng là cựu dân biểu, bị ép từ chức vì chuyên tung ảnh
khoả thân của mình gửi qua điện thoại di động cho các bà các cô. Bà Abedin cũng
có thái độ không khác gì bà Hillary, bênh vực chồng và sỉ vả những nạn nhân của
chồng mình. Đó có phải là một thái độ đúng để bảo vệ quyền lợi và nhân cách của
phụ nữ không?<br/><br/>Thử tưởng tượng bà Hillary làm tổng thống và bà Abedin làm Chánh Văn Phòng, các
phụ nữ có chồng đi “ăn phở” có thể sẽ được bênh vực và bảo vệ kỹ hơn không? Hay
là nữ tổng thống Hillary Clinton sẽ khuyến cáo các bà này nên thông cảm và tha
thứ cho chồng để bảo vệ cái job của chồng?<br/><br/>Nhiều chiến lược gia trong đảng Dân Chủ đã lên tiếng nhắc nhở nên thận trọng
trong vấn đề khai thác “cuộc chiến chống phụ nữ của đảng Cộng Hoà” đề phòng
chuyện gậy ông đập lưng ông khi bà Hillary ra tranh cử.<br/><br/>Việc bà Hillary ra tranh cử và đắc cử có nhiều hy vọng thành sự thật, nhưng
chuyện bà bảo vệ quyền lợi và tranh đấu cho phụ nữ là một dấu hỏi lớn. Chỉ có một
điều chắc chắn là bà sẽ hết lòng tranh đấu và bảo vệ quyền lợi của cá nhân bà.
(23-02-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com.
Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a217792/ba-hillary-va-phu-nu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/