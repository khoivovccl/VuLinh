# Tổng Thống Bay Bướm Của Pháp

18/02/2014

...TT Hollande, đang ở mức thấp kỷ lục, dưới 20%, tăng vài điểm khi vụ ăn vụng
với bà tài tử bị bật mí...<br/><br/>Tuần qua, TT Pháp Francois Hollande chính thức viếng thăm Hoa kỳ. Đây là một cuộc
viếng thăm khá đặc biệt, với vị khách được xếp vào loại quốc khách –state
visit-, có bắn 21 phát đại bác chào mừng, kèm theo nhiều nghi lễ chính thức rất
trịnh trọng. Bao gồm quốc yến –state dinner- vĩ đại.<br/><br/>Không phải quốc trưởng nào đến thăm Mỹ cũng đều được đón tiếp như quốc khách.
Phải là quốc trưởng của một nước đồng minh quan trọng. Dù vậy thì tính cách
linh đình trịnh trọng cũng khác biệt. Các buổi dạ yến của TT Obama vượt xa hầu
hết tất cả các dạ yến của các vị tiền nhiệm về tính huy hoàng, lộng lẫy, chỉ
thua TT Kennedy. Đệ Nhất Phu Nhân Michelle đã trưng diện bộ áo trị giá sơ sơ có
12.000 đô (dĩ nhiên là chỉ mặc một lần, sau đó chẳng ai biết áo sẽ đi đâu, chắc
đi bán đấu giá?). Hơn 300 khách quý được mời, một số lớn là tài tử và ca sĩ nổi
tiếng đương thời. Chi phí được ước tính gần 1.500 đô một đầu người tham dự. Quý
độc giả đang đóng thuế cho Nhà Nước Obama và kẻ viết này là những người hoan hỷ
đài thọ chi phí dù không được tham dự.<br/><br/>Quan hệ giữa Mỹ và Pháp có lẽ chưa bao giờ tốt đẹp như… tuần qua. Đúng ra phải
nói quan hệ giữa hai nước rất phức tạp, nay nóng mai lạnh. Hai nước là đồng
minh chặt chẽ trong hai cuộc đại chiến thế giới khi Mỹ hai lần cứu Pháp khỏi Đức,
nhưng không bao lâu sau khi Thế Chiến Thứ Hai chấm dứt, quan hệ Mỹ-Pháp trở nên
u ám cho đến cách đây … vài tháng.<br/><br/>Ông Tây ngay sau Thế Chiến Thứ Hai rất thân thiện với TT Truman vì TT Truman
giúp Pháp trở lại Việt Nam, đổi lấy hậu thuẫn của Pháp trong cuộc chiến tranh lạnh
chống Liên Xô tại Âu Châu khi Mỹ bận rộn lo thành lập Liên Minh Bắc Đại Tây
Dương –NATO. Nhưng sau đó quay qua hận ông Mỹ đã khoanh tay ngó lơ để Pháp bị
thảm bại tại Điện Biên Phủ, khi TT Eisenhower từ chối yêu cầu của Pháp thả bom
tiêu diệt các lực lượng Việt Minh đang bao vây Điện Biên Phủ. Rồi lại tìm mọi
cách loại Pháp ra khỏi Đông Dương, nhẩy vào giúp TT Diệm củng cố thế lực và tẩy
xoá dấu vết ảnh hưởng của Pháp.<br/><br/>Người ta còn nhớ trong cuộc chiến VN, TT Pháp Charles de Gaulle đã công khai có
thái độ bài Mỹ, thậm chí còn kêu gọi trung lập hoá Đông Dương. TT de Gaulle
cũng là người quyết định rút Pháp ra khỏi Liên Minh Bắc Đại Tây Dương, đóng cửa
cá căn cứ quân sự Mỹ và đuổi hết lính Mỹ ra khỏi Pháp.<br/><br/>Gần đây hơn, Pháp tuy là đồng minh tham chiến chống Taliban và Al Qaeda tại
Afghanistan, nhưng lại kịch liệt chống đối cuộc chiến Iraq. Có một thời dưới TT
Bush, phong trào chống Pháp đã lên đến cao điểm tại Mỹ với nhiều tiệm ăn đổi
tên món khoai tây chiên French fries thành… Freedom fries, hay nhiều tiệm khác
đổ rượu vang Tây xuống cống.<br/><br/>Dưới thời TT Obama, bang giao Mỹ-Pháp cũng không khác gì mấy, nay lạnh mai
nóng. TT Sarkozy công khai phê bình TT Obama ngây thơ. Nhưng ngược lại, khi
Pháp chủ trương đánh Libya, lật đổ Khaddafi, thì lại được TT Obama hậu thuẫn,
“lãnh đạo từ sau lưng”, thành công thay đổi chế độ tại đây.<br/><br/>Gần đây, bang giao Mỹ-Pháp có vẻ chặt chẽ hơn khi hai nước hợp tác để ép Iran
ký kết thoả ước kiểm tra vũ khí hạt nhân, cũng như áp lực Syria chấm dứt việc
dùng vũ khí hóa học. Nói cho chính xác hơn, Mỹ cần nhờ vào ảnh hưởng của Pháp
trong hai vấn đề then chốt này vì dù sao thì quan hệ giữa Pháp với hai xứ Iran
và Syria cũng còn tốt hơn quan hệ giữa Mỹ và hai xứ này.<br/><br/>Nhưng rồi gần đây, quan hệ lại bị sứt mẻ nặng khi tin tức bị xì ra là an ninh Mỹ
nghe lén điện thoại tư của TT Pháp, cũng như của các vị lãnh đạo đồng minh như
Thủ Tướng Đức và nhiều vị khác. Chuyện đồng minh chơi trò gián điệp với nhau là
chuyện bình thường, nhưng đây là chuyện nghe lén điện thoại cá nhân riêng tư.
Bà Thủ Tướng Đức Merkel công khai tỏ ý bất bình. TT Obama đã tốn không biết bao
nhiêu công sức điện thoại nói chuyện với từng vị, phân trần, giải thích, xin lỗi,
và mới đây, đã ra chỉ thị cấm NSA nghe lén điện thoại riêng tư của mấy vị quốc
trưởng đồng minh.<br/><br/>Chuyện nghe lén điện thoại riêng tư của các vị này đã là một cái bực mình khổng
lồ cho TT Pháp vì ông này lúc sau này đã dính dáng vào chuyện lem nhem tình ái
đúng theo kiểu … Tây.<br/><br/>TT Hollande trước đây đã sống chung không có hôn thú với bà Segolene Royal, một
lãnh tụ trong đảng Xã Hội Pháp, đã từng ra tranh cử tổng thống Pháp năm 2007
nhưng bị ông Sarkozy hạ. Hai ông bà này sống chung và có bốn con. Sau khi bà “vợ”
thất cử, mất chức chủ tịch đảng Xã Hội, thì ông chồng, sau khi núp bóng bà vợ
leo thang lên vai lãnh tụ thay thế, cũng đã mau mắn thay thế … bà vợ luôn. Thật
ra, ông Hollande trước đó đã lén lút có bà hai cả mấy năm rồi. Bỏ bà Royal, ông
Hollande cặp với một bà mới, không phải là bà hai. Sống với một bà “vợ” mới,
Valerie Trierweiler, cũng chẳng đám cưới, hôn thú gì. Bà “vợ” thứ ba này là một
nhà báo làm cho tờ báo nổi tiếng của Pháp, Paris Match. Khi ông Hollande đắc cử
tổng thống năm 2012, hạ đương kim TT Sarkozy, bà này chính thức trở thành Đệ Nhất
Phu Nhân.<br/><br/>Mới đây, TT Hollande đội “mũ bảo hiểm” chùm hết đầu và mặt chỉ chừa hai con mắt,
lẻn ra cửa sau Điện Elysée lén lút lấy xe gắn máy chạy đi thăm … một nữ tài từ
xi-nê hết sức xinh đẹp, sexy, Julie Gayet. Câu chuyện nghe thật khôi hài và khó
tin. Một tổng thống lẻn ra cửa sau, lấy xe gắn máy chạy đi thăm vợ bé? Chúng ta
ở Mỹ, quen với các biện pháp an ninh chung quanh tổng thống, thật khó có thể tưởng
tượng TT Obama lén mượn xe gắn máy của anh cắt cỏ Toà Bạch Ốc chạy ra nhà bà
đào nào đó ở Hoa Thịnh Đốn.<br/><br/>Dĩ nhiên câu chuyện đổ bể, người ta khám phá ông tổng thống đã lén đi “ăn phở”
từ hai năm nay, từ trước khi ông đắc cử tổng thống. Ông tổng thống đành công
khai xác nhận người yêu mới, và tuyên bố chấm dứt liên hệ với bà Trierweiler.
Bà “vợ” Trierweiler nghe tin, bị xúc động mạnh, khủng hoảng tinh thần, lâm bệnh
phải vào nhà thương nằm mấy ngày, sau đó, ra khỏi bệnh viện, đi du lịch qua tuốt
xứ Ấn Độ để cố quên chuyện tình buồn.<br/><br/>Câu chuyện nghe đúng là… chuyện Tây. Ông tổng thống mà có tới bốn bà đào, nhưng
luôn luôn cặp kè với hai bà một lúc. Mấy bà đào, càng về sau càng trẻ. Bà đầu,
Royal, 60 tuổi, bà thứ nhì 55, bà Trierweiler 48, và bà Gayet 41. Ăn cơm với bà
này, ăn phở với bà kia, đổi qua ăn cơm với bà kia, lại ăn phở với bà nọ, đổi qua
ăn cơm với bà nọ lại đi ăn phở với bà khác nữa. Mà đó chỉ là kể các bà có quan
hệ khá lâu dài, vài năm, chưa kể các “phi vụ” ngắn hạn. Chỉ có xứ của mấy ông
Tây mới có mấy chuyện hấp dẫn như vậy. Không ai có thể tưởng tượng một chính
khách Mỹ -khoan nói tới tổng thống- với cuộc sống bay bướm lăng nhăng như vậy lại
có thể leo lên tột đỉnh của chính quyền. Mà ông Hollande không phải là người đầu
tiên.<br/><br/>Trước đây, TT Francois Mitterand cũng lén có phòng nhì, có con luôn. Chẳng biết
bà Đệ Nhất Phu Nhân có biết hay không, nhưng khi ông Mitterand chết, bà hai và
con gái cũng công khai tham dự đám táng, đứng ngang hàng với bà nhất luôn.<br/><br/>Rồi ông Nicholas Sarkozy còn đi xa hơn nữa. Sau khi đắc cử tổng thống, ông mau
mắn ly dị bà vợ, lấy một người mẫu mà hình khỏa thân được phổ biến khắp thế giới
cho tất cả thiên hạ cùng chiêm ngưỡng. Bà Carla Bruni là vợ chính thức thứ ba của
ông Sarkozy, không kể vài bà người tình không hôn thú nhưng sống chung công
khai.<br/><br/>Thiên hạ cũng chưa quên trước đây, một chính khách đầy tương lai có thể được bầu
làm tổng thống Pháp, ông Dominique Strauss Kahn, có uy tín rất lớn vì là Tổng
Giám Đốc Quỹ Tiền Tệ Quốc Tế (IMF), bất thình lình bị cảnh sát Mỹ bắt khi ông
đang đi công tác tại Nữu Ước, vì tội thông dâm với cô đen dọn phòng khách sạn 5
sao ông đang cư ngụ. Làm tiêu tan mộng làm tổng thống. Không phải vì lem nhem vớ
vẩn, mà vì đang bị nhốt khi có bầu cử tổng thống Pháp, không ra tranh cử được.
Biết đâu nếu được ra tranh cử, ông này cũng đã đắc cử và đang làm tổng thống
Pháp không chừng.<br/><br/>Cái lạ lùng đối với dân Mỹ là tất cả những lem nhem của các tổng thống Pháp đều
là chuyện công khai cả thế giới biết. Không như chuyện TT Kennedy bị ám ảnh
sex, ngày nào cũng phải có “thao diễn” với bà vợ hay với hàng lô giai nhân
khác, trong đó có Marylin Monroe, nếu không sẽ bị đau đầu, theo chính lời thú
nhận của ông. Chuyện này được dấu nhẹm, đến cả mấy chục năm sau khi ông chết,
thiên hạ mới được biết.<br/><br/>Thật ra, các tổng thống Mỹ tuy không đào hoa như mấy ông Tây, nhưng cũng chẳng
thánh thiện hơn. Nhiều vị tổng thống tên tuổi lẫy lừng, uy tín hết mực cũng
không thoát khỏi những cám dỗ của “phòng nhì”. Như các TT Washington,
Roosevelt, Eisenhower, Johnson, đều có phòng nhì, tuy rất kín đáo. TT
Jefferson, một tổng thống nổi tiếng tranh đấu cho bình đẳng nhân quyền và giải
phóng nô lệ da đen, đã để lại cả lô con rơi con rớt với mấy bà nô lệ da đen của
ông.<br/><br/>Dân Âu Châu, nhất là dân Pháp, chẳng những có cuộc sống phóng khoáng hơn, mà đặc
biệt lại luôn luôn coi những chuyện tình cá nhân của các ông tổng thống như là
chuyện… cá nhân, chẳng liên quan gì đến chuyện làm tổng thống hay bất cứ chức vụ
hay nghề nghiệp nào. Không ai đặt vấn đề bãi chức hay từ chức gì hết. Cùng lắm
thì chỉ làm đề tài cho truyền thông diễu cợt thôi. Vấn đề đời công đời tư dường
như có lằn ranh rõ rệt, không có lẫn lộn gì hết. Đó cũng là lý do tại sao ngày
trước, dân Âu Châu, nhất là dân Pháp, không hiểu tại sao câu chuyện TT Clinton
lem nhem với cô Monica lại có thể trở thành một câu chuyện lớn lao đến vậy, đưa
TT Clinton ra xét xử trước quốc hội, đến độ xém bị cách chức.<br/><br/>Chẳng những vậy mà khi các vụ lem nhem bị khui ra thì oái ăm thay, hậu thuẫn của
các ông chồng bê bối đó lại tăng vọt lên ngay. Tỷ lệ hậu thuẫn của TT Hollande,
đang ở mức thấp kỷ lục, dưới 20%, tăng lên ngay vài điểm khi vụ ăn vụng với bà
tài tử bị bật mí. Không biết tăng lên vì dân Pháp cảm phục tài đào hoa lăng
nhăng của ông Hollande, hay vì tội nghiệp cho những cái nhức đầu mà ông
Hollande đã trải qua mấy ngày đó?<br/><br/>Mà chẳng phải chỉ có ông Hollande nhức đầu không thôi, mà ngay cả TT Obama khi
đó cũng nhức đầu luôn. Nhức đầu vì phải chuẩn bị cho cuộc viếng thăm chính thức
gần kề của vị quốc khách Francois Hollande. Không biết ông này đi có bà nào
theo? Mà theo với tư cách Đệ Nhất Phu Nhân hay gì gì khác? “Đệ Nhất Người Tình”
như báo Pháp Libération đã mệnh danh? Đón tiếp và sắp xếp chỗ ngồi như thế nào
nếu bà này không phải là Đệ Nhất Phu Nhân? Mà là bà nào? Bà nhà báo Trierweiler
hay bà tài tử Gayet? Không phải là Đệ Nhất Phu Nhân mà chỉ là “Đệ Nhất Người
Tình” thì đón tiếp như thế nào? Đâu có chuyện Đệ Nhất Phu Nhân Michelle Obama
chính thức đón tiếp một bà “Đệ Nhất Người Tình” được, rồi thì để ngồi đâu? Nghe
nói khi chuẩn bị, ban nghi lễ Tòa Bạch Ốc có hỏi Tòa Đại Sứ Pháp tại Hoa Thịnh
Đốn TT Hollande sẽ qua Mỹ với bà nào, trong tư cách gì, và được trả lời “chúng
tôi cũng mù tịt như các ông”.<br/><br/>Cũng may mà TT Hollande đã giải quyết chuyện nhức răng này dùm bằng cách đi một
mình, không có bà nào theo hết, và được xếp ngồi giữa TT Obama và Đệ Nhất Phu
Nhân Michelle trong buổi dạ yến.<br/><br/>Chuyện TT Hollande không có bà nào đi theo chắc cũng làm bà Michelle vui lòng
vì an tâm hơn.<br/><br/>Thiên hạ còn nhớ cách đây không lâu, TT và phu nhân Obama đi Nam Phi dự đám
tang của cựu TT Nelson Mandela. Trong khi các chính khách cả thế giới thay
phiên nhau đọc diễn văn ca tụng và khóc lóc ông Mandela, thì TT Obama, ngồi cạnh
bà Thủ Tướng Đan Mạch Helle Thorning Schmidt, đã hết sức thân mật cười nói
huyên thuyên với bà này, không có vẻ gì là đang dự đám ma, lại còn chụp hình kiểu
mà Việt Nam bây giờ gọi là “hình tự sướng” –selfie-, tự mình chụp mình nhe răng
cười. Một nhà báo đã mau mắn chụp được bức hình mấy vị đang “tự sướng” đó,
trong bức hình đó lại có bà Michelle ngồi bên cạnh, mặt hầm hầm giận dữ không cần
dấu diếm gì hết. Vài phút sau, anh nhà báo chụp bức hình đó, chụp lại một lần nữa,
và người ta thấy hai ông bà Obama đã đổi chỗ ngồi. Bà Michelle bây giờ qua ngồi
cạnh bà Thủ Tướng Đan Mạch, TT Obama ngồi ngoài bià, mặt thất thểu buồn so, bây
giờ mới đúng là đang dự đám ma.<br/><br/>Thử tưởng tượng trong buổi dạ tiệc mà TT Obama được xếp ngồi cạnh bà tài tử
sexy Julie Gayet, rồi hai người chụp hình “tự sướng” thì không biết mặt bà
Michelle sẽ như thế nào?<br/><br/>Thái độ của bà Michelle không phải là không có lý do. Theo báo Daily Mail của
Anh và National Enquirer của Mỹ thì đang có tình trạng “gia cang xào xáo” giữa
TT Obama và phu nhân. Theo tin này, bà Michelle đã khám phá ra nhân viên an
ninh của tổng thống đã lén lút giúp TT Obama ăn phở.<br/><br/>Dĩ nhiên tin tức của hai tờ báo lá cải siêu thị đó có vẻ khó tin, nhưng ta cần
ghi nhận tờ National Enquirer trước đây đã khui tin thượng nghị sĩ John Edwards
trong khi đang tranh cử tổng thống, đã có vợ bé và con rơi trong khi bà vợ đang
bị ung thư. Khi đó, không ai tin báo này cả, cho đến khi nội vụ đổ bể và sự thật
lòi ra đúng như vậy. Thêm vào đó, thiên hạ cũng không lạ gì chuyện TT Obama xém
chút đã ly dị bà Michelle vài năm trước khi ông đắc cử tổng thống.<br/><br/>Một chuyện đáng nói là trong dịp nghỉ lễ cuối năm, cả gia đình TT Obama đã đi
Hawaii nghỉ, nhưng sau đó, chỉ có TT Obama và hai cô con gái trở về Hoa Thịnh Đốn,
còn bà Michelle tiếp tục du hý đây đó một mình. Có tin bà Michelle đã có ý định
tìm nhà tại Hoa Thịnh Đốn để ở sau khi TT Obama mãn nhiệm, trong khi TT Obama lại
công khai khẳng định ông sẽ về nghỉ hưu tại Hawaii.<br/><br/>TT Obama đang cố chạy theo gương cấp tiến của Âu Châu trong các chính sách của
ông. Chỉ không biết là ông có muốn chạy theo gương bay bướm của TT Hollande hay
không thôi. Dù sao thì TT Obama cũng trẻ tuổi và đẹp mã hơn ông Hollande nhiều,
mà cũng quen rất nhiều tài tử cấp tiến xinh đẹp của Hồ Ly Vọng. (16-02-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com.
Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a217498/tong-thong-bay-buom-cua-phap

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/