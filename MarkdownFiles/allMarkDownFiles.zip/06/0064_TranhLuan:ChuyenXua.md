# Tranh Luận: Chuyện Xưa

27/09/2016



### Nguồn:

Viet Bao: https://vietbao.com/a258517/tranh-luan-chuyen-xua

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/