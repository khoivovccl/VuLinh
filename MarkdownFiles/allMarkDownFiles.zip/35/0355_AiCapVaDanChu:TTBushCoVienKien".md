# Ai Cập Và Dân Chủ: TT Bush Có Viễn Kiến"

08/02/2011

<p>Ai Cập Và Dân Chủ: TT Bush Có Viễn Kiến"</p><p>Vũ Linh</p><p></p><p>Nếu Ai Cập, Yemen, và Jordan rơi vào tay Hồi giáo quá
khích thì sẽ là một đại họa... </p><p>Thời sự quốc tế đã tràn ngập tin tức biến động tại các
nước Trung Đông và Phi Châu, từ Tunisia đến Ai Cập, qua Yemen, Algeria, Jordan
và Sudan, phiá nam sa mạc Sahara của Phi Châu luôn. Tại những nơi này, bất ngờ
dân chúng nổi lên chống đối chính quyền và đòi tự do dân chủ.</p><p>Tại Tunisia, tổng thống bị lật đổ sau khi cầm quyền một
cách tuyệt đối, phải trốn chạy ra khỏi nước. Tại Ai Cập, hàng trăm ngàn người
xuống đường liên tục đòi TT Mubarak từ chức, bất kể sự đàn áp mạnh mẽ của cảnh
sát, đã khiến cả trăm người chết, hàng ngàn người bị thương, và hàng ngàn người
khác bị bắt. Tại Yemen, dân chúng cũng ào ạt xuống đường chống đối chính quyền
và cho đến nay, vẫn bị đàn áp mạnh. Cả ba ông tổng thống Tunisia, Ai Cập, và
Yemen đều là những con khủng long đã nắm quyền một cách tuyệt đối từ trên dưới
ba thập niên.</p><p>Các quan sát viên nhận định dường như đang có một cơn
cuồng phong dân chủ thổi vào vùng này. Không ai biết được đây có phải là những
ngày đầu của một phong trào quy mô sẽ dấy lên và thay đổi toàn diện bàn cờ
chính trị trong vùng hay không. Có nhiều người lạc quan còn nghĩ tới cơn cuồng
phong dân chủ của cuối thập niên 80 đã quét sách chủ nghĩa cộng sản tại Âu
Châu.</p><p>Tuy chưa ai biết chuyện gì sẽ xẩy ra trong lâu dài, nhưng
ở đây, ta cũng nên nhìn lại quá khứ.</p><p>Năm 2005, TT Bush tái đắc cử, nhậm chức tổng thống nhiệm
kỳ hai.</p><p>Năm đó là năm quân đội Mỹ còn đang bù đầu với hai cuộc
chiến chống khủng bố toàn cầu tại Afghanistan và Iraq. Đặc biệt cuộc chiến tại
Iraq đang bị chỉ trích mạnh. Chẳng những quân đội Mỹ gặp khó khăn lớn khi thanh
toán dư đảng của Saddam Hussein, đối phó với cuộc chiến nội bộ giữa các phe
nhóm sắc tộc và giáo phái, mà hơn thế nữa, lại hoàn toàn thất bại không tìm
thấy vũ khí giết người tập thể gì hết. Và quân đội Mỹ cũng có triển vọng sẽ ở
lại hai xứ này rất lâu, để tái tạo và củng cố hòa bình, cũng như để dựng nước.</p><p>Trong bài diễn văn nhậm chức lần thứ hai, ông nhấn mạnh
nước Mỹ đang trực diện với cuộc chiến khủng bố của khối Hồi Giáo quá khích.
Những biện pháp quân sự và an ninh chống khủng bố trong nước, hay cùng với các
đồng minh trên thế giới chỉ là tìm cách giải quyết cái “diện” của nạn khủng bố,
mà không nhắm vào cái “điểm”. Cái điểm chính là thể chế chính trị tại Trung
Đông và trong các nước Hồi Giáo. Tại đây, đã không có dân chủ, người dân không
có tiếng nói trong khi phải sống cơ cực trong cảnh nghèo nàn và chậm tiến cùng
với những bất công xã hội thật lớn. Tình trạng đótạo ra những dồn ép, bất mãn, chống các chế
độ cầm quyền trong vùng, nhưng cũng chống luôn cả Mỹ và các nước Tây Phương
đồng minh của Mỹ, bị coi như là đã hậu thuẫn các chính quyền độc đoán trong
vùng. Từ đó đưa đến 9/11 và nạn khủng bố toàn cầu.</p><p>Muốn giải trừ nạn khủng bố thì phải trực diện với nguyên
nhân xâu xa này, và tìm cách giải quyết. Và cách giải quyết mà tổng thống tái
cử Bush đưa ra trong bài diễn văn nhậm chức là xây dựng dân chủ trong các nước
Trung Đông. Một khi có dân chủ, dân chúng được thoả mãn, thì bất mãn, chống đối
sẽ chấm dứt, và nạn khủng bố toàn cầu sẽ tự nó bị đào thải vì không còn hậu
thuẫn, không còn lý do tồn tại.</p><p>Sứ mạng của quân đội Mỹ tại Afghanistan và Iraq chẳng
những là tái tạo và bảo vệ hòa bình, mà còn là xây dựng dân chủ, làm gương hay
làm đầu cầu dân chủ, cho tất cả các nước trong vùng. Nếu nước Mỹ thành công,
mang lại dân chủ -tức là cho người dân có tiếng nói- tại hai xứ này, thì chắc
chắc là dân chúng cũng như các chính quyền trong vùng sẽ nhìn vào đó mà suy
gẫm.</p><p>Nhiều người khi đó đã cho rằng chủ thuyết mới này của TT
Bush có tính cách ngụy biện nhằm biện minh cho cuộc chiến tại Iraq, hoàn toàn
không thực tế vì dân Hồi giáo không có truyền thống dân chủ.</p><p>Bây giờ nhìn lại những biến chuyển tại Tunisia, Ai Cập và
Yemen, người ta không khỏi thắc mắc. Hình như dân Ả Rập Hồi giáo cũng có những
ước vọng về tự do dân chủ. Biết đâu TT Bush quả thực là người đã có viễn kiến,
nhìn thấy rõ giải pháp trường kỳ cho nạn khủng bố" Và giải pháp đó đang thực sự
xẩy ra"</p><p>Dù sao thì các biến cố này, nhất là cuộc khủng hoảng tại
Ai Cập, đã đặt chính quyền Obama vào một thế bí, chẳng biết phải làm gì. Tiến
thoái lưỡng nan.</p><p>TT Obama và truyền thông cấp tiến phe ta dĩ nhiên không
dám nhắc đến chủ thuyết Bush. Ứng viên Obama, rồi sau đó, tổng thống Obama, là
người chỉ trích cuộc chiến tại Iraq mạnh nhất. Ông không tin vào chuyện vết dầu
loang dân chủ, và chủ trương rút quân Mỹ về càng sớm càng tốt. Bây giờ làm sao
ông có thể nói “Bush có lý, tôi sai”"</p><p>Một lý do nữa khiến cho ban đầu ông thấy khó ủng hộ dân
nổi dậy vì chưa rõ phe nhóm nào đang điều khiển cuộc nổi dậy và có cơ lên nắm
quyền tại Ai Cập. Hiện nay, tổ chức đối lập lớn nhất tại Ai Cập, cũng là tổ
chức có nhiều hy vọng nắm quyền nếu TT Mubarak bị lật đổ, là tổ chức Hồi giáo
Muslim Brotherhood, cực đoan, hoàn toàn không thân thiện với Mỹ, chủ trương
tiêu diệt Do Thái. Trong khi đó TT Mubarak lại là đồng minh quan trọng nhất của
Mỹ trong khối Ả Rập và Hồi giáo, mỗi năm nhận được hàng trăm tỷ viện trợ của Mỹ
để tiếp tay chống khủng bố, và nhất là duy trì hoà bình với Do Thái, bảo đảm ổn
định trong vùng. </p><p>Từ đây đưa đến phản ứng đầu tiên của chính quyền Obama,
qua lời tuyên bố của PTT Biden. Ông nói rõ ràng “TT Mubarak không phải là nhà
độc tài”. Ông Biden luôn luôn vẫn là một Biden nói năng lung tung không khác gì
ông tướng râu kẽm của ta ngày xưa: 30 năm nắm quyền, cấm chỉ mọi đối lập, mà
lại không phải là độc tài. Ông Biden cũng phán quyết thêm TT Mubarak không cần
từ chức. Tiếng nói của phó tổng thống Mỹ quan trọng hay tiếng nói của hàng
triệu dân Ai Cập quan trọng" </p><p>Thái độ này dĩ nhiên làm quần chúng đang nổi dậy càng
thêm bất mãn với Mỹ, và càng tăng thêm uy tín của nhóm Hồi giáo quá khích
Muslim Brotherhood, tức là tăng triển vọng nắm quyền của khối này. </p><p>Trước sự lớn mạnh của phong trào nổi dậy, chính quyền Obama
phải điều chỉnh thái độ, một cách mập mờ: kêu gọi cải cách và một sự chuyển
tiếp trong trật tự (orderly transition), nhưng lại phủ nhận chủ trương thay đổi
chế độ (regime change). Không ai hiểu nghĩa là gì.</p><p>Đến khi TT Mubarak hứa sẽ không ra tranh cử Tháng Chín
tới, thì TT Obama lại thay đổi lập trường, kêu gọi bắt đầu tiến trình chuyển
tiếp ngay từ bây giờ. Người ta có cảm tưởng chính quyền Obama đúng là không
biết phản ứng như thế nào, chỉ chạy theo biến cố từng ngày.</p><p>Trong cuộc chính biến trước đây tại Tunisia, chỗ đứng của
Mỹ dễ dàng hơn. Ông tổng thống trị vì ba chục năm tại đây là đồng minh quan
trọng của Pháp, ít quan hệ với Mỹ. Cuộc nổi dậy cũng thành công mau lẹ khi ông
tổng thống nhanh chân trốn ra khỏi nước khi vừa có biến động.</p><p>Tình hình tại Ai Cập rắc rối hơn nhiều vì tổng thống, đối
ngoại là đồng minh tích cực đáng tin tưởng của Mỹ, đối nội lại là bàn tay sắt,
chẳng những nắm quyền tuyệt đối từ hơn ba chục năm lại còn đang chuẩn bị cho
ông con lên kế vị, theo gương Bắc Hàn nữa. Mỹ ủng hộ chuyện này thì thật là
tréo cẳng ngỗng với truyền thống dân chủ Mỹ. </p><p>Nhưng nếu nhanh chóng phản bội đồng minh từ mấy chục năm
qua để ủng hộ phe nổi dậy Hồi giáo cực đoan, có thể là thù địch với Mỹ, thì
cũng thật khó. Nếu “không may” nhóm quá khích Muslim Brotherhood lật đổ được TT
Mubarak thì Ai Cập có thể sẽ trở thành một Iran thứ hai, và Mỹ sẽ trở thành kẻ
thù của chính quyền mới. </p><p>Có lẽ chỉ còn một giải pháp cho TT Obama là… câu giờ. </p><p>Trì hoãn xem bên nào thắng thế, đồng thời hy vọng trong
phe nổi dậy sẽ nổi lên một lãnh tụ tương đối ôn hòa. Hiện nay, ông Mohammed
ElBaradei, trước đây là Tổng Giám Đốc Cơ Quan Năng Lực Nguyên Tử Quốc Tế
(International Atomic Energy Agency), đã từng lãnh giải Nobel Hoà Bình (thường
dành cho các người có khuynh hướng cấp tiến hay thiên tả), có vẻ đã nổi lên như
là người lãnh đạo, nhưng không ai biết thực quyền của ông này tới đâu. </p><p>Ông là người sống ở ngoại quốc, chưa bao giờ chống TT
Mubarak đòi dân chủ gì hết, mới chỉ bay về nước sau khi cuộc nổi loạn đã xẩy ra
rồi, theo kiểu lợi dụng thời cơ, chứ không phải là lãnh tụ thật sự từ đầu. Vấn
đề nữa là ông này cũng chẳng thân thiện gì với Mỹ, trước đây đã cản chuyện Mỹ
muốn kiểm soát mạnh hơn chương trình nguyên tử Iran và không hề kết án hành
động quá khích của lực lượng Hamas trên dải Gaza.</p><p>Điều phiền toái cho TT Obama là thái độ câu giờ, lưỡng lự
nước đôi cuối cùng chẳng thỏa mãn bên nào hết, và bên nào thắng thì cũng không
cám ơn Obama.</p><p>Chẳng những TT Obama đang mắt kẹt khúc xương Ai Cập, mà
ngay cả tại Yemen và Jordan nữa.</p><p>Yemen là nước Hồi giáo sào huyệt của rất nhiều lãnh tụ
khủng bố. Ông tổng thống ở đây là đồng minh quan trọng trong cuộc chiến. Gần
đây các tài liệu do WikiLeaks tiết lộ trên báo chí cho thấy ông tổng thống đã
thoả thuận ngầm với Mỹ, cho phép máy bay không người lái của Mỹ bắn giết các
sào huyệt khủng bố dưới danh nghĩa là máy bay của Yemen đánh.</p><p>Trong khi đó, Jordan là một vương quốc có truyền thống
thân thiện với Mỹ từ trước đến giờ, với cái giá cụ thể là cả tỷ Mỹ kim viện trợ
mỗi năm. Cũng là một đồng minh tích cực giúp đỡ duy trì hòa bình tại Trung Đông
và tiếp tay chống khủng bố toàn cầu. Tuy Quốc vương Jordan không mạnh tay như
TT Ai Cập, nhưng không ai có thể nói Jordan là một xứ có tự do dân chủ hết. Vua
Jordan đã mau mắn giải tán nội các, nhưng vấn đề là dân chúng chống chế độ quân
chủ độc đoán chứ đâu có chống nội các.</p><p>Cái rắc rối trong chủ thuyết của TT Bush không phải là
dân Hồi giáo trong vùng không có truyền thống dân chủ, mà chính là ở điểm nếu
có dân chủ thì các nhóm ít thân thiện với Mỹ sẽ khai thác, lợi dụng mức dân trí
thấp và ảnh hưởng của các nhóm Hồi giáo quá khích, nhẩy lên nắm quyền, để rồi
áp dụng những chính sách không thân thiện với Mỹ.</p><p>Đây không phải là chuyện không thể xẩy ra. Trái lại, đã
xẩy ra rồi. Tại Palestine, dưới áp lực của Mỹ, chính quyền Palestine đã phải tổ
chức bầu cử trong dân chủ. Kết quả là nhóm quá khích Hamas chiếm quyền tại vùng
Gaza, gây bối rối và khó khăn vô tận cho chính quyền Palestine và Mỹ.</p><p>Nếu Ai Cập, Yemen, và Jordan rơi vào tay các nhóm Hồi
giáo quá khích thì sẽ là một đại họa cho Mỹ, cho hoà bình trong vùng, cho sự
sinh tồn của Do Thái cũng như sự tồn tại của các chế độ vương quốc vùng Vịnh
như Ả Rập Saudi và Liên Hiệp Các Vương Quốc Ả Rập, và cho cuộc chiến chống
khủng bố toàn cầu.</p><p>Đó là chưa nói đến chuyện kinh tế. Vùng Trung Đông này
sản xuất đâu gần hai phần ba dầu hỏa trên thế giới, trong khi 40% dầu di chuyển
qua kinh đào Suez của Ai Cập. Không những Mỹ và Âu Châu lo ngại, mà ngay Nhật,
Tàu, và cả vùng Đông Nam Á cũng đang hồi hộp vì lệ thuộc vào dầu hỏa Trung
Đông. Sẽ không phải chuyện lạ nếu giá dầu xăng thế giới vọt lên gấp đôi (8 đô
một ga-lông xăng tại Mỹ"). </p><p>Trong tuần qua, khi tin khủng hoảng Ai Cập bùng nổ, chỉ
số chứng khoán Dow Jones rớt ngay gần hai trăm điểm.</p><p>Biến động tại Trung Đông là thử thách lớn nhất về đối
ngoại của chính quyền Obama. Ta hãy xem ông đối phó như thế nào. Nếu ông để mất
Ai Cập thì đảng Dân Chủ có dịp chứng minh một lần nữa là các tổng thống từ đảng
này chỉ mang lại đại họa cho chính sách đối ngoại của Mỹ: TT Truman để mất
Trung Hoa, TT Johnson để mất Việt Nam, TT Carter để mất Iran, và TT Obama để
mất Ai Cập – hay mất cả Trung Đông" - (06-02-11)</p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua
email: Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a166758/ai-cap-va-dan-chu-tt-bush-co-vien-kien

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/