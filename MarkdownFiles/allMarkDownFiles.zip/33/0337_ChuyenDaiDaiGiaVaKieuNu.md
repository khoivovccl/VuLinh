# Chuyện Dài Đại Gia Và Kiều Nữ

14/06/2011

<p>Chuyện
DàiĐại Gia Và Kiều Nữ</p><p>Vũ
Linh</p><p>Dân
Mỹ vẫn là ngây ngô, dễ mắc bẫy mị dân, dễ tin bánh vẽ...</p><p>Báo
chí còn đang bận rộn bàn ra tán vào chuyện ông Tây và bà làm phòng Phi Châu tại
New York, thì bất ngờ lòi ra chuyện con hoang của ông cựu thống đốc lực điền của
Cali. Chưa bàn xong ông này thì đẻ ra chuyện ông kia. Internet tràn ngập tin vịt,
tin thật, chuyện vui, chuyện buồn, chuyện kín, chuyện hở về hai ông này. Đã vậy,
tuần qua, cả nước Mỹ lại có dịp sôi nổi với chuyện ông John Edwards. Lại thêm một
đại gia tiêu tan sự nghiệp vì kiều nữ.</p><p>Để
nhắc nhở quý độc giả ít theo dõi tin tức chính trị Mỹ, xin có đôi lời giới thiệu
lại về ông Edwards này.</p><p>Ông
John Edwards là ngôi sôi sáng giá nhất của đảng Dân Chủ vào những năm
2002-2003. Ông xuất thân là con một thợ hầm mỏ tiểu bang North Carolina, nhờ
trí thông minh và cần cù, trở thành một trong những luật sư chuyên tranh cãi đòi
bồi thường cho nạn nhân của các đại công ty, Mỹ gọi là trial lawyer, tức là
chuyên môn đi thưa kiện các đại công ty sơ xuất làm hại người khác. Đặc biệt là
các công ty chế thuốc, bác sĩ, hay nhà thương gây ra tai nạn cho bệnh nhân.
Ngành luật này thịnh hành nhất ở Mỹ trong khi gần như không có ở các nước khác.
Những vụ kiện toàn lên đến bạc triệu mặc dù thiệt hại phần lớn chỉ tương đối nhỏ.
Những vụ kiện các hãng thuốc lá thường lên đến bạc trăm triệu và bạc tỷ như
không. </p><p>Trên
quan điểm chính trị, đảng Dân Chủ, là đảng nhận được hàng trăm triệu tiền yểm
trợ từ những vận động hành lang của khối luật sư này, thì họ là "mạnh thường
quân" bênh vực người nghèo chống các đại gia. Đảng Cộng Hòa thì cho họ là những
kẻ chịu trách nhiệm làm tăng chi phí y tế lên mức cao nhất thế giới vì những vụ
kiện cực kỳ tốn kém mà các nước khác không có, kể cả các nước tiến bộ Âu Châu. </p><p>Các
"đại gia" nhà thương, hãng bảo hiểm, bác sĩ dĩ nhiên không ngoan ngoãn trả tiền
bồi thường, mà luôn luôn mau mắn "thua me gỡ bài cào" tăng giá trên tất cả các
bệnh nhân khác, những người không nhận được bồi thường nào, nhưng vẫn tốn tiền
bác sĩ, nhà thương, thuốc men, và bảo hiểm.</p><p>Trong
một vụ kiện như vậy, thông thường nạn nhân và luật sư chia nhau 60%-40%. Luật sư
lãnh 40%, cộng thêm mọi chi phí của luật sư - như tiền di chuyển, khách sạn,
thuê chuyên gia làm nhân chứng, v.vmà nạn nhân phải trả. Các nạn nhân lấy tiền
trang trải nhà thương, thuốc men, và chi phí, cuối cùng thường chẳng còn lại
bao nhiêu. Chỉ có mấy vị luật sư là làm giàu to. Ông Edwards chưa đến bốn chục
tuổi đã trở thành một trong những luật sư nổi tiếng và cũng là giàu có nhất. Dù
vậy, vẫn được tiếng là luôn tranh đấu cho người nghèo chống các đại gia.</p><p>Ông
khai thác ngay sự thành công nghề nghiệp và nhẩy vào chính trị. Năm 1998, khi
ông 45 tuổi, ông ra tranh cử thượng nghị sĩ Dân Chủ tại tiểu bang North
Carolina và dễ dàng đắc cử với tư cách là ứng viên của dân lao động và dân thấp
cổ bé họng. Vào Thượng Viện, nổi tiếng ngay với cái mã đẹp trai và ăn nói thao
thao bất tận, lúc nào cũng tận lực bênh dân nghèo.</p><p>Không
bỏ lỡ cơ hội diều gặp gió, chỉ ba năm sau khi vào Thượng Viện, năm 2002, ông nhẩy
ra tranh cử tổng thống trong kỳ bầu năm 2004. Đúng như tính toán, ông thành
công vượt mức, về hạng nhì trong số gần một tá ứng viên Dân Chủ ra chống tổng
thống đương nhiệm George W. Bush. Một John Kennedy tái sinh. </p><p>Thượng
Nghị Sĩ John Kerry, người về đầu, vội mời ông Edwards ra đứng chung liên danh
Dân Chủ như ứng viên phó tổng thống. Hai ông ra tranh cử và thua liên danh
Bush-Cheney sát nút, qua hơn một trăm ngàn phiếu của tiểu bang Ohio. </p><p>Thua
keo này, bày keo khác. Ông John Edwards, ra tranh cử tổng thống trở lại vào năm
2007. Lần nầy, ông đụng hai đối thủ: một cực kỳ nặng ký là bà nghị sĩ cựu đệ nhất
phu nhân Hillary Clinton, và một ông tay mơ thuộc loại ứng viên vớ vẩn mà không
ai tin là có chút hy vọng nào, nghị sĩ da đen Barack Obama. Theo các thầy bàn
thời đó, đây là cuộc chạy đua tay đôi giữa bà Hillary và ông Edwards. Thế rồi,
trước sự bất ngờ của tất cả thiên hạ, TNS Obama thắng cuộc bầu sơ bộ đầu tiên tại
Iowa, và về nhì trong cuộc bầu thứ nhì ngay sau đó tại New Hampshire. Cuộc chạy
đua tay đôi biến thành tay ba. Với Obama độc quyền phiếu của dân da màu, trí thức
trẻ, giới khoa bảng và truyền thông. Bà Hillary và ông Edwards chia nhau phiếu
dân lao động da trắng, các bô lão và các bà. Thời điểm đó là đầu năm 2008.</p><p>Vài
tháng trước đó, tháng Mười năm 2007, tờ lá cải National Enquirer đi theo ông
Edwards, chụp được hình ông này nửa đêm từ khách sạn lén lút ra về. Tờ báo mau
mắn tung tin ông này lem nhem có phòng nhì và hình như còn có con hoang nữa. Nhưng
chẳng ai để ý. Báo này nổi tiếng là chuyên đăng tin giựt gân lếu láo, loại tin
phòng the của các nhân vật nổi tiếng như nghệ sĩ hay tài tử xi-nê. Không đáng
tin cậy.</p><p>Các
cơ quan truyền thông lớn như New York Times, Washington Post, các đài truyền
hình như CNN, ABC, NBC, CBS đều phớt lờ đi. Họ tập trung nỗ lực đánh ứng viên Cộng
hòa John McCain về tin lem nhem với một bà nào đó, do New York Times tung ra.
Tin này được đưa ra ào ạt, mặc dù không báo nào có được bất cứ bằng chứng nào.
Trong khi đó bằng chứng đành rành về ứng viên Edwards thì không ai nhắc đến.</p><p>Một
phần vì cùng là phe ta cấp tiến với nhau. </p><p>Nhưng
một lý do quan trọng hơn là những tính toán chính trị của họ. Nếu khui tin
phòng the của Edwards ra thì có hy vọng ông này sẽ bị loại khỏi cuộc chiến
ngay, và tất cả phiếu của dân da trắng, lao động và bô lão, sẽ dồn vào bà
Hillary, nâng cao hy vọng cho bà thắng Obama. Nếu ỉm chuyện này đi, thì dĩ
nhiên thế "tam quốc" có lợi lớn cho Obama. Sau này khi Obama đã vững rồi thì
tung tin Edwards lem nhem mới thực sự có lợi. Với chủ ý giúp Obama tối đa, các
cơ quan truyền thông dòng chính dìm tin Edwards để ông này tiếp tục tranh cử, đánh
bà Hillary. </p><p>Mãi
cho đến tháng Bẩy năm 2008, sau khi bà Hillary đã thua rồi thì giới truyền
thông dòng chính mới bắt đầu khui chuyện ông Edwards. Bắt buộc ông này lên truyền
hình xác nhận có lem nhem nhưng chối biến là không có con gì hết. </p><p>Câu
chuyện dan díu của ông Edwards, cũng có thể quay thành phim rất hấp dẫn.</p><p>Trong
khi vận động tranh cử, ông tình cờ gặp đào, dan díu với bà rất dễ dàng vì trong
thời gian tranh cử, các ứng viên thường ở khách sạn ròng rã cả năm, đi từ tỉnh
này đến tỉnh nọ. Bà vợ của ông lại bị ung thư nặng, không đi theo ông một cách
thường trực, mà chỉ nằm nhà, thỉnh thoảng mới xuất hiện trên truyền hình tuyên
bố mấy câu ủng hộ.</p><p>Ông
Edwards bổ nhiệm cô vợ bé làm chuyên viên về truyền thông, giao cho cô ta vài
cái "jobs" quay phim vận động. Trả thù lao cả trăm ngàn cho mỗi phim mặc dù
nàng chưa bao giờ biết cầm máy quay phim, và các phim quay chẳng bao giờ được
chiếu. Thật ra, cô ả có quay được một phim ông Edwards và mình đang "làm việc"
trong khách sạn. Cuốn phim hiện là tang chứng quan trọng được tòa án cất giữ. </p><p>Không
hiểu tại sao mấy ông bà Mỹ ưa có cái thú quay phim mình đang "làm việc", không
biết để khoe cái gì cho ai" </p><p>Sau
một thời gian, nàng phòng nhì có bầu rồi sanh con. Một phụ tá, cánh tay mặt của
ông Edwards nhẩy ra công khai nhận đây là con của anh ta, dù anh đã có vợ con đầy
đủ. Vài người lấy làm lạ sao anh này nhận lem nhem có con hoang mà bà vợ tỉnh
khô, chẳng than phiền chửi bới đòi ly dị gì cả.</p><p>Sau
khi ông Edwards thất cử và rút lui thì báo chí mới bắt đầu tranh nhau điều tra,
và lòi ra chuyện đứa bé quả thật là con ông. Thêm vào đó, chẳng biết về sau,
chuyện cơm không lành canh không ngọt như thế nào, chỉ biết ông đệ tử họp báo,
rồi viết sách đúng truyền thống của dân Mỹ, kể hết câu chuyện ông thầy dan díu,
có con, rồi ép anh đệ tử nhận làm con của mình. Anh ta còn tố cáo thêm là ông
thầy cũ đã nhận gần một triệu đô từ hai mạnh thường quân dưới danh nghĩa là tiền
vận động tranh cử, nuôi cô vợ bé và con hoang của ông. Một triệu đô để nuôi một
vợ bé và cái bầu trong thời gian hơn một năm, đó là cách xài tiền của người ủng
hộ thật là "hoành tráng" của ông ứng viên của đảng dân nghèo. </p><p>Ông
mạnh thường quân già thì bây giờ đã qua đời rồi. Còn bà mạnh thường quân thì là
một bà tỷ phú già lẩm cẩm, năm nay gần 100 tuổi. Mấy ông bà già thường là những
người ủng hộ đảng Dân Chủ mạnh nhất.</p><p>Tuần
qua, cựu thượng nghị sĩ John Edwards đã chính thức bị Bộ Tư Pháp truy tố về tội
lấy tiền vận động tranh cử đi nuôi phòng nhì, có thể bị bắt đi tù vài năm.</p><p>Nhưng
vụ án không giản dị như vậy. Hai vị mạnh thường quân đưa tiền mặt cho anh phụ
tá, và anh này dùng tiền này thuê khách sạn, thuê xe, mua vé may bay, lo cho cô
vợ bé của xếp ăn xài, lo tiền nhà thương khi sanh nở. Làm sao chứng minh đó là
tiền vận động tranh cử" Ngược lại nếu ông Edwards không ra tranh cử thì hai vị
mạnh thường quân này không có lý do gì đưa tiền cho ông ta. </p><p>Vấn
đề đáng bàn ở đây không là chuyện ông Edwards có vi phạm luật hay không. Mà là
mấy ông chính khách giả dối thượng hạng. Từ một ông giáo sư chuyên gia tài
chánh uyên thâm nhất, có nhiều triển vọng làm Tổng thống Pháp năm tới, cho đến
ông thống đốc người hùng lành mạnh của trẻ con, đến ông người hùng của dân lao động.</p><p>Chưa
hết. Tuần qua, lại lòi ra chuyện ông dân biểu Dân Chủ Anthony Weiner của Nữu Ước,
buồn tình đi chụp hình mình, giấu mặt nhưng trần gần như nhộng gửi cho một nữ
sinh viên để khoe hạ thể. Sau khi chối quanh chối quẩn cả tuần, ông mới thú tội
đã chính là hình của mình, do mình tự chụp, gửi qua internet. Ông này cũng thú
nhận trong mấy năm qua, đã trao đổi rất nhiều hình với ít nhất sáu bà khác, mà
bà vợ không hay biết. Nhưng cũng xác định không từ chức vì trách nhiệm vĩ đại đối
với cử tri!</p><p>Và
hình như cử tri của quản hạt tại New York vẫn có vẻ tin như vậy mới lạ! </p><p>Nước
Mỹ có thể tự hào là có dân thông minh nhất, nhiều thông tin nhất, báo chí đầy đủ
nhất, mức dân trí cao nhất, là miền đất lý tưởng nhất cho thể chế dân chủ để lựa
những người lãnh đạo tài đức nhất. Thực tế dân Mỹ vẫn là dân ngây ngô, dễ mắc
cái bẫy mị dân, dễ tin bánh vẽ nhất, đặc biệt là khi cái bánh vẽ đó được giới
truyền thông tô vẽ thêm. Một anh triệu phú cắt tóc tốn tới bốn trăm đô, ở nhà năm
chục ngàn square feet bên bãi biển, lấy cả triệu bạc của dân nghèo ủng hộ đi
nuôi vợ bé, mà vẫn là người hùng của dân lao động được! Năm 2004, chỉ cần vài
chục ngàn cử tri Ohio thay đổi lá phiếu là ông Edwards đã trở thành phó tổng thống,
không chừng vẫn còn làm phó tổng thống đến ngày nay và sẽ trở thành tổng thống
với kỳ bầu năm tới 2012. Năm 2008, nếu không có cái bánh vẽ to hơn và đẹp hơn của
một thượng nghị sĩ từ Chicago thì biết đâu chừng ông Edwards này đã thành tổng
thống ngay từ năm 2008 rồi. (12-6-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p><p></p>

### Nguồn:

Viet Bao: https://vietbao.com/a172988/chuyen-dai-dai-gia-va-kieu-nu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/