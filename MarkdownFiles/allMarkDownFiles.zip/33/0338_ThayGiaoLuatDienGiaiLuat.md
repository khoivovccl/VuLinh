# Thầy Giáo Luật Diễn Giải Luật

07/06/2011

<p>Thầy Giáo Luật Diễn Giải Luật</p><p>Vũ Linh</p><p></p><p>...nghĩa là TT Obama sẽ có quyền đánh lai
rai, vô hạn kỳ sao"</p><p></p><p>Cách đây hơn hai tuần, TT Obama
gửi thư cho lưỡng viện quốc hội Mỹ, thông báo cho các dân biểu và nghị sĩ ông
không thấy có nhu cầu cần xin phép quốc hội để tiếp tục can dự vào cuộc chiến tại Lybia.</p><p>Muốn hiểu câu chuyện cho rõ, ta cần coi lại lịch sử một chút.</p><p>Đầu thập niên 70, cuộc chiến Việt Nam leo thang ngày càng mạnh, bất chấp lời hứa của TT Nixon khi còn tranh cử là sẽ có giải pháp bí mật chấm dứt cuộc chiến. Đắc cử cuối năm 1968, ông nhậm chức đầu năm 1969. Qua mấy năm đầu, dân Mỹ chẳng thấy giải pháp bí mật gì, chỉ thấy CSBV tiếp tục đánh mạnh qua Mùa
Hè Đỏ Lửa 72, và TT Nixon tung quân Mỹ-Việt qua đánh căn cứ VC trên đất
Căm-Pu-Chia. Qua tháng Bẩy năm 1973, vì bực tức, quốc hội do phe chủ hòa Dân Chủ nắm đa số bèn thông
qua luật War Powers Act, cho phép tổng thống Mỹ có quyền ra quân
khai chiến để bảo vệ quyền lợi và an ninh quốc gia. Nhưng trong vòng 60 ngày, tổng thống phải xin quốc hội phê chuẩn quyết định. Sự phê chuẩn có thể được đặc miễn thêm 30 ngày nếu tổng thống có thư chính thức cho quốc hội, xác nhận quân nhân
Mỹ sẽ ở
trong tình trạng nguy hiểm nếu chấm dứt sự tham chiến ngay lập tức. </p><p>Đây là một trong những luật bị bàn cãi nhiều nhất. Nhiều người cho rằng luật này không
những vi phạm nguyên tắc phân quyền của thể chế chính trị Mỹ, mà còn bó tay tổng thống một cách vô lý và không thực tế. Trên cõi đời này, ít khi ta thấy một cuộc chiến nào kéo dài vài chục
ngày. Tất cả các tổng thống từ Nixon, đến Ford,
Carter, Reagan, Bush 41, Clinton, và Bush 43, đều lớn tiếng chỉ trích, nhưng không
làm gì được vì đã thành luật.</p><p>Khi tranh cử tổng thống, Nghị sĩ Barack
Obama mạnh miệng chỉ trích cuộc chiến Iraq và chính thức xác
định ông không phản đối luật War Powers nên dĩ nhiên sẽ tuân thủ tuyệt đối. Ông là tổng thống duy nhất ủng hộ luật War Powers này.</p><p>Ngày 20 Tháng 3 năm 2011, kỷ niệm đúng tám năm ngày TT Bush đánh
Iraq, TT Obama “tuân theo quyết định của thế giới” ra lệnh cho máy bay Mỹ đánh bom
quân lực của TT Gaddhafi của Lybia. TT Obama lên truyền hình trấn an dân
chúng, xác nhận sẽ tuân thủ một cách tuyệt đối luật War Powers, đồng thời tuyên bố cuộc can dự này chỉ là một chiến dịch giới hạn và ngắn hạn để “cứu dân” Lybia vì lý do “nhân đạo, khỏi bị Gaddhafi tàn sát”. Ông khẳng định đây là chuyện vài ngày, chứ không phải là vài tuần (it’s a
matter of days, not weeks).</p><p>Dù tổng thống công
khai hứa là sự can dự của Mỹ sẽ chỉ có vài ngày, trên thực tế không có một người nào tin đó sẽ là sự thực, ngoại trừ những ai tin tưởng vào TT
Obama một cách tuyệt đối, vô điều kiện. Trong một bài đăng
trên Việt Báo, kẻ viết này có ghi: “Đại khái thì
TT Obama hứa và hy vọng –lại hy vọng- cuộc chiến sẽ rất giới hạn, chỉ kéo dài “vài ngày” thôi (within days). Ta hãy chờ coi.”</p><p>Theo đúng luật, ngày 20 tháng 5 vừa qua
là hạn cuối, sau đótổng thống phải xin quốc hội phê chuẩn nếu quân Mỹ còn tiếp tục thả bom đánh Lybia. Ngày hôm nay
đây, máy bay Mỹ vẫn tiếp tục dội bom, nhưng TT Obama
gửi thư cho quốc hội cho biết ông sẽ hoan hô mọi hậu thuẫn của quốc hội, mà không cần quốc hội cho phép. </p><p>TT Obama giải thích đây là một sự can dự ở mức tối thiểu không là
một cuộc chiến quy mô lâu dài như chiến tranh Việt Nam,
trong khuôn khổ một quyết định của Liên Hiệp Quốc. Và hiện nay, quân
Mỹ không giữ vai trò chỉ đạo mà chỉ là một thành phần của lực lượng của Liên Minh Bắc Đại Tây Dương NATO
thôi.</p><p>TT Obama trước đây là phụ giảng về luật Hiến Pháp (Constitutional Law) tại Đại Học Chicago, chứ không dạy về luật thương mại hay luật hình sự vớ vẩn gì.
Ông giáo sư Obama chuyên dạy thiên hạ làm sao diễn giải và tôn trọng Hiến Pháp, làm sao diễn giải và tôn trọng quyền ra luật của quốc hội. Như vậy lời giải thích của TT Obama
phải đúng và chắc như đinh đóng cột sao"</p><p>Câu trả lời là “không”. TT Obama ngụy biện không hơn không kém.</p><p>Trong lời giải thích của ông, TT Obama viện dẫn ba chuyện: mức tối thiểu, quyết định của Liên Hiệp Quốc, và NATO. Cả ba lý do đều không được ghi trong luật War
Powers.</p><p>Luật đó không có ghi là tổng thống được phép tiếp tục cuộc chiến mà không
cần phép của quốc hội nếu là một cuộc chiến ở mức tối thiểu hay tối đa hay vừa phải, ngắn hạn hay lâu dài gì hết.
Đâu là mức tối thiểu, tối đa" Thả vài chục quả bom một ngày chết vài chục người là tối thiểu khỏi phải rắc rối xin phép mấy ông bà
nghị sĩ" Thế thả bao nhiêu trái bom thì mới phải xin phép" </p><p>Luật đó cũng không ghi là tổng thống được miễn xin phép quốc hội Mỹ nếu đã có quyết định của Liên Hiệp Quốc hay bất cứ tổ chức Anh, Pháp, Nga, Tầu,
hay quốc tế nào khác. Tổng thống Mỹ bắt buộc phải tuân thủ lệnh của Hội Đồng Bảo An Liên Hiệp Quốc từ hồi nào" Hiến Pháp Mỹ có ghi điều này không" Tuyệt đối không có, cũng như luật War Powers cũng không ghi luôn.</p><p>Luật đó cũng không ghi là tổng thống được miễn xin phép quốc hội nếu Mỹ tham chiến dưới quyền chỉ huy của NATO hay bất cứ liên minh quân sự nào
khác. Năm 1973, Mỹ tham chiến tại Việt Nam dưới danh
nghĩa của Liên Minh Phòng Thủ Đông
Nam Á (SEATO), có đầy đủ lính Úc, Tân Tây Lan, Phi, Thái, Đại Hàn tham gia. Có khác gì việc máy bay Mỹ đang thả bom Lybia dưới danh
nghĩa NATO" Trong cả hai trường hợp, máy bay là máy bay Mỹ, bom là bom Mỹ, tư lệnh quân đồng minh là tướng Mỹ, mọi quyết định là từ tổng thống Mỹ, tiền là do dân Mỹ đóng thuế. Khác nhau điểm nào" </p><p>Chuyện Mỹ núp sau các liên minh là chuyện cũ xì, đã thịnh hành từ thời TT Truman trong cuộc chiến với Bắc Hàn. Nếu quốc hội năm 73 ra luật War
Powers để kềm chế TT Nixon trong khuôn khổ SEATO được thì tại sao luật đó lại không áp dụng cho TT
Obama trong khuôn khổ NATO" </p><p>Phát ngôn viên Tòa Bạch Ốc phụ họa cho tổng thống và nói với báo chí TT Obama tin rằng ông làm chuyện đúng và
có tham khảo thường xuyên với quốc hội. Luật War
Powers không hề đề cập đến chuyện tổng thống nghĩ
đúng hay sai, vì dĩ nhiên chưa có tổng thống nào lại nhận là “tôi nghĩ tôi đã lấy quyết định sai”! Còn chuyện
tham khảo với quốc hội thì thế nào là tham khảo" Hỏi ý kiến vài ông
bà dân biểu phe ta không phải là
lấy biểu quyết của quốc hội như luật War Powers đòi hỏi. </p><p>Nói tóm lại, TT Obama bất chấp dân Mỹ theo lý luận kiểu người nào đã chống thì làm
gì cũng vẫn chống, người nào đã ủng hộ thì làm gì cũng ủng hộ hết. Thắc mắc làm chi. Muốn làm gì thì cứ làm thôi.
Mà quả nhiên là như vậy. Một vài tiếng nói chỉ trích của vài cơ quan truyền thông bảo thủ, nhưng bị phủ lấp bởi hàng loạt bài bình
luận ủng hộ từ phía truyền thông “phe ta”.</p><p>Từ Nixon cho đến Obama, tất cả các tổng thống chống luật War
Powers đều tuân thủ luật, nhưng ông tổng thống duy nhất lớn tiếng tuyên bố ủng hộ luật cũng lại là tổng thống duy nhất vi phạm luật này. Cái oái ăm của
chính trị Mỹ"</p><p>Ngày trước, TT Bush quyết định đánh Afghanistan và Iraq. Cả hai lần đều được tổng thống xin quốc hội biểu quyết cho phép
trước khi đánh. Cả hai lần quốc hội đều biểu quyết với đa số tuyệt đối cho phép tổng thống ra quân.
Nhưng rồi sau đó, phe Dân Chủ và báo chí cấp tiến có lẽ bị bệnh lú lẫn alzheimer nên vẫn nằng nặc chỉ trích TT Bush vi phạm Hiến Pháp, gian manh vi phạm đủ thứ luật. Bây giờ TT Obama
công khai vi phạm luật, và “phe ta” đồng loạt chấp nhận sự ngụy biện của tổng thống. Hãy thử tưởng tượng nếu như ông tổng thống đang đánh Lybia mà bất cần quốc hội cho phép là TT Bush thì phản ứng của các ông bà dân cử Dân
Chủ sẽ như thế nào" Báo New York Times và
Washington Post, đài CNN và MSNBC sẽ bình luận ra sao"</p><p>Thiên hạ có thể hỏi thế quốc hội đâu rồi" Sao không thấy phản ứng"</p><p>Trong quốc hội, dĩ nhiên là các vị dân cử Dân Chủ khó có thể dám chỉ trích lãnh tụ của mình. Nhưng cũng chẳng ai dám bênh vực những lời ngụy biện trắng trợn đó. Kết quả, phe ta im lặng như tờ.</p><p>Phe Cộng Hòa cũng phản ứng y chang, im lặng là vàng.
Nhưng vì lý do khác. Nếu các
vị dân cử Cộng Hoà lên tiếng chỉ trích thì có nghĩa là đòi hỏi tổng thống phải xin phép
quốc hội, tức là đòi mang vấn đề ra tranh luận trước quốc hội, và lúc đó các vị dân
cử cả Dân Chủ và Cộng Hòa sẽ phải lên tiếng và biểu quyết chấp nhận hay chống. Mà chống hay chấp thuận đều là chuyện thật khó. Há miệng mắc quai. </p><p>Chống việc tham chiến của Mỹ tại Lybia có nghĩa là chống lại cao trào dân chủ đang bùng lên tại Trung
Đông, chống lại việc làm “nhân đạo cứu dân” của TT Obama.
Nhất là ngay sau đó, TT Obama khôn ngoan đọc diễn văn giải thích, biện minh bằng một lập luận mà phe Cộng Hòa đã hoan hô không ngừng từ bao năm nay: đó là “phát huy
dân chủ tại Trung Đông và thế giới Ả Rập Hồi Giáo” để đem lại hoà bình
và ổn định lâu dài cho vùng này và chấm dứt nạn khủng bố toàn cầu. Đây
chính là “chủ thuyết Bush”, được ông Bush long trọng
tuyên cáo cùng quốc dân trong diễn văn nhậm chức nhiệm kỳ hai.
Làm sao các ông bà Cộng Hòa chống được"</p><p>Mà ủng hộ thì tức là nhìn nhận TT Obama
làm đúng, làm giỏi, tức là lại dâng thêm
một mâm cỗ cho TT
Obama xơi trước ngày bầu cử sắp tới. Làm sao phe Cộng Hòa ủng hộ được"</p><p>Thôi thì tốt nhất là chúng ta thông cảm cho nhau, cùng nhau lờ đi
cho vui nhà vui cửa, cả hai bên đều có lợi. Hơn thế nữa, ta cứ lờ đi, mai mốt TT Obama thành công thì có thể nói “chúng tôi đã cho phép ông ấy mà”. Nếu TT Obama
thất bại thì lúc đó hỏi giấy cũng chưa muộn.</p><p>Mãi đến ngày 3 tháng 6 vừa
qua, tức là 75 ngày sau, Hạ Viện do Cộng Hòa nắm đa số mới thông qua được một nghị quyết ển ển xìu
xìu, vô thưởng vô phạt, cảnh giác tổng thống (put on notice) “phải làm
đúng nếu không sẽ chịu hậu quả”. Một quyết định làm cho có, hoàn toàn chẳng mang ý nghĩa gì hết. Thượng Viện do phe
Dân Chủ kiểm soát thì tuyệt đối không lên tiếng.</p><p>Vấn đề ở đây
không phải là có nên đánh Gaddhafi hay không, mà là TT Obama
có tuân theo luật do chính đảng Dân Chủ đề xướng
và chính TT Obama hoan nghênh hay không. </p><p>Không xin phép quốc hội có nghĩa là TT Obama sẽ có quyền đánh lai
rai, vô hạn kỳ sao" Đây là một điểm thắc mắc lớn mà TT Obama không đề cập đến, mà cũng chẳng ai đặt câu hỏi. Đánh đến chừng nào" Mục đích đầu tiên và
chính thức là để cứu một nhóm dân nổi loạn đang trốn trong thành phố Benghazi
khỏi bị Gaddhafi tàn sát, như vậy đã cứu xong chưa" TT Obama
muốn cứu vài trăm dân nổi loạn chống Gaddhafi, nhưng cho đến nay cả ngàn người đã chết vì các cuộc oanh tạc của máy bay Mỹ. Có mâu thuẫn không" Còn bao nhiêu ngàn người sẽ chết" Bao nhiêu trăm triệu đô
sẽ được đổ vào nữa" Để đạt mục đích gì"</p><p>Người duy nhất có câu trả lời đã không trả lời. Cơ quan duy nhất có thẩm quyền bắt ông trả lời là quốc hội, thì đã đào nhiệm,
tránh làm bổn phận. (5-6-11)</p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a172677/thay-giao-luat-dien-giai-luat

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/