# Cộng Hòa Lâm Nguy"

31/05/2011

<p>Cộng Hòa
Lâm Nguy"</p><p>Vũ Linh</p><p></p><p>...Obama
tiếp tục hành xử theo kiểu… “Cộng Hòa nằm vùng” thì cũng tốt thôi...</p><p></p><p>Tuần vừa
qua, đã có một cuộc bầu cử địa phương mà dân tỵ nạn chúng ta rất ít người biết
đến. Ngay cả dân Mỹ cũng chẳng có bao nhiêu người để ý. Đó là một cuộc bầu dân
biểu liên bang đặc biệt tại Hạt 26 trong tiểu bang Nữu Ước. Đây là địa hạt từ
trước đến giờ vẫn là một trong số các căn cứ địa Cộng Hòa rất hiếm hoi trong một
tiểu bang mà đảng Dân Chủ nắm đa số ở mọi cấp. Ứng viên của đảng Dân Chủ lần
này bất ngờ hạ ứng viên của đảng Cộng Hòa luôn.</p><p>Trong thời
gian qua, cũng đã có nhiều cuộc bầu đặc biệt tương tự được tổ chức tại nhiều
nơikhác để bầu thay thế các vị dân cử
đã chết, hay từ chức, hay được bầu vào những trách vụ khác. Qua các cuộc bầu đặc
biệt này, đảng Cộng Hòa đã liên tục rớt đài, thua các đối thủ Dân Chủ, đặc biệt
là tại một số tiểu bang then chốt cho cuộc chạy đua vào Tòa Bạch Ốc năm tới. </p><p>Dĩ nhiên
đây là những tin vui lớn cho TT Obama, cho đảng Dân Chủ, cũng như là cho khối
truyền thông cấp tiến. Họ đã không ngần ngại thổi phồng những chuyện này lên,
coi như là gió đã đổi chiều. Sau ngày bầu cử tháng Mười Một năm ngoái khi Cộng
Hòa đại thắng chiếm lại được đa số trong Hạ Viện, và cắt thế đa số của Dân Chủ
tại Thượng Viện.</p><p>Phe Dân
Chủ cho rằng gió đổi chiều vì từ ngày thắng lợi tháng Mười Một, đảng Cộng Hòa
đã tung ra nhiều đòi hỏi quá đáng không hợp “lòng dân” nữa. Điển hình là trong
thời gian qua đã có hai cuộc chiến lớn giữa hai chính đảng:</p><p>- Cuộc
chiến ngân sách: phe Cộng Hòa chủ trương giảm thiểu thâm thủng ngân sách, đòi cắt
chi tiêu mà không chịu tăng thuế. </p><p>- Vấn đề
cải tổ y tế: phe Cộng Hòa đòi hủy bỏ toàn bộ cái luật mới này, hay nếu không được,
thì cũng sửa đổi quy mô. </p><p>Phe Dân
Chủ mau mắn diễn giải dùm cho thiên hạ hiểu: Cộng hòa muốn cắt tiền già, cắt tiền
medicare, medicaid, cắt tiền thất nghiệp, sa thải công chức, giáo viên, công
nhân,… đồng thời bảo vệ nhà giàu không cho TT Obama tăng thuế họ. Cộng Hòa cũng
sẽ bỏ mặc hàng chục triệu người ốm đau ráng chịu, trong đó có những trẻ em bị
khuyết tật vì không muốn các triệu phú phải đóng thuế cao hơn, đại khái giữa trẻ
em khuyết tật và triệu phú thì Cộng Hòa đứng về phiá triệu phú. Dĩ nhiên thiên
hạ không rảnh rang hay không đủ khả năng suy nghĩ lâu dài, nghe vậy thì biết vậy,
và đương nhiên nghe vậy là tá hỏa rồi, sợ Cộng Hòa hơn sợ ngáo ọp. Không cần biết
trong tám năm Nixon, tám năm Reagan, bốn năm Bush cha, rồi tám năm Bush con, đã
chẳng có trẻ em khuyết tật nào bị vứt ra đường, mà cũng chẳng có cụ nào bị cắt
tiền già, cắt tiền thuốc hết.</p><p>Đã vậy,
trong vấn đề đối ngoại, TT Obama giỏi hơn Bush nhiều vì giết được Bin Laden,
không cần biết chuyện tìm ra được đầu giây mối nhợ là do ai. Iraq biến khỏi mặt
báo, chứng tỏ chiến lược của Obama thành công vẻ vang như PTT Biden đã khoe, bất
cần biết ổn định tại Iraq là từ chiến lược đôn quân của Bush mà ra. Cuộc chiến
tại Lybia chứng tỏ TT Obama là một người có lòng nhân ái, muốn cứu rỗi dân vô tội
Lybia, bất kể chuyện Mỹ khoanh tay đứng nhìn hàng ngàn dân Syria và Yemen bị giết.
Lòng nhân ái cũng tốt nhưng cần phải có tính toán lợi hại nữa chứ. Mới đây
thiên hạ cũng thấy TT Obama lớn tiếng kêu gọi dân chủ hóa Trung Đông để giải
quyết tận gốc những bất công đưa đến tình trạng bất ổn trong vùng và khủng bố
toàn cầu. Nghe thật là đẹp, nhưng thiên hạ quên mất hình như đây là chiến lược
toàn cầu của TT Bush, đã được long trọng tuyên bố trong diễn văn nhậm chức nhiệm
kỳ hai, tháng Một năm 2005.</p><p>Trước
các chuyển biến trên, quả bóng Cộng Hoà hiển nhiên đã xì hơi sớm hơn dự tính rất
nhiều, đưa đến chiến thắng liên tục của các ứng viên Dân Chủ.</p><p>Đương
nhiên những lập luận trên chỉ là cách diễn giải của phe Dân Chủ. Sự thật có hơi
khác.</p><p>Sau chiến
thắng của phe Cộng Hòa, TT Obama đã thay đổi chiến lược trị quốc. Ông đã chấp
nhận mình đã vung tay quá trán, chấp nhận cắt giảm cả tỷ trong các chương trình
vĩ đại của ông, chấp nhận sửa đổi luật cải tổ y tế. Chấp nhận luôn cả chủ thuyết
của Bush, dùng dân chủ để mang lại ổn định cho Trung Đông và như vũ khí để chống
khủng bố toàn cầu. Đến độ bình luận gia Dân Chủ cấp tiến, ông James Carville, cựu
cố vấn của TT Clinton, đã phải lên tiếng than phiền Obama chính là Cộng Hòa nằm
vùng!Hình như gió đã đổi chiều. Nhưng
gió ở đây là gió Obama, đổi chiều, chuyển qua hướng Cộng Hòa hơi xa.</p><p>Nhìn dưới
khiá cạnh này, phe Cộng Hoà đang rơi vào tình trạng chéo cẳng ngỗng: vì gây được
áp lực đẩy TT Obama vào vị trí ôn hòa hơn, nghe lời Cộng Hòa hơn, làm theo ý Cộng
Hòa hơn, thì lại tăng uy tín cho TT Obama, nhất là trong khối Cộng Hoà và khối
Độc Lập không sống chết với đảng nào. Và càng tăng hy vọng tái đắc cử của tổng
thống năm tới. Tuy một số các ông bà cấp tiến cực đoan như Carville sẽ bất mãn,
đả kích, nhưng cuối cùng khi vào phòng phiếu thì họ vẫn phải bỏ phiếu cho Obama
thôi, chứ không lẽ lại bỏ phiếu cho một ông bà bảo thủ Cộng Hòa" Đảng Cộng Hoà
đang dọn cỗ cho TT Obama ăn trong năm 2012"</p><p>Thế thì
Cộng Hòa phải làm gì bây giờ" Một bài toán chưa có đáp số"</p><p>Sự thật
không phải vậy. Chưa chắc gió đã đổi chiều như phe Dân Chủ kết luận.</p><p>Lấy thí
dụ cuộc bầu tại hạt 26 nêu trên phần đầu bài. Bà Kathy Hochul của Dân Chủ thắng
trong tình trạng ngựa về ngược. Truyền thông phe ta vội vàng khua trống rầm rộ
và diễn giải đây là chiến thắng vĩ đại của TT Obama vì bà Hochul tranh cử với
chiêu bài ủng hộ cải tổ y tế của TT Obama chống lại chương trình mà bà gọi là
“cắt giảm Medicare của Cộng Hòa”. Điều mà truyền thông kín miệng hơn là bà
Hochul thật ra chỉ thắng với hơn 41% tức là có gần 60% không bỏ phiếu cho bà. Sở
dĩ bà thắng chỉ vì phe Cộng Hòa bị chia phiếu làm hai, cho ứng viên Cộng Hòa,
và mất 9% số phiếu cho ứng viên cực hữu từ xưng là của Phong Trào Tea Party và
bỏ tiền túi ra tranh cử.</p><p>Nói cách
khác, chiến thắng của bà Hochul không phải vì hậu thuẫn của TT Obama lên cao
hơn, mà là vì có nhiều người chống Obama mạnh hơn, không vừa lòng với bà ứng
viên Cộng Hòa bị coi như chống chưa đủ mạnh, bỏ phiếu cho ông Tea Party, khiến
bên Cộng Hòa thua. Đó có phải là tin tốt cho TT Obama như truyền thông phe ta
quảng bá không"</p><p>Nhưng vấn
đề vẫn là chống Obama rồi thì bầu cho ai" Còn một năm rưỡi nữa là đến cuộc bầu
tổng thống. Giờ này trong kỳ bầu trước thì các ứng viên cả hai đảng đã rõ ràng,
thu bạc triệu để tranh cử rồi. Nhưng năm nay, bên Dân Chủ thì dĩ nhiên khỏi phải
bàn, nhưng bên Cộng Hòa thì hình ảnh vẫn rất lờ mờ.</p><p>Các tên
tuổi lớn như cựu thống đốc Mitt Romney, cựu chủ tịch Hạ Viện Newt Gingrich, cựu
thống đốc Sarah Palin, cựu thị trưởng Rudy Giuliani, … vẫn chân trong chân
ngoài. Vài ngôi sao chưa mọc đã tắt như tỷ phú Donald Trump. Vài ứng viên mới vẫn
loay hoay tìm chỗ đứng như cựu thống đốc Tim Pawlenty, dân biểu Michelle
Bachmann, …</p><p>Nhìn kỹ
vào hậu trường Cộng Hòa, ta thấy cũng có chuyện đáng nói.</p><p>Trước hết,
hình như đang có cuộc đấu võ giữa hai bà. Đảng Cộng Hòa nổi tiếng là đảng của đấng
mày râu da trắng, bây giờ, sôi động nhất lại là màn chạy đua giữa hai bà. Hai
bà này là dân biểu Michelle Bachmann và cựu thống đốc Sarah Palin. Cả hai bà đều
trẻ, đẹp, hấp dẫn, ăn hay nói giỏi. Đặc biệt là cả hai bà đều có khuynh hướng bảo
thủ cực đoan, chống Obama cực mạnh, được ủng hộ tối đa của Phong Trào Tea
Party, nhưng đồng thời cũng là tấm bia của truyền thông dòng chính cấp tiến. Ta
có thể nói không sai lầm, cả hai bà quả là chị em sinh đôi. Cả hai bà đều muốn
nhẩy ra tranh cử và đều quả quyết dư xăng đánh hạ đương kim tổng thống. Nhưng cả
hai bà đều gờm nhau, chưa ai ra chiêu, chưa ai nhẩy vào cuộc. Dĩ nhiên, trong
hai bà, chỉ có thể có một. Không thể nào có chuyện cả hai bà ra chung liên
danh, một ứng cử tổng thống và một ứng cử phó tổng thống. Trong cuộc chạy đua
không có gì bí hiểm, hấp dẫn lần này, đây chính là màn "múa đôi" hồi
hộp nhất. Ta hãy chờ xem bà nào thắng.</p><p>Sau đó
là đến chuyện ông Herman Cain. </p><p>Ông này
là người da đen, cực kỳ bảo thủ, cựu Tổng Giám Đốc nhà hàng dây chuyền
Godfather Pizza, giông giống như Pizza Hut, nhưng chuyên trị các khu dân da màu
khắp miền nam nước Mỹ. Truyền thông thân Cộng Hòa đã khua chiêng gõ trống quảng
bá ông này tối đa. Cái thông điệp của họ cũng dễ thấy: Cộng Hoà chẳng phải chỉ
có đàn ông da trắng, mà cũng có phụ nữ và dân da màu. Trước đây quảng bá ông thống
đốc gốc Ấn Độ của Louisiana, bây giờ đến ông Cain. Hơn nữa chuyện đáng nói là
cái ông đen này ăn nói rất bạo phổi, xỉ vả TT Obama không nương tay. Mang ông
đen ra đánh ông đen thì mới thích. Như cộng đồng tỵ nạn của ta cũng vậy, mỗi lần
có một anh “phản đảng” nào lên tiếng chửi cộng sản, là được ta công kênh hoan
nghênh ngay, không cần biết anh này chống cộng thiệt hay chống cuội, nói thật
hay nói phét. </p><p>Dù sao,
thì ta cũng thấy hy vọng đắc cử của ông Herman Cain này coi như chỉ là con số
âm khổng lồ thôi. Ông này chẳng có chương trình kế hoạch gì ghê gớm ngoài những
khẩu hiệu chửi Obama. Hiển nhiên chưa đủ để vào Bạch Cung. Chỉ đủ cho những người
không ưa Obama nghe cho sướng lỗ nhĩ thôi. </p><p>Trong
tình trạng chưa có gì rõ ràng hiện nay, ai có nhiều hy vọng đắc cử nhất bên Cộng
Hòa"</p><p>Theo
thông lệthì khi tổng thống mãn nhiệm
không ra tranh cử nữa thì phó tổng thống sẽ ra. Trong lịch sử cận đại, các phó
tổng thống Nixon, Bush, bên Cộng Hòa; Humphrey, Mondale, Gore bên Dân Chủ đều
ra tranh cử. Từ sau Đệ Nhị Thế Chiến, chỉ có một ông phó duy nhất không ra
tranh cử là Cheney của TT Bush. Hai ông phó Cộng Hòa đều thành tổng thống. Cả
ba ông phó Dân Chủ đều thất bại.</p><p>Không kể
mấy ông phó TT, thì bên Dân Chủ thường đưa ra những ứng viên thuộc hạng bình
dân, bất ngờ nổi lên từ chỗ vô danh không ai biết đến. Từ ông thống đốc chuyên
nghề trồng đậu phộng là Carter của tiểu bang ruộng Georgia, đến ông thống đốc
Clinton của tiểu bang làng Arkansas, với bố đẻ và bố nuôi đều là dân tứ chiếng,
rồi đến Obama là con anh sinh viên Phi Châu, sống với bố ghẻ là một anh sinh
viên Indonesia, tất cả đều xuất thân khiêm nhường, là những người mới nổi chẳng
ai biết đến, rõ ràng là do hạ tầng cơ sở đảng đưa lên. Bên Cộng Hòa ngược lại,
luôn đưa ra những ông đại gia tai to mặt lớn như cựu thống đốc tiểu bang lớn nhất
Mỹ, Reagan của Cali, Chủ Tịch Thượng Viện Dole, hay thượng nghị sĩ người hùng
McCain. </p><p>Nhìn vào
quá khứ này, ta thấy trong danh sách ứng viên Cộng Hòa hiện nay, có cựu thống đốc
Romney –bố cũng là thống đốc cựu ứng viên tổng thống- có nhiều hy vọng nhất, vì
có tướng đại gia nhất theo cái nhìn của Cộng Hòa.</p><p>Xét cho
cùng, dù ứng viên Cộng Hòa là Romney, hay Giuliani, hay Gingrich, hay Palin,
hay Pawlenty, thì tất cả đều hy vọng rất mong manh. Nhưng nhiệm kỳ hai của TT
Obama, nếu có như vậy, cũng sẽ không có chuyện tiêu xài vung vít đáng sợ như
trước vì ông sẽ vẫn bị Hạ Viện trói tay. Có khi TT Obama tiếp tục hành xử theo
kiểu…“Cộng Hòa nằm vùng” thì cũng tốt
thôi. Chỉ có mấy ông cấp tiến như James Carville là sẽ nổi điên. (29-05-11)</p><p>Quý độc
giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của
tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a172366/cong-hoa-lam-nguy

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/