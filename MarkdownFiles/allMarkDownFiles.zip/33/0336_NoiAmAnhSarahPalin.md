# Nỗi Ám Ảnh Sarah Palin

21/06/2011

<p>Nỗi Ám Ảnh Sarah Palin</p><p>Vũ Linh</p><p></p><p>...bà Palin trở thành một đe dọa thật sự khiến cả giới truyền
thông phe ta phải ùn ùn xúm lại đánh...</p><p>Tuần trước, một biến cố xẩy ra, biến thành tiêu đề lớn trang
nhất của mấy tờ báo lớn nhất Hoa Kỳ, từ New York Times, đến Washington Post, từ
Los Angeles Times đến Miami Herald. Nó cũng là đề tài nóng nhất trên các đài
truyền hình CNN, NBC, ABC, và CBS. Đài MSNBC chỉ định tám ký giả gộc, và thuê
40 sinh viên đi điều tra sự kiện. Washington Post điều động hơn một trăm (100!)
nhân viên. New York Times lập nguyên một trang mạng mới với mấy chục ngàn
trang, yêu cầu độc giả toàn quốc vào đó và tiếp tay truy tìm dữ kiện.</p><p>Rõ ràng là một biến cố động trời, vĩ đại hơn tất cả những biến
cố khác hiện đang xẩy ra trên thế giới như chiến tranh Afghanistan, cuộc đàn áp
của chính quyền Syria đối với người biểu tình, cuộc xung đột Biển Đông giữa Tàu
và Việt Nam. Quan trọng hơn cả bài diễn văn của TT Obama về phục hồi kinh tế và
thất nghiệp tăng vọt lên hơn 9%. So với những vấn đề trọng đại gần đây ảnh hưởng
đến đời sống của chúng ta như cuộc tranh cãi về ngân sách tại quốc hội, những sửa
đổi về luật cải tổ y tế…, tất cả hình như đã trở thành chuyện nhỏ đối với giới
truyền thông Mỹ.</p><p>Chuyện gì mà ghê gớm thế" Xin thưa đó là chuyện chính quyền
tiểu bang Alaska vừa “giải mật” gần 25.000 cái email của bà Sarah Palin trao đổi
với nhân viên và dân chúng khi bà còn làm Thống Đốc và ra tranh cử phó tổng thống
bên cạnh TNS John McCain, năm 2007-2008.</p><p>Theo luật Mỹ, việc giải mật các tài liệu liên quan đến tổng
thống là thường tình. Nhưng chuyện giải mật đối với các thống đốc thì chưa hề
có. Đây là lần đầu tiên. Do đòi hỏi của các tổ chức truyền thông cấp tiến qua
luật Freedom of Information Act.</p><p>Trong lịch sử xứ này, chưa khi nào một“phong trào” quy mô như phong trào đi truy cứu
tin tức về bà Palin. Ngay kho tài liệu của các tổng thống Johnson và Nixon là
những tổng thống quan trọng nhất lịch sử cận đại Mỹ, cũng chưa thu hút được mức
chú tâm của truyền thông bằng kho tài liệu emails của bà Palin. Mà cái “kho tài
liệu” ghê gớm này thật ra cũng chẳng có gì liên quan đến quốc sách vĩ đại hay
bí mật an ninh quốc gia kinh khủng. Chỉ là một mớ điện thư trao đổi giữa bà
Palin và bàn dân thiên hạ Alaska.</p><p>Bà Sarah Palin chỉ làm thống đốc chưa đến nửa nhiệm kỳ của một
tiểu bang ít quan trọng nhất Mỹ ở tuốt bắc cực, và bây giờ bà cũng là một người
chẳng có chức vụ hay quyền hành quyết định gì ngoài chuyện gia đình bà. Bà cũng
chẳng là chủ tịch một đảng chính trị hay một hội đoàn từ thiện nào. Thăm dò dư
luận cho thấy bà chỉ có khoảng 10% hậu thuẫn trong khối cử trị Cộng Hòa. Tóm lại
bà chẳng là một nhân vật quan trọng ghê gớm. </p><p>Điều đáng nói là có một nhân vật quan trọng hơn bà Palin gấp
ngàn lần mà không thấy cơ quan truyền thông nào nhân danh luật Freedom of
Information đòi “giải mật” emails của ông: Obama thời ông còn làm nghị sĩ tiểu
bang và liên bang.</p><p>Dù vậy, Palin vẫn là đối tượng hàng đầu của truyền thông cấp
tiến. Dĩ nhiên ai cũng biết các báo không đi tìm những cái hay cái đẹp để ca tụng,
mà chỉ là đi bới móc chuyện để chửi. Đây là chiến dịch “khui thùng rác” lớn nhất
của truyền thông Mỹ. </p><p>Nhân danh “quyền muốn biết sự thật”, các cơ quan ngôn luận lớn
nhất của Mỹ đổ xô bới rác để đánh một người mà họ chống đối mạnh nhất. Bình luận
gia bảo thủ Ann Coulter đã gọi đây là một thứ “colonoscopy” của truyền thông (kẻ
viết xin gượng dịch cho lịch sự là "soi ruột"). Sau cả tuần lễ, báo
điện tử The Ticket lên tiếng bày tỏ sự thất vọng chung của cả khối truyền
thông: chẳng thấy gì ghê gớm để chửi! Chẳng những vậy, hình ảnh bà thống đốc
hình như còn được tốt ra nhiều: theo báo phe ta là Washington Post, mấy chục
ngànemails này có thể là những tài liệu
vận động hữu hiệu nhất cho bà ra tranh cử tổng thống, vì cho thấy hình ảnh một
thống đốc rất có khả năng, mạnh bạo đứng ra chống lại các thế lực kể cả các thế
lực Cộng Hòa (bài "Palin vs. the Press", Washington Post, June 14,
2011)</p><p>Trong lịch sử tranh cử tổng thống Mỹ, chưa người nào bị đánh
kỹ như bà Palin. Ngay khi tin bà được lựa làm ứng viên phó tổng thống của Cộng
Hòa được loan ra là cả ngàn ký giả đã đổ bộ vào tiểu bang Alaska để bắt đầu đi
tìm rác. Truyền thông cấp tiến dòng chính tìm mọi cách mô tả Palin như một mụ
nhà quê u mê nhất trái đất. Đài truyền hình NBC đưa một nữ kịch sĩ hài vô danh
là Tina Fey lên đóng vai Palin trong một chương trình hài hàng tuần để bôi lọ
bà. Rồi một số báo lấy luôn mấy câu hài ngớ ngẩn của Tina Fey gán ghép thành những
câu tuyên bố của bà Palin để có cớ chê bai! </p><p>Đời sống cá nhân của bà và gia đình cũng bị xuyên tạc, bôi
nhọ không nương tay. </p><p>Thậm chí đứa con tật nguyền của bà cũng không được tha, bị
lôi ra làm đề tài diễu trên truyền hình, còn bị bôi lọ đây là cháu ngoại của bà
Palin. Bà nhận là con ruột để khỏa lấp chuyện đây thực sự là con hoang của cô
con gái vị thành niên. Riêng bà thì việc xuất hiện trên truyền hình để trả lời
hai cuộc phỏng vấn được truyền thông biến thành bằng chứng không chối cãi về
tính ngớ ngẩn của bà.</p><p>Dưới con mắt của truyền thông cấp tiến, các ông bà Cộng Hòa
đều là những tên cà đụt nhất thế giới: từ một Eisenhower hữu dũng vô mưu, đến một
Nixon vô lại, một Ford không đủ khả năng làm hai chuyện một lúc như vừa đi vừa
nhai kẹo cao su, một Reagan tài tử cao bồi hạng bét, một Bush cha công chức lờ
mờ, một Bush con là thằng ngốc của làng. Trong khi các ông Dân Chủ thì đều là
thiên tài xuất chúng, thông minh tuyệt thế, tinh hoa của vũ trụ như Kennedy,
Johnson, Clinton và dĩ nhiên Obama. Ngay cả ông trồng đậu phộng lờ mờ Carter
cũng được tung hô là kỹ sư nguyên tử học. </p><p>Trong lịch sử cận đại Mỹ, từ sau Đệ Nhị Thế Chiến đến TT
Bush, dân Mỹ đã bầu cho năm tổng thống Dân Chủ qua 24 năm và sáu tổng thống Cộng
Hòa với 36 năm. Đảng của mấy ông ngố hình như được dân Mỹ ủng hộ hơn. Thành ra
chuyện truyền thông trí thức bôi bác bà Palin cũng không có gì mới lạ. </p><p>Điều mới lạ là tính hung hãn chưa từng thấy.</p><p>Dường như truyền thông cấp tiến nhìn bà Palin như là một mối
họa lớn nhất, cần phải nhổ cỏ tận rễ, không thể coi thường hay có một sơ hở nhỏ
nào. Xét cho cùng thì lo sợ này không phải là không căn cứ.</p><p>Bà Palin, chẳng chỉ là một người bảo thủ, mà còn là hình ảnh
của một nước Mỹ rất… Mỹ, mà dân Mỹ cảm thấy gần gũi. Một người đàn bà tiêu biểu
cho một nước Mỹ trung lưu.</p><p>Đây là một người vừa là hoa hậu vừa là cầu thủ bóng rổ, với
một mức giáo dục bình thường (không biết Yale hay Harvard là gì), mức hiểu biết
bình thường (chẳng bao giờ đọc New York Times hay Wall Street Journal) mà vẫn
thành công leo đến tột đỉnh, vừa lo chuyện quốc sự vừa gánh chuyện gia đình -
mà lại là một gia đình trung lưu bình thường với những vấn đề và những lục đục
mà cả triệu gia đình Mỹ cũng gặp phải, can đảm không phá thai để sanh và nuôi một
đứa con tật nguyền, một người luôn luôn lớn tiếng cổ võ cho những giá trị rất Mỹ
như đức tin, quyền có súng, thú đi săn, hạnh phúc gia đình, quyền tự do ăn nói
mà không cần rào trước đón sau như các chính khách. </p><p>Mà cũng là người có sức thu hút hấp dẫn rất đặc biệt. </p><p>Cuộc tranh cử tổng thống của TNS John McCain trước đây đi đến
giai đoạn hấp dẫn còn thua bài giảng của một thầy giáo làng dạy công dân giáo dục
cho học sinh tiểu học. Nhưng ông McCain vừa tuyển bà Palin vào liên danh là đảng
Cộng Hòa như sống lại và cuộc chạy đua tự nhiên thành hào hứng. Mỗi lần đi vận
động, ông McCain huy động được chừng vài ba trăm người nghe là mừng. Mỗi lần ra
mắt công chúng là bà Palin có ngay vài chục ngàn người tham gia. Ngay sau hai Đại
hội đảng, có lúc liên danh Obama-Biden của Dân Chủ bị tuột xuống thấp hơn liên
danh McCain-Palin.</p><p>Nếu không có cuộc khủng hoảng tài chánh bất ngờ hồi Tháng
Chín năm 2008 thì chưa biết được bên nào đã thắng!</p><p>Ngay bây giờ, hai năm sau cuộc bầu cử và sau khi bà Palun đã
là công dân không chức vụ gì mà uy tín vẫn đứng hàng đầu trong khối bảo thủ Cộng
Hòa. Sách của bà viết bán chạy hơn tôm tươi. Bà là lãnh tụ không chính thức của
Phong Trào Tea Party, phong trào đã làm cho đảng Dân Chủ mất thế đa số tại Hạ
Viện, và mất thế kiểm soát tuyệt đối Thượng Viện trong cuộc bầu cử Tháng 11 năm
ngoái.</p><p>Truyền thông cấp tiến có thể tùy hỷ bôi bác khinh thường
Palin nhưng không ai có thể phủ nhận tiếng nói của bà có ảnh hưởng mạnh mẽ
trong chính trường Mỹ. Ít người chịu nhìn nhận cái mâu thuẫn trong câu chuyện
“một mụ nhà quê ngớ ngẩn” mà lại gây tiếng vang chính trị lớn lao như vậy. Giới
truyền thông này bị ám ảnh đến mức nhất cử nhất động của bà đều được theo dõi
và chỉ trích. Báo điện tử CNN gần như cứ hai ba tuần là lại tung lên một bài với
những cái tựa đề như “tin xấu cho bà Palin” (Bad News for Palin), hay “Bà Palin
gặp rắc rối” (Palin in Trouble).</p><p>Việc truyền thông dòng chính bị hớp hồn bởi Palin được một
nhà báo trung lập viết một bài than phiền trên báo điện tử phe ta CNN với tựa đề
“Phải khảo xét tổng thống, chứ không phải bà Palin” (Scrutinize the President,
not Palin). Ông nhà báo này bực mình sao truyền thông lại thắc mắc quá mức về một
bà chẳng là ai cả, chẳng có chức quyền gì, cũng chẳng phải là ứng viên tổng thống.
Trong khi chẳng ai để ý đến bài diễn văn của TT Obama đọc trong tuần về vấn đề
phục hồi kinh tế, một đề tài hiển nhiên quan trọng gấp ngàn lần mấy cái emails
cũ rích của bà Palin.</p><p>Hoặc giả khối truyền thông cấp tiến rất thông minh, đang tìm
cách đánh lạc hướng dư luận" Cố tình kéo thiên hạ ra xa những thành quả khiêm tốn
của TT Obama"</p><p>TT Obama trong bài diễn văn, đã kể công ông đã cứu nguy kinh
tế bằng cách cứu nguy các hãng xe hơi. Ông cho rằng không cứu nguy các hãng xe
thì đã có thêm một triệu người bị thất nghiệp, và hơn thế nữa, hãng xe Chrysler
đã hoàn trả lại hết tiền chính phủ bỏ ra cứu họ. Nghe thì rất đáng hoan nghênh,
nhưng các đệ tử trung kiên của TT Obama khoan vỗ tay vội. Thành tích này, thật
ra là thành tích của… TT Bush vì quyết định cứu nguy các hãng xe là quyết định
của TT Bush, TT Obama chỉ tiếp tục chi tiền theo quyết định của Bush. Trong 12
tỷ đưa cho Chrysler, đã có 4 tỷ được đưa từ thời Bush, và 8 tỷ đưa tiếp tục dưới
thời Obama. Còn chuyện Chrysler hoàn trả hết tiền của Nhà Nước là điều mà ngay
cả Washington Post cũng phải than phiền TT Obama đã nói không đúng sự thật
(President Obama’s phony accounting on the auto industry bailout, Washington
Post, June 7, 2011). </p><p>Nếu TT Obama chỉ có thể khoe thành tích thừa hưởng của TT
Bush thì ông sẽ gặp khó khăn lớn trong kỳ bầu cử tới, và bà Palin trở thành một
đe dọa thật sự khiến cả giới truyền thông phe ta phải ùn ùn xúm lại đánh hội đồng
phủ đầu trước. Một mụ nhà quê u mê mà trở thành mối đe dọa lớn cho Đấng Tiên
Tri như vậy, kể ra thì cũng là một câu chuyện hy hữu đáng chú ý. (19-6-11)</p><p>Ghi chú: Sau bài về TNS Edwards tuần vừa qua, một số độc giả
đã góp ý. Vài người chỉ trích tác giả bình luận một chiều. Đây có lẽ là những độc
giả mới bắt đầu đọc bài của tác giả. Nếu có hứng thú tìm hiểu thêm, xin mời những
độc giả đó đọc thêm các bài nhận định về Cộng Hòa trên Việt Báo:</p><p>Điểm Danh Đối Lập (26-4-2011)</p><p>Chính Khách Và Mỹ Nhân (7-7-2009)</p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a173269/noi-am-anh-sarah-palin

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/