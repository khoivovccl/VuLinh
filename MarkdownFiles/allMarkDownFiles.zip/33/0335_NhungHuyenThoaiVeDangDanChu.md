# Những Huyền Thoại Về Đảng Dân Chủ

28/06/2011

<p>Những Huyền Thoại Về Đảng Dân Chủ</p><p>Vũ Linh</p><p></p><p>...tỷ phú giàu nhất thế giới như Warren Buffet,
George Soros… đều là Dân Chủ. </p><p></p><p>Còn đúng 18 tháng nữa là dân Mỹ sẽ đi bầu tổng
thống, và một phần lớn hệ thốngchính
quyền Mỹ, từ địa phương đến cấp tiểu bang và liên bang. </p><p>Với quốc tịch Mỹ, ta sẽ có quyền đi bầu. Và cũng như
tất cả những người dân Mỹ khác, ta cũng có quyền nằm nhà làm thầy bàn hay chửi
đổng. Chẳng ai bắt ta đi bầu. Thường thì hai chức năng chửi đổng và nằm nhà lại
hay đi đôi, nhất là khi không nhìn thấy ông bà ứng viên nào hấp dẫn hết! Như
năm tới khi ta đang thấy một bên là một ông họa sĩ vẽ bánh rất đẹp, và một bên
là một lô các ông bà tranh luận ồn ào mà chẳng có chương trình gì cụ thể.</p><p>Một điều mà nhiều người không để ý. Trong số dân Mỹ
đi bầu, đại đa số chẳng cần biết hay chẳng muốn biết hay chẳng có khả năng biết
chương trình ông ứng viên là gì, mà chỉ bầu hay không bầu vì cái mã đẹp trai
hay xấu trai, ba hoa giỏi hay cà lăm, làm bánh vẽ giỏi hay chân chỉ hạt bột, …
Chẳng hạn nếu nói về khả năng chính trị thì bà Hillary thuộc hàng sư mẫu, nhưng
Obama làm bánh vẽ hấp dẫn mấy anh chị trí thức sống trong sách vở hơn. Thế là
Obama làm tổng thống.</p><p>Nói nôm na ra, trong chính trị Mỹ, những yếu tố chi
phối, có tính quyết định, thường là những yếu tố hời hợt, phần lớn dựa trên ảo
tưởng, thành kiến và huyền thoại. Vì vậy, chúng ta nên thông cảm với nhiều
người hùng hồn bênh đảng này hoặc chống đảng kia mà chưa hiểu rõ, hoặc hiểu
theo truyền thông Việt ngữ xuất phát từ… Hà Nội!</p><p>***</p><p>Trong khi còn tranh cử tổng thống, TNS Obama hay bị
phe bảo thủ tố cáo là có khuynh hướng xã hội, thậm chí là cộng sản nữa. Ông
Obama mạnh mẽ tố cáo đây là những lập luận nằm trong chiến thuật khủng bố tinh
thần, dọa dẫm thiên hạ - mà ông gọi là scare tactics. Quả thật những lời tố cáo
Obama là cộng sản có tính bóp méo quá đáng, mặc dù ông giao du khá thân với
những thành phần thiên tả cực đoan nhất trong giới trí thức khoa bảng Mỹ. Nhưng
bản thân TT Obama cũng không ngần ngại dùng lập luận có tính khủng bố tinh thần
bóp méo không kém, khi ông cảnh cáo đảng Cộng Hòa sẽ không chữa bệnh cho các
trẻ em bị bệnh tâm thần để bảo vệ túi tiền của mấy ông triệu phú.</p><p>Khủng bố tinh thần nghe có vẻ lố bịch, nhưng thực tế
lại là vũ khí sở trường của cả hai đảng. Biết là hăm dọa vô căn bản, nhưng nói
mãi cũng sẽ có người tin. Đó là nguyên tắc cơ bản của kỹ thuật nhồi sọ cho loại
quần chúng rất thích bị nhồi sọ mà không biết. Có ai muốn công nhận mình là
hình nộm và bị nhồi sọ đâu"</p><p>Trong chính trường Mỹ hiện nay, cái huyền thoại đơn
giản nhưng thịnh hành nhất vẫn là cái huyền thoại đảng Dân Chủ là đảng của dân
lao động nghèo trong khi đảng Cộng Hòa là đảng của 2% tài phiệt da trắng. Không
cần biết trong kỳ bầu tổng thống năm 2008, ông Obama đã thắng nhờ có 750 triệu
tiền yểm trợ, phần lớn của các đại gia Wall Street. Các ông tỷ phú giàu nhất
thế giới như Warren Buffet, George Soros… đều là Dân Chủ. Hầu hết các tài tử
Hollywood sống trong nhung lụa đều là Dân Chủ. Các đại gia chủ các hãng truyền
hình (ví dụ CNN của ông chồng cũ của tài tử “Hanoi Jane Fonda”) và báo lớn nhất
nước (ví dụ Newsweek của ông chồng bà cựu dân biểu Dân Chủ Jane Harman) đều là
Dân Chủ. Ông Nghị Sĩ giàu nhất Thượng Viện là John Kerry, ứng viên tổng thống
của Dân Chủ năm 2004.</p><p>Một số người ngây thơ thì coi rằng những ai phê phán
đảng Dân Chủ và hệ thống truyền thông một chiều kia là nạn nhân của đài Fox
News!</p><p>Dựa theo huyền thoại này, những chuyên gia xách động
chính trị không ngưng quảng bá Dân Chủ tranh đấu cho đủ thứ quyền lợi cho
“người nghèo”. Tất cả đều như là quà miễn phí của Ông Già Noel cho vậy. Trong
khi Cộng Hòa chỉ chờ cơ hội cắt hết. Một số người nghe vậy, nghĩ rằng bầu cho
Cộng Hòa thì bảo đảm sẽ mất medicare, mất tiền thất nghiệp, mất tiền già, các
nghiệp đoàn sẽ bị giải tán, không còn ai tranh đấu bảo vệ quyền lợi cho nhân
công thấp cổ bé họng nữa, nhân công sẽ bị sa thải hết, mà ngồi nhà cũng không
đủ tiền uống trà ngắm trăng. Tất cả mọi người sẽ bị các đại gia bóp cổ chết
hết. </p><p>Nghe thì khó tin, nhưng sự thật lại có rất nhiều
người tin. Thế mới nói là tuyên truyền có kỹ thuật. Cái kỹ thuật đó chỉ thuần
túy dựa trên sự thiếu hiểu biết hay lười suy nghĩ của thiên hạ.</p><p>Ta hãy thử lấy công tâm mà nghĩ lại xem.</p><p>Từ sau Đệ Nhị Thế Chiến đến nay, chưa khi nào medicare,
medicaid, tiền già, tiền thất nghiệp đã bị cắt, kể cả dưới thời sáu tổng thống
Cộng Hoà. Trong 36 năm Cộng Hòa, chưa có một người dân Mỹ nào chết vì nghèo,
đói, hay bệnh mà không được chữa. Gần đây nhất, chương trình trả tiền thuốc cho
người già – Drug Prescription program - tốn kém của công quỹ cả trăm tỷ, chính
là phát minh của ông Cộng Hòa Bush con. </p><p>Nói welfare và medicare là của đảng Dân Chủ là nói
mà không biết mình nói gì, cũng không đáng trách vì chỉ là thiếu hiểu biết
thôi. </p><p>Dân Chủ cũng như Cộng Hòa đều nhìn nhận trách nhiệm
của Nhà Nước đối với dân. Khác biệt là đến mức nào. Trong khi Dân Chủ rải tiền
vô hạn để rồi Nhà Nước nợ hơn Chúa Chổm, thì Cộng Hoà chủ trương có giới hạn
cho an sinh xã hội, cho tiền thất nghiệp, chứ không thể có chuyện vài bà ăn
welfare đầu năm con trai, cuối năm con gái, hay vài ông nằm nhà chiều chiều
nướng barbecue uống bia coi football tháng này qua năm nọ, với tiền của những
người cong lưng cầy xâu cuốc bẫm.</p><p>Cũng chưa có nghiệp đoàn nào bị giải tán hết, ngoại
trừ những nghiệp đoàn trong các công ty bị phá sản vì tiền lương cho công nhân
quá cao. Tóm lại, cái luận điệu cho rằng Cộng Hoà sẽ cắt an sinh xã hội, giết
nghiệp đoàn, chỉ là hù dọa vô căn cứ, nhưng không thiếu gì người thiếu hiểu
biết hay vì thành kiến tin là đúng. </p><p>Kẻ viết này nhớ lại có bà cụ hàng xóm. Trong cuộc
bầu cử Gore-Bush, hỏi bà sẽ bầu cho ai thì bà trả lời “Tao chẳng bầu cho ai
hết. Dân Chủ toàn là mấy thằng phản chiến thân cộng khiến tao phải tỵ nạn ở
đây, còn Cộng Hòa là thằng nhà giàu Bush nó sẽ cắt hết tiền già và thuốc men
của tao”. Sau khi Bush thắng, bà cụ ăn không ngon ngủ không yên, hồi hộp chờ
đợi bị cắt tiền già và tiền Medicare.</p><p>Một huyền thoại lớn nữa là chuyện thuế. </p><p>Trên đời này có gì free đâu. Tiền an sinh muốn có
tất phải có người đóng thuế thôi. Giải pháp của Dân Chủ luôn luôn là giải pháp
“đánh thuế nhà giàu”. Chỉ là chuyện vớ vẩn. Trong xã hội Mỹ này, có ba lớp dân:
nghèo thì dĩ nhiên khỏi đóng thuế. Giàu thì trên nguyên tắc phải đóng thuế rất
cao nhưng thực tế chẳng đóng bao nhiêu. Ông cố vấn kinh tế của TT Obama là Chủ
Tịch đại công ty GE. Công ty GE năm vừa qua lời vài tỷ nhưng đóng “zero” thuế.
Các đại gia luôn luôn có cả ngàn cách trốn thuế. Rốt cuộc, thành phần gọi là
trung lưu như kẻ viết này và đa số độc giả Việt Báo là lãnh búa. Kẻ viết này
chẳng cần biết Dân Chủ hay Cộng Hoà là gì, là ai, chỉ không muốn đi làm tối tăm
mặt mũi để đóng thuế đến tắc thở thôi.</p><p>Một huyền thoại không kém thịnh hành: Cộng Hoà lên
là mấy đại gia sẽ sa thải nhân viên hết, tất cả mọi người sẽ thất nghiệp, rồi
tiền thất nghiệp sẽ mất luôn. Ai nghe mà không toát mồ hôi"</p><p>Nhưng chẳng lẽ mấy ông đại gia đuổi hết nhân công để
mấy ông ấy đích thân vào hãng tự mình đi làm nhân công" Và rồi hàng hoá sản
xuất bán ra cho ai" Ai cũng bị mất job mà không có tiền thất nghiệp nữa thì ai
sẽ có tiền mua hàng"</p><p>Cái lý luận sơ đẳng nhất vẫn là cái lý luận theo
thuyết thịnh vượng chung. Ông đại gia muốn giàu có thì phải bán được hàng, mà
hàng chỉ có thể bán được nếu thiên hạ có tiền mua. Đuổi hết nhân công, cắt tiền
thất nghiệp, tiền đâu họ mua, mà họ không mua thì đại gia cũng chỉ đi đến phá
sản thôi. </p><p>Chuyện nhà giàu đuổi nhân công để giàu thêm chỉ là
thứ lý luận nghe cho vui… người Hà Nội xã hội chủ nghĩa, không đáng chú tâm.
Ngay cả chuyện đảng Cộng Hòa là đảng của nhà giàu chủ trương cắt thuế bạc tỷ
cho các đại gia cũng chỉ là những bài bản tuyên truyền che mắt những người
thiếu hiểu biết. Vấn đề ở đây là vấn đề lý luận về kinh tế học.</p><p>Đảng Dân Chủ lý luận theo thuyết khuynh tả
tân-Keynesian mà kẻ viết này đã bàn qua trước đây, chủ trương Nhà Nước là công
cụ phát triển kinh tế, tức là Nhà Nước đánh thuế lấy tiền nhà giàu tài trợ
những dự án lớn lao của Nhà Nước, tạo công ăn việc làm quy mô cho dân chúng, và
bành trướng tối đa guồng máy Nhà Nước. Chỉ cần nhích thêm một bước nữa là ta sẽ
thấy các bác Mác và Lê-nin mỉm cười ngay.</p><p>Đảng Cộng Hòa thiên hữu thì ngược lại, cho rằng kinh
tế chỉ có thể phát triển dựa trên sáng kiến tư nhân chứ không thể trông cậy vào
mấy ông công chức lờ mờ làm kế hoạch trong tình trạng cha chung chẳng ai khóc.
Do đó cần phải giảm thiểu bộ máy công quyền, không đánh thuế cắt cổ, bóp chết
hết kinh doanh, để khuyến khích khu vực tư nhân thuê nhân viên nhiều hơn.</p><p>Lý luận nào đúng, lý luận nào sai" Đó là chuyện suy
nghĩ của mỗi người, và lá phiếu của mỗi người. Không cần phải dùng thậm từ chửi
nhau. Xứ tự do mà. </p><p>Hãy thử nhìn vào Âu Châu, đất dụng võ của các ông
tân Keynesian. Thực tế, Âu Châu bây giờ chỉ là một khối những nước đã hoàn toàn
khánh tận. Từ Hy Lạp đến Bồ Đào Nha, qua Anh, Pháp, Aí Nhĩ Lan, Tây Ban Nha,
Bỉ, … đang vật lộn với những khó khăn kinh tế và chính trị không lối thoát. Chỉ
vì Nhà Nước chi tiêu quá lớn, nợ hơn chúa chổm, công chức lãnh quá nhiều quyền
lợi bổng lộc, làm ít chơi nhiều quen rồi, bây giờ phải thắt lưng buộc bụng là xuống
đường đập nhà đốt xe ngay.</p><p>Hay là nhìn vào ngay kinh tế Mỹ. </p><p>TT Obama lên nắm quyền từ gần ba năm nay, nhưng nạn
thất nghiệp vẫn không suy giảm, lửng lơ khoảng 9%-10% dù đã tung ra cả ngàn tỷ
kích cầu đủ loại, theo đúng thuyết tân Keynesian. TT Obama không giải quyết
được nạn thất nghiệp mặc dù kinh tế đã phục hồi, phần lớn vì các đại gia không
muốn đầu tư phát triển, không muốn thuê nhân viên để gia tăng sản xuất. Họ
không có lý do gì gia tăng sản xuất để rồi bị TT Obama đè xấn lấy thuế như ông
thường hăm dọa. </p><p>TT Carter là tổng thống cuối cùng của Dân Chủ đã áp
dụng thuyết Keynesian. Trong bốn năm cầm quyền từ 1976, TT Carter đã nâng tỷ lệ
thất nghiệp lên mức 9%. Từ sau khi chiến tranh Việt Nam chấm dứt, ba lần mức
thất nghiệp lên cao nhất là dưới thời Carter (8.9%), Clinton (7.7% tháng Chín
năm 1992) và Obama (9.1% tuần qua), đều là Dân Chủ. Có một ông TT Cộng Hoà lãnh
theo với mức thất nghiệp hơn 10% là cụ già Reagan. Ông ta dẹp luôn chương trình
tân Keynesian của Carter và tái đắc cử huy hoàng!</p><p>Thành ra la
hoảng bầu cho Cộng Hòa sẽ bị thất nghiệp chỉ đúng là la hoảng.</p><p>Một vấn đề quan trọng nữa: Việt Nam.</p><p>Những người ủng hộ Dân Chủ trách TT Cộng Hoà Nixon
bán đứng Việt Nam mà quên mất ông bị quốc hội Dân Chủ trói tay lôi ra khỏi Việt
Nam. TT Nixon nổi tiếng là diều hâu qua các vụ đánh Căm Pu Chia, thả bom Hà
Nội, … Nhưng nước Mỹ là nước dân chủ, cho dù diều hâu đến đâu thì ông cũng
không thể phớt lờ các phong trào phản chiến do phe Dân Chủ cấp tiến xách động
từ quốc hội đến các khuôn viên đại học, nơi mà các giáo sư và sinh viên cấp
tiến suốt ngày phất cờ Mặt Trận và ảnh Hồ Chí Minh, Võ Nguyên Giáp bên cạnh Mao
Trạch Đông và Che Guevarra để đòi Nixon rút khỏi Việt Nam ngay. </p><p>Khi ấy nhiều người Việt tỵ nạn vẫn chưa… tỵ nạn nên
không biết! </p><p>Một số người Việt tỵ nạn chỉ trích Bush nhút nhát
không đăng lính qua Việt Nam đánh VC, nhưng không nhắc đến chuyện Clinton can
đảm chạy qua Anh trốn lính. Họ nói Bush có tội vì nói lính VNCH không bằng lính
Iraq, nhưng không nhắc gì đến Kerry đi Việt Nam vài tháng, trở về, thành phản
chiến gộc, vứt hết mề đay, ra trước quốc hội tố cáo lính Mỹ và lính Cộng Hoà
chỉ là thổ phỉ giết dân vô tội, lấy chuyện “tùng xẻo” cắt tai mũi dân, bắn chó
và gia súc làm thú vui, gìống như lính của Thành Cát Tư Hãn. </p><p>Kerry giải thích cho quốc hội Mỹ cuộc chiến VN là
nội chiến, trong đó người dân nổi dậy đòi giải phóng khỏi ách thống trị của
thực dân đế quốc (quý độc giả có hứng thú có thể vào Google, đánh “Kerry and
Congressional Testimony” để đọc bài của Kerry). Kerry cũng là người bỏ phiếu
khai tử VNCH, bác đề nghị của TT Ford xin giải ngân 700 triệu cho quân đội VNCH
tháng 4 năm 1975, và ông cũng là người bỏ phiếu chống việc nhận dân tỵ nạn Việt
vào Mỹ. Cái “tội” của Bush và Kerry, tội nào nặng hơn" </p><p>Điều lạ lùng là có không ít dân tỵ nạn bỏ phiếu cho
Kerry năm 2004. </p><p>Họ cũng chỉ trích Bush cho VNCS vào “World Trade” mà
quên mất TT Dân Chủ Carter là tổng thống đã gửi một phái đoàn qua VN để mở màn
cho việc bình thường hoá quan hệ VC-Mỹ ngay năm 1977 khi cả trăm ngàn “ngụy
quân” vẫn còn sống dở chết dở trong tù cải tạo, và TT Dân Chủ Clinton là người
hủy bỏ cấm vận VNCS do TT Cộng Hòa Ford áp đặt, gửi đại sứ Mỹ đầu tiên đến Việt
Nam, mời VNCS vào Liên Hiệp Quốc, Ngân Hàng Thế Giới và Quỹ Tiền Tệ Quốc Tế. </p><p>***</p><p>Xứ Mỹ này là xứ tự do, với đủ loại tin tức trong tầm
tay của tất cả mọi người. Ai nói gì, viết gì (kể cả kẻ viết này), thì cũng nên
kiểm chứng. Không thể nhắm mắt tin khi nghe hợp ý, mà cũng không thể chửi bậy
khi nghe không hợp ý. Nền dân chủ đòi hỏi một điều rất mệt ở người dân là khả
năng xét đoán và suy xét!(26-6-11)</p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua
email: Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a173568/nhung-huyen-thoai-ve-dang-dan-chu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/