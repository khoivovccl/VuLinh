# TT Obama Và Luật Pháp

05/08/2014


<div style="text-align: center;"><span style="font-weight: bold;">* * *</span></div>
<br/>Trước những kết quả thua liên tục như vậy, người ta có thể đặt câu hỏi sao Nhà Nước Obama, với ông siêu chuyên gia về luật Hiến Pháp, lại có thể thiếu hiểu biết về luật lệ đến như vậy. Đây là câu hỏi chính đáng khó có câu trả lời dứt khoát.<br/><br/>Theo ý kiến cá nhân của kẻ viết này –không phải là luật sư, chưa bao giờ học luật- thì Nhà Nước Obama không thể mù mờ về luật pháp như vậy được. Chẳng qua là một sự cố tình đẩy càng xa chính sách Nhà Nước Vú Em càng tốt, tới đâu hay tới đó, cùng lắm là TCPV bác thôi, rồi thì ta lại thử chiêu khác. Gặm nhấm được chừng nào hay chừng nấy. Dường như con đường xã hội chủ nghiã thật sự là con đường TT Obama muốn đi theo.<br/><br/>Đặt vấn đề như vậy ta mới thấy vai trò của TCPV quan trọng tới mức nào trong việc định hướng cho chính sách trị quốc của Mỹ. TCPV hiện nay có 4 thẩm phán bảo thủ, 4 cấp tiến, và một sàng qua sàng lại. Những vụ thất bại của TT Obama chỉ chứng minh TT Obama đã đi quá xa đến độ ngay cả những thẩm phán cấp tiến, trong đó có hai vị do chính TT Obama bổ nhiệm, cũng không chấp nhận được.<br/><br/>Tin giờ chót, Hạ Viện đã biểu quyết thưa TT Obama ra tòa về tội lạm quyền lấn át Lập Pháp. Đây sẽ là một vụ xử cực kỳ quan trọng, đi xa hơn việc thưa kiện cá nhân TT Obama, vì đây là vấn đề xác định quyền hạn giữa Hành Pháp và Lập Pháp. Điều oái ăm là trong khi các dân biểu CH thưa Hành Pháp để dành lại quyền cho Lập Pháp, thì tất cả các dân biểu DC đã biểu quyết chống lại, tức là họ đã biểu quyết muốn nhường quyền của Lập Pháp cho Hành Pháp, để họ được... ngồi chơi xơi nước, chấp nhận tất cả những gì tổng thống muốn!<br/><br/>Cũng cần ghi nhận chuyện này khác xa đàn hạch –impeach-. Đàn hạch nhắm vào cá nhân tổng thống với mục đích cất chức ông. Vụ thưa này là Lập Pháp thưa Hành Pháp đã lạm quyền. Nếu Hạ Viện thắng, thì TT Obama vẫn làm tổng thống, chỉ có quyền hành bị giới hạn bớt đi. Thật ra, TT Obama chưa phạm tội tầy trời gì để phải bị đàn hạch, chỉ là chuyện lấn quyền và bất tài thôi. Hiến Pháp không có quy định cất chức tổng thống vì bất tài. Nhưng phe DC đã mau mắn khua chiêng trống rầm rộ là TT Obama sắp sửa bị đàn hạch, kêu gọi gây quỹ giúp DC bảo vệ ông, và ngay sau đó, đã thu được một triệu đô trong một ngày. Chính trị mánh mung là vậy, thiên hạ ai dại ráng chịu. Năm 2008, 11 dân biểu DC đưa ra dự luật đàn hạch TT Bush, nhưng không đi đến đâu vì chẳng có thêm phiếu nào. (03-08-14)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a225123/tt-obama-va-luat-phap

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/