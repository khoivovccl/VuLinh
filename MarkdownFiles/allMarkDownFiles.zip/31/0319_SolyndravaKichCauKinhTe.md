# Solyndra và Kích Cầu Kinh Tế

18/10/2011

<p>Solyndra
và Kích Cầu Kinh Tế</p><p>Vũ
Linh</p><p></p><p>...tiền
thuế của dân - yểm trợ tài chánh cho một dự án có nhiều hy vọng thất bại...</p><p></p><p>Sau
khi cuộc khủng hoảng gia cư kéo qua cuộc khủng hoảng kinh tế toàn diện, năm
2009 tân chính quyền của TT Obama đã xin Quốc Hội phê chuẩn gần 800 tỷ tiền
kích cầu kinh tế, có nghĩa là tiền bơm vào hàng loạt chương trình, kế hoạch
kinh tế để kích động sản xuất, tạo công ăn việc làm cho dân, phục hồi kinh tế. </p><p>Với
đảng Dân Chủ khi ấy nắm quyền kiểm soát tuyệt đối tại Nhà Trắng, Thượng Viện,
và Hạ Viện, số tiền trên được mau mắn phê duyệt trước sự đồng loạt phản đối của
đối lập Cộng Hòa. Dự luật được thông qua tháng Hai 2009 mà không có phiếu nào của
CH tại Hạ Viện, và chỉ có ba phiếu CH tại Thượng Viện. Không phải Cộng Hoà
không muốn kích động lại kinh tế, hay không muốn tạo công ăn việc làm cho dân,
mà chỉ vì đảng bảo thủ này không tin kinh tế sẽ được phục hồi với những chương
trình tiêu xài phần lớn bị cho là có tính cách lãng phí lãng xẹc, hay chỉ là tiền
chia chác cho phe cánh.</p><p>Trong
số 800 tỷ đó, có 43 tỷ được dành cho khu vực năng lượng, chủ yếu là giúp các
công ty chuyên về phát huy năng lượng mới như năng lượng mặt trời. Công ty đầu
tiên được chia tiền kích cầu này là công ty Solyndra, với hơn 500 triệu đô cho
vay, từ cái quỹ 43 tỷ dành cho khu vực năng lượng.</p><p>Solyndra
được thành lập năm 2005 tại Fremont, thuộc tiểu bang California. </p><p>Công
ty chuyên sản xuất một loại ống dẫn nhiệt từ mặt trời, biến sức nóng mặt trời
thành năng lượng, tương tự như các tấm phản gọi là solar panels, thu ánh sáng mặt
trời ta thường thấy trên nhiều mái nhà. Đây là một kỹ thuật tân tiến nhất, mới
phát minh ra, và có tính thử nghiệm. Công ty là sở hữu của gia đình ông George
Kaiser, với vốn góp từ tám công ty đầu tư mà Mỹ gọi là Venture Capital
companies.</p><p>Các
công ty đầu tư Venture Capital thuộc loại đầu tư mạo hiểm vì rủi ro rất cao.
Họ bỏ tiền đầu tư vào các công ty mới thành lập trong những ngành tân tiến nhất,
mà không ai có thể tiên đoán được thành bại trong tương lai. Thông thường thì
trong 10 dự án đầu tư, họ thất bại 6-7 lần, và tỷ lệ thành công chỉ là một phần
ba. Nhưng nếu thành công thì lại là thành công rất lớn, với tỷ lệ hoàn vốn và lợi
nhuận gấp cả trăm hay có khi cả ngàn lần vốn đầu tư. </p><p>Hầu
hết các công ty trong các ngành tiên tiến điện toán, mạng internet, đều được
khai sinh bằng vốn mạo hiểm của các công ty Venture Capital này. Điển hình là
Microsoft, Apple, Googles, Ebay, Yahoo, </p><p>Chuyện
đầu tư có tính phiêu lưu mạo hiểm này chỉ có thể được thực hiện bởi những nhà đầu
tư rất giàu, dư thừa tiền để chấp nhận mức rủi ro cực cao. Hiển nhiên, đây
không thể là loại đầu tư mà Nhà Nước nên tham gia. Ta thấy chẳng hạn như tiền
già - social security - của chúng ta luôn luôn được đầu tư vào công khố phiếu của
nước Mỹ, hết sức an toàn mặc dù với lãi suất cực thấp trên dưới 1%. Đầu tư vào
các dự án với xác suất hai mất một được thì không thể là việc có thể làm với tiền
thuế của dân đóng.</p><p>Trong
suốt mấy năm từ trước khi thành lập đến sau khi thành lập Công ty Solyndra đã cố
xin vay tiền của Nhà Nước vì nhu cầu chi phí đầu tư rất cao, ngoài khoản vốn
650 triệu đã gom được, nhưng đều bị chính quyền Bush từ chối. Lần cuối cùng,
tháng Giêng năm 2009, hai tuần trước khi tổng thống tân cử Obama nhậm chức, Bộ
Năng Lượng - Department of Energy - của TT Bush đã bác bỏ đơn xin vay tiền của
Solyndra. Lý do là mức rủi ro quá cao. </p><p>Các
công ty thẩm định tín dụng Fitch và Dun & Bradstreet khi đó đánh giá dự án
Solyndra thuộc loại B, tức là loại không nên đầu tư vào (highly speculative,
non-investment grade rating).</p><p>Nhưng
ngay sau khi tân bộ trưởng Năng Lượng Steven Chu được TT Obama bổ nhiệm, một
trong những quyết định đầu tiên của ông là phê duyệt ngay 535 triệu đô la bảo đảm
cho Solyndra vay, tháng Ba năm 2009. Đúng ra, đây không phải là tiền vay trực
tiếp từ Nhà Nước, mà là tiền Solyndra vay từ các ngân hàng hay những nhà đầu tư,
nhưng được Nhà Nước bảo đảm, tức là nếu vì lý do nào đó Solyndra không trả nợ được
thì Nhà Nước sẽ trả thay cho, bằng tiền thuế của dân đóng. </p><p>Quyết
định trên được công bố một cách rất hoành tráng trong cuộc viếng thăm Solyndra
cùa TT Obama.</p><p>Tháng
Chín năm đó, một nghiên cứu của chính Bộ Năng Lượng tiên đoán công ty Solyndra
sẽcạn tiền vào tháng Chín năm 2011, tức là hai năm sau. Cũng trong tháng Chín
đó, và bất kể những báo động về nguy cơ hụt tiền và phá sản của công ty,
Solyndra khánh thành một nhà máy mới, xây bằng tiền TT Obama cho vay.</p><p>Tháng
Hai vừa qua, Solyndra bắt đầu gặp khó khăn, cần thêm tiền. Công ty điều đình với
một số nhà đầu tư để được vay thêm 75 triệu, với điều kiện như trước, là bộ Năng
Lượng bảo đảm tiền vay, và thêm một điều kiện đặc biệt là nếu gặp rắc rối, phải
khai phá sản, thì tài sản của công ty sau khi được thanh lý, sẽ ưu tiên trả các
khoản nợ của các nhà đầu tư trước, phần còn lại - nếu còn - sẽ được hoàn trả Nhà
Nước sau. </p><p>Cuối
tháng Chín vừa qua, đúng như các chuyên gia Bộ Năng Lượng đã tiên đoán hai năm
trước, Solyndra xập tiệm, khai phá sản, đóng cửa tiệm, sa thải hơn 1.100 nhân
công. Tài sản còn lại chẳng bao nhiêu, có bán hết cũng chưa đủ hoàn vốn cho các
nhà đầu tư. Theo như thỏa thuận về điều kiện thanh lý vừa nêu trên, Nhà Nước sẽ
được thanh toán chót, tức là sẽ không còn gì nữa. Có nghiã là Nhà Nước mất toi
hơn nửa tỷ tài trợ cho Solyndra, tức là hơn nửa tỷ tiền thuế dân đóng tan thành
mây khói.</p><p>Vấn
đề đặt ra là tại sao TT Obama lại hồ hởi tài trợ cho Solyndra như vậy" </p><p>Tại
sao Nhà Nước lại đóng vai trò công ty đầu tư mạo hiểm Venture Capital, bỏ tiền đầu
tư vào một dự án đã được các công ty thẩm định tín dụng đánh giá là không nên đầu
tư vào"</p><p>Những
người có cảm tình với TT Obama sẽ bênh vực quyết định này vì đây là hành động
có mục đích rõ ràng phù hợp với chính sách của tân chính quyền Obama: đó là
khuyến khích việc truy tìm các nguồn năng lượng mới, đặc biệt là nguồn năng lượng
miễn phí từ mặt trời. Để cởi trói nước Mỹ khỏi dầu hỏa ngoại nhập càng ngày
càng mắc mỏ. Và dĩ nhiên là đầu tư này, như tất cả các đầu tư khác, cũng là
chuyện hên xui may rủi. Chuyện chẳng may là như TT Obama đã từng than phiền,
ông gặp nhiều rủi hơn may nên dự án thất bại. Chuyện đầu tư là chuyện có ăn có
thua, đành chịu thôi.</p><p>Những
người ít cảm tình với TT Obama thì nêu lên hàng loạt vấn đề khúc mắc hơn nhiều.</p><p>Trước
hết là quyết định đầu tư đầy phiêu lưu này. Nhà Nước không phải như những nhà đầu
tư mạo hiểm, mang tiền của mình ra đầu tư, có ăn thì ăn rất lớn, có thua thì
thua tiền của mình. Ở đây, chính quyền Obama lấy tiền của dân đóng thuế ra đểđánh
canh bạc Solyndra. Được thì Solyndra và các nhà đầu tư, các ngân hàng, lời to
trong khi Nhà Nước chẳng được gì nhiều mà chỉ lấy lại được tiền vay gốc và tiền
lãi với lãi suất bèo của Nhà Nước. Thua thì mất hơn nửa tỷ của dân. Đã vậy,
khi Solyndra có nguy cơ sập tiệm đúng như các chuyên gia đã tiên đoán, thì Nhà
Nước lại cố bơm thêm mấy chục triệu nữa.</p><p>Trước
đây, TT Bush đề nghị lấy một phần ba tiền đóng góp vào quỹ An Sinh Social
Security để đầu tư vào thị trường chứng khoán với hy vọng có tiền lời cao hơn để
cứu vãn quỹ An Sinh này, nhưng bị phe Dân Chủ chống đối kịch liệt vì cho rằng
quá phiêu lưu, không thể lấy tiền thuế của dân ra đánh bạc với thị trường chứng
khoán. Bây giờ thì chính phe Dân Chủ đó đã mang tiền thuế này đi cá độ với
Solyndra. Và mất hết.</p><p>Chính
quyền Obama đã biện minh quyết định của mình bằng phương cách rất tiêu biểu của
TT Obama: đổ thừa là Solyndra thất bại vì bịTrung Cộng cạnh tranh bất chính bằng
cách tung ra hàng loạt sản phẩm biến nhiệt từ mặt trời với giá rẻ mạt. Nói rõ
ra, trên quan điểm thẩm định dự án, không có ai đã nghĩ đến vấn đề cạnh tranh
có thể có được từ một nguồn gốc nào đó, tức là chẳng ai nghiên cứu thị trường
trước khi quyết định đầu tư cả nửa tỷ bạc. Nếu không phải là đổ thừa vớ vẩn thì
cũng là chuyện tắc trách hay bất tài.</p><p>Điều
chỉ trích thứ hai là sự hấp tấp trong quyết định cho vay của bộ trưởng Steven
Chu. Trong khi chính quyền Bush bác đơn xin vay thì ông Chu đã mau mắn quyết định
ngay tháng đầu tiên vừa mới nhậm chức, trong lúc có triệu chuyện phải học và
làm khi mới nhậm chức. Thời giờ đâu ông Chu nghiên cứu một dự án hơn nửa tỷ đô"
Ở đây người ta đã nêu ra một email của Tòa Bạch Ốc nhắc khéo ông Chu phải quyết
định sớm. Sau khi email được khui ra thì các dân cử Cộng Hòa trong quốc hội cho
rằng đây là bằng chứng chính quyềnObama
trực tiếp áp lực bộ trưởng Chu phải phê duyệt ngay món nợ này. Nhà Trắng thì giải
thích đây chỉ là nêu câu hỏi chừng nào món nợ này được phê duyệt để có thể hoạch
định chương trình cho TT Obama đi công du tiểu bang Cali, nhân tiện ghé thăm
Solyndra và công bố món nợ luôn.</p><p>Vấn
đề thứ ba là điều khoản cho phép thanh lý, bán đổ bán tháo tài sản để trả cho
các nhà đầu tư trước khi hoàn trả nợ cho Nhà Nước trong trường hợp Solyndra
khai phá sản. Các nhà lập pháp Cộng Hòa cho rằng điều này vi phạm trắng trợn luật
tài trợ của Nhà Nước. Điều này phải đợi một tòa án nào đó quyết định.</p><p>Vấn
đề thứ tư đáng nói, mà cũng là câu trả lời cho tất cả những khúc mắc vừa nêu
ra: tại sao lại cho Solyndra vay" Dĩ nhiên là có vấn đề hỗ trợ một công ty truy
tìm nguồn năng lượng mới đúng như chính quyền Obama giải thích. Nhưng sau lưng
là một chuyện thực tế hơn nhiều: ông chủ dự án, George Kaiser là một trong những
mạnh thường quân, yểm trợ tài chánh mạnh nhất cho công cuộc vận động tranh cử tổng
thống của Thượng Nghị Sĩ Barack Obama. Nhà tỷ phú Kaiser được xếp hạng vào loại
bundler trong danh sách các mạnh thường quân. Bundler là một danh hiệu
trong chương trình vận động gây qũy của ứng viên Obama, dành cho những người
gây quỹ được hơn 500.000 đô cho ứng viên Obama.</p><p>Điều
đáng nói là vấn đề quan hệ cửa sau này đi xa hơn ông Kaiser nữa. </p><p>Phụ
tá của bộ trưởng Steven Chu, đặc trách quản lý các chương trình bảo đảm vay mượn
của bộ Năng Lượng là ông Steve Spinner. Trước đó, ông Spinner là thành viên Ủy
Ban Chuyển Tiếp của chính quyền Obama, tức là ủy ban lo tiếp nhận các cơ quan
chính quyền từ TT Bush qua TT tân cử Obama, đồng thời đề cử và bổ nhiệm các
quan chức chính quyền mới. Ông Spinner nhận được những trách nhiệm béo bở trên
vì cũng là một bundlerđã gây quỹ hơn
500.000 đô cho ứng viên Obama. Ông Spinner là người đã đẩy mạnh đơn vay tiền của
Solyndra cho bộ trưởng Chu phê duyệt. Bà vợ của ông Spinner cũng chính là luật
sư của công ty Solyndra. Đây là một trường hợp mâu thuẫn quyền lợi - conflict
of interests - lộ liễu nhất: một viên chức cao cấp dùng quyền hành của vị trí của
mình để áp lực bộ Năng Lượng tài trợ cho một công ty mà bà vợ mình là luật sư đại
diện.</p><p>Ngay khi có tin quốc hội mở cuộc điều tra về những
chuyện mờ ám trong vụ Solyndra thì ông Spinner đã mau mắn từ chức phụ tá cho bộ
trưởng Chu, cùng với Giám Đốc Chương Trình Cho Vay của Bộ Năng Lượng Jonathan
Silver.</p><p>Nhưng
xì-căng-đan Solyndra nổ bùng ra vì vấn đề có thể còn đi xa hơn các ông Kaiser và
Spinner nữa. Trong những emails được công bố mới đây, có một cái ông Spinner hối
thúc ông Chu lấy quyết định, nhấn mạnh ông đang bị văn phòng Phó TT Biden và cả
văn phòng TT Obama áp lực mạnh về vụ cho Solyndra vay mượn (I have the [office
of the vice president] and [White House] breathing down my neck on this). </p><p>Tức
là cả tổng thống lẫn phó tổng thống đều đã can thiệp bắt bộ Năng Lượng dùng tiền
kích động kinh tế - tức là tiền thuế của dân - yểm trợ tài chánh cho một dự án
có nhiều hy vọng thất bại, để trả công cho hai mạnh thường quân đã đóng góp vào
công cuộc vận động tranh cử của tổng thống và phó tổng thống.</p><p>Trước
áp lực mạnh của phe Cộng Hòa trong quốc hội, hồ sơ Solyndra đang được FBI và bộ
Tài Chánh điều tra, trong khi các người lãnh đạo công ty Solydra bị lôi ra trước
quốc hội điều trần, nhưng đều viện dẫn Tu Chính 5 của Hiến Pháp (Constitution
Fifth Amendment theo đó những người bị điều trần trước quốc hội có thể từ chối
trả lời những câu hỏi họ nghĩ có hại cho họ trước pháp luật)</p><p>Câu
chuyện Solyndra chưa ngã ngũ thì báo chí lại mới khui ra thêm ba công ty trong
cùng ngành, khai thác năng lượng mặt trời, đang bị chú ý vì đã nhận được bạc tỷ
tiền cho vay từ chính quyền Obama. Trong đó có công ty Sun Power đã nhận được
1,2 tỷ để xây một cơ sở sẩn xuất tên là California Valley Solar Ranch, với đúng
15 nhân viên. Dùng 1.200 triệu đô trong chương trình kích cầu để tạo việc làm
cho 15 người, vị chi là khoảng 80 triệu đô cho mỗi người. Trong sáu tháng đầu năm
nay, Sun Power đã lỗ mất hơn 150 triệu đô. Chuyên viên vận động - lobbyist - của
công ty Sun Power là con của dân biểu Dân Chủ George Miller của California. </p><p>Đó
là những cách TT Obama sử dụng tiền kích cầu kinh tế để tạo công ăn việc làm"
(16-10-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a178445/solyndra-va-kich-cau-kinh-te

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/