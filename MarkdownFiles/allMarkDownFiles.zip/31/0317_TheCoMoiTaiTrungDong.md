# Thế Cờ Mới Tại Trung Đông

01/11/2011

<p>Thế
Cờ Mới Tại Trung Đông</p><p>Vũ
Linh</p><p></p><p>...Trung
Đông, mỏ dầu thế giới, sẽ thành một vùng xôi đậu bất an và nguy hiểm nhất... </p><p></p><p>Chuyện
phải đến đã đến, nhà độc tài Kaddhafi cuối cùng đã bị giết chết. Chính quyền
Obama làm rùm beng, báo chí phe ta hồ hởi đăng tin, ăn mừng chiến thắng, ca tụng
thành tích loại được một nhà độc tài, mang dân chủ tự do cho dân Libya trong
vòng nửa năm mà không mất một lính Mỹ nào, tốn có khoảng trên một tỷ, bạc cắc đối
với chính quyền Obama.</p><p>Một
ngày sau, TT Obama bất ngờ loan báo tất cả lính Mỹ sẽ rút khỏi Iraq trước cuối
năm nay. Dĩ nhiên, lại là một dịp để truyền thông ca tụng tài bình thiên hạ của
tổng thống. Cũng là dịp để TT Obama nhắc nhở mọi người ông đã giữ lời hứa chấm
dứt một cuộc chiến mà Obama cho là không chính đáng, đáng lẽ không nên xẩy ra
ngay từ đầu.</p><p>Sau
một mùa hè mưa lũ với toàn những tin nhức răng đau đầu, tháng Mười đã mang lại
những tin tốt đẹp hơn, khiến triển vọng tái đắc cử năm tới của TT Obama trở nên
sáng sủa hơn nhiều.</p><p>Tháng
Mười mở màn với tin địch thủ nặng ký Rick Perry rớt đài nhanh hơn sung rụng
trong cuộc chạy đua tranh cử tổng thống của phe Cộng Hòa, trong khi ông ứng
viên yếu nhất, Herman Cain lại đang lên như diều. Rồi đến sự bùng nổ của phong
trào Chiếm Phố Wall Street (OWS), nổi lên đánh nhà giàu được hiểu như là đồng
minh của Cộng Hòa. Rồi bây giờ thì đến tin Kaddhafi chết. Đúng là quà Giánh
Sinh của TT Obama năm nay đã đến thật sớm. Gió bắt đầu đổi chiều sao" </p><p>Chưa
hẳn như vậy.</p><p>Trước
hết ta thử nhìn vào chuyện Libya.</p><p>Hiển
nhiên, cái chết của Kaddhafi đánh đấu một khúc quanh vĩ đại trong cuộc chiến tại
kho dầu lửa và dầu khí Libya. Phe nổi loạn mà truyền thông gọi là Chiến Sĩ của
Tự Do -Freedom Fighters- đã hạ được nhà độc tài thô bạo và chiếm được quyền kiểm
soát chính quyền cả nước. Nhưng câu chuyện chỉ mới bắt đầu. Bây giờ là lúc cả
thế giới nhìn vào nhóm nổi loạn - cũng có thể gọi là quân cách mạng, tùy theo
cái nhìn của mỗi người- để xem họ trị quốc như thế nào.</p><p>Trước
hết là Kaddhafi đã chết, nhưng cả chục bộ lạc phe của ông ta vẫn còn đó. </p><p>Cả
vùng sa mạc miền nam, và ven biển phía Tây, từ thủ đô Tripoli cho đến biên giới
Tunisia/Algeria vẫn là căn cứ địa của các bộ tộc phe Kaddhafi. Libya sẽ trở
thành một Iraq thứ hai với các bộ tộc tiếp tục trường kỳ kháng chiến, hay sẽ được
ổn định mau chóng" Và ngay trong nội bộ phe nổi dậy, cho đến giờ vẫn chưa ai
nhìn thấy ai là lãnh đạo thật sự và đường hướng chính sách sẽ như thế nào. Đoàn
kết tới mức nào" Chính quyền mới sẽ có chính sách như thế nào với Mỹ và Tây Phương
là những thế lực đã giúp phe nổi dậy thành công. Các lực lượng Hồi giáo cực đoan
và Al Qaeda trong phe nổi dậy sẽ có vai trò gì và ảnh hưởng như thế nào" Đây là
những câu hỏi lớn mà không ai có câu trả lời trong ngắn hạn. </p><p>Ít
ra phải vài tháng nữa mới nhìn rõ bức tranh. Chưa kể kho vũ khí khổng lồ, trong
đó có kho vũ khí hoá học của Kaddhafi và hai chục ngàn hỏa tiễn tầm nhiệt bắn
máy bay đã bị thất lạc, sẽ được xử trí ra sao.</p><p>Một
thắc mắc lớn là Kaddhafi chết như thế nào. Tin tức đầu tiên được công bố là
Kaddhafi bị chết trong lúc giao tranh. Thực tế, ta thấy hình Kaddhafi bị bắt sống
lôi đi và bị đánh đập dã man (kể cả bị thọc gậy lớn vào hậu môn như người ta đã
thấy qua video của Global Post), nhưng không có vẻ gì là bị thương nặng cả, đầu
tóc rối bù nhưng không có vết thương trên đầu. Một loạt hình thứ hai cho thấy
xác Kaddhafi nằm dưới đất với máu me tràn ra từ đầu. Bác sĩ khám nghiệm tử thi
Kaddhafi đã xác nhận ông ta bị chết vì đạn bắn vào đầu. Rõ ràng là bị giết sau
khi bị bắt sống. Chính quyền mới của Libya đã cho biết sẽ mở cuộc điều tra sau
khi bị nhiều tổ chức nhân quyền hạch hỏi.</p><p>Bị
hành hạ và chết kiểu này sẽ khiến các chiến sĩ của tự do và cả Âu Châu và Mỹ
mang tiếng và người ta sẽ nghi ngờ về tính dân chủ hay bảo vệ nhân quyền
trong chính quyền tương lai của Libya. Nhưng dù sao, cái chết của Kaddhafi cũng
có thể thông cảm được. Sau hơn bốn chục năm chuốc oán, ông có bị quân nổi dậy đánh
đập và hạ nhục rồi hạ sát thì cũng chẳng có gì đáng ngạc nhiên. Mấy ông nhân
quyền than vãn cách mấy cũng không lấp được tiếng hò hét vui mừng của dân
Libya. Chỉ không biết là dân Libya có mừng quá sớm không thôi. </p><p>Cách
đây hơn 40 năm họ cũng đã xuống đường ăn mừng người hùng Kaddhafi đảo chánh lật
đổ chế độ phong kiến thối nát rồi.</p><p>Một
câu chuyện bên lề được nhiều báo Âu Châu nêu lên. Trong cuộc chiến tại Libya,
ngay từ đầu, Pháp, Anh, và Ý đã là những nước chủ trương đánh Kaddhafi, ép TT
Obama phải tham chiến một cách miễn cưỡng để bảo đảm các nước này tiếp tục ủng
hộ Mỹ tại Afghanistan. Sau đó, TT Obama đưa ra kế sách độc đáo lãnh đạo từ
phía sau, đẩy NATO ra trước chịu sào. Nhưng khi Kaddhafi bị giết, các lãnh tụ
Âu Châu chưa kịp lên tiếng thì TT Obama đã là người đầu tiên chường mặt ra trước,
không còn đứng sau lưng nữa, để họp báo khoe công. Thời buổi tranh cử khó khăn,
thành tích hiếm hoi, có dịp là phải khai thác cho nhanh. Đây gọi là đổ thừa giỏi
mà tranh công cũng tài. </p><p>Dù
vậy, việc tranh công này có vẻ hơi quá sớm. Ổn định và dân chủ hoá là điều
chính quyền Obama quảng bá. Nếu như việc giết Kaddhafi là chỉ dấu về cách hành
xử của những người lãnh đạo mới của Libya thì thế giới có nhiều lý do lo ngại hơn
là hy vọng. </p><p>Hơn
thế nữa, tân chính quyền Libya loan báo Libya sẽ là quốc gia được cai trị theo
luật Sharia là luật Hồi giáo nổi tiếng khắt khe, coi phụ nữ như công dân hạng
ba, sử dụng hình phạt lạc hậu như ném đá đến chết hay chặt tay chặt chân tội phạm.
Điều đáng nói là một trong những quyết định đầu tiên của quân cách mạng là cho
phép các ông có ngay bốn bà vợ theo đúng luật Hồi Giáo. Điều chắc chắn nữa là thể
chế chính trị dân chủ không có trong kinh Koran. Đây có phải là thành tích đáng
tranh công của chính quyền Obama không"</p><p>Các
cơ quan truyền thông dòng chính đã mau mắn ca tụng thành tích đối ngoại của TT
Obama: giết được Bin Laden, Kaddhafi, và rút quân khỏi Iraq trước cuối năm nay.
Có thật là thành tích không"</p><p>Cái
chết của Bin Laden là thành tích của lực lượng đặc nhiệm đã truy lùng hắn ta từ
thời Bush. Thành tích của TT Obama làcơ may làm tổng thống đúng khi nhóm đặc
nhiệm đó bắt được cuộc nói chuyện điện thoại của tên cận vệ Bin Laden rồi từ đó
truy ra tung tích của hắn. Sau khi Bin Laden chết, tỷ lệ hậu thuẫn của TT Obama
vọt lên 9 điểm, nhưng chỉ hai tuần sau là đâu vào lại đấy, rớt mất 8 điểm, vì
dân Mỹ sau những cảm xúc đầu tiên, đã nhìn rõ vấn đề. Chẳng những không phải
hoàn toàn là công của Obama, mà hơn thế nữa, cái chết của Bin Laden một cách cụ
thể đã chẳng thay đổi được gì trong cuộc chiến chống khủng bố. Dân Mỹ vẫn phải
cởi giầy, cởi nịt quần, cho nhân viên an ninh rờ mò khắp người mỗi khi qua phi
trường. Có gì khác"</p><p>Trong
khi đó, cuộc chiến tại Libya và cái chết của Kaddhafi, như vừa nhận định, thực
sự là kết quả của chính sách can dự bằng vũ lực do TT Pháp Sarkozy chủ động từ đầu
đến cuối. Ngay cả ngày cuối của Kaddhafi cũng vậy. Ông bị bao vây trong tỉnh
Sirte và nhẩy lên xe tìm cách chạy ra khỏi tỉnh, nhưng bị máy bay Pháp bắn theo
gắt gao, buộc ông ta phải quay trở lại trốn vào ống cống và bị quân nổi dậy bắt
sống. Lính Mỹ không dính dáng gì từ đầu đến cuối. Cái chết của Kaddhafi cũng sẽ
tăng tỷ lệ hậu thuẫn TT Obama trong ngắn hạn, nhưng về lâu dài rồi cũng sẽ đi
vào lãng quên. Ưu tiên của dân Mỹ vẫn là kinh tế và công ăn việc làm.</p><p>Việc
rút quân tại Iraq thì phức tạp hơn.</p><p>Đây
là yêu cầu chính của khối cấp tiến và cũng là một trong những lý do đưa Obama
vào Nhà Trắng. Việc chấm dứt can dự vào Iraq sẽ tạo hậu thuẫn mạnh và lâu dài
cho TT Obama. Nhưng cũng có thể sẽ gây ra vấn đề lớn sau này.</p><p>Nhà
báo cấp tiến Fareed Zakaria, chủ bút tuần báo Time, đã nhận định rút quân thực
sự là một thất vọng (disappointment) vì chỉ là hậu quả của việc thất bại
trong điều đình với chính quyền Iraq.</p><p>Theo
kế hoạch của TT Obama, Mỹ sẽ lưu giữ lại Iraq một lực lượng quân sự trên nguyên
tắc để duy trì ổn định, nhưng trên thực tế để ngăn cản sự bành trướng ảnh hưởng
của Iran. Con số ngày một teo dần. Lúc đầu thì nói 35.000 người, rồi hạ dần,
xuống đến 3.000. Theo đúng truyền thống trịch thượng của Mỹ (mà dân Việt ta đã
biết quá rõ), Mỹ muốn toàn quyền sử dụng lực lượng này, độc lập với chính quyền
Iraq, đồng thời cũng đòi hỏi quân nhân Mỹ được hưởng quyền miễn tố trước toà án
dân sự và quân sự Iraq vì bất cứ tội gì. Cuộc điều đình bế tắc và TT Obama quyết
định rút hết quân Mỹ về. Qua đầu năm tới thì chỉ còn vài trăm quân nhân bảo vệ
tòa đại sứ thôi. </p><p>Trên
nguyên tắc thì chính quyền Iraq có lý do chính đáng muốn xác định chủ quyền của
mình trên đất nước của mình. Trên thực tế, vấn đề đi xa hơn vậy rất nhiều. </p><p>Trước
hết, cả ngàn công dân Mỹ tại Iraq, phần lớn đang làm việc qua cả trăm chương
trình, dự án tái thiết Iraq, sẽ bị bỏ lại mà không còn được quân đội Mỹ bảo vệ
nữa. Họ sẽ dễ dàng trở thành mục tiêu của các vụ khủng bố, bắt cóc, ném bom,Cho đến giờ, chưa thấy chính quyền Obama nói đến biện pháp gì để bảo vệ họ. Nhưng
đây cũng vẫn chỉ là chuyện tương đối nhỏ, giống như chuyện miễn tố quân nhân Mỹ
phạm tội. </p><p>Chuyện
mẫu chốt là chính quyền Iraq bị áp lực mạnh của Iran muốn bằng mọi giá đẩy Mỹ
hoàn toàn ra khỏi Iraq để áp đặt ảnh hưởng của mình. Cả tổng thống, thủ tướng,
và tư lệnh quân đội của Iraq đều là những người có cảm tình với Iran vì trước đây,
dưới thời Saddam Hussein, họ đều tỵ nạn chính trị tại Iran. Ngoài ra, dân quân
thuộc giáo phái Shiite của Muqtada al Sadr do Iran nuôi dưỡng vẫn là lực lượng
quân sự mạnh nhất sau quân đội chính quy Iraq. Người ta cũng không quên Hồi
giáo Shiite là tôn giáo đa số của cả Iran lẫn Iraq.</p><p>Việc
Mỹ rút khỏi Iraq sẽ đảo lộn thế cờ Trung Đông, tạo cơ hội cho Iran bành trướng ảnh
hưởng. Mỹ và Âu Châu sẽ đối đầu với một liên minh Iran-Iraq thật lớn, cực đoan,
và không thân thiện gì lắm. </p><p>Hơn
nữa, Iran sẽ rảnh tay về phiá Tây, trực tiếp bắt tay với Syria, Lebanon, và các
tổ chức cực đoan có tính khủng bố của Palestine, Hamas và Hezbollah, đồng thời
tập trung nỗ lực vào phiá Đông, tức là Afghanistan. Với chính sách địch tiến
ta lùi của TT Obama, có nhiều hy vọng con cờ thí tới sẽ là Afghanistan và Iran
sẽ đông tiến thêm một bước và áp lực trực tiếp lên Pakistan bị kẹp vào nách của
Ấn Độ. Trong khi đó thì quan hệ giữa Mỹ và Pakistan không tốt đẹp gì cho lắm. Vụ
giết Bin Laden trên lãnh thổ Pakistan đã gây căng thẳng với chính quyền
Pakistan và oán ghét trong quần chúng. Rồi quan hệ với ngay Afghanistan cũng xuống
cấp mạnh. TT Karzai gần đây công khai tuyên bố nếu có tranh chấp quân sự giữa Mỹ
và Pakistan, Afghanistan sẽ đứng ngay về phe Pakistan. Người ta có thể dễ dàng
mường tượng ảnh hưởng của khối Hồi giáo chống Mỹ chạy dài từ Ấn Độ đến tận bờ
biển Địa Trung Hải, trực tiếp đe dọa Do Thái, Ả Rập Saudi và các vương quốc
vùng Vịnh phiá nam, và phiá bắc đe dọa Thổ Nhĩ Kỳ.</p><p>Quyết
định rút quân khỏi Iraq sẽ có thể có những hậu quả về lâu về dài hết sức bất lợi
cho Mỹ. Trước đây Saddam Hussein đã là kỳ đà cản mũi các giáo chủ Iran. Sau đó đến
phiên Bush cản trở tham vọng bá quyền của các giáo chủ. Bây giờ thì với việc
rút quân Mỹ khỏi Iraq và Afghanistan, con đường bành trướng đãthêng thang mở rộng cho Iran. Trung Đông, mỏ
dầu của thế giới, sẽ thành một vùng xôi đậu bất an và nguy hiểm nhất thế giới,
với Iran có khả năng có vũ khí nguyên tử mà TT Obama đã hoàn toàn bất lực không
cách nào ngăn cản được. Dĩ nhiên chưa kể Pakistan và Do Thái cũng đã có vũ khí
nguyên tử rồi.</p><p>Không
phải là chính quyền Obama không nhìn thấy mối nguy Iran. Bà ngoại trưởng Clinton
đã lên tiếng cảnh cáo Iran không nên lợi dụng nước đục thả câu. Làm như thể mấy
giáo chủ quá khích Iran nghe vậy là bèn ngoan ngoãn ngồi im như học sinh tiểu học
ngay.</p><p>Nôm
na ra, người ta có cảm tưởng như Mỹ đã nhổ cái gai Saddam rồi dâng cả Trung Đông
lên mâm cho các giáo chủ Iran. Nhà báo phe ta Zakaria miễn cưỡng phải khều chân
TT Obama rất nhẹ nhàng với danh từ thất vọng. Nếu như là Bush thay vì Obama,
thì người ta có thể tưởng tượng Zakaria sẽ không nương tay như vậy.</p><p>Tóm
lại, thành tích ngoại giao mà truyền thông phe ta đang quảng bá là gì" </p><p>Việc
tháo chạy khỏi Iraq, kèm với những thắng lợi gần đây của các nhóm Hồi giáo cực đoan
tại bắc Phi như Ai Cập, Libya, Tunisia qua mùa Xuân Ả Rập vừa qua, sẽ đưa đến
kết luận là rất có thể TT Obama đã chủ trì - nếu không muốn nói là giúp đỡ - một
sự bành trướng vĩ đại nhất và nguy hiểm nhất của Hồi giáo cực đoan từ mấy trăm
năm qua.</p><p>Nếu
đó là thành tích duy nhất hay lớn nhất của ba năm chính quyền Obama thì ta có
lý do để lo ngại nhiều hơn vui mừng. (10-30-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a179158/the-co-moi-tai-trung-dong

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/