# Cộng Hòa hay Dân Chủ: Lựa Chọn Nào?

13/12/2011

<p>Cộng
Hòa hay Dân Chủ: Lựa Chọn Nào?</p><p>Vũ
Linh</p><p></p><p>...thuế
nặng là người ta sẽ bớt đầu tư, tuyển người, và kinh tế vẫn khó khá...</p><p>Còn
chưa tới một năm nữa là người dân Mỹ sẽ có dịp thực thi quyền làm chủ đất nước
này, tức là quyền đi bầu những người lãnh đạo guồng máy chính trị, từ cấp làng
xã cho đến quốc hội tiểu bang, thống đốc, rồi đến quốc hội liên bang và tổng thống.
Trong số công dân Mỹ, dù muốn hay không, dù vui hay buồn, cũng có chúng ta, những
người Việt tỵ nạn đã gia nhập cộng đồng Mỹ. </p><p>Một
số người trong chúng ta cho rằng chuyện làm dân Mỹ chỉ là hành chánh, một mảnh
giấy ghi nhận ta là công dân Mỹ thôi, chẳng có gì ghê gớm, đáng quan tâm, vì
thâm tâm mỗi người vẫn nghĩ mình là người Việt thuần túy, từ cái mũi tẹt đến những
ngón chân giao chỉ, từ món nước mắm nặng mùi đến cái áo dài lả lướt.</p><p>Không
sai. Nhưng đi xa hơn mảnh thông hành xác nhận công dân Mỹ là những hậu quả thực
tế, là quyền lợi và nghĩa vụ của một công dân. Những quyền lợi và nghĩa vụ của
dân Mỹ cũng là những quyền lợi và nghiã vụ của một người Mỹ gốc Việt. Chúng
ta không thể nói đó là chuyện của họ được. Các cộng đồng khác cũng nghĩ như vậy
và có khi tích cực sử dụng quyền công dân của họ mà mình không biết.</p><p>Đến
vấn đề lựa chọn người lãnh đạo của dân Mỹ cũng là lựa chọn người sẽ có những
quyết định liên quan trực tiếp đến đời sống của chúng ta, đến tương lai của
chúng ta và con cháu chúng ta.</p><p>Thể
chế chính trị Mỹ hiện nay là một thể chế hai đảng chính trị khác biệt. Chúng ta
phải lựa một bên. Ở đây có hai vấn đề cần nhìn rõ: cá nhân và đảng.</p><p>Nói
về cá nhân thì cả hai đảng cũngnhư nhau thôi, đảng nào cũng có người tốt, người
xấu. Nếu Cộng Hòa ưa nói chuyện đạo đức thì cũng có mấy trự mắc tội lăng nhăng
tình dục ngoài vòng lễ giáo chẳng thua gì phe kia. Ngược lại, luôn luôn nói đến
chuyện thương dân nghèo và đề cao lòng trong sạch, nhiều người bên Dân Chủ cũng
lấm lem tiền bạc hoặc mua quan bán tước đến độ ngồi tù. Cũng thế, nếu Cộng Hòa
không thiếu người nói phét, thì Dân Chủ cũng thừa người nói láo.</p><p>Truyền
thông dòng chính không bao giờ bỏ cơ hội mô tả chính khách Cộng Hoà toàn là tài
phiệt da trắng bóc lột thiên hạ, đối chọi với chính khách Dân Chủ toàn là hiện
thân của nhân ái và độ lượng. Họ mạt sát gốc gác tài phiệt dầu hỏa của gia đình
Bush, Cheney, nhưng ca tụng sự giàu sang quý phái của gia đình Kennedy và gia
tài kếch xù của John Kerry hay Nancy Pelosi. </p><p>Washington
Post đăng tin cựu chủ tịch Hạ Viện Cộng Hòa Gingrich ăn tiền 30.000 đô một
tháng nhờ làm tư vấn cho Freddie Mac, mà không viết gì về chuyện cựu TT
Clinton lãnh 50.000 đô một tháng làm tư vấn cho công ty đầu tư MF Global của
cựu thượng nghị sĩ và thống đốc New Jersey Jon Corzine. Công ty MF Global này vừa
khai phá sản vì hơn một tỷ tiền mặt của thiên hạ gửi lại biến không dấu vết!
Không nghe nói tiền bốc hơi có là nhờ ông Clinton tư vấn chăng, chắc không đến
nỗi!</p><p>Những
chuyện cá nhân như vậy dễ xuyên tạc bôi bác. Do đó, chúng ta cũng khó nhận diện
đâu giả đâu thật. Nhân vô thập toàn. Nếu dè dặt với một cá nhân nào đó, thì ta
có thể nhìn xa hơn cá nhân đó, tức là xét vào chủ trương của đảng của cá nhân đó.
Dù kỷ luật nội bộ các chính đảng Mỹ khá lỏng lẻo tức là không nhất thiết phải bầu
cùng một hướng - nếu không thì bị... đuổi khỏi đảng chẳng hạn - nói chung, giới
dân cử hai đảng đều có quan điểm nền tảng rõ ràng. </p><p>Đảng
Dân Chủ có chủ trương thiên tả, gần với chủ nghĩa xã hội, trong khi Cộng Hòa chủ
trương thiên hữu, gần với chủ nghĩa tư bản với mọi xấu tốt của chủ nghĩa này.
Có người so sánh rất gọn là Dân Chủ thích tải đồ trên con tầu kinh tế xuống cho
dân nghèo, còn Cộng Hoà thì muốn phát triển để chất đồ lên con tầu kinh tế đó.
Khi thịnh đạt thì dân Mỹ sẵn lòng san xẻ và cho đảng Dân Chủ tái lập công bằng,
khi kinh tế thiếu thốn thì cũng dân Mỹ lại muốn Cộng Hoà ra tay.... </p><p>Dân Chủ coi trọng công bằng xã hội, chú tâm
vào nhu cầu của những người thiếu điều kiện thuận lợi, như người nghèo, người
lao động, người già, dân thiểu số, do đó Nhà Nước cần can thiệp mạnh bằng trợ cấp
tài chánh, bằng luật lệ, bằng một chính sách kiểm soát càng nhiều sinh hoạt quần
chúng càng tốt, tuy chưa đến nỗi như các nước cộng sản. Dĩ nhiên là muốn can
thiệp mạnh thì Nhà Nước cần một guồng máy hành chánh to tát nặng nề, và nhất là
cần thu thuế cho nhiều để có tiền trả lương cho guồng máy đó, cũng như chi trả
cho các chương trình trợ cấp đủ loại. Vì vậy, các nghiệp đoàn công chức cũng đứng
về phe Dân Chủ, theo lối ăn cây nào rào cây nấy.</p><p>Nghe
thì hiển nhiên rất là nhân đạo, đầy tình người. Nhưng cái khổ là thực tế chính
trị và lý tưởng tình cảm ít khi đi đôi. TT Jimmy Carter là người đầy nhân ái,
mà cũng là tổng thống một nhiệm kỳ dở nhất lịch sử Mỹ. Chính sách nhân đạo, lấy
nhân quyền, bình đẳng và trợ cấp an sinh làm nền tảng đưa đến cảnh trong nước
thì kinh tế lụn bại, thất nghiệp tràn lan, lạm phát phi mã, ngoài nước thì bị
Nga qua mặt, Iran tát tai, Cuba đẩy cả ngàn tù và người điên qua Florida</p><p>Nếu
nhìn cho kỹ và nhớ cho sâu thì chính sách mị dân bắt các ngân hàng phải
chongười nghèo vay mượn tiền mua nhà mặc
dù không đủ tiêu chuẩn của TT Carter cũng là nguyên nhân sâu xa của cuộc khủng
hoảng địa ốc, rồi khủng hoảng tài chánh và kinh tế của mấy năm qua. Mà nạn nhân
của chính sách này lại chính là dân nghèo mà ông muốn giúp. Nhìn vào tình trạng
nhà cửa hiện nay, ta thấy mấy đại gia vẫn ung dung mua nhà bạc triệu, chỉ có giới
nghèo và trung lưu thì bị mất nhà hàng loạt. </p><p>Trên
căn bản, giúp người thiếu may mắn là chuyện phải làm, cần làm. Con người ta
khác loài cầm thú, nên dĩ nhiên có trách nhiệm tương trợ, giúp đỡ nhau. Nhưng
chỉ có thể đến một mức nào đó thôi. Đi quá xa sẽ tạo ra một tinh thần ỷ lại,
không còn tinh thần phấn đấu cầu tiến nữa. Và cũng đưa đến tình trạng bất công
xã hội, với hai loại người, những người cong lưng miệt mài đi làm đóng thuế để
nuôi những người không đóng xu thuế nào, ăn không ngồi rồi lãnh trợ cấp. </p><p>Theo
thống kê mới nhất, tại các tiểu bang Mississippi, New Mexico, Tennessee, Oregon
và Louisiana, cứ năm người dân thì đã có một người ngồi nhà sống nhờ phiếu thực
phẩm foodstamps. Tổng cộng ở Mỹ hiện đã có gần 46 triệu người sống bằng
foodstamps, mức cao nhất lịch sử Mỹ. Thống kê cũng cho thấy lạm dụng tràn lan,
với phiếu thực phẩm được đổi qua tiền mặt lấy tiền mua bia, mua càng cua
Alaska, thậm chí mua cả phấn son, làm móng tay cho các bà độc thân có con cái
hàng đàn mà vẫn muốn làm dáng kiếm thêm con cho Nhà Nước nuôi. Nhân đạo thật,
nhưng đó có phải là điều chúng ta ước mơ không? Phải chi Nhà Nước có một chính
sách phát triển kinh tế hùng mạnh, mọi người đều có công ăn việc làm, tự lực
cánh sinh, không ai cần foodstamps nữa, như vậy có ý nghĩa hơn không?</p><p>Những
vấn đề khi Nhà Nước nhúng tay quá nhiều là lạm dụng, phung phí, quản lý yếu
kém, kế hoạch sai trật. Kinh nghiệm thất bại của các thiên đường xã hội chủ
nghĩa đầy rẫy. Kinh nghiệm lủng củng Âu Châu ta thấy mỗi ngày trên báo. Mô thức
Âu Châu là mô thức của thập niên 50-60 đang phá sản, chỉ có TT Obama mới đang
tìm cách tái diễn. </p><p>Đó
là chưa nói đến khả năng tài chánh. Nhà Nước chỉ có thể thu thuế của thiên hạ đến
một mức nào thôi, quá mức đó thì chính mấy người đang đóng thuế mới là những người
cần giúp đỡ vì đã bị Nhà Nước lột sạch rồi.</p><p>Cộng
Hoà trái lại, chủ trương tôn trọng tự do cá nhân, và tin tưởng vào sáng kiến cá
nhân và khả năng tự lực cánh sinh của mỗi người. Nhà Nước có trách nhiệm lo cho
dân trong một giới hạn tối thiểu nào đó vì thế gian này bao giờ cũng có những
người không tự cánh sinh được do đủ mọi tai ách, như đau yếu, lớn tuổi, Những
người tỵ nạn HO chẳng hạn qua đây ốm yếu sau bao năm ngục tù cộng sản, nghề
không có, tiếng không biết, đó là những người bắt buộc Nhà Nước phải giúp. Nhưng
những người có điều kiện tự lo được thì phải tự lo, không thể suốt ngày nằm nhà
uống bia coi football ăn BBQ để Nhà Nước nuôi. Vì vai trò Nhà Nước ở mức giới hạn
nên nhu cầu cũng giới hạn, do đó thuế má cũng giới hạn, để tiền lại cho mỗi người
có phương tiện tự phát huy.</p><p>Mặt
trái của vấn đề là thả lỏng quá sẽ đưa đến nạn cá lớn nuốt cá bé, là nhà giàu
dùng thế lực để ức hiếp hay bóc lột nhà nghèo, tạo ra bất công xã hội quá mức.</p><p>Nói
cách khác, cả hai chủ trương đều có điểm tốt, nhưng nếu đi quá xa, cả hai đều
có điểm hại. Cái thuyết trung dung của Khổng Tử chẳng biết áp dụng ở đây có đúng
nghiã và đúng cách hay không, nhưng hiển nhiên trạng thái cực đoan chẳng bao giờ
tốt. </p><p>Khi
mạt sát các dân biểu Cộng Hòa, thiên hạ quên mất mấy ông này đều do dân bầu
lên. Nếu họ chiếm được đa số kiểm soát Hạ Viện thì cũng chỉ vì đa số dân Mỹ muốn
vậy, trao quyền để họ thắng bớt lối xài tiền vung vít rồi tăng thuế của TT
Obama và phe Dân Chủ. Cái nhóm dân cử Cộng Hòa đó không thể chiếm được đa số
56% ghế tại Hạ Viện hiện nay nếu họ chỉ đại diện cho bọn nhà giàu chỉ có 1% dân
số. </p><p>Trên
diễn đàn mạng Politico, John Podesta, cựu Chánh Văn Phòng của TT Clinton, mới
viết bài bình luận dưới tựa đề Cộng Hòa chỉ lo cho Nhà Giàu. Lập luận này dựa
trên sự chống tăng thuế nhà giàu của Cộng Hòa dĩ nhiên. Cái lý luận mị dân
che mắt thiên hạ cho đến nay vẫn rất ăn tiền. Điều mà nhiều người không biết
hay không muốn biết là chuyện tăng thuế nhà giàu không có nghĩa là chỉ nhà
giàu mới bị tăng thuế, mà có nghĩa là tăng thuế cho mọi người, giàu, nghèo và
trung lưu. Trên cột báo này, kẻ viết này đã viết quá nhiều về vấn đề rất kinh tế
thường thức này rồi. Nếu mấy ông nhà giàu ngớ ngẩn ngồi khoanh tay chịu đóng
thuế cao hơn, thì họ không thể nào trở thành nhà giàu được. Họ biết xoay trở và
thường chi tiền cho các chính khách làm luật hoặc bẻ luật cho họ. Mà than ôi,
thành phần chính khách Dân Chủ cũng là khách xộp của họ. </p><p>TT
Obama đề nghị tăng thuế những người có lợi tức trên 200.000 đô một năm. Đây
không là lợi tức của các ông tỷ phú thân đảng Dân Chủ như Warren Buffett, Bill
Gates hay George Soros đâu, mà là lợi tức của mấy ông bà như chủ tiệm phở khu
Bolsa thôi. </p><p>Nếu
bị tăng thuế, bảo đảm là họ sẽ không ngồi yên đóng thuế. Nhẹ thì sẽ hoặc tăng
giá tô phở, hoặc nhắc nhà bếp bỏ ít thịt hơn. Như vậy có phải tất cả mọi người đều
cùng đóng thuế giúp tiệm phở không? Tô phở tăng giá một đô không có nghĩa gì
nhiều, nhưng nhân lên hàng trăm hàng ngàn món hàng khác, sẽ là bao nhiêu? Vài
trăm hay vài ngàn đô một năm? Số tiền này đối với ông Buffet chỉ là muối bỏ biển,
nhưng đối với kẻ viết này lại rất lớn. Ai chịu thiệt thòi hơn?</p><p>Đó
chính là lý do kẻ viết này làm lương năm đồng ba cọc lại chống tăng thuế nhà
giàu, cũng như đa số dân Mỹ đã bầu cho Cộng Hòa chiếm đa số tại Hạ Viện. Vì kẻ
viết này tin chắc hơn đinh đóng cột, nếu TT Obama tăng thuế nhà giàu thì bảo đảm
không bao lâu sau, cái gia tăng đó sẽ được đổ lên đầu nhà nghèo này, và cuối
cùng mình sẽ là người đóng thuế cao hơn chứ không phải ông Buffett, đóng thuế
cao hơn khi tính theo tỷ lệ của lợi tức. Ngay cả những người hiện giờ không đóng
một xu thuế nào cũng phải trả giá tô phở cao hơn, tức là phải đóng thuế thêm rồi.
Sự thật gọi là phũ phàng này cần phải được nhìn cho rõ.</p><p>Dĩ
nhiên là chúng ta còn một lựa chọn nữa: không thèm đi ăn phở nữa, để ông bà chủ
tiệm phở hết cơ hội chém oan chặp đẹp. Nhưng như vậy thì tiệm phở bắt buộc phải
thâu nhỏ kinh doanh, sa thải vài người chạy bàn hay phụ bếp, thậm chí đóng cửa
tiệm luôn. Và như vậy thì tỷ lệ thất nghiệp sẽ tăng hay giảm?</p><p>TT
Obama lớn tiếng kêu gọi công bằng kinh tế (economic fairness), nếu nhà giàu
chịu chia sẻ với người nghèo nhiều hơn thì mọi việc sẽ tốt đẹp hơn. Làm như thể
là nếu tăng thuế những người giàu nhất thêm 4%, từ 35% lên 39%, là giải quyết mọi
khó khăn kinh tế. Sự thật là tăng thuế kiểu đó chỉ mang lại cho ngân sách thêm
1.000 tỷ - nếu thu được - trong khi bội chi ngân sách của TT Obama là trên
10.000 tỷ, công nợ hiện nay là hơn 15.000 tỷ, và tổng cộng chi tiêu Nhà Nước
trong 10 năm tới là gần 45.000 tỷ. Mà bị thuế nặng là người ta sẽ bớt đầu tư,
tuyển người, và kinh tế vẫn khó khá.</p><p>Có
người cho rằng Dân Chủ và Cộng Hoà đều ăn như nhau, khác biệt là Cộng Hòa ăn
vô hạn trong khi Dân Chủ ăn còn chừa lại cho dân. Kẻ viết này chỉ xin hỏi lại
bà con tỵ nạn lâu năm có để ý thấy trong lịch sử cận đại Mỹ, chỉ có hai tổng thống
đã cắt thuế toàn diện cho dân là Reagan và Bush (con), đều là Cộng Hòa không?
Dĩ nhiên với các độc giả có lợi tức thấp không phải trả thuế thì điều này chẳng
nghĩa lý gì, nhưng với các độc giả thuộc hạng trung lưu phải đóng thuế, thì đây
có phải là điều đáng suy gẫm không? </p><p>Lại
nữa, Nhà Nước mới đây đã phát triển chương trình trợ cấp tiền thuốc chongười lớn tuổi trong Medicare Plan D. Đây là
chương trình trợ cấp an sinh lớn nhất từ thời TT Johnson, và tác giả chính làông Cộng Hòa Bush con, chứ không phải Clinton hay Obama đâu.</p><p>Chính
sách của TT Obama gần đây cũng là chính sách bình thường của đảng Dân Chủ, theo
chủ trương hỗ trợ giới yếu thế nói chung bằng tiền Nhà Nước qua cải tổ y tế
và kích cầu kinh tế. Tốt lắm. Nhưng vấn đề là với các chương trình đầy nhân
tính này, số công nợ của Nhà Nước lên đến những mức vô tiền khoáng hậu, để rồi
câu hỏi ai sẽ trả những nợ nầy bị ém nhẹm vào ngăn kéo. Chỉ vài năm nữa, món
nợ cất trong ngăn kéo sẽ ung thối, nổ bùng, và mọi người sẽ lãnh đạn, như ta đang
thấy xẩy ra bên Âu Châu hiện nay. Nhưng lúc đó TT Obama có thể đã làm tổng thống
hai nhiệm kỳ rồi, ung dung vui thú điền viên, viết hồi ký lãnh vài chục triệu đô
rồi. </p><p>Có
độc giả cho rằng tác giả bị dị ứng Obama. Thật ra tác giả này dị ứng chuyện
phải cong lưng đi làm rồi đóng thuế mệt nghỉ cho TT Obama tung tiền ra mua phiếu
qua các chương trình mị dân vĩ đại, chỉ phí tiền trong khi kinh tế vẫn lụn bại
và thất nghiệp vẫn tràn lan. Nếu TT Obama cắt giảm bớt các chương trình đó, giảm
thuế cho dân, phục hồi kinh tế, thì tác giả sẽ tình nguyện nghỉ làm, đi vận động
toàn thời cho TT Obama, mỗi tuần sẽ viết 7 bài ca tụng công đức của Đấng Tiên
Tri ngay. (11-12-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a181110/cong-hoa-hay-dan-chu-lua-chon-nao

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/