# Tương Lai Không Sáng Sủa

06/12/2011

<p>Tương
Lai Không Sáng Sủa </p><p>Vũ
Linh</p><p></p><p>...Cộng
Hòa lần này đều có vẻ thuộc hạng lông, nhẹ ký, khó hạ được TT Obama...</p><p></p><p>Nếu
kẻ viết này nói huỵch tẹt ra rằng đảng Cộng Hòa tiếp tục để nước Mỹ loay hoay
trong hoạn nạn, không ít độc giả có lẽ gãi đầu không hiểu chuyện gì đã xẩy ra
cho tác giả, là người hay bị tố cáo là "mù quáng chạy theo đảng của Mỹ trắng
tài phiệt bóc lột!" Nhưng sự thật quả là chuyện đang xẩy ra. </p><p>Vâng,
đang xẩy ra chứ không phải là sẽ xẩy ra năm 2013 sau khi Cộng Hòa lên nắm quyền
thay thế TT Obama. Đang xẩy ra vì nhìn vào tình trạng chạy đua trong nội bộ Cộng
Hòa, ta có cảm tưởng như đảng này đang tìm mọi cáchthua đảng Dân Chủ, giúp TT
Obama đắc cử thêm một nhiệm kỳ nữa.</p><p>Một
ứng viên vững chắc nhất từ đầu lại là một người lửng lơ với mức hậu thuẫn không
bao giờ leo lên hơn một phần tư đảng viên bảo thủ Cộng Hoà. Đó là cựu thống đốc
tiểu bang cấp tiến nhất Mỹ, Massachusetts, ông Mitt Romney. </p><p>Với
một phần tư hậu thuẫn, ông sẽ gặp khó khăn lớn để thành ứng viên Cộng Hoà. Cái
ba phần tư bảo thủ sẽ dồn phiếu cho một ứng viên khác. </p><p>Ông
Romney đang vướng vào cái vòng luẩn quẩn. Vì khối bảo thủ không tin ông nên ông
phải càng cố chứng tỏ ông là bảo thủ thứ thiệt, nên càng phải đưa ra những chủ
trương bảo thủ cực đoan, như không tha thứ hay dung hoà gì trong chuyện di dân ở
lậu. Nếu từ giờ cho đến những ngày bầu cử sơ bộ bắt đầu từ đầu năm tới mà ông
Romney chưa thuyết phục được đa số cử tri bảo thủ của Cộng Hoà rằng ông là người
bảo thủ thực sự, thì hy vọng làm ứng viên Cộng Hoà sẽ thành mây khói, chưa nói đến
chuyện chạy đua cùng TT Obama. </p><p>Nếu
ông thuyết phục được và trở thành đối thủ của TT Obama, thì ông lại phải chuyển
hướng, trở thành bớt bảo thủ cực đoan hơn để thu hút phiếu của khối độc lập ôn
hòa. Mà làm như vậy thì lại đúng làthay áo một lần nữa rồi. </p><p>Đây
quả là cái khúc mắc lớn nhất cho ông Romney. Người ta còn nhớ TT Bush đã thẳng
thừng tuyên bố: quý vị có thể không đồng ý với tôi và không bầu cho tôi, nhưng
quý vị biết rất rõ quan điểm tôi như thế nào. Ông Romney thì chẳng thể nào nói
câu này được. </p><p></p><p>Trong
quá trình mấy chục năm hoạt động chính trị, ông Romney thay đổi lập trường như
người ta thay áo. Đến độ không ai có thể bảo đảm quan điểm của ông về một vấn đề
nào đó là như thế nào. Đều là những vấn đề hết sức quan trọng đối với cử tri bảo
thủ: sở hữu súng, phá thai, hôn nhân đồng tính, bảo hiểm y tế toàn dân, </p><p>Trên
nguyên tắc, sự uyển chuyển này chứng tỏ ông không cực đoan quá khích, do đó,
có thể sẽ thu hút được phiếu của nhóm độc lập không đảng nào. Nhưng bù lại, cái
ba phần tư bảo thủ vốn không ủng hộ ông này có thể sẽ ngồi nhà không thèm đi bầu,
hay đi bầu cho một ứng viên thứ ba nào đó, có thể là ông già gàn Ron Paul, chia
phiếu của khối bảo thủ ra để làm cỗ cho TT Obama.</p><p>Ngay
cả khả năng ông Romney thu hút phiếu của khối độc lậpcũng đáng nghi ngờ. Chẳng qua chỉ vì ông này
rất đángnghi. TT Obama bảo đảm sẽ không nương tay. Và như vậy, ông Romney sẽ
gặp khó khăn lớn đối đầu với ông vua của hứa hẹn Obama, và có nhiều hy vọng sẽ
phải nghĩ đến chuyện thua keo này, bày keo2016 nếu còn quyết tâm.</p><p>Chính
vì không tin tưởng ông Romney, nên cái ba phần tư bảo thủ của Cộng Hoà phải
loay hoay đi tìm người hợp nhãn hơn. Họ kiếm ra hàng loạt ứng viên, nổi lên rầm
rộ như cồn, rồi lẳng lặng bốc hơi như cồn. Nói theo từ ngữ phổ biến trong giới
thương mại của dân tỵ nạn: tưng bừng khai trương rồi âm thầm đóng cửa. </p><p>Danh
sách khá dài: từ tỷ phú Donald Trump, đến bà dân biểu Michele Bachmann, thống đốc
Texas Rick Perry, từ nguyên thống đốc Utah và đại sứ Jon Hunstman đến doanh gia
Herman Cain -vừa loan báo "ngưng
tranh cử" vào trưa Thứ Bảy mùng 3 vì có quá nhiều bóng hồng lấp loé sau lưng.
</p><p>Và
bây giờ là cựu chủ tịch Hạ Viện Newt Gingrich.</p><p>Chỉ
có điều khác là cho đến nay, hình như ông Gingrich không lọt đài và bị thay thế
bởi một ngôi sao nào nữa. Lý do chính là hết thời gian nữa và cũng chẳng còn
ai. Chỉ một tháng nữa là sẽ có cuộc bầu sơ bộ đầu tiên tại tiểu bang Iowa, sau đó
là liên tục bầu trên cả nước, đến mùa hè là sẽ tới Đại Hội Đảng. Cuộc chạy đua
trong nội bộ Cộng Hòa dường như sẽ là giữa hai ông Romney và Gingrich thôi (trừ
phi các cuộc bầu lại thay đổi cuộc diện lần nữa, ai mà biết được!)</p><p>Ông
Romney không phải là ứng viên hoàn hảo. Mà ông Gingrich cũng chẳng khá hơn.</p><p>Newt
Gingrich nổi tiếng là người đầy kinh nghiệm chính trị, cực kỳ thông minh, dư thừa
khả năng lãnh đạo. Ông từng lãnh đạo cuộc đảo chính năm 1994, dành chiến thắng
cho Cộng Hoà, chấm dứt 40 năm thống trị Hạ Viện của đảng Dân Chủ. Người ta nói
rằng từ buổi ăn sáng đến lúc ăn trưa ông Gingrinch có thể đưa ra một trăm ý kiến.
Vấn đề là trong một trăm ý kiến đó có 70 sáng kiến, mà cũng còn 30 tối kiến
có thể khá tai hại! </p><p>Trong
mùa tranh cử này, lập trường của ông Gingrich đã có nhiều thay đổi so với quá
khứ, khiến nhiều người chỉ trích ông chao đảo. Nhưng trong khi ông Romney thì bị
tố là lăng ba vi bộ không lập trường, thì ông Gingrich chỉ bị tố là đã chuyển
hướng từ bảo thủ cực đoan qua bảo thủ bớt cực đoan hơn thôi. Chẳng hạn như
trong vấn đề di dân ở lậu, ông bày tỏ quan điểm chấp nhận những người đã ở lậu
cả mấy chục năm, sanh con đẻ cái, đi làm và đóng thuế mấy chục năm qua. Lập trường
này có thể nghe không lọt tai mấy ông bà bảo thủ cực đoan, nhưng sẽ gây cảm
tình từ đa số không thuộc đảng phái nào. Rõ ràng là ông Gingrich đang chuẩn bị
cách lấy phiếu của nhóm độc lập này trong cuộc tranh cử chống TT Obama. Nghĩa
là quá sớm nhích về phía trung dung khi chưa chắc đã có hậu thuẫn của khối bảo
thủ ở vòng loại.</p><p>Trên
cá tánh, ông cũng là người nổi tiếng nóng nẩy, có thể lấy quyết định táo bạo hoặc
quá sớm. Ông cũng bị tố dính dáng vào nhiều chuyện tiền bạc không rõ ràng. Ông
luôn mạnh miệng tố cáo cơ quan tài trợ nợ mua nhà Freddie Mae, trong khi lại
làm tư vấn cho chính cơ quan này, lãnh lương sơ sơ có ba chục ngàn đô một
tháng. Nhưng quan trọng hơn cả là cuộc sống gia đình của ông. Lem nhem trong
khi có vợ, bỏ bà cả lấy bà bé. Liên tiếp ba lần. Ngoài ra, vì tham gia chính trường
trong bốn thập niên, ông để lại không biết bao nhiêu diễn văn, tuyên bố, lá phiếu</p><p>Tất
cả sẽ là nguồn cung cấp đạn dược vô tận cho TT Obama sử dụng. </p><p>Ta
còn nhớ trước đây Nghị sĩ Obama ra tranh cử với quá trình như tờ giấy trắng, chẳng
có gì để có thể khui ra chỉ trích. Đó có lẽ là lý do quan trọng nhất đưa Obama đến
thành công. Bây giờ, với ông Gingrich thì hoàn toàn trái ngược: ông này để lại
cả núi dấu vết, tốt cũng như xấu, để các đối thủ chính trị khai thác, có khi
bóp méo nữa.</p><p>****</p><p>Chính
trường Mỹ trong mùa tranh cử này thấy thật èo uột, một bên là một tổng thống giỏi
hứa hẹn mà chẳng làm nên trò trống gì, một bên là một lô chính khách chẳng ông
nào sáng giá đến chói mắt hết. Nước Mỹ cạn kiệt nhân tài sao?</p><p>Không
phải vậy. Về khả năng cá nhân, có thể nói thẳng thừng chẳng có xứ nào nhiều
nhân tài bằng xứ Mỹ, trong bất cứ ngành nghề, khu vực nào. Vấn đề là làm chính
trị gia ở Mỹ, ra tranh cử các chức vụ dân cử, đặc biệt là cái chức tổng thống, đã
trở thành cái nghề chẳng có gì hấp dẫn cho rất nhiều người có khả năng. Trong
nền dân chủ Mỹ, 97% dân Mỹ từ chối cái nghiệp dân cử! Lãnh lương ba cọc để giải
quyết những chuyện hóc búa nhất và rồi nghe chửi hàng thúng. Nhìn TT Obama làm
việc ba năm là tóc bạc trắng và phải nghỉ hè tưng bừng thì đủ hiểu ngay áp lực
nặng nề đến cỡ nào.</p><p>Những
ai có tài và có thiện chí đóng góp cho xã hội thì lựa đóng góp kiểu khác, chứ
không chui đầu vào chính trị. </p><p>Chỉ
tại vì muốn làm chính khách ở xứ này đòi hỏi họ phải chịu cảnh bị khui bới đời
tư bằng kính hiển vi lớn nhất. Như các cụ ta đã nói từ ngàn xưa, quét nhà tất
phải ra rác. Chẳng ai hoàn hảo và chẳng ai muốn những cái không tốt của mình -
không tốt thật, hay phịa - bị phơi bày cho cả thế giới thấy ra và bàn tán rồi
chửi rủa. </p><p>Chẳng
phải là báo lá cải mới ưa bới rác. Ngay báo lớn của dòng chính cũng vậy. Tờ
Washington Post mới đây đã có bài kêu gọi các độc giả tiếp tay, coi lại tất cả
những lời tuyên bố, diễn văn của ông Gingrich trong bốn thập niên hoạt động
chính trị, có gì đáng nói thì gửi cho tờ báo! Ông ứng viên bảo thủ Cộng Hoà
Gingrich chưa chi đã lọt mắt xanh của Washington Post rồi. Dĩ nhiên Washington
Post chỉ muốn bới rác trong đám ứng viên Cộng Hòa bảo thủ thôi, còn với Obama
hay các ứng viên cấp tiến phe ta thì có biết cũng không đăng, như trường hợp
TNS Edwards ra tranh cử tổng thống rồi phó tổng thống mà có vợ bé, con hoang và
lấy tiền tranh cử chi cho đào, chuyện tầy trời vậy cũng chẳng báo lớn nào đăng
tin. </p><p>Còn
chuyện chửi là chuyện đương nhiên. Bất cứ làm chuyện gì hay không làm chuyện gì
cũng có thể bị chỉ trích, không tránh được.</p><p>TT
Obama được phiếu của 53% dân Mỹ, tức là có 47% không đồng ý, không thích và
không bỏ phiếu. Tính nhẩm ra cũng cả trăm triệu người không ủng hộ và có thể chống
đối mạnh. Biết đâu có ngày bị một tên vô lại ném giầy vào đầu không chừng. Chạy
đâu cho thoát? Dĩ nhiên là có cách thoát, khỏi bị chửi, mà lại còn yên ổn ngồi
tích lũy của cải cho các đời con cháu. Muốn biết thì cứ hỏi các đỉnh cao trí
tuệ nhân loại đâu đó ở Bắc Kinh hay Hà Nội. </p><p>Xứ
Mỹ này, dân chúng được quyền chọn, nhưng muốn chọn đúng thì phải nhìn cho kỹ.
Mà bị nhìn kỹ quá thì đâm ra hơi phiền cho các ứng viên. Người giỏi sẽ tránh
né, thế là dân Mỹ được quyền lựa chọn trong đám dở để lấy một ngườiít dở nhất.
</p><p>Trong
năm tới, ta sẽ có quyền chọn giữa một người dở - thôi gọi là không hoàn hảo đi
- của Dân Chủ và một ngườikhông hoàn hảo của Cộng Hòa. Người không hoàn hảo của
Cộng Hòa thắng thì ta còn có hy vọng thấy tình tạng hiện nay khấm khá hơn tuy
chẳng có gì bảo đảm. Ít ra là còn Hy Vọng. Người không hoàn hảo của Dân Chủ thắng
thì nước Mỹ khó có hy vọng thoát ra khỏi những khó khăn kinh tế, giải quyết thất
nghiệp, sau ba năm loay hoay mà vẫn chưa tìm ra thuốc.</p><p>Với
các ứng viên ta thấy hiện nay, người không hoàn hảo của Cộng Hòa dường như chưa
có khả năng hạ được người không hoàn hảo của Dân Chủ mặc dù người của Dân chủ đang
tuột dốc nhanh hơn diều đứt giây - còn tệ hơn ông Jimmy Carter vào cùng thời điểm
- và ta sẽ thấy tình trạng bết bát hiện nay kéo dài ít ra cũng tới năm 2016. </p><p>Nói
tóm lại, các ứng viên Cộng Hòa lần này đều có vẻ thuộc hạng lông, nhẹ ký, khó
hạ được TT Obama. Mà nếu không hạ được thì coi như TT Obama sẽ được tự do phóng
tay tiêu xài hơn nữa trong nhiệm kỳ hai. Ông sẽ không được ra tranh cử nữa nên
không còn lo lắng thắc mắc chuyện lấy phiếu mà chỉ còn lo làm chuyện gì lớn lao
vĩ đại lấy tiếng để đời thôi. Ai cũng vậy, tổng thống nào cũng thế thôi. </p><p>Khi
đó, nước Mỹ chỉ còn hy vọng Cộng Hòa vẫn giữ được đa số tại Quốc hội, Hạ Viện
hay Thượng viện, để cầm chân TT Obama lại. Còn nếu như Dân Chủ lại đại thắng
chiếm Lập Pháp lại trong khi vẫn giữ Hành Pháp, thì coi như những chương trình
tiêu xài khổng lồ sẽ tái tục. Ngân sách ngày càng thâm thủng nặng hơn, nợ công
leo thang vùn vụt là chuyện không còn tránh được nữa.</p><p>Đó
chính là lý do kẻ viết này phải nói dường như đảng Cộng Hòa đang tiếp tục để nước
Mỹ loay hoay trong vòng hoạn nạn vài năm nữa, nếu không muốn nói là đang đưa nước
Mỹ vào vòng đại nạn khi TT Obama không còn lý do tự kềm chế trong khi lại không
có gì kềm chế ông nữa. (4-12-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a180733/tuong-lai-khong-sang-sua

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/