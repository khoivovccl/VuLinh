# Bài Toán Của TT Obama

20/12/2011

<p>Bài
Toán Của TT Obama </p><p>Vũ
Linh</p><p></p><p>...dân
Mỹ cũng đã bắt đầu bỏ ông thuyền trưởng Obama hàng loạt rồi...</p><p>Nếu
ta mở báo ra đọc, bất cứ báo nào, sẽ thấy tràn ngập thăm dò dư luận về cuộc chạy
đua vào Nhà Trắng năm tới. Về phiá Cộng Hòa, bức tranh vẫn mù mịt, sớm lắm chắc
cũng phải đợi hết tháng Hai sau khi một vài tiểu bang bắt đầu bầu sơ bộ mới thấy
được ai nhiều hy vọng. Mà cũng chưa chắc. Giống như cuộc chạy đua giữa ông
Obama và bà Hillary năm 2008, mãi đến gần đại hội đảng, vào mùa hè mà vẫn chưa
ngã ngũ. Bên Cộng Hòa hiển nhiên là sẽ còn nhức răng đau đầu nhiều. Nhưng đây
là truyền thống chính trị Mỹ, chẳng có gì lạ. Các ứng viên Obama và Hillary xâu
xé nhau đến gần chết, đắc cử xong, TT Obama mời bà Hillary làm Ngoại Trưởng. </p><p>Như
vậy chắc bên Dân Chủ, TT Obama giờ này đang ung dung ngồi viết diễn văn nhậm chức
sao? Không hẳn là vậy. Trong khi Cộng Hoà rối như tơ vò thì phiá Dân Chủ, tin xấu
rớt xuống đầu như sầu riêng chín rụng ban đêm vậy.</p><p>Trước
hết nói về hậu thuẫn tổng quát.</p><p>GQ,
là tập san chuyên viết về chuyện mấy ông, quảng cáo quần áo đàn ông, đồ thể
thao, xế xịn, v.vMỗi năm tập san này làm một thăm dò dư luận hết sức ngược đời:
xem trong những người nổi tiếng, những người nào có ít ảnh hưởng nhất, tức là
tiếng nói của họ giống như chém gió trong sa mạc nhất. Năm nay, trong số 25 người
đầu bảng, có tổng thống Đại Cường Cờ Hoa nhà ta. Chỉ là châm biếm dĩ nhiên. Dù
sao thì TT Obama cũng có thể đánh Lybia, giết quốc trưởng một nước độc lập mà
không cần xin phép quốc hội, giết Bin Laden tuốt bên Pakistan không cần hỏi ý
kiến chủ nhà mà cũng chẳng cần đưa Bin Laden ra tòa, cho máy bay bắn chết mấy
cha con ông Awlaki tuốt bên Yemen mặc dù mấy người này đều là công dân Mỹ trong
khi Hiến Pháp Mỹ không cho phép chính quyền giết bất cứ một công dân Mỹ nào chưa
bị toà kết án tử hình. Toàn là quyết định táo bạo mà chẳng có ông nhà báo nào
dám ho he hỏi thăm sức khỏe. </p><p>Xin
quý độc giả đừng hiểu lầm: tác giả hoan nghênh cái chết của mấy ông Khaddafi,
Bin Laden và Awlaki một trăm phần trăm. Nhưng ta thử tưởng tượng Bush mà làm những
chuyện này thì chắc giờ này chúng ta đang mỗi ngày theo dõi trực tiếp truyền
hình quốc hội đàn hạch Bush vì đủ tội vi phạm Hiến Pháp, nhân quyền rồi. </p><p>Một
người chi phối được các báo và đài truyền hình lớn nhất nước, và mấy trăm vị
dân cử Dân Chủ, tổng tư lệnh lực lượng quân sự mạnh nhất thế giới, không thể
nói là ít ảnh hưởng nhất được. Ở đây cái ý của tờ GQ chỉ có nghiã làchẳng ai để
ý đến chuyện TT Obama đang làm gì nữa. Nói theo Mỹ: who cares?</p><p>Dân
biểu Dennis Cardoza (Dân Chủ!) của Cali viết bài dài than phiền TT Obama xử thế
như một nhà giáo phách lối (arrogant professor), luôn luôn tự cho mình đúng, dạy
bảo người khác mặc dù rất ít kinh nghiệm với cuộc sống thực tế, chưa nói đến
kinh nghiệm chính trị.</p><p>Một
chuyện rất thú vị. Anh nhà báo Chris Matthews, người đã từng công khai tuyên bố
trên chương trình nói lảm nhảm của anh ta trên đài MSNBC, mỗi lần nghe đến tên
Obama là anh ta cảm thấy có luồng điện chạy rần rần từ chân lên đầu, cũng là người
tự cho mình có cái may mắn vô tận đã được sinh ra cùng thời với Obama và được
Obama đang dẫn dắt lên thiên đường. Bây giờ thì anh Matthews này đã đổi giọng,
lớn tiếng hỏi Obama ơi, ông đâu rồi? Sao chẳng thấy ông làm gì hết vậy? Ông hãy
ra lệnh đi chúng tôi sẵn sàng nghe mà. </p><p>Bỏ
qua chuyện thay đổi lập trường của anh Matthews, điều đáng chú ý là ta thấy một
nhà báo Mỹ công khai kêu gọi TT Obama hãy ra lệnh đi để anh ta làm theo. Ngay cả
mấy anh đọc tin trên đài truyền hình Hà Nội cũng chưa dám trắng trợn yêu cầu Thủ
Tướng hay Tổng Bí Thư như vậy!</p><p>Nói
về những con số cụ thể thì tin tức càng ngày càng không vui. Kết quả mới nhất
cho thấy trong mười người dân, chỉ có bốn người tin TT Obama đáng được bầu lại.
Ba người cho rằng ba năm qua là ba năm của thất vọng hoàn toàn. Đáng chú ý là
trong mười người đảng Dân Chủ, đã có hai cho rằng TT Obama nên đi về câu cá là
vừa. </p><p>Kinh
tế là ưu tư số một của tuyệt đại đa số dân Mỹ. Vậy mà trong mười người, chưa tới
ba người cho rằng TT Obama làm được việc trong vấn đề này. Đại đoàn kết dân tộc,
chủ đề chính trong cuộc tranh cử 2008: chỉ có ba người cho rằng Obama đã cố gắng
đoàn kết các phe nhóm, bẩy người cho chính sách của ông đã tạo chia rẽ.</p><p>Nhưng
con số làm cho TT Obama băn khoăn nhất: gần bẩy người (66%) không hiểu TT Obama
có thể làm được chuyện gì trong nhiệm kỳ hai, sau khi nhìn vào thành quả thật
khiêm tốn của nhiệm kỳ đầu khi Dân Chủ kiểm soát hết trong hai năm đầu. TT
Obama tuyên bố ông cần một nhiệm kỳ nữa để hoàn thành công tác. Ba năm qua chưa
làm gì nhiều, bốn năm nữa có gì khác? Phần lớn thiên hạ tin Cộng Hòa sẽ tiếp tục
kiểm soát quốc hội, có thể sẽ thắng thêm vài ghế then chốt ở Thượng Viện, và như
vậy, TT Obama với những chương trình cấp tiến cực đoan sẽ khó leo qua rào cản bảo
thủ để thông qua bất cứ luật gì, làm được bất cứ chuyện gì. Họ không tin hai
bên sẽ nhượng bộ nhau để có thỏa hiệp. Nếu TT Obama không làm được gì thì sao đáng
được bầu lại?</p><p>Dân
Mỹ có đầu óc thực dụng nhất thế giới, chỉ cần làm được việc, còn lại chẳng
nghĩa lý gì, chẳng có chuyện trung thành, tình cảm lẩm cẩm gì hết. </p><p>Hơn
thế nữa, càng ngày thì dân Mỹ càng nhìn thấy rõ và lo lắng chính sách của TT
Obama. Chủ trương tài trợ tiền trợ cấp bằng nợ nần chồng chất, chẳng qua chỉ là
chính sách dùng tiền đời con cháu để mua phiếu cử tri bây giờ. Không thiếu gì
người choá mắt vì trợ cấp bây giờ mà không nghĩ đến chuyện con cháu họ sẽ phải
trả nợ như thế nào. Nhưng cũng không thiếu gì người lo xa cho con cháu đã bắt đầu
đặt câu hỏi.</p><p>Ta
đã nghe TT Obama và đảng Dân Chủ ra rả đổ thừa Bush đủ mọi chuyện. Kể ra thì
cũng không phải vô lý hoàn toàn. Làm tổng thống là như vậy thôi, phải chịu
trách nhiệm hết mọi chuyện, xấu cũng như tốt.</p><p>Nhưng
điểm đặc biệt với TT Obama là khi ông làm tổng thống thì tất cả mọi chuyện, hễ
tốt thì do công của ông, hễ xấu là do đủ thứ lý do và ông cũng chỉ là nạn nhân
như thiên hạ. Từ lỗi tại Bush cho đến máy rút tiền, đảo chánh bên Ai Cập, sóng
thần bên Nhật, 1% cường hào ác bá Wall Street (miệng xỉ vả họ nhưng tay vẫn nhận
tiền), rồi mới đây làthời tiết. Trả lời câu hỏi của CBS về những khó khăn ông
đang gặp, TT Obama trả lời ông cũng như là thuyền trưởng trong cơn bão, đang
làm hết sức mình, nhưng bão to quá không làm gì được hết, vì ông không kiểm
soát được thời tiết. </p><p>Ủa,
vậy tại sao khi đắc cử, ông đã rất hoành tráng tuyên bố ngày hôm nay là ngày
thủy triều bắt đầu xuống, không phải là ông đã quả quyết sẽ kiểm soát được thủy
triều luôn sao? Còn nữa. </p><p>Thế
bão lớn này ai gây ra? Bush? Như vậy hóa ra Bush mới là người điều khiển được
thời tiết, tạo ra sóng to gió lớn gây khó khăn cho Obama sao? Như vậy Bush mới đúng
là Đấng Tiên Tri có phép màu sao?</p><p>Dù
ông đổ thừa gì đi nữa thì dân Mỹ cũng đã bắt đầu bỏ ông thuyền trưởng Obama
hàng loạt rồi. Hậu thuẫn của ông hiện giờ lảng vảng ở mức 40% trong khi số người
chê bai ông lên đến trên dưới 55% rồi. Tương lai như ghế hai chân.</p><p>Tổng
quát thì như vậy, nhưng thực tế, bầu cử tổng thống ở Mỹ được định đoạt bởi cử
tri trong khoảng một chục tiểu bang then chốt. Con số màu nhiệm không phải là mấy
trăm triệu phiếu, mà là số 270 phiếu cử tri đoàn của các tiểu bang. Tại những nơi
như Cali hay Nữu Ước, nhắm mắt cũng biết Obama sẽ thắng, trong khi tại Texas,
Alabama, , nhắm mắt cũng biết Obama sẽ thua. Thành ra quan trọng là nhìn vào
vài tiểu bang xôi đậu. </p><p>Ta
đừng quên Hoa Kỳ là một tập hợp của 50 tiểu bang. Số phiếu quyết định không phải
là tổng số phiếu của tất cả cử tri cả nước, mà là số phiếu tính theo cử tri đoàn
của tiểu bang. </p><p>Và
khi nhìn vào các tiểu bang xôi đậu thì TT Obama sẽđau đầu không ít.</p><p>Theo
thống kê mới nhất, tại các tiểu bang then chốt Colorado, Florida, Iowa, Nevada,
New Hampshire, New Mexico, North Carolina và Pennsylvania, đảng Dân Chủ từ 2008
đến nay đã mất hơn 825,000 đảng viên, trong khi đảng Cộng Hoà mất 378,000 người.
Theo USA Today, trong 12 tiểu bang xôi đậu, số đảng viên Dân Chủ giảm trung
bình 4% trong khi đảng viên Cộng Hòa tăng 5%. Quan trọng nhất, cử tri Dân Chủ
có vẻ nản chí trong khi Cộng Hoà thì hăng xay với cuộc bầu sắp tới hơn. Yếu tố
này sẽ quyết định tỷ lệ đi bầu.</p><p>Đây
toàn là những tiểu bang mà TT Obama đã thắng McCain khít nút năm 2008. Không cần
thua hết, mà chỉ cần thua ở hai hay ba tiểu bang lớn là TT Obama sẽ có dịp về
Hawaii viết hồi ký nữa rồi.</p><p>Một
cách nhìn khác nữa: các tiểu bang Virginia, Ohio, Pennsylvania, Wisconsin,
trong thời gian qua đều đã đổi thống đốc từ Dân Chủ qua Cộng Hòa. New Jersey
tuy cũng có đổi thống đốc qua Cộng Hoà, nhưng không ai tin TT Obama sẽ thua ở đây,
trừ phi thống đốc Cộng Hoà Christie nhẩy ra tranh cử phó tổng thống thì TT
Obama sẽ bị đe dọa lớn tại đây.</p><p>Nhưng
đáng lo ngại nhất là thăm dò của Quinnipiac tại hai tiểu bang đã quyết định kết
cuộc bầu cử của hai kỳ bầu năm 2000 (Florida) và 2004 (Ohio). Ai cũng biết tiếng
nói quyết định là tiếng nói của khối độc lập không thuộc đảng nào. Thăm dò
Quinnipiac cho thấy tại Florida và Ohio, cả hai ông Cộng Hòa Romney và Gingrich
đều hạ TT Obama dễ dàng trong giới độc lập.</p><p>Báo
National Journal trong số ra ngày 15 Tháng Chạp, đã phân loại cử tri thành 18
khối. Kết quả thăm dò của họ cho thấy hậu thuẫn của TT Obama suy giảm trong 16
khối cử tri, nhất là khối độc lập, da trắng, trong tuổi 18-44.</p><p>TT Obama ý thức được nguy cơ nên đã tính chiến
lược mới: ông không còn có thể rẽ về phía giữa ôn hòa để thu hút khối độc lập,
mà trái lại phải đi xa hơn nữa về phiá tả để giữ chắc phiếu của khối này. Đây
là chiến lược của Bush: củng cố khối cử tri trung kiên nhất của mình để kéo họ đi
bầu đông nhất. </p><p>Trong
thời gian qua, TT Obama đã cố gắng tự mô tả là người hùng bảo vệ người nghèo,
dân lao động, chống nhà giàu, chống Cộng Hoà bóc lột, xách động đấu tranh giai
cấp mới. Thông điệp Không có một nước Mỹ đỏ hay một nước Mỹ xanh, mà chỉ có một
Hiệp Chủng Quốc Hoa Kỳ đã vào thùng rác từ ba năm nay rồi. </p><p>Ông
chạy theo nhóm Occupy Wall Street xỉ vả 1% nhà giàu ích kỷ không đóng góp cho
quyền lợi chung, kêu gọi công bằng kinh tế (economic fairness) nhưng lờ qua
chuyện cái 1% đó đã đóng tới 40% thuế của cả nước mà hầu như không lãnh trợ cấp
an sinh (chưa ai nghe nói các ông Bill Gates hay Warren Buffett đi lãnh tiền thất
nghiệp hay tiền Social Security hay nhận Medicare cả), trong khi 40% dân không đóng
một xu thuế nào vì lợi tức thấp, nhưng lại lãnh 60% trợ cấp an sinh. Nói cách
khác, cái 1% nhà giàu ích kỷ đó đã gánh chịu hết những trợ cấp cho gần một nửadân cả nước, thuộc giới lợi tức thấp. Có lẽ
TT Obama cho rằng 1% lo cho 40% chưa phải là công bằng, mà công bằng phải là
1% lo cho 99%. Chính trị và toán học không đi đôi với nhau là vậy.</p><p>Ông
lớn tiếng tố giác luật giảm thuế nhà giàu của TT Bush, nhưng không nhắc chuyện
chính ông đã gia hạn luật đó khi nó hết hạn cuối năm ngoái. Đó là một trong những
biệt tài của chính trị gia, nói một đàng làm một nẻo mà vẫn tỉnh bơ, vì lúc nào
cũng có rất nhiều người thích nghe mà không thích mở mắt nhìn, gọi là nhắm mắt
thưởng thức nhạc. </p><p>Điều
đáng chú ý hơn cả: bộ luật để đời của TT Obama, luật cải tổ y tế, hình như đã bị
quên bẵng, không ai nghe ông quảng bá luật này nữa. Lý do rất giản dị: gần 60%
dân Mỹ phản đối đạo luật này. </p><p>***</p><p>Nhìn
vào tình hình chung, trở ngại lớn nhất của TT Obama chính là những lời hứa trời
biển của ông so với thành quả hết sức khiêm tốn, chứ không phải là các đối thủ
Cộng Hòa.</p><p>Ở
Las Vegas, có rất nhiều chỗ cho thiên hạ đến đánh cá xem bên nào sẽ thắng, độc
giả nào có hứng thú có thể thử thời vận - hay nói cho đúng hơn, thử tài nhận định
chính trị của mình - xem sao. Những người tuyệt đối tin tưởng vào TT Obama có
thể mang căn nhà mình ra đánh cá, biết đâu sẽ có dịp trả hết ngay nợ nhà, khỏi
thắc mắc vài chục năm tới? Có thua thì đưa nhà cho mấy ông cá độ Las Vegas,
thay vì đưa nhà cho Bank of America cũng vậy thôi. Chỉ có ăn hay huề mà không
có thua. </p><p>Dĩ
nhiên đây là nói chơi thôi, đừng có vị nào tưởng thật, mất nhà thì kẻ viết này
không bồi thường được đâu. (18-12-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p><p>Đôi
lời tâm tình: Tác giả nhận thấy Việt Báo Online đã rất thành công tạo ra được một
diễn đàn trong đó độc giả tích cực trao đổi ý kiến. Phần lớn chúng ta thuộc thế
hệ tỵ nạn đầu tiên, đến từ các chế độ không có truyền thống tự do dân chủ mà lại
đối kháng nhau trong một cuộc chiến sống còn, nên không có thói quen chấp nhận
người khác ý. Ra nước ngoài, môi trường thay đổi, chúng ta có cơ hội sống trong
tự do dân chủ thực sự, nhưng dù sao cũng vẫn còn đang học tập về các khái niệm
phức tạp đó. Tác giả hoan nghênh mọi ý kiến khác biệt, mọi chỉ trích, nhất là từ
các vị học cao hiểu rộng, chỉ mong sao quý độc giả chấp nhận không ai sở hữu
chân lý tuyệt đối, chấp nhận có người khác ý mình mà vẫn có thể tôn trọng nhau,
không cần phải chụp mũ hay phỉ báng nhau. Xin chân thành đa tạ.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a181448/bai-toan-cua-tt-obama

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/