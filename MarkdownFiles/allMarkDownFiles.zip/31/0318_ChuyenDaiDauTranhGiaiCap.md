# Chuyện Dài Đấu Tranh Giai Cấp

25/10/2011

<p>Chuyện
Dài Đấu Tranh Giai Cấp</p><p>Vũ
Linh</p><p></p><p>...Sỉ
vả tư bản bóc lột dã man hơn CS, nhưng vẫn tìm mọi cách trốn khỏi thiên đường
CS...</p><p>Phong
trào nổi loạn chống nhà giàuOccupy Wall Street (OWS) như vết dầu loang, lan
tràn ra nhiều thành phố lớn của Mỹ và trên thế giới. Nhưng ảnh hưởng của phong
trào cũng không thuần nhất. </p><p>Xuất
phát từ giữa tháng 5 tại xứ Tây Ban Nha (Spain), trong khi phong trào lớn mạnh
nhanh chóng tại Nữu Ước và các thủ đô Âu Châu, thì tại Hoa Thịnh Đốn, cuộc biểu
tình chỉ thu hút được đúng 53 người. Người ta cũng nhận thấy phong trào này lớn
mạnh nhanh nhất là ở bên Âu Châu, nơi có khủng hoảng kinh tế trầm trọng hơn Mỹ
cũng như ảnh hưởng của tư tưởng xã hội chủ nghiã mạnh hơn ở Mỹ. Tại nhiều nơi
như Rome, thủ đô Ý, biểu tình đã biến thành xung đột bạo lực phá cửa tiệm, đốt
xe, đánh nhau với cảnh sát.</p><p>Hình
ảnh phong trào OWS không khác gì các cuộc biểu tình thiên tả của sinh viên và
nghiệp đoàn vào thập niên 60: chống chiến tranh Việt Nam, chống chính quyền cả
Dân Chủ (TT Johnson) lẫn Cộng Hòa (TT Nixon), hoan hô Castro, Che Guevarra, Mao
và Hồ, cổ võ cho tự do tình dục và ma túy. </p><p>Theo
Gallup, chỉ có hơn 20% dân Mỹ ủng hộ mục tiêu đấu tranh của OWS dù chẳng ai hiểu
rõ mục tiêu đó là gì. Chống nhà giàu nhưng đòi hỏi gì" Nếu là đòi hỏi tăng thuế
nhà giàu và tão ra công ăn việc làm thì hiển nhiên họ đã không nhìn thấy cái
mâu thuẫn trong lý luận kinh tế. Không khác nào đòi hỏi cả mưa lẫn nắng cùng
lúc. Cả hai kinh tế gia cấp tiến cực đoan -đã từng nhận Nobel Kinh tế - là
Joseph Stiglitz và Paul Krugman, đều cổ võ việc ủng hộ người nghèo chống tài
phiệt. </p><p>Điều
đáng nói là cả hai ông đều là những người trước đây cổ súy cho chính sách cho nhà
nghèo vay tiền mua nhà bừa bãi đưa đến khủng hoảng gia cư rồi khủng hoảng tài
chánh lớn nhất lịch sử Mỹ, nguyên nhân xa của cuộc nổi loạn. Nếu mấy ông Na Uy
có thể tặng Nobel Hoà Bình cho Lê Đức Thọ được thì họ cũng tặng Nobel kinh tế
cho các ông Krugman và Stiglitz được.</p><p>Vài
con số đáng chú ý: 75% số người tham gia OWS trước đây đã bầu cho Obama, 51% bây
giờ khẳng định không ủng hộ Obama nữa.</p><p>Một
nhà báo Mỹ - Conor Friedersdorf - đã viết một tham luận trên báo cấp tiến The
Atlantic. Theo ông thì phong trào OWS đã lẫn lộn hai thứ Wall Street: một Wall
Street thực tế và một Wall Street biểu tượng. Những người nổi loạn đã nhìn vào
chuyện xẩy ra trong Wall Street thực tế và quay qua đả phá cái Wall Street biểu
tượng. Phiên dịch cho dễ hiểu, theo nhà báo này, thiên hạ đã nhìn vào những lạm
dụng, việc làm bất chính của một số tài phiệt Wall Street để quay qua chống lại
Wall Street biểu tượng của chế độ tư bản. Họ không ý thức rõ hành động của một
vài cá nhân bất hảo không phải là triết lý nền tảng của một chế độ hay một chủ
thuyết.</p><p>Đây
có lẽ là nhận định chính xác nhất về phong trào OWS. </p><p>***</p><p>Phong
trào OWS đã lan mạnh qua Âu Châu. Giữa Mỹ và Âu Châu, hai tình trạng khác nhau,
nhưng bị suy diễn là cùng nguyên nhân: chế độ tư bản, tài phiệt bóc lột.</p><p>Trước
hết, hãy nhìn sơ qua Âu Châu. Khó khăn kinh tế ở đây xuất phát từ thất bại của
chế độ bao cấp quá mức, ngân sách Nhà Nước thâm thủng quá nặng, bây giờ phải thắt
lưng buộc bụng, cắt giảm đủ thứ trợ cấp, đưa đến bất mãn và chống đối. </p><p>Một
chuyên gia kinh tế Âu Châu nhận định người dân không ý thức được rằng Nhà Nước
vú em hết là một mô thức khả thi. Không có Nhà Nước nào có thể tiếp tục trợ cấp
quá lớn bằng nợ chồng chất được. Hiển nhiên là các cuộc nổi đậy do cánh tả rất
mạnh bên Âu Châu phát động nhắm vào việc phục hồi chế độ xã hội bao cấp tối đa
trước đây. </p><p>Tình
trạng Mỹ khác xa. Chế độ bao cấp của Mỹ chưa thể so sánh được với Âu Châu. Cuộc
nổi đậy ở Mỹ được kích động bởi những khó khăn kinh tế khác: thất nghiệp, mất
nhà, mất xe, mất thẻ tín dụng, Từ đó sinh ra bất mãn. Và đúng theo văn hoá
truyền thống của dân Mỹ, không bao giờ là lỗi tại mình hết mà luôn luôn là lỗi
người khác. Phải tìm cho ra thủ phạm của những khó khăn của mình. Và họ đã nhìn
các tài phiệt Wall Street, những người đã xiết nhà của họ trong khi vẫn ung
dung lãnh lương bạc triệu, như những thủ phạm. </p><p>Đi
thêm một bước, đối tượng chống đối đã lan qua ngành ngân hàng, khu vực tài
chánh, rồi đến cả chế độ tư bản luôn, một chế độ bị tố là của nhà giàu ăn cướp
nhà nghèo. Nhưng nhìn vào hành động sai trái của một vài cá nhân không thể đưa
đến một kết luận tổng thể nào. </p><p>Kẻ
viết này còn nhớ cách đây rất lâu, khi chưa đến tỵ nạn tại Mỹ, nhờ vào cái tính
mê coi phim Mỹ nên luôn luôn trong đầu nghĩ rằng xứ Mỹ là xứ của dân cao bồi bạo
động, của da trắng kỳ thị da đen, da vàng, của các tài phiệt hành hạ, bóc lột
thợ thuyền công nhânKhi phải tính chuyện trốn chạy cộng sản năm 75 thì đã
phân vân nát óc không biết mấy ông tài phiệt đó đáng sợ hơn, hay mấy ông cán bộ
trong phim "Chúng Tôi Muốn Sống" mới đáng sợ. Kết quả là đã chọn đi Mỹ
vì cùng lắm là mấy ông tư bản bóc lột bắt mình đi làm như trâu như bò, nhưng chưa
đến nỗi bắt mình mang ra đấu tố, chôn sống. </p><p>Qua
đây sống một thời gian mới biết những hành động bóc lột, kỳ thị, bạo lực trong
phim ảnh không phản ánh lối sống, suy tư và văn hoá của cả mấy trăm triệu dân Mỹ.</p><p>Nhìn
chung vào nước Mỹ, hai thập niên qua là hai thập niên của suy đồi kinh tế, văn
hoá và luân lý, và khủng hoảng niềm tin ở Mỹ. Khi mà vị quốc trưởng bàn chuyện
quốc sự trên điện thoại trong khi một cô gái đáng tuổi con làm việc dưới gầm
bàn giấy, rồi vị đó trở thành một trong những tổng thống được ái mộ nhất lịch sử
cận đại, thì thiên hạ rõ ràng là phải thắc mắc về nền tảng luân lý trong văn
hoá Mỹ. </p><p>Khi
một tổng thống hai lần quyết định giảm thuế cho dân bị tố là tổng thống bóc lột
dân nhất thì dường như nước Mỹ đang có vấn đề về nhận định trung thực. Khi một
người không có một ly kinh nghiệm gì về chính trị, quân sự, kinh tế, xã hội,
ngoại giao, hay về quản lý, lãnh đạo, được chọn làm người lãnh đạo tối cao và
tôn vinh ngang hàng Thượng Đế thì người ta có thể suy gẫm về lý trí của người
dân. </p><p>Không
ai phủ nhận được cách biệt giàu-nghèo ngày càng lớn ở Mỹ, và bất công xã hội
ngày càng khó chấp nhận. Khi Bank of America gặp khó khăn thì 30.000 nhân viên
bị sa thải, lệ phí thẻ tín dụng bị tăng đồng loạt, nhưng Tổng Giám Đốc vẫn được
tăng lương từ sáu triệu lên mười triệu. Sự nổi giận của nhóm OWS không phải
không có lý do chính đáng.</p><p>Đúng
là nước Mỹ có rất nhiều vấn đề lớn. </p><p>Nhưng
những vấn đề lớn đó vẫn không xoá mờ được thực tế một nước Mỹ như cường quốc
giàu mạnh nhất thế giới, hoàn toàn thống trị cả thế giới về kinh tế, quân sự, kỹ
thuật, và cả văn hoá luôn, gần như hoàn toàn qua diễn biến hòa bình tuy cũng
có lúc không hòa bình lắm. Không thiếu gì người trên thế giới ra rả mạ lỵ Hoa
Kỳ nhưng vẫn sẵn sàng xếp hàng cả ngày, qua hàng loạt thủ tục rườm rà khó chịu
nhất để xin chiếu khán đi Mỹ. Chửi Mỹ đủ chuyện nhưng vẫn mặc quần cao bồi với
áo thung có cờ Mỹ, nghe nhạc pop và rap, coi CNN, ái mộ Brad Pitt và Angelina
Jolie, xài iPad, iPod, iPhone, ước mơ bằng cấp Mỹ, thức đêm học tiếng Mỹ, coi
Steven Jobs và Bill Gates như mẫu người lý tưởng, và nhất là vẫn mêdollar hơn
bất kể thứ gì khác.</p><p>Quan
trọng hơn nữa, nước Mỹ là nước của cơ hội thăng tiến. Có nghĩa là bất cứ người
nào trong cái khối 99% bị áp bức cũng có cơ hội lọt vào cái khối 1% đang bị
chửi rủa. Những con sâu tài phiệt, hầu hết đều là những người xuất thân với
hai bàn tay trắng. Tỷ phú Steven Jobs của Apple thời trung học đã từng đi nhặt
loon coca để bán lại. Rồi đến cả con một anh sinh viên gốc Kenya nghèo mạt cũng
đã trở thành thành viên của khối 1%, rồi thành tổng thống luôn. </p><p>Trong
cộng đồng ty nạn Việt, không thiếu gì người đã không bỏ qua cơ hội nào để chửi
Mỹ, nhưng vẫn không bao giờ nghĩ đến chuyện từ bỏ quê hương thứ hai này để trở
về lại quê hương thứ nhất. Sỉ vả tư bản bóc lột dã man hơn cộng sản, nhưng vẫn
tìm mọi cách trốn khỏi thiên đường cộng sản, qua đây làm nạn nhân cho tư bản
bóc lột. </p><p>Vấn
đề ở đây là cần phải phân biệt cho rõ nồi canh và những con sâu làm rầu nồi
canh đó. </p><p>Không
ai có thể phủ nhận một số lớn những viên chức điều hành các ngân hàng lớn là thủ
phạm đã tạo ra khủng hoảng tài chánh lớn nhất thế kỷ, đảo lộn đời sống của cả
triệu người, đẩy họ vào vòng điêu linh không lối thoát. Họ không từ bỏ một mánh
khoé hay một thủ đoạn nào để có tiền, có tiếng, và có quyền. Họ đã gạt người
dân khi tung ra những loại nợ mua nhà với điều kiện quá dễ, lãi suất thật thấp
lúc đầu, làm mồi câu để thiên hạ nhẩy vào bẫy, ký giấy nợ bạt mạng. Họ đã lừa gạt
những nhà đầu tư khi bán cho những người này những gói nợ mà họ biết trước sẽ
trở thành giấy lộn. Họ đã mua chuộc những chính khách làm luật và thi hành luật
để những người này nhắm mắt làm ngơ cho họ tung hoành. </p><p>Những
người chống Bush chỉ trích Bush đã thông đồng với giới tài phiệt bóc lột đó,
nhưng lại không bao giờ đặt vấn đề Obama đã làm gì để trừng phạt, và bảo vệ người
dân khỏi trở thành nạn nhân trong tương lai" Nhiều tài phiệtlãnh cả trăm triệu nhờ bóc lột thiên hạ vẫn
còn đó, hơn nữa lại đã trở thành những cột trụ của chế độ. </p><p>Tổng
Giám Đốc đại ngân hàng JP Morgan, ông Jamie Dimon là người thường được nhắc đến
như là sẽ thay thế Tim Geithner làm bộ trưởng Tài Chánh (ít ra thì phong trào
OWS này đã phá tan giấc mộng làm bộ trưởng của ông tài phiệt Dimon). </p><p>Tổng
Giám Đốc đại ngân hàng Goldman Sachs, ông Lloyd Blankfein là cố vấn bán chính
thức của TT Obama. Theo Washington Post, cho đến nay, TT Obama đã nhận được tiền
yểm trợ của các đại gia Wall Street nhiều hơn tất cả 8 ứng viên Cộng Hòa cộng lại!
Đó chính là những con sâu cần phải truy diệt. </p><p>Chứ
không phải chế độ tư bản. Chế độ tư bản tự nó không cổ võ cho những hành động
có tính lạm dụng, phạm pháp này.</p><p>Thật
ra là không sai nếu tố giác chế độ tư bản là môi trường nuôi dưỡng những con
sâu đó, đã thả lỏng cho chúng lộng hành. Nhưng cũng không thể chối cãi được thả
lỏng chính là một cách định nghĩa khác của tự do. </p><p>Cái
môi trường thả lỏng này cũng là nơi mà tất cả mọi người đều có cơ hội đồng đều
để tiến thân. Sự thành công của các ông Jobs và Obama là chuyện không bao giờ
có được trong một chế độ có kiểm soát khắt khe từ Nhà Nước.</p><p>Môi
trường tư bản này cũng là cái xứ duy nhất trên thế giới mà gần một nửa dân
chúng được xếp hạng vào loại nghèo không phải đóng một xu thuế nào hết, dù là
thành phần lãnh nhiều trợ cấp của Nhà Nước nhất, từ tiền già, tiền thuốc, tiền
thất nghiệp, tiền foodstamps, Trong khi đó, cái khối 1% đang bị chửi rủa, với
mức lợi tức lên đến 24% lợi tức toàn quốc, đã đóng tới 40% tổng số thuế thu được,
mà lại hầu như không nhận trợ cấp an sinh nào (có tỷ phú nào cần mấy trăm tiền
oe-phe hay tiền thất nghiệp đâu). Có bao nhiêu người trong OWS đòi công bằng xã
hội đã nhìn thấy chuyện thiếu công bằng này" </p><p>Khách
quan mà nói, nước Mỹ tuy vẫn còn là số một trên thế giới, nhưng rõ ràng đã
trên đà suy thoái từ thời chiến tranh Việt Nam đến giờ, hay ít nhất cũng là từ
hai thập niên qua, từ sau thời TT Reagan, do đó cần phải thay đổi rất nhiều để
duy trì thế đứng của mình, đặc biệt là trước nguy cơ bành trướng của Trung Cộng.
Nhu cầu thay đổi đó đã được ứng viên Obama khai thác tối đa với chiêu bài Change
We Can Believe In, và được hậu thuẫn mạnh của dân Mỹ. </p><p>Nhưng
đáng tiếc là những thay đổi mà TT Obama đã thực hiện lại toàn là những thay đổi
đưa nước Mỹ vào vết xe đổ Âu Châu, đưa nước Mỹ vào chế độ Nhà Nước vú em đã thất
bại. Thất bại tại Âu Châu, rồi bây giờ thất bại tại Mỹ. Đưa đến những khó khăn
kinh tế dồn dập, bất mãn toàn diện, và chống đối tràn lan.</p><p>Thay
vì nhìn nhận những thất bại, chuyển hướng để cải đổi thì TT Obama đã lựa chọn
giải pháp mỵ dân là khai thác phong trào OWS, hùa theo họ đổ thừa lên đầu tài
phiệt và chế độ tư bản, sau khi đã đổ thừa lên tsunami Nhật, đảo chánh Ai Cập,
máy rút tiền, núi lửa, động đất, xui xẻo, cạnh tranh của Trung Cộng, sai lầm của
Bush, phá đám của Cộng Hoà, v.v</p><p>Điều
đáng nói là việc TT Obama và một số lãnh tụ Dân Chủ ủng hộ phong trào OWS mang
nhiều rủi ro lớn. Loại hình ảnh của người biểu tình chà dẫm lên cờ Mỹ, cũng như
hát những bài ca nhục mạ nước Mỹ sẽ khó bào chữa hơn những lời của một mục sư
Wright sỉ vả God Damn America. </p><p>Chính
quyền Obama ủng hộ phong trào OWS cũng sẽ tăng thêm ngờ vực về chủ trương xã hội
chủ nghĩa của TT Obama khi phong trào này được hậu thuẫn mạnh của các tổ chức
thiên tả cực đoan. Đảng Cộng sản Mỹ đã chính thức lên tiếng cổ võ OWS trên
trang mạng. Báo chí Việt Nam do đảng CSVN kiểm soát thời gian qua đã không bỏ lỡ
cơ hội khai thác, làm rùm beng trên trang nhất, liên tục bình luận về mâu thuẫn
giai cấp của chế độ tư bản Mỹ, nhiệt liệt cổ võ cho phong trào thiên tả này, sỉ
vả tư bản Mỹ, dù không đả động gì đến tư bản đỏ ở Việt Nam.</p><p>Dân
tỵ nạn chúng ta cần nhận định cho rõ trước khi vô tình hát cùng nhịp điệu với
báo Sàigòn Giải Phóng. (23-10-11)</p><p>Vũ
Linh</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a178754/chuyen-dai-dau-tranh-giai-cap

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/