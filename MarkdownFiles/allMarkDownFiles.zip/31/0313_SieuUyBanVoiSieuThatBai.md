# Siêu Ủy Ban Với Siêu Thất Bại

29/11/2011

<p>Siêu
Ủy Ban Với Siêu Thất Bại</p><p>Vũ
Linh</p><p></p><p>...Không
làm gì thì không được, mà muốn làm gì thì cũng chẳng thể làm được... </p><p></p><p>Sau
cả tháng trời tranh cãi về vấn đề tăng mức trần của nợ công, Đầu tháng Tám vừa
qua,TT Obama và Quốc hội đã đi đến thỏa hiệp, trong đó có một điều khoản được
coi là cực kỳ quan trọng. Trần nợ được tăng, nhưng với điều kiện là quốc hội sẽ
thành lập một thứ siêu ủy ban lưỡng đảng, gồm 12 vị dân cử của cả Dân Chủ và
Cộng Hoà từ Thượng Viện và Hạ Viện, để cùng làm việc và đưa ra được một chương
trình cắt giảm thâm thủng ngân sách.</p><p>Trong
bài viết về vấn đề này, tác giả lúc đó có nhận định mọi việc sẽ tùy thuộc vào
cuộc tranh cãi giữa hai chính đảng, và kết luận có nhiều hy vọng các vị dân
cử Dân Chủ cũng như Cộng Hòa, sẽ coi chuyện tái đắc cử quan trọng hơn là chuyện
cứu nguy kinh tế Mỹ. </p><p>Đúng
như tiên đoán, siêu ủy ban đó đã hoàn toàn thất bại, không có được một thỏa thuận
nào tính đến ngày Thứ Năm vừa qua, là hạn kỳ đã đặt ra trước đây và ghithành luật.</p><p>Không
cần là thầy bói giỏi cũng thấy được những khó khăn thực tế của giải pháp có
tính vừa bán cái qua quốc hội, vừa câu giờ của chính quyền của TT Obama.</p><p>Trên
căn bản, chỉ có hai cách để cắt giảm thâm thủng ngân sách: cắt chi tiêu và tăng
thu nhập.</p><p>Cắt
chi tiêu là mục tiêu của Cộng Hoà mà Dân Chủ cực lực phản đối. Vì cắt chi tiêu
là cắt bỏ những chương trình phần lớn liên quan đến các vấn đề an sinh xã hội.
Lý luận của Cộng Hoà là các chương trình vĩ đại của TT Obama, cũng như những chương
trình an sinh xã hội đã đi quá khả năng tài chánh của nước Mỹ. Các chương trình
tiền già, tiền thuốc đều bị đe dọa phá sản, để rồi đến đời con chúng ta sẽ
không còn được bao nhiêu nữa. Cần phải có kế hoạch cải tổ quy mô, thắng bớt lại
những trợ cấp đó. Chẳng hạn như chương trình tiền hưu trí, hoặc là phải giảm bớt,
hoặc là phải tăng mức đóng góp, hoặc phải tăng tuổi về hưu. </p><p>Hay
chẳng hạn như những chương trình bảo hiểm y tế Medicare và Medicaid, phải có
cách giới hạn phần chi của Nhà Nước, nhất là khi chương trình cải tổ y tế của
TT Obama sẽ tốn cả chục ngàn tỷ trong thập niên tới. Chẳng những cần cắt giảm
trợ cấp mà còn hủy bỏ những chương trình chi tiêu chưa cần thiết, hoặc có hại
như tiền thất nghiệp, càng trả thì thiên hạ càng ỷ lại và ngồi ỳ ở nhà ăn lương
thất nghiệp, hoặc phí phạm vô lý hay vì phe cánh kiểu như cho công ty làm mấy tấm
phản thu năng lượng từ mặt trời Solyndra mượn nửa tỷ đô trong một dự án hết sức
phiêu lưu trong thời buổi kinh tế khó khăn như hiện nay. Do đó, phải cắt chi
tiêu.</p><p>Lý
luận của Dân Chủ là tất cả những chi tiêu đều cần thiết, nhất là để phục hồi
kinh tế. Và cách chữa bệnh là tăng thuế, đặc biệt là tăng thuế nhà giàu, để bù đắp
thâm thủng và có tiền xài tiếp. Theo đảng Dân Chủ, những nhà giàu ở Mỹ chưa đóng
góp đủ vào nền kinh tế quốc gia, nếu có phải đóng thuế thêm nữa thì cũng chỉ là
chuyện muỗi đốt gỗ, vẫn còn dư dả sống mãn đời, trong khi các trợ cấp an sinh
cho người nghèo còn quá ít, nhất là bây giờ khi còn quá nhiều người thất nghiệp,
phải trông chờ vào Nhà Nước. Do đó, phải tăng thuế để tiếp tục tiêu xài.</p><p>Các
vị dân cử Dân Chủ không nghĩ đến chuyện chỉ trong ba năm dưới trào Obama, công
nợ của Mỹ đã tăng 4.400 tỷ, đưa mức công nợ lên đến trên 15.000 tỷ hiện nay. TT
Bush, là người bị ứng viên tổng thống Obama gọi là vô trách nhiệm vì tiêu xài
vung vít, đã phải mất tám năm mới tăng mức nợ lên được 5.000 tỷ.</p><p>Cộng
Hòa cho rằng tăng thuế nhà giàu khi mà 1% khối người giàu nhất đã đóng tới 40%
thuế của cả nước, sẽ chỉ khiến họ không mở doanh nghiệp, không thuê thêm nhân
công, và duy trì tình trạng kinh tế èo uột, thất nghiệp tràn lan. </p><p>Hơn
vậy nữa, cái nguyên lý của chuyện tăng thuế cũng không ổn. Các chính trị gia
vung tiền xài loạn, rồi đè những người gọi là nhà giàu để bắt họ trả. Làm như
thể các nhà giàu này đều làm giàu bằng cách đi ăn cướp cho nên bây giờ Nhà Nước
và những người gọi là nghèo phải đi ăn cướp lại cho huềvậy. Chính cái lý -hay nói cho đúng hơn, cái
vô lý - này cũng hiến cho phong trào Chiếm Phố Wall (Occupy Wall Street) hầu như
xì hơi, chỉ còn thu hút được một thiểu số có vẻ cuồng tín, trước sự thờ ơ của đại
đa số dân Mỹ. </p><p>Dân
Mỹ cũng không ngây thơ đến độ không nhìn thấy những tay tổ đứng sau hò hét hậu
thuẫn cho phong trào OWS cũng là những tỷ phú triệu phú luôn, như Michael Moore
và George Soros, chỉ muốn lợi dụng nhóm OWS vì quyền lợi cá nhân. Ông Moore ban
ngày ra đường hò hét ủng hộ những người cắm lều ngủ trong công viên Nữu Ước,
ban tối về lại căn nhà đáng giá vài triệu ở ngoại ô Hoa thịnh Đốn để ngủ, ấm hơn
nhiều. Ngay cả một số lớn các vị dân cử Dân Chủ ủng hộ OWS cũng là triệu phú chỉ
muốn kiếm phiếu trong mùa tranh cử thôi. Một thăm dò mới đây cho thấy một phần
ba các vị dân biểu và thượng nghị sĩ cũng thuộc thành phần 1% mà phong trào OWS
đang chống đối mạnh.</p><p>Dù
sao thì cuộc tranh cãi với những lý luận cổ điển mọi người đều biết vẫn tiếp diễn
mà không ai có giải pháp dung hòa được.</p><p>Trên
nguyên tắc, qua cuộc tranh cãi trong nội bộ siêu ủy ban, Cộng Hòa đã đồng ý tăng
thuế, và Dân Chủ cũng đồng ý cắt giảm trợ cấp. Nhưng chỉ là đồng ý nguyên tắc để
lấy tiếng, rồi khi vào chi tiết và các con số cụ thể thì hết đồng ý, cho nên
không có thỏa hiệp gì hết.</p><p>Vấn
đề cực kỳ phức tạp, vì đi vào nền tảng triết lý cơ bản của hai khối bảo thủ và
cấp tiến. Những nhà học giả uyên bác nhất hay kinh tế gia với cả túi giải Nobel
cũng không dung hòa được lập trường khác biệt giữa hai khối.</p><p>Nhìn
vào vấn đề, người ta thấy bế tắc là điều hiển nhiên khi cả hai bên đều không
bên nào dám nhượng bộ bên kia vì sợ sẽ mất phiếu trong mùa tranh cử năm tới. Cộng
Hoà không dám tăng thuế vì sợ Phong Trào Tea Party phản ứng. Dân Chủ không dám đụng
đến các khoản chi tiêu vì cái lý giản dị là khi quà cáp đã được tặng rồi thì
không thể lấy lại được nữa, cắt trợ cấp bảo đảm sẽ mất hậu thuẫn của những người
đang lãnh trợ cấp ngay. </p><p>Điều
đáng nói là cái khoản cắt giảm thật ra rất nhỏ, chỉ là 1.200 tỷ trong mười năm
tới, so với ngân sách chi tiêu tổng cộng là hơn 44.000 tỷ trong mười năm tới, tức
là chưa tới 3%. Vậy mà cũng không thoả thuận được. Dù sao thì đối với các vị
dân cử của cả hai bên, cái ghế của họ vẫn là chuyện sinh tử. Thất cử, mất job
là mất hết.</p><p>Vấn
đề bây giờ là siêu ủy ban đã thất bại, chuyện gì sẽ xẩy ra?</p><p>Theo
luật do quốc hội biểu quyết khi chấp nhận cho tăng nợ trần, thì nếu siêu ủy ban
không đạt thỏa thuận để có thể cắt tối thiểu 1.200 tỷ trước ngày Lễ Tạ Ơn, thì
ngân sách sẽ tự động bị cắt giảm 1.200 tỷ kể từ tháng Giêng năm 2013, cùng lúc
với nhiệm kỳ mới của tổng thống.</p><p>Luật
không ghi rõ tiết mục nào trong ngân sách sẽ bị cắt, nhưng các chuyên gia có thể
thấy trợ cấp an sinh như tiền già và tiền bảo hiểm y tế Medicare và Medicaid sẽ
không thể cắt được vì không ai dám đụng đến. Do đó, sẽ chỉ có thể cắt chi tiêu
quốc phòng vào khoảng 600 tỷ, và các chi tiêu về canh nông, giáo dục, môi sinh,
v.v</p><p>Một
vài vị dân cử Dân Chủ đã đưa ra ý kiến thay đổi luật, bỏ cái chuyện tự động cắt
giẳm. Nhưng TT Obama đã mau mắn bác bỏ ngay ý kiến này. Dĩ nhiên, TT Obama
không ngây ngô đến độ chấp nhận thay đổi luật để khỏi cắt giảm thâm thủng ngân
sách. Quyết định kiểu này bảo đảm sẽ bị phe Cộng Hòa khai thác làm vũ khí tranh
cử. Bây giờ đây, TT Obama đã có quá nhiều rắc rối, đâu cần thêm chuyện nhức đầu
nữa.</p><p>Thái
độ thích đáng nhất của TT Obama là cứ để mọi chuyện đi vào bế tắc như vậy, để
có cớ đổ thừa Cộng Hoà phá hoại, không có thiện chí tìm giải pháp. Với bộ máy
công quyền hùng hậu cũng như sự hỗ trợ gần như tuyệt đối của truyền thông dòng
chính, TT Obama và phe Dân Chủ sẽ vẽ lên bức tranh của một đảng Cộng Hòa đối lập
phá hoại, và thế nào cũng được một phần hậu thuẫn quan trọng trong quần chúng.</p><p>Theo
các thăm dò dư luận mới nhất, 44% dân Mỹ đồng ý thất bại là lỗi của Cộng Hòa,
trong khi 38% cho là đó là lỗi của Dân Chủ.</p><p>Nhưng
mọi việc sẽ không yên ổn như vậy.</p><p>Nếu
không có biện pháp gì, khá nhiều chuyện tệ hại có thể xẩy ra từ giờ đến ngày bầu
cử, và khó ai đoán trước được hậu quả sẽ như thế nào.</p><p>Trước
hết là với mức nợ tăng vùn vụt như hiện nay, thâm thủng sẽ ngày một trầm trọng
hơn. Kinh tế có thể sẽ suy thoái mạnh hơn nữa, đưa đến thất nghiệp tăng thêm nữa.
Thị trường chứng khoán sẽ rớt mạnh nữa. Hai ngày trước khi siêu ủy ban chính thức
tuyên bố thất bại, chỉ số Dow Jones đã rớt hơn 500 điểm. Rồi tiếp đến là viễn tượng
các cơ quan thẩm định tín dụng sẽ có thể hạ điểm tín dụng của Mỹ thêm một mức.
Kết quả là lãi suất trên công nợ của Nhà Nước Mỹ sẽ tăng vọt, kéo theo việc gia
tăng lãi suất toàn diện, kinh tế đã khó khăn sẽ khó khăn hơn nữa.</p><p>Trên
phương diện chính trị, cả hai bên sẽ tiếp tục tranh cãi, và dĩ nhiên tiếp tục đổ
thừa lẫn nhau, không bên nào chịu nhận trách nhiệm hết. Chính trường sẽ như chợ
cá. Đại đoàn kết dân tộc cũng như thay đổi mà ứng viên Obama đã hứa vẫn chỉ là
một hình ảnh lờ mờ cuối đường hầm.</p><p>Trước
một viễn ảnh đen tối như vậy mà TT Obama bình chân như vại lo tranh cử thì dân
Mỹ cũng sẽ khó mà thông cảm cho tổng thống, để rồi tín nhiệm ông thêm một nhiệm
kỳ nữa.</p><p>Nói
nôm na ra, TT Obama đang trong cái thế tiến thoái lưỡng nan. Không làm gì thì
không được, mà muốn làm gì thì cũng chẳng thể làm được gì. Trong một cuộc phỏng
vấn trên đài truyền hình mới đây, nhà báo Jack Tapper của CBS công khai hỏi TT
Obama có dám cắt các tài trợ an sinh không thì TT Obama đã bắt buộc phải trả lời
kiểu lửng lơ con cá vàng, chẳng có gì rõ ràng mặc dù câu hỏi rất rõ ràng, đưa đến
tình trạng trả lời theo kiểu ai muốn hiểu sao cũng được. Loại trả lời này bây
giờ thì còn được vì chưa ai để ý đến, nhưng vào cao điểm mùa tranh cử, mùa hè năm
tới, thì chắc chắn sẽ không còn được cử tri chấp nhận nữa.</p><p>Đây
là cái thế mà phe Cộng Hòa cố tình cài ông vào, đưa đến hình ảnh một tổng thống
hoàn toàn thụ động vì không có khả năng, không biết phải làm gì. Còn chờ đợi gì
nữa mà không chấp nhận về quê câu cá? (27-11-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a180350/sieu-uy-ban-voi-sieu-that-bai

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/