# ộng Hòa: Ông Cain Và Thuế 9-9-9

08/11/2011

<p>Cộng
Hòa: Ông Cain Và Thuế 9-9-9</p><p>Vũ
Linh</p><p></p><p>...tài
ăn nói của ông Cain chưa đủ để hạ tài thề trăng hẹn biển của Obama...</p><p>Nội
bộ đảng Cộng Hòa sau mấy tháng chạy đua vẫn chưa có gì sáng tỏ. </p><p>Ngôi
sao Michele Bachman hầu như đã biến khỏi sân khấu. Ngôi sao Rick Perry giống như
tsunami, tràn lên thật nhanh như vỡ đê mà rút xuống cũng rất mau. Bây giờ lại
xuất hiện một ngôi sao mới là Herman Cain. Trong khi đó thì người dẫn đầu mọi
thăm dò vẫn là Mitt Romney. Gần nửa tá những người khác có vẻ vẫn như dã tràng
se cát. </p><p>Vấn
đề của Romney là ông có được một số những người ủng hộ, gần như nhất định, khoảng
một phần năm cho đến một phần tư đảng viên Cộng Hòa. Không ít hơn, nhưng cũng
không leo lên hơn được. Chưa đủ để thắng trong đảng chứ đừng nói tới hạ được TT
Obama. Nói trắng ra, xấp xỉ 80% đảng viên Cộng Hòa muốn tìm một đại diện khác
cho đảng.</p><p>Lý
do chính là ông chưa tạo ra được niềm tin trong khối bảo thủ vì thành tích đãlàm thống đốc tiểu bang cấp tiến nhất Mỹ là
Massachusetts. Ông cũng là người theo đạo Mormon, bị khối công giáo coi như tà
đạo. Đã vậy, ông cũng là một doanh gia rất giàu, đối tượng hàng đầu của phong
trào Occupy Wall Street hiện nay. Thời buổi OWS này, có tiền là một cái tội lớn,
cho dù là tiền làm ra từ công sức chính mình chứ không phải tiền ăn cướp hay tiền
bán bánh vẽ. </p><p>Nói
tóm lại, mặc dù ông Romney có kinh nghiệm kinh tế là điều tối cần trong tình trạng
hiện tại của Mỹ, đã mang quá nhiều hành trang với khối bảo thủ tương đối cực đoan,
là khối sẽ tích cực đi bầu nhiều nhất trong các cuộc bầu sơ bộ trong nội bộ Cộng
Hòa. Không qua được cửa ải này thì dĩ nhiên không có cơ hội đương đầu với ứng
viên Dân Chủ Obama.</p><p>Điều
này thực sự đáng tiếc vì trong tất cả các ứng viên Cộng Hòa, lập trường bảo thủ
ôn hòa của ông Romney có nhiều hy vọng thu hút được phiếu của khối độc lập, tức
là có nhiều hy vọng hạ TT Obama nhất, tuy không phải là chuyện dễ.</p><p>Phương
thức bầu cử sơ bộ của cả hai chính đảng Mỹ có tác dụng rõ rệt là giúp những ứng
viên tương đối cực đoan có nhiều hy vọng thắng hơn. Dân Chủ thì có khuynh hướng
giúp cho các ứng viên cấp tiến cực đoan, trong khi Cộng Hoà thì có khuynh hướng
tuyển chọn những ứng viên bảo thủ cực đoan. Nguyên nhân cũng dễ hiểu: chỉ những
cử tri tương đối có nhiệt tình - hoặc quá khích - mới hăng say tham gia các cuộc
bầu sơ bộ từ đầu, chẳng những phải đi bầu hai ba lần, mà nhiều khi cách bầu sơ
bộ cũng rất phức tạp, phiền toái, hay khó hiểu.</p><p>Chính
vì vậy mà ba ngôi sao mới nổi của Cộng Hòa, bà Bachman, ông Perry và bây giờ
ông Cain, đều là những người có quan điểm bảo thủ cực đoan, ít hy vọng thắng
Obama hơn ông Romney. Việc mấy ông bà này nổi lên rồi mau chóng lặn đi nói lên
tình trạng tang gia bối rối của Cộng Hoà: không thoả mãn với ông Romney, nhưng
vẫn chưa tìm được người khác hợp ý hơn.</p><p>Ông
Herman Cain là một doanh gia thành công, đã từng làm Tổng Giám Đốc chuỗi Burger
King của tiểu bang Pennsylvania (khoảng 400 tiệm), và chuỗi nhà hàng pizza
Godfather. Cả hai chuỗi nhà hàng đều đến bờ vực phá sản, nhờ ông Cain mà lật ngược
thế cờ và thắng lớn. Ông Cain cũng từng là thành viên Ngân Hàng Dự Trữ khu vực
Kansas. Nói cách khác, trên phương diện kinh nghiệm kinh tế tài chánh, ông Cain
so với ông Obama là một trời một vực.</p><p>Khoảng
cách với TT Obama về ý thức hệ chính trị còn lớn hơn nữa. Ông Cain là thành phần
thiên hữu cực đoan, chống Nhà Nước vú em bao cấp, chống sưu cao thuế nặng. Quan
điểm này đã đưa đến một tình trạng có vẻ tréo cẳng ngỗng. Ông da đen này được
phong trào Tea Party ủng hộ dù phong trào này mang tiếng là của dân da trắng,
trong khi ông lại bị các chính khách và nhà báo da đen đả kích thậm tệ, gọi ông
là Oreo, tức là loại bánh kẹp, hai miếng bánh sô-cô-la đen kẹp kem trắng ở giữa,
ý muốn nói ông Cain đen vỏ trắng ruột. Ông Cain cũng có điểm khá giống Obama là
khả năng ăn nói rất hùng hồn, dễ hớp hồn người nghe.</p><p>Bỏ
qua vấn đề màu da, quan điểm chống Nhà Nước vú em, hay khả năng ăn nói thu hút
cá nhân, điểm thành công lớn nhất của ông Cain là đề nghị về thuế của ông.</p><p>Kế
hoạch thuế của ông Cain mang một cái tên rất giản dị và dễ nhớ: 9-9-9, đã trở
thành khẩu hiệu tranh cử của ông.</p><p>Trên
căn bản, ông Cain chủ trương loại bỏ toàn diện hệ thống thuế hiện hữu để thay
thế bằng ba loại thuế: thuế doanh lợi công ty (corporate income tax) 9%, thuế lợi
tức cá nhân (personal income tax) 9%, và thuế thương vụ (sales tax) 9%. Không
thể nào giản dị hơn. Dân Mỹ với đầu óc giản dị ôm chầm lấy mô thức này, dù đại đa
số chẳng hiểu rõ những hậu quả cụ thể của chính sách thuế đó là gì.</p><p>Ông
Cain quảng bá chính sách thuế này chẳng những giản dị, ngăn chặn được hầu hết
những mánh khóe lách thuế - nhất là của mấy đại công ty và nhà giàu - mà còn
giúp phát triển kinh tế, tạo công ăn việc làm cho dân nữa. Nghe qua như vậy thì
quả là toa thuốc màu nhiệm tối cần cho nước Mỹ hiện nay. Vì vậy mà hậu thuẫn của
ông Cain đã tăng vọt như hỏa tiễn trong thời gian qua.</p><p>Nhìn
gần hơn thì mô thức của ông Cain chỉ là chuyệnhão, không bao giờ có thể trở
thành sự thật vì sẽ không bao giờ kiếm được đủ hậu thuẫn trong quần chúng một
khi bị mổ xẻ chi tiết. Kế hoạch này đầy lỗ hổng vĩ đại. Ta hãy xét thử.</p><p>Thuế
doanh lợi sẽ được giảm xuống 9%. Hiện nay mức thuế này là 35% tối đa, nhưng thực
tế, nhờ hàng trăm cách miễn trừ lách thuế, hầu hết các công ty đóng thuế dưới
20%. Dù sao đề nghị của ông Cain cũng là điều các công ty hoan nghênh hết mình
vì mức thuế thấp hơn hiện tại rất nhiều. Hậu quả tất yếu là sẽ khuyến khích các
công ty đầu tư, phát triển kinh doanh, hoặc mang các cơ sở, hãng sản xuất từ nước
ngoài về Mỹ. Và đây sẽ là yếu tố hữu hiệu nhất giúp phục hồi kinh tế và tạo
công ăn việc làm. Đây hiển nhiên là điểm lợi lớn nhất và thực tế nhất trong đề
nghị của ông Cain.</p><p>Vế
thứ hai là thuế lợi tức cá nhân sẽ ở mức duy nhất 9% cho mọi người, sau phần miễn
giảm cá nhân (individual exemption), không có đặc miễn nào khác. Dẹp bỏ tất cả
các loại thuế liên bang khác như thuế an sinh xã hội, thuế gia sản, thuế trên lợi
nhuận đầu tư, và những trường hợp đặc miễn hay giảm bớt cực kỳ rắc rối không những
chẳng ai hiểu, mà còn đầy lỗ hổng để thiên hạ khai thác lách thuế.</p><p>Ở
đây vấn đề lớn là quý độc giả và kẻ viết này sẽ đóng thuế ngang mức với các ông
Bill Gates và Warren Buffett! Chỉ nghe đến đây là sẽ không thiếu gì người hoảng
hốt và bất bình. Ông Buffett với lợi tức năm bẩy chục triệu một năm sẽ đóng thuế
ở mức 9% giống như mấy cô bán hàng siêu thị hay bất cứ ai khác, tuy tính theo số
tiền thì sẽ có chênh lệch rất nhiều. Hơn thế nữa, thuế trên lợi nhuận đầu tư -
tax on capital income, là nguồn lợi tức lớn nhất của những nhà giàu có dư tiền đầu
tư - sẽ được miễn thuế hoàn toàn. </p><p>Nói
cách khác, nhà giàu từ trước đến giờ đóng thuế 35% trên lợi tức và 35% trên lợi
nhuận đầu tư, bây giờ sẽ chỉ đóng 9% trên lợi tức và 0% trên lợi nhuận đầu tư. </p><p>Riêng
đối với khối 45% gọi là nghèo hiện nay không đóng một xu thuế nào, họ sẽ phải
đóng thuế, sau khấu trừ cá nhân. Sau khi bị chỉ trích nặng, ông Cain nhấn mạnh
công thức của ông thật ra là 9-0-9 cho dân nghèo, tức là dân nghèo sẽ được miễn
đóng thuế lợi tức cá nhân hoàn toàn: 0%. Chỉ có điều là chưa ai biết thế nào là
dân nghèo" Đến mức lợi tức nào thì mới phải đóng thuế" Khi nào thì 9-0-9 trở
thành 9-9-9"</p><p>Vế
thứ ba trong đề nghị thuế của ông Cain là việc áp đạt đồng nhất thuế thương vụ
9% trên mọi hàng hoá. Bất cứ ai mua hàng đều phải trả thuế 9% giá món hàng. Ở đây
cũng vậy, ông Cain không nói rõ món hàng nào được miễn thuế. Hiện nay loại thuế
này đã được nhiều tiểu bang áp dụng, gọi là State sales tax, tuy một số mặt
hàng như thực phẩm, thuốc men, được hoàn toàn miễn. Thuế thương vụ ông Cain đề
nghị là thuế của liên bang, được đánh thêm, trên mức thuế thương vụ của các tiểu
bang. </p><p>Ví
dụ như tại tiểu bang Cali, thuế thương vụ của tiểu bang là 10%, bây giờ với thuế
của liên bang 9% thì tổng cộng mỗi lần mua hàng sẽ phải trả 19% thuế doanh thu.
Không có khác biệt gì giữa các mặt hàng, cũng như không có khác biết gì đối
khách hàng giàu hay nghèo. </p><p>Thuế
này được đưa ra để bù đắp việc giảm thuế lợi tức, và theo ông Cain, sẽ có tính
cách công bằng, người nào xài nhiều người đó đóng thuế nhiều. Nhà nghèo mua
xe đạp đóng thuế trên trị giá bán của xe đạp, nên trả thuế ít hơn ông Buffett
di chuyển bằng máy bay, phải trả tiền thuế trên trị giá máy bay và thuế trên xăng
nhớt, bảo trì máy bay. </p><p>Điểm
khúc mắc lớn nhất của thuế này là ai cũng phải đóng, dù nghèo hay giàu. Tại Alaska
là tiểu bang hiện không có sales tax, thiên hạ mỗi khi mua hàng sẽ phải đóng 9%
sales tax, trong khi tại Cali, sẽ phải đóng 19%. Tức là một hình thức tăng thuế
tổng quát, kể cả đối với những người nghèo từ trước đến không đóng thuế lợi tức
gì hết.</p><p>Ông
Cain đã nhấn mạnh là bù lại, không ai phải đóng thuế an sinh xã hội -payroll
tax - tức là thuế tiền già hiện họ đang phải đóng.</p><p>Cả
ba hình thức thuế đều giản dị, dễ tính, mà không thể bị lạm dụng hoặc trốn lách
gì hết. Nhà Nước sẽ có dịp tận thu thuế, không thất thoát gì nữa, do đó dù thuế
suất thấp nhưng Nhà Nước sẽ thu được nhiều tiền hơn. Mặt trái của vấn đề mà nhiều
người nghi ngờ nhưng chưa chứng minh cụ thể được vì thiếu chi tiết là mức thu
nhập thuế như vậy thực sự có nhiều hơn không, có đủ cung ứng cho nhu cầu chi
tiêu của Nhà Nước không. Tiêu xài kiểu chính quyền Obama hiện nay thì bảo đảm
không có mức thuế nào đủ hết, chứ đừng nói đến mức có vẻ thấp mà ông Cain đề
nghị.</p><p>Nhưng
diễn giải cách nào thì cuối cùng người ta cũng thấy theo mô thức Cain, giới nhà
giàu sẽ được giảm thuế rất nhiều, trong khi giới trung lưu và giới nghèo sẽ phải
chịu gánh nặng thuế lớn hơn.Theo trung
tâm nghiên cứu Tax Policy Center, gần 85% dân trung lưu và nghèo sẽ phải đóng
thuế cao hơn mức hiện hữu. Đây là bài toán ông Cain sẽ phải giải thật rõ ràng
cho dân chúng nếu ông muốn có được phiếu của họ. </p><p>Điều
cần nói là ông Cain là người duy nhất đưa công thức thuế mới này ra. Ông Perry
cũng đã đưa đề nghị giảm thuế kinh doanh từ 35% xuống 20%, không có thuế thương
vụ, còn thuế lợi tức cá nhân thì thiên hạ có thể đóng thuế như bây giờ không
thay đổi, hoặc có thể lựa đóng 20% nhất định, không có đặc miễn gì ngoài khấu
trừ cá nhân lên tới 12.500$ một người, tức là một gia đình hai vợ chồng với hai
con sẽ được miễn thuế lới tức cá nhân hoàn toàn. Các ứng viên Cộng Hòa khác vẫn
duy trì công thức thuế hiện hành. </p><p>Nếu
vì bất cứ lý do nào ông Cainthắng được
trong nội bộ Cộng Hòa, và ra tranh cử chống TT Obama, điều e ngại lớn là ông sẽ
chỉ là miếng mồi ngon cho TT Obama thôi. Cái tài ăn nói của ông Cain chưa đủ để
hạ tài thề trăng hẹn biển của Obama. Cái mã trẻ tuổi đẹp trai hơn của Obama
cũng dễ câu khách hơn. Trong thời gian qua, ông Cain cũng đã vấp ngã mấy lần
khi đối diện với các câu hỏi có tính gài bẫy của truyền thông cấp tiến muốn triệt
hạ ông. </p><p>Ông
đã trả lời một cách hùng hồn về các vấn đề phá thai (chống phá thai nhưng lại
nói chuyện phá thai là chuyện riêng mà mấy bà có quyền quyết định), trao đổi tù
binh Do Thái (sẵn sàng thương thuyết với các nhóm khủng bố), để rồi ngay sau đó,
phải cải chính là đã nói nhầm (misspoke) vì cả hai lập trường đều đi ngược lại
quan điểm của khối bảo thủ Cộng Hoà. Cũng như ông đã nói nửa đùa nửa thật là
ông sẽ câu điện vào hàng rào dọc biên giới Mễ để ngăn cản dân Mễ nhập cảnh lậu
vào Mỹ. Tuy sau đó ông khẳng định đó là câu nói đùa, nhưng cũng đủ bảo đảm mất
hết phiếu của cử tri gốc Mễ. Chưa kể chuyện ông đang bị tố lem nhem tình dục gì
đó với hai người đàn bà cách đây rất lâu rồi.</p><p>Trong
bối cảnh của các phong trào Chiếm Phố Wall đang nổi lên chống nhà giàu, chủ
trương của ông Cain giảm thuế các đại gia xuống ngang mức của dân lao động
không khác nàotự sát chính trị. Đó là chưa nói đến chuyện ngoài vấn đề thuế
này ra thì dường như chương trình kinh bang tế thế của ông Cainchẳng có gì.</p><p>Chưa
ai biết chương trình y tế, giáo dục, ngoại giao, quân sự, chống khủng bố,của
ông là gì. Ông Cain chưa bao giờ dính dáng gì vào chính trị. </p><p>Không
được phiếu của dân da đen vẫn trung thành với TT Obama, mất phiếu của những người
nghèo cho đến nay chẳng đóng thuế gì, mất phiếu của mấy bà nội trợ mua gì cũng
thấy phải trả thêm sales tax quá cao, mất phiếu dân gốc La-tinh, mất phiếu của
những người nghi ngờ chuyện lem nhem tình dục, như vậy làm sao ông Cain vào Nhà
Trắng được" Hậu thuẫn của một thiểu số cực đoan Tea Party có thể sẽ chỉ là một
gánh nặng chứ không phải là lợi thế. </p><p>TT
Obama có thể là một tổng thống không xứng đáng được bầu lại như hơn một nửa dân
Mỹ đang nghĩ, nhưng nếu Cộng Hoà đưa ông Cain ra thì có nhiều hy vọng đang dọn
cỗ cho TT Obama có đầy đủ tiểu yến đại yến thêm bốn năm nữa. (6-11-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a179468/ong-hoa-ong-cain-va-thue-9-9-9

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/