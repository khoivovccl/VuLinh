# Chuyện Đàn Bà Hay Chuyện Trẻ Con"

15/11/2011

<p>Chuyện
Đàn Bà Hay ChuyệnTrẻ Con"</p><p>Vũ
Linh </p><p></p><p>...rầm
rộ quảng cáo, chuyện bà Michelle Obama đi chợ Target đã thành biến cố chính trị...
</p><p></p><p>Đã
lâu nay, chúng ta bàn ra tán vào chuyện thuế, chuyện tiền già, chuyện thất nghiệp,toàn là những chuyện quá nghiêm chỉnh, mãi cũng hơi nhức đầu rồi. Để thay đổi
không khí, kỳ này ta bàn chuyệnmấy bà đi shopping.</p><p>Cách
đây ít tuần, truyền thông phe ta phổ biến vài ba tấm hình chụp Đệ Nhất Phu
Nhân Michelle Obama đi mua sắm tại siêu thị Target ở Alexandria, sát nách thủ đô
Hoa Thịnh Đốn. Bà ăn mặc xuề xòa, quần bó, áo hoa hòe rẻ tiền, đội mũ baseball
xụp xuống trán, đeo kính mát to tướng che hết nửa mặt, đẩy xe chở hàng ra quầy
trả tiền. Lời bình luận kèm theo: ca tụng Đệ Nhất Phu Nhân là người bình dân,
cũng giống như hàng triệu phụ nữ khác, cũng thích đi shopping, mua hàng rẻ tiền
tại Target. Nhưng vì là nhân vật quan trọng, nên phải lén lút đi, che đầu che mặt
để thiên hạ khỏi nhận ra, tuy chưa đến nỗi đeo khẩu trang che hết cả mặt
luôn. Lời bàn cũng ghi rõ cuối cùng, chẳng ai nhận ra bà Michelle hết, ngoại trừ
cái cô ở quầy tính tiền. </p><p>Nhưng
cô này có vẻ cũng thông cảm cho bà Michelle, nên chẳng làm rùm beng và bà tổng
thống đã lặng lẽ đi shopping, trả tiền đàng hoàng, rồi ra bãi đậu xe, lên xe về
Tòa Bạch Ốc. Không thấy báo nào nói bà đi xe gì, có mấy chiếc xe mô-tô hộ tống
với cảnh sát có còi hụ chăng. Cũng không nghe nói gì về chuyện tại sao bà đi xa
như vậy, từ Tòa Bạch Ốc ra tuốt tận ngoại ô vùng Alexandria trong khi có cả chục
tiệm Target gần hơn. Có lẽ khu da trắng cao cấp Alexandria an toàn hơn khu
downtown DC. </p><p>Một
số báo phe ta đăng lại mấy tấm hình, kèm theo với đủ loại lời bàn Mao Tôn Cương,
nức nở tung hô hành động bình dân, hòa mình của Đệ Nhất Phu Nhân. Đài truyền
hình phe ta NBC trong chương trình Today, đã mau mắn bình luận Đệ Nhất Phu
Nhân cũng như chúng ta thôi! </p><p>Thật
cảm động.</p><p>Kẻ
viết này đoán chừng thế nào cũng có vài độc giả thắc mắc, thậm chí bất bình,
khi thấy bài này viết về chuyện bà Michelle đi shopping. Chuyện đàn bà, sao
mang ra bàn làm gì" Đúng là nhỏ mọn.</p><p>Thật
ra, nếu câu chuyện chỉ giản dị là chuyện bà Obama đi shopping, thì đúng làkhông đáng nói, hay không nên nói. Bà
Michelle tuy có chồng là tổng thống, nhưng vẫn có nhân quyền và nữ quyền như
hàng triệu phụ nữ bình thường khác, hay như hàng ngàn bà đại gia nổi tiếng
khác, cũng có quyền tự do cá nhân, quyền riêng tư cá nhân, có quyền hít thở
không khí tự do như bất cứ người bình thường nào, có quyền mê đi shopping như tất
cả các phụ nữ trên thế giới. Moi móc những chuyện lẩm cẩm như thế này quả đúng
là bẻm mép. Tình hình thời sự Mỹ này thiếu gì chuyện quan trọng đáng nói.</p><p>Nhưng
thực tế, vấn đề không giản dị, ngây ngô như vậy. Như thiên hạ hay nói, coi dzậy
mà hổng phải dzậy chút nào.</p><p>Ta
hãy thử coi lại câu chuyện.</p><p>Trước
hết là nhìn vào mấy tấm hình. Bà Michelle đi có một mình, không có ai khác đi
theo. Điều này là điều tuyệt đối không thể xẩy ra được. Dù muốn hay không, bà
Michelle bất cứ đi đâu cũng bắt buộc là phải tiền hô hậu ủng, có cả một đoàn
tùy tùng đi theo, không thua gì vua Càn Long nam du ngày xưa. Bây giờ cứ cho là
bà lén lút ra khỏi Tòa Bạch Ốc vì muốn thở không khí tự do, không cho đám tùy
tùng đi theo, thì tối thiểu bà cũng có ít ra là vài ba anh cận vệ đi bảo vệ an
ninh. </p><p>Oái
ăm thật, nhưng phải chấp nhận mất hết tự do cá nhân mới hy vọng làm lãnh đạo
cái xứ tự do nhất thế giới này. Tuyệt đối không thể nào có chuyện Đệ Nhất Phu
Nhân đi ra phố một mình mà không có bảo đảm an toàn tối thiểu, nhất là trong thời
buổi khủng bố Tea Party này. Bà cũng không thể nào lén ra khỏi Tòa Bạch Ốc mà
không ai biết. Đố bảo bác tài của bà dám lái xe chở Đệ Nhất Phu Nhân ra phố đi
lòng vòng mà không có bảo đảm an ninh. Đố bảo các anh lính canh Tòa Bạch Ốc dám
để xe Đệ Nhất Phu Nhân ra khỏi Toà Bạch Ốc một mình mà không báo động ngay cho
các xếp lo về an ninh, từ FBI đến mật vụ Phủ Tổng thống, đến cảnh sát tiểu
bang, thành phố, quận, phường, </p><p>Thôi
thì cứ cho là có vài ba anh cận vệ thật sự núp đâu đó đi. Có thể cũng ăn mặc giả
trang như khách hàng bình thường của Target, thay vì mặc áo vét đậm, đeo kính đen
thui, gắn máy nghe có giây chạy lòng thòng quanh tai, như ta thấy trong phim ảnh.
Mấy anh đó núp ngoài tầm nhìn của ống kính máy ảnh. Hay anh phó nhòm cố ý tránh
chụp mấy anh đó.</p><p>Một
điểm lạ lùng nữa là những bức hình cho thấy cái cô ở quầy trả tiền rất tỉnh bơ,
tính tiền bình thường như không có chuyện gì xẩy ra. Nếu ta ở Mỹ lâu, hiểu một
chút về tâm lý dân Mỹ, thì ta có thể mường tượng ngay cái cô này một khi nhận
ra Đệ Nhất Phu Nhân, bảo đảm sẽ hú hét nhẩy dựng lên không thua gì mấy bà mấy
cô trúng giải trong các chương trình khuyến mãi trên truyền hình như The Price
is Right. </p><p>Không
thể nào có chuyện bình thản tính tiền mặc dù biết đây là bà tổng thống, trừ phi
đã được thông báo và dặn dò kỹ càng trước. Biết đâu cái cô đứng két đó chính là
an ninh chìm không chừng.</p><p>Rồi
đến thắc mắc lớn nhất. Anh phó nhòm là ai, sao lại tình cờ chụp được như vậy"
Hỏi ra thì được biết đây không phải là một bức hình của một khách hàng bình thường
nào đó, tình cờ nhận ra bà Michelle rồi chụp hình và gửi cho báo chí. Anh phó
nhòm đó là ký giả chuyên nghiệp của hãng thông tấn Associated Press, tên là
Charles Dharapak. Anh này là phó nhòm được chính thức chỉ định theo chụp hình Đệ
Nhất Phu Nhân từ lâu nay. Anh cũng là người đã từng công du theo bà Michelle tại
nhiều nơi trên thế giới để chụp hình bà và hai cô công chúa.</p><p>Cho
đến nay, cả anh Dharapak lẫn Tòa Bạch Ốc đều từ chối trả lời câu hỏi làm sao
anh ta biết bà Michelle lén ra ngoài shopping, rồi đi theo và chụp được những tấm
hình này" Làm sao có chuyện tình cờ lạ lùng này được. Ông phó nhòm của hãng AP,
được chính thức chỉ định chuyên chụp hình bà tổng thống lại tình cờ đi Target
không hẹn mà gặp được bà tổng thống" Nếu không tình cờ thì làm sao anh ta biết được
bà Michelle sẽ đi Target đúng lúc để đến nơi chụp hình, nếu bà lén lút ra khỏi
Tòa Bạch Ốc không ai biết, kể cả đám tùy tùng, cận vệ của bà"</p><p>Nhưng
nếu anh ta biết trước thì có phải là do bà tổng thống đã thông báo cho anh ta
không" Và như vậy thì tất cả có phải chỉ là màn dàn dựng hết sứcthô thiển
không" </p><p>Đến
ngay cả báo phe ta Washington Post cũng phải nêu lên những thắc mắc này. Tờ báo
này còn nêu thêm chi tiết nữa là Target cũng như tất cả cửa hàng hiệu lớn, có
chính sách rất rõ rệt là cấm không ai được chụp hình trong tiệm, nếu muốn chụp
thì phải xin phép trước. Có nghĩa là anh phó nhòm chụp hình bà Michelle trong
tiệm Target đã xin phép hay thông báo trước cho ban quản lý của tiệm, và được sự
chấp thuận của Target.</p><p>Nôm
na ra, toàn thể câu chuyện Đệ Nhất Phu Nhân lén lút đi shopping một mình không
ai biết chỉ là một màn dàn cảnh rẻ tiền và dấm dớ kiểu như mấy phim bộ của đài
truyền hình Hà Nội.</p><p>Dàn
cảnh thô thiển đến độnếu nhìn kỹ bức hình, sẽ thấy bà Michelle một tay cầm
hai túi hàng, tay kia đẩy cái xe trống không"! Một độc giả của Washington Post đã
bình luận có lẽ tại bà Đệ Nhất Phu nhân không bao giờ đi shopping nên không biết
là người ta bỏ mấy túi hàng trên xe để đẩy đi chứ không ai xách bị xách gói
trên tay rồi đẩy xe không mà đi.</p><p>Tại
sao phải dàn cảnh như vậy"</p><p>Bây
giờ là mùa tranh cử, nhất cử nhất động của TT Obama đều được theo dõi chặt chẽ.
Ngay cả nhất cử nhất động của Đệ Nhất Phu Nhân hay các Đệ Nhất Công Chúa cũng đều
có thể bị - hay được - truyền thông thổi phồng lên, ảnh hưởng lên các thăm dò dư
luận, tức là lên lá phiếu của cử tri trong tương lai.</p><p>TT
Obama lúc này đang gặp khó khăn tầy trời, đang vật lộn với các tỷ lệ hậu thuẫn
thấp dưới đầu gối, và đang làm tất cả mọi chuyện cần thiết để phục hồi hậu thuẫn.</p><p>Mà
những tin tức liên quan đến bà vợ lại không lấy gì làm thuận lợi cho lắm. </p><p>Trong
thời buổi kinh tế khó khăn, gạo châu củi quế, với hàng chục triệu người thất
nghiệp xếp hàng xin foodstamps, bà Michelle đi du lịch Âu Châu, Phi Châu, hết sức
đình đám, hay đi nghỉ hè ở những bãi biển của tỷ phú, đã không tạo ra được một
hình ảnh mẫu nghi thiên hạ thu hút cử tri cho lắm. </p><p>Dư
âm chuyến đi bãi biển Tây Ban Nha và Cape Cod còn đó. Bây giờ đến chuyến đi Phi
Châu mới đây (21-27/6/2011) của bà Michelle cùng với hơn hai chục phụ tá và
thân nhân (bà mẹ, hai đứa cháu, và hai cô công chúa được liệt kê trên giấy tờ
là senior staff, có lẽ để khỏi phải trả tiền vé máy bay"), theo tổ chức
Judicial Watch đã tốn 425.000 đô tiền xăng máy bay, chưa kể tiền khách sạn, thịt
bò rượu đỏ, di chuyển, nhân viên tùy tùng làm giờ phụ trội. </p><p>Đã
vậy, mới đây, báo chí chụp hình bà đi dự bữa ăn gây quỹ tại Nữu Ước, tức là bữa
ăn tốn 70.000 đô một người (vâng, gần ba năm lương của một người dân bình thường
đi chợ Target, với lợi tức 2.000 đô một tháng) với các đại gia tài phiệt cự
phú, nên phải làm sao cho xứng đáng là Đệ Nhất Phu Nhân. Bà đã đeo nữ trang
lóng lánh, được các chuyên gia đánh giá là tốn ít nhất 40.000 đô. Đắt hơn nữ
trang của Nữ Hoàng Anh. </p><p>Trong
cái xứ của dân chủ và trong thời khủng hoảng kinh tế, đây không phải là loại
hình ảnh sẽ thu hút được lá phiếu cử tri mà TT Obama đang cần. Bị đả kích, Tòa
Bạch Ốc vội vã phân trần nữ trang này là của bà Michelle đi mượn của một tiệm
bán nữ trang thôi, chứ không phải của bà. Thế là sao" Quý bà đọc tờ báo này có
cách nào mà đi mượn nữ trang ở một tiệm kim hoàn thì mách cho chúng tôi!</p><p>Mà
bà tổng thống phải đi mượn nữ trang đắt giá của các tiệm đeo chơi một buổi tối
sao" Thế có phải trả tiền cọc nữ trang không" Sao Đệ Nhất Phu Nhân phải làm vậy"
Không có thì thôi, mắc chi phải đi mượn đeo lấy le" Nữ trang mượn tạm thì
cũng chỉ đưa ra những hình ảnh xa hoa lộng lẫy giả tạo như là một giấc mộng làm
nữ hoàng của một người chưa phải là nữ hoàng.</p><p>Hình
ảnh bất lợi cho cuộc bầu cử này cần được điều chỉnh lại. Thế là xẩy ra câu chuyện
tình cờ ăn mặc xuề xoà đi shopping tiệm rẻ tiền Target bị nhà báo bắt được,
chụp hình đưa lên báo. Có vẻ như là lộ tẩy, nhưng là lộ tẩy hết sức có lợi. Để
rồi cuối cùng, lòi ra một vụ dàn cảnh hết sức ngây ngô. Tất cả nằm trong một kế
hoạch của bộ máy tuyên truyền của tổ chức vận động tranh cử cho TT Obama.</p><p>Thật
tình mà nói, có lẽ ông hay bà cố vấn nào đã đưa cái ý kiến ngây ngô đi Target
này ra cần bị sa thải lập tức, vì tính cách xi-nê-ma, thiếu tế nhị, phản tuyên
truyền, thậm chí coi thường thiên hạ quá lộ liễu.</p><p>Được
hỏi ý kiến, một giáo sư Đại Học DePauw của tiểu bang Indiana bênh vực bà Obama,
và cho rằng không có gì chứng minh đã có sự toa rập giữa bà Michelle và anh nhà
báo Dharapak. Ai dám nói giáo sư đại học đều là những người sáng suốt"</p><p>Nói
chung, thiên hạ nhận định các chính khách hay các phu nhân từ cách xử thế chung
qua một thời gian lâu dài, chứ không ngây ngô đánh giá ai qua một hành động hay
một cử chỉ nào đó. Không ai có thể nói bà Laura Bush là cao xa phách lối, cũng
như không ai có thể nói bà Jackie Kennedy là bình dân không quý phái, hay bà
Hillary Clinton là hiền lành yểu điệu. Cũng không ai có thể nói bà Michelle
Obama là người thích ăn mặc lôi thôi đi shopping tiệm rẻ tiền. Nhưng đó là những
chuyện về cá tính mỗi người. Nhân vô thập toàn, ta không nên phê bình cá tính của
mỗi người. </p><p>Chuyện
mấy bà thích đi shopping không phải là đề tài bình luận chính trị. Hơn thế nữa,
đây không phải là lần đầu tiên một Đệ Nhất Phu Nhân ra ngoài phố đi chơi, đi ăn,
hay đi thăm dân tình. Các bà Laura Bush và Hillary Clinton đều làm như vậy nhiều
lần. Nhưng chưa bao giờ ta thấy báo chí chụp hình, đăng tin rồi nức nở ca tụng
tính bình dân hòa mình của các đệ nhất phu nhân như lần này với bà Michelle.</p><p>Vấn
đề ở đây là các cố vấn của TT Obama đã biến bà tổng thống thành công cụ quảng
bá chính trị, công cụ tranh cử để lấy điểm với cử tri.Nhờ báo phe ta rầm rộ quảng cáo, chuyện bà
Michelle Obama đi chợ Target đã thành biến cố chính trị. Nếu là biến cố chính
trị thì chúng ta có quyền bình loạn chơi. Mọi người đều có quyền khen chê.
Riêng với kẻ viết này, rõ ràng đây không phải là chuyện đàn bà, mà chỉ là chuyện
trẻ con ấu trĩ nhất.</p><p>Chuyện
trẻ con đúng ra thì không đáng nói, không cần nói, không nên nói, nhưng ở đây vẫn
phải nói vì là chuyện trẻ con từTòa Bạch Ốc. Có thể có ảnh hưởng đến việc bầu
người lãnh đạo tối cao cái xứ này. Trong cái chế độ dân chủ kiểu Mỹ này, người
ta có thể đắc cử làm tổng thống hay thất cử về quê câu cá, vì những chuyện trẻ
con. Vì vậy mà các chính khách ra tranh cử cũng sẵn sàng dùng những mánh khoé
trẻ con dấm dớ nhất để ra tranh cử, nhất là khi đang gặp khó khăn. Đó chính là
câu chuyện Đệ Nhất Phu Nhân đi Target. (13-11-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a179762/chuyen-dan-ba-hay-chuyen-tre-con

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/