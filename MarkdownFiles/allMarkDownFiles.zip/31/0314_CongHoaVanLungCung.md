# Cộng Hòa Vẫn Lủng Củng

22/11/2011

<p>Cộng
Hòa Vẫn Lủng Củng</p><p>Vũ
Linh</p><p></p><p>Chỉ
có hai ông Romney và Gingrich mới có đủ khả năng tranh luận cùng Obama...</p><p></p><p>Còn
chưa tới hai tháng nữa là sẽ có cuộc bầu sơ bộ đầu tiên tại Iowa để chọn ứng
viên tranh cử tổng thống cho hai chính đảng Cộng Hòa và Dân Chủ. Bên Dân Chủ
thì TT Obama không có đối thủ nên sẽ độc tấu. Cho dù chê bai hay bất mãn đến đâu
thì đảng Dân Chủ cũng không dám cho về vườn ông tổng thống da đen đầu tiên của
họ. Bên Cộng Hoà thì vẫn như chợ cá. </p><p>Các
ứng viên nổi lên rồi lặn xuống mỗi tháng như làcá nhẩy qua khỏi mặt nước! Đột
bay đột lặn. Tháng Tám là bà dân biểu Michele Bachmann, tháng Chín là thống đốc
Texas Rick Perry, tháng Mười là doanh gia Herman Cain, bây giờ tháng Mười Một
là cựu chủ tịch Hạ Viện Newt Gingrich.</p><p>Ông
Perry từ trong bóng tối nhẩy ra, leo lên hàng đầu trong vài ngày, thay thế bà
dân biểu Bachmann, nhưng rồi bắt đầu lặn ngay trong mấy tuần sau, qua hàng loạt
thất bại trong các cuộc tranh luận trên truyền hình. Ông lên truyền hình mà
không có chuẩn bị kỹ càng cho lắm, tuyên bố vung vít những câu có tính mỵ dân
mà không có chiều sâu. Nhưng lý do quan trọng nhất khiến ông rớt đài mau chóng
là khối bảo thủ khám phá ra ông thống đốc Perry đã ra luật cho phép con của dân
ở lậu gốc Nam Mỹ được học tại các trường công miễn phí tại Texas. Tuy quyết định
này có tính cách ôn hòa và thực tế, nhưng đi ngược lại quan điểm của khối bảo
thủ cực đoan chỉ muốn trục xuất triệu dân Mễ ở lậu ra khỏi nước Mỹ. Khối bảo thủ
này cũng không chấp nhận chuyện dân Mỹ đóng thuế cho con di dân lậu đi học miễn
phí.</p><p>Nhưng
viên đạn thi ân cuối cùng dường như đã do chính ông Perry bắn vào mình trong cuộc
tranh luận tại Michigan gần đây khi ông mạnh mẽ đả kích sự lớn mạnh của guồng
máy thư lại Nhà Nước, quả quyết sẽ giải tán ba bộ, là Bộ Thương Mại, Bộ Giáo Dục
và " Ông quên mất cái bộ thứ ba là bộ nào. Trong 54 giây mà sau này ông kể lại
là có vẻ như 54 năm, ông không tài nào nhớ nổi cái bộ thứ ba ông muốn cắt bỏ là
bộ nào. Ông coi lại đống giấy trước mặt, cũng không có ghi gì, đành phải xin lỗi
cử tọa. Cái clip đoạn phim ông luống cuống được phổ biến rộng rãi trên YouTube
và hàng triệu người đã nhẩy vào xem, biến thành trò cười của tháng Mười Một
-joke of the month. Chính ông Perry để gỡ rối, cũng biến câu chuyện thành truyện
tiếu lâm, tự mang mình ra chọc quê.</p><p>Ông
Perry trước đó đã bị truyền thông phe ta mô tả như là một người không thông
minh cho lắm, không có chiều sâu, đại khái cũng lại là một anh cao bồi giỏi chăn
bò, tốt nghiệp trường làng tại Texas, chứ không phải dân đại trí thức Harvard
hay Yale như các thiên tài Dân Chủ Clinton hay Obama. Báo chí và truyền hình
phe ta khai thác triệt để, thêm mắm thêm muối đến mặn chát. Bây giờ câu chuyện
mất trí nhớ theo họ chỉ xác nhận hệ số thông minh IQ của ông Perry không được
cao lắm, mặc dù các nhà phân tâm học đã khẳng định chuyện nhất thời bị lỗ hổng
trí nhớ không liên quan gì đến chuyện thông minh hay u tối. </p><p>Thực
tế mà nói, hy vọng của ông Perry coi như tiêu tan. Cho dù ông thắng được trong
nội bộ Cộng Hòa, sau này ra tranh luận với TT Obama thì sẽ bị nuốt chửng thôi.</p><p>Ông
Cain thì nổi lên như diều gặp bão nhờ chủ trương giảm thuế mạnh, được ngay hậu
thuẫn của đảng viên bảo thủ cực đoan trong nhóm Tea Party. Nhưng qua các cuộc
tranh luận liên tục trên truyền hình, nhất là lần tranh luận mới đây về chính
sách đối ngoại, ông Cain chứng minh là một doanh gia có thể đã rất thành công,
và là người có cách nói chuyện dễ tạo cảm tình, dễ thu hút, nhưng quả là không
có chút kinh nghiệm chính trị nào, nhất là kinh nghiệm về đối ngoại. Ông Cain
cho đến bây giờ vẫn không biết là Trung Cộng đã có thử bom nguyên tử từ thời
Mao còn sống, cách đây gần bốn thập niên!</p><p>Rồi
mới đây, trong một cuộc phỏng vấn, được hỏi về vấn đề Libya, ông ấp úng không
biết trả lời thế nào, đành phải thú nhận tôi cần tìm hiểu nhiều hơn về chuyện
này.</p><p>Quan
trọng hơn nữa, ông bị liên tục bốn bà tố giác đã có lời nói, thậm chí hành động
có tính lem nhem tình dục. Mặc dù ông gân cổ cải chính, nhưng điều đáng phiền
là có tới bốn bà tố cáo. Một hay hai người thì còn châm chế được, bốn người thì
cần xét lại. Dân Mỹ đã xét lại và hậu thuẫn của ông Cain bắt đầu xuống thang
nhanh chóng tuy chưa đến mức độ có thể loại ông ra khỏi cuộc chạy đua. Đặc biệt
là trong khối bảo thủ coi trọng những giá trị luân lý gia đình, và khối cử tri
phụ nữ.</p><p>Thiên
hạ những tưởng với ngôi sao mới Cain bắt đầu lu mờ thì ngôi sao cũ Rick Perry sẽ
sáng tỏ. Dù sao thì khối bảo thủ trong đảng Cộng Hoà cũng không hồ hởi lắm với
cựu thống đốc Massachusetts Mitt Romney, nên vẫn muốn tìm người bảo thủ hơn. Thực
tế đã có nhiều bất ngờ hơn thiên hạ nghĩ. Ông Perry tiếp tục tự hủy mình.</p><p>Dân
Mỹ bèn quay qua tìm người khác, và khám phá ra thêm một nhân vật mới thật. Đó
là ông Newt Gingrich. Đúng ra ông Gingrich chẳng phải là người mới mẻ gì trong
chính trường Mỹ. </p><p>Ông
Gingrich năm nay 68 tuổi, là chính khách thuộc loại lão làng. Năm 1994, ông nổi
như cồn, lãnh đạo ngọn cuồng phong Cộng Hòa, tung ra chương trình Contract with
America, chiếm lại đa số cho Cộng Hòa tại Hạ Viện sau 42 năm ngồi chầu rìa. Sau
đó, ông được bầu làm chủ tịch Hạ Viện, nhân vật đứng hàng thứ ba trong chính
quyền Mỹ, sau tổng thống và phó tổng thống. Ông là người chủ động cuộc đàn hạch
TT Clinton trong vụ lem nhem với cô Monica Lewisnky. Ông cũng là người công
khai chống kế hoạch tiêu xài của TT Clinton, không cho Hạ Viện phê chuẩn ngân
sách, đưa đến việc hai lần guồng máy Nhà Nước bị đóng cửa mất mấy ngày. Người
ta nói ngân sách của Clinton được cân bằng phần lớn là do công của ông Gingrich
đã kéo tay TT Clinton lại, không cho ông Dân Chủ này xài hoang.</p><p>Ông
bị phe Dân Chủ tìm đủ cách đánh nặng, tố cáo ông 84 lần vi phạm đủ thứ tội, nhất
là lem nhem tiền bạc, trốn thuế. Nhưng cả 84 vụ đều thất bại và những tố cáo đều
bị các ủy ban điều tra Hạ Viện bác bỏ. Vụ tố quan trọng nhất là vụ ông giảng dạy
về chính trị tại một trường tư thục được hưởng quy chế miễn thuế. Trên căn bản
vì được miễn thuế nên trường này không được dạy chính trị phe đảng. Tháng Giêng
năm 1997, ông bị Hạ Viện biểu quyết cảnh cáo ông thiếu cẩn trọng đã không tham
khảo ý kiến luật sư trước khi nhận dạy. Nhưng rồi sau đó, đến năm 1999, ngay cả
vụ tố giác này cũng bị bác bỏ khi sở thuế IRS xác nhận ông không hề vi phạm luật
thuế.</p><p>Chuyện
nổi bật hơn cả là trong khi ông Gingrich ban ngày lớn tiếng tố giác TT Clinton
lem nhem với Monica, đòi cất chức Clinton, thì ban đêm ông lại đi hú hý với cô
thư ký. Đây là lần thứ hai ông Gingrich đi ăn phở. Ông đã đi ăn phở với người vợ
đầu, rồi ly dị khi bà này đang bị ung thư, có bà vợ thứ hai, vẫn chứng nào tật
nấy, lại đi ăn phở nữa với một bà phụ tá, để rồi ly dị vợ thứ hai, lấy bà phụ
tá. Truyền thông phe ta, vừa muốn bênh TT Clinton vừa muốn đánh Gingrich, nên đả
kích ông Gingrich thậm tệ, tố cáo ông này giả dối. </p><p>Ông
cũng là người bị chỉ trích vì rất nhiều chuyện khác, như hợp tác với kẻ thù
là bà Nancy Pelosi của Dân Chủ, với Louis Farakhan, lãnh tụ nhóm Hồi Giáo quá
khích Nation of IslamThêm vào đó, đảng
Cộng Hoà cũng thất bại trong mùa tranh cử 1998, mất ghế tại Hạ Viện. Thế là cuối
cùng ông cũng bị đánh gục. Ông Gingrich từ chức chủ tịch Hạ Viện, cũng từ chức
dân biểu luôn năm 1998. </p><p>Đến
bây giờ mới tái xuất giang hồ, tranh cử tổng thống. Ông bắt đầu cuộc tranh cử tổng
thống lần này với tỷ lệ hậu thuẫn cỡ 1-2%, ì ạch mãi mới leo lên 5-7%, rồi khoảng
10%. Rồi bất ngờ đến nay thì leo lên hàng đầu với 23%, ngang hàng với ứng viên
hàng đầu từ trước đến giờ là Mitt Romney, bỏ xa các ngôi sao đã lặn như Michele
Bachmann, Rick Perry, và Herman Cain. Tại tiểu bang then chốt có bầu cử sơ bộ đầu
tiên, ôngđược hậu thuẫn của 34%, bỏ xa
luôn cả ông Romney.</p><p>Sự
nổi bật của ông là hậu quả của những sai lầm và rắc rối liên tục của những ngôi
sao mới lặn, của việc đa số đảng viên Cộng Hòa vẫn chưa tin tưởng ông Romney,
và nhất là thành quả của ông Gingrich trong các cuộc tranh cãi trên truyền
hình. Thiên hạ đã có dịp thấy ông Gingrich là bảo thủ đáng tin cậy, là người hiển
nhiên có kinh nghiệm chính trị dầy đặc, có đầu óc, khả năng lý luận, và nghiêm
chỉnh. Ông là một người có lập trường vững vàng, không chao đảo như ông Romney.</p><p>Chưa
ai biết trò xiếc tranh cử Cộng Hòa sẽ đi về đâu, ai nổi ai lặn. Nhưng nhiều
quan sát viên đã nhận định nếu phải ra tranh luận trước truyền hình thì các ông
Perry và Cain, với sự thiếu hiểu biết về chính trị và thiếu khả năng ứng phó
mau lẹ, sẽ bị TT Obama nuốt sống dễ dàng. Chỉ có hai ông Romney và Gingrich mới
có đủ khả năng tranh luận cùng Obama. Và ai cũng biết trong thời đại truyền hình
hiện nay, các cuộc tranh luận trên truyền hình đều có tính quyết định rất lớn.</p><p>Nếu
ông Gingrich đắc cử là đại diện cho Cộng Hòa để chạy đua với TT Obama thì ông
có nhiều lợi điểm nhưng cũng không thiếu yếu điểm.</p><p>Điểm
mạnh lớn của ông Gingrich là từ hai yếu tố. </p><p>Thứ
nhất là hậu thuẫn của TT Obama ngày càng tuột dốc mau lẹ. Đáng chú ý nhất là đối
với hơn hai phần ba dân Mỹ, kinh tế là yếu tố quan trọng nhất trong cuộc tranh
cử tổng thống này. Trong khi đó thì lại có tới 62% dân Mỹ không ủng hộ chính
sách kinh tế của tổng thống. Trong ba người, chỉ có một người (34%) ủng hộ
chính sách kinh tế này. Gần 70% không thấy chỉ dấu nào chứng tỏ tổng thống đã bắt
đầu phục hồi được kinh tế sau gần ba năm loay hoay. Và 56% không còn tin tưởng
-no confidence- nơi TT Obama. Không cần biết lỗi phải tại đâu, họ chỉ biết TT
Obama thực tế không có khả năng phục hồi kinh tế. Một bác sĩ mát miệng nhưng
không mát tay.</p><p>Ngay
cả trong nội bộ Dân Chủ, hậu thuẫn của TT Obama cũng suy yếu rất nhiều. Đã có
ít nhất bốn thượngnghị sĩ Dân Chủ công
khai đặt vấn đề với TT Obama và từ chối không lên tiếng hậu thuẫn tổng thống
trong mùa tranh cử. Có báo đã nói xa nói gần về chuyện bà Hillary nên nhẩy ra
làm Lê Lai cứu đảng Dân Chủ.</p><p>Yếu
tố thứ hai là thiên hạ qua ba năm với TT Obama bắt đầu nhìn thấy tính quan trọng
của kinh nghiệm thực tế. Ba năm sống trong hão huyền của những thề trăng hẹn biển
của TT Obama cùng với việc ông hoàn toàn bất lực trong việc phục hồi kinh tế và
giảm tỷ lệ thất nghiệp, đã làm cho thiên hạ đánh giá cao hơn kinh nghiệm chính
trị thực tế của ông Gingrich.</p><p>Nhược
điểm lớn nhất là ông Gingrich có rất nhiều hành trang từ quá khứ. Truyền thông
dòng chính, vốn ủng hộ các ứng viên cấp tiến Dân Chủ và vẫn thần phục TT Obama,
sẽ lôi ông ra làm thịt kỹ lưỡng. Hiện tượng này đã bắt đầu. Các báo Washington
Post và New York Times, cũng như các diễn đàn điện tử như Salon đã viết bài
khui lại hàng loạt thành tích không vẻ vang gì của ông Gingrich cách đây cả hai
chục năm.</p><p>Bây
giờ thì các báo đang lớn tiếng khui móc ông Gingrich đã lãnh gần hai triệu đô
làm cố vấn cho Freddie Mac là tổ chức tín dụng gia cư của Nhà Nước, đã bị
mang tiếng là một trong những thủ phạm cho vay bừa bãi, tạo ra khủng hoảng tài
chánh năm 2008. Điều đáng nói là cái truyền thông dòng chính đó lớn tiếng bôi
bác ông Gingrich, nhưng lại im lặng không đả động đến chuyện thượng nghị sĩ
Obama trước đây cũng đã nhận một triệu đô yểm trợ của Freddie Mac. </p><p>Thực
tế mà nói, ông bà chính khách Mỹ nào mà từ chối không nhận tiền của các đại gia
hình như chưa ra đời.</p><p>Tuy
nhiên, nếu ông đắc cử được trong nội bộ đảng Cộng Hòa thì điều đó chứng minh
thiên hạ đều biết quá rõ các vấn đề rắc rối của ông Gingrich, và họ cho thông
qua. Cuộc chạy đua trong nội bộ Cộng Hòa đã mổ xẻ các ứng viên Cộng Hòa kỹ lưỡng,
tạo cảm tưởng mấy ông bà Cộng Hòa đánh nhau như mổ bò, nhưng thực tế lại rất hữu
dụng cho người nào thắng cuộc. Những điểm yếu của họ đã bị phơi bày và bới móc
tối đa nên và khi ra tranh cử chống TT Obama, thì sẽ bớt ảnh hưởng tác hại rất
nhiều. Có nghiã là TT Obama sẽ khó tấn công vào những điểm mà tất cả mọi người đều
đã nghe quá nhiều rồi.</p><p>Kinh
nghiệm thực tế cho thấy khi tranh cử sơ bộ trong nội bộ đảng Dân Chủ, ông
Clinton đã bị moi móc quá nhiều về những chuyện lem nhem ăn phở của ông, nên
khi vào chung kết với TT Bush cha, yếu tố đào hoa này không còn là đề tài tranh
cử nữa. TT Obama cũng vậy, bị khui những vụ quan hệ với mục sư quá khích
Jeremiah Wright và giáo sư khủng bố Bill Ayers khi còn chạy đua với bà Hillary,
nên khi chạy đua cùng ông Cộng Hoà McCain, thì hai vấn đề này không hại ông được
nữa. Ngay cả chuyện thiếu kinh nghiệm của ứng viên Obama cũng đã bị bà Hillary
khai thác quá nhiều, nên đến khi tranh cử chống thượng nghị sĩ lão thành
McCain, thì chuyện thiếu kinh nghiệm cũng hết là yếu tố quyết định.</p><p>Nói
tóm lại, nếu ông Gingrich vượt qua được cửa ải nội bộ Cộng Hòa ông có hy vọng
thượng đài ngang ngửa với TT Obama, nhiều hy vọng hơn các ông Perry và Cain. Nhưng
nhìn vào cảnh lửa rơm bộc phát trong thời gian qua trong đảng Cộng Hòa, cũng
khó mà biết được ông Gingrich có thọ hay không. Hay sẽ lại xì hơi trong vài tuần
nữa, và cuối cùng cũng chỉ còn ông Romney mà cử tri bảo thủ sẽ phải liều bỏ phiếu
như uống thuốc đắng. (20-11-11)</p><p>Vũ
Linh</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a180060/cong-hoa-van-lung-cung

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/