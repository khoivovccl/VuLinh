# Những Mối Lo Của TT Obama

28/02/2012

<p></p><p></p><p>Syria
khác xa Libya, không có nhiều dầu hỏa và dầu khí như Libya, mà chỉ là sa mạc...</p><p>Trong
tình trạng xào xáo gia cang bên Cộng Hòa hiện nay, TT Obama có vẻ đương nhiên
tái đắc cử, kiểu như sáng mai mặt trời vẫn mọc như thường. Thực tế, chẳng có gì
đương nhiên hết. Cho dù bên Cộng Hòa mạnh hay yếu, vẫn có những yếu tố khác quyết
định cuộc bầu cử cuối năm. Từ giờ đến tháng Mười Một, không thiếu gì chuyện bất
ngờ có thể xẩy ra thay đổi cuộc diện.</p><p>Chúng
ta có thể điểm qua một cách thật sơ xài.</p><p>KINH
TẾ MỸ</p><p>Suốt
ba năm qua, ưu tư lớn nhất của dân Mỹ là kinh tế. TT Obama nhậm chức đúng lúc
kinh tế Mỹ và cả thế giới bước vào chu kỳ khủng hoảng. Ứng viên Obama nhận thức
được vấn đề và luôn tố giác đây là cuộc khủng hoảng lớn nhất từ đầu thế kỷ hai
mươi. Nhưng ông vẫn quả quyết có khả năng giải quyết vấn đề trong vòng ba năm,
tức là tính đến ngày hôm nay là phải xong xuôi hết rồi. Hiển nhiên là TT Obama đã
không thực hiện được lời hứa.</p><p>Thất
nghiệp vẫn dây dưa ở những mức cao nhất tuy đã hạ xuống phần nào. Hiện nay tỷ lệ
thất nghiệp là 8,3% và có triển vọng tiếp tục xuống nữa. Nếu được như vậy thì sẽ
bớt được một gánh nặng lớn cho tổng thống.</p><p>Tỷ
lệ tăng trưởng kinh tế thì vẫn ì ạch ở mức thật thấp, trên dưới 2% một năm từ
ba năm qua. Nhưng thị trường chứng khoán thì có vẻ lạc quan vì trong năm qua, đã
từ từ leo lên những mức của đầu năm 2008, trước cuộc khủng hoảng.</p><p>Thị
trường chứng khoán phản ánh một tình trạng kinh tế phục hồi nhưng không kéo
theo việc làm. Giá cổ phiếu tăng nhờ các công ty hoạt động có lời nhiều qua việc
cắt giảm nhân công, do đó, sẽ tiếp tục đường hướng này. Cựu bộ trưởng Lao Động
của TT Clinton, ông Robert Reich nhận định rằng một số lớn việc làm đã mất sẽ
không trở lại. Nói cách khác, mặc dù kinh tế đã phục hồi phần nào, và có thể tiếp
tục phục hồi trong những tháng tới, vấn đề thất nghiệp vẫn không thể giải quyết
được, và đến ngày bầu cử, tỷ lệ thất nghiệp khó có thể xuống thấp hơn 8%. Đây
là tin không vui cho TT Obama. </p><p>Trong
lịch sử cận đại Mỹ, không có vị tổng thống nào được bầu lại khi tỷ lệ thất nghiệp
cao hơn 7%. Đã vậy, theo Gallup, tỷ lệ thất nghiệp của Tháng Hai này đã leo lên
9% trở lại rồi.</p><p>Trong
khi đó thì giá sinh hoạt trở nên ngày càng đắt đỏ vì giá nhiên liệu ngày càng
cao.</p><p>Giá
dầu xăng hiện nay đã lên đến mức kỷ lục, mà lại không có vẻ sẽ suy giảm. Giá
trung bình một ga-lông xăng thường đã lên đến 3,65 đô. So sánh với giá tháng
Hai năm 2009 là 1,89 đô thì đã tăng 93%, chưa kể giá này có triển vọng lên đến
4,25 đô vào Tháng Tư, rồi cao hơn nữa vào mùa hè. Đây là giá trung bình toàn quốc,
riêng tại Cali, giá trung bình đã cao hơn 4 đô rồi, thậm chí có một cây xăng tại
vùng Miracle Mile bán xăng thường -regular- với giá 4,99. Đây cũng là nói chuyện
tình trạng bình thường. </p><p>Nếu
có biến cố lớn tại Trung Đông -sẽ bàn đến ở phần dưới- thì giá xăng có thể leo
lên hơn 6 đô dễ dàng. </p><p>Giữa
năm 2008, vì tình trạng đầu cơ của những tay buôn trên thế giới, giá xăng nhất
thời vọt lên gần 4 đô, và báo chí xúm lại đổ lỗi cho TT Bush cố tình đẩy giá
lên để các công ty dầu hỏa trục lợi. Chỉ vài tuần sau là giá xăng rớt xuống mức
bình thường, không ai rút lại lời chỉ trích Bush hết. Bây giờ, giá xăng từ từ
leo thang một cách chắc hơn định đóng cột, không có triển vọng xuống thấp gì hết,
nhưng không ai nghe truyền thông nói TT Obama thông đồng tăng giá làm giàu cho
tài phiệt dầu hỏa. Chỉ nghe thấy những đổ thừa. </p><p>Hết
mùa đông quá lạnh tại Âu Châu, đến tình trạng căng thẳng ở Trung Đông, rồi tới
chuyện dân Ấn Độ đẻ nhanh quá,khiến người ta có cảm tưởng Obama được bầu làm
tổng thống không phải để giải quyết những vấn đề mà chỉ để ngồi giải thích và
phân trần.</p><p>Dù
sao đi nữa thì tình trạng giá dầu xăng leo thang sẽ có những hậu quả nghiêm trọng.
Chẳng những thiên hạ phải chi tiền nhiều hơn để đổ đầy bình xăng, các công ty,
hãng xưởng sẽ thấy chi phí nhiên liệu tăng, đưa đến giảm lợi nhuận, cắt giảm
nhân công thêm nữa, và tăng giá bán. Tức là tình trạng kinh tế sẽ không khả
quan hơn mà còn có nguy cơ đi vào khủng hoảng trở lại. Nếu TT Obama không tìm
ra được phương thức nào kềm giá dầu xăng thì vấn đề này sẽ là đe dọa lớn nhất
cho cuộc tranh cử của ông. </p><p>Có
một vấn đề khác còn nghiêm trọng hơn nữa, mà dân Mỹ có vẻ vẫn chưa ý thức được
tầm mức quan trọng vì không có tác dụng trực tiếp trước mắt. Đó là chuyện thâm
thủng ngân sách và công nợ leo thang.</p><p>Ứng
viên Obama long trọng cam kết sẽ cắt giảm một nửa thâm thủng ngân sách trong
vòng một nhiệm kỳ. Khi đó ngân sách bị thâm thủng ở mức một ngàn tỷ. Có nghĩa
là trong năm tới, ngân sách sẽ chỉ thâm thủng khoảng năm trăm tỷ theo lời cam kết
của ứng viên Obama. Bây giờ, TT Obama mới công bố ngân sách cho năm cuối của
nhiệm kỳ: sơ sơ thâm thủng hơn 1.300 tỷ, gần gấp ba lần mức thâm thủng ông hứa
hẹn khi tranh cử. </p><p>Mức
công nợ trong ba năm của TT Obama đã tăng bằng mức công nợ của tất cả 43 vị tổng
thống tiền nhiệm cộng lại. Cho dù phải tính việc đồng tiền mất giá liên tục từ
hơn hai trăm năm qua, thì cũng không thể biện minh được chuyện vay mượn một
cách quá đáng như vậy được.</p><p>Quá
đáng ở đây là nhận định không phải của kẻ viết này, mà là của các chuyên gia
tài chánh thế giới và các cơ quan thẩm định quốc tế. Họ sẽ là những người quyết
định điểm tín dụng của Mỹ, cũng như giá trị đồng đô trên thị trường thế giới,
là những yếu tố hiển nhiên có tác dụng lớn trên kinh tế Mỹ, rồi từ đó, ảnh hưởng
đến mức lạm phát, phục hồi kinh tế, và tạo công ăn việc làm.</p><p>Từ
giờ đến cuối năm, nếu điểm tín dụng lại bị hạ, đồng đô tiếp tục mất giá và cán
cân thương mại tiếp tục bị thâm thủng, thì triển vọng tái đắc cử của TT Obama sẽ
thật mong manh.</p><p>Chưa
kể nếu Tối Cao Pháp Viện tuyên cáo luật cải tổ y tế vi phạm Hiến Pháp và cần hủy
một phần hay toàn bộ thì coi như ba năm Obama đã chẳng có gì để chứng minh ông đã
làm được gì xứng đáng để được bầu lại. </p><p>LÒ
THUỐC NỔ TRUNG ĐÔNG</p><p>Trong
thời gian tranh cử năm 2008, Nghị sĩ Hillary Clinton tung lên cái quảng cáo để đời,
gọi là ba giờ sáng, đặt thẳng vấn đề TT Obama sẽ không đủ kinh nghiệm ứng phó
với những biến cố bất ngờ lớn trên chính trường quốc tế. </p><p>Ngày
nay hơn bao giờ hết, thế giới đang trực diện với nhiều biến chuyển vĩ đại, với
những hậu quả khó ai lường được.</p><p>Chuyện
lớn nhất hiển nhiên là chuyện Iran đang đạt được thành quả lớn trong việc xây dựng
hệ thống vũ khí nguyên tử, và việc Iran làm được bom nguyên tử không còn là
chuyện được hay không, mà đã thành chuyện khi nào được. Cả thế giới biết rõ
nguy cơ Do Thái sẽ phải trực diện và cả thế giới cũng biết Do Thái sẽ phản ứng
như thế nào. Không ai nghĩ Do Thái sẽ khoanh tay ngồi chờ ngày Iran có bom
nguyên tử và dùng bom đó để diệt Do Thái. Câu hỏi là chừng nào thì Do Thái sẽ đánh
Iran.</p><p>TT
Obama đang cố tìm cách trấn an Do Thái và tạo áp lực lên Iran, nhưng không thấy
được kết quả gì khả quan. Đối với Do Thái, tiếng nói của TT Obama không nặng ký
gì cho lắm, vì chính sách vuốt ve khối Ả Rập của ông khiến Do Thái không còn
tin tưởng vào Mỹ nữa. Trong khi đó thì những áp lực đè lên Iran chỉ làm cho mấy
giáo chủ quá khích nổi khùng hơn thôi. Những biện pháp phong tỏa kinh tế từ Mỹ
và các đồng minh Âu Châu cho đến nay vẫn chẳng có tác dụng gì. Các giáo chủ đã
lên tiếng cảnh cáo, đến một mức nào đó mà Iran chịu không nổi thì họ sẽ phải phản
công, sẽ cắt eo biển Hormuz. Đây là hải lộ huyết mạch của hàng triệu tấn dầu hỏa
từ Trung Đông đi ra thế giới mỗi ngày.</p><p>Do
Thái mà đánh Iran thì chắc chắn Hormuz sẽ bị Iran phong tỏa, chưa kể đến chuyện
Iran có thể bắn hàng loạt hoả tiễn qua Do Thái. Khi đó thì giá dầu xăng có tăng
gấp đôi trong vòng vài ngày cũng không có gì là lạ. Cử tri Mỹ sẽ phản ứng như
thế nào nếu giá xăng vọt lên năm hay sáu đô một ga-lông vài tuần trước ngày bầu
cử?</p><p>Điều
đáng lo ngại là kho dầu của thế giới đang ở trong tình trạng cực kỳ bất an, chẳng
những vì vấn đề Iran - Do Thái, mà còn vì nhiều lò thuốc súng khác có thể nổ
tung bất cứ lúc nào tại đây.</p><p>Tình
hình Syria nổi bật rõ ràng nhất. Trong gần một năm qua, dân chúng liên tục nổi
dậy chống chế độ độc tài cha truyền con nối ở đây. Cho đến nay, thế giới và TT
Obama đã nhắm mắt coi như không nhìn thấy gì hết và chẳng dám ho he gì hết.</p><p>Tại
Libya trước đây, Mỹ và Âu Châu lấy cớ có vài trăm quân nổi dậy bị đe dọa tiêu
diệt bởi Khaddafi nên đã dùng biện pháp quân sự thanh toán Khaddafi luôn. Bây
giờ, không phải là vài trăm người có thể bị giết, mà là cả chục ngàn người dân đã
và đang bị giết tại Syria mà TT Obama vẫn bình chân như vại, không còn lớn lối
tuyên bố những giá trị luân lý của Hiệp Chủng Quốc không cho phép chúng ta
khoanh tay ngồi nhìn người dân vô tội bị giết. </p><p>Chính
sách của Mỹ hiện nay là khua chiêng gõ trống cho có lệ, nhưng tuyệt đối không
nhúc nhích. Các giá trị luân lý mà TT Obama từng nêu ra có lẽ đã thay đổi theo
kiểu Change We Can Believe In?</p><p>Bà
ngoại trưởng Hillary tuyên bố Mỹ không thể can thiệp được tại khắp thế giới. Quả
đúng như vậy vì Syria khác xa Libya, không có nhiều dầu hỏa và dầu khí như
Libya, mà chỉ là sa mạc. Nhưng dĩ nhiên, không ai dám nói Mỹ và Âu Châu can thiệp
vào Libya vì dầu hỏa mà phải dùng đến bình phong nhân đạo, cứu vài trăm người.
Một cái bình phong thô thiển mà giới truyền thông dòng chính hết mình phô trương
dùm cho chính quyền Obama mà không thiếu gì người ngây ngô đã tin.</p><p>Quan
trọng hơn cả Libya lẫn Syria là Ai Cập. Trước đây, Ai Cập với TT Mubarak là đồng
minh lớn nhất của Mỹ, cũng là nước chủ chốt duy trì hòa bình và ổn định tại
Trung Đông qua một chính sách thân thiện với Do Thái. Bây giờ, sau khi TT Obama
không dám có phản ứng, để nhóm Hồi Giáo quá khích Muslim Brotherhood lật đổ TT
Mubarak, thì tình hình trở nên bất ổn. Quân đội hiện đang nắm quyền, nhưng chịu
áp lực mạnh của Hồi giáo quá khích khi các nhóm này chiến thắng qua các cuộc bầu
cử mới đây. Các tướng lãnh bắt buộc phải chứng tỏ mình không quá lệ thuộc vào Mỹ
bằng cách hăm he đe doạ Do Thái, mở cửa kinh đào Suez cho tàu chiến Iran qua lại,
có thể đánh úp Do Thái từ phía biển, và đưa ra tòa năm chục chuyên gia thiện
nguyện ngoại quốc trong đó có gần hai chục người Mỹ, vì vài tội mập mờ liên
quan đến an ninh quốc gia.</p><p>Cả
vùng Trung Đông đã trở thành lò thuốc súng có thể nổ tung bất cứ vào nửa đêm
nào, và cho đến nay, ba năm sau khi đã làm tổng thống, TT Obama vẫn chưa khiến
thiên hạ yên tâm ông sẽ có khả năng đối phó. Những tháng tới sẽ là những thử
thách lớn cho tổng thống.</p><p>KHỦNG
HOẢNG ÂU CHÂU</p><p>Khối
Liên Hiệp Âu Châu đang trong cơn khủng hoảng lớn nhất với nguy cơ tan vỡ toàn
diện. Từ Hy Lạp đến Tây Ban Nha, Bồ Đào Nha, Ý Đại Lợi, Bỉ, Aí Nhĩ Lan, Anh,...
hàng loạt các nước chìm ngập trong chế độ bao cấp đang bị khủng hoảng nặng. Các
nước bị bệnh nhẹ hơn như Pháp, Đức, Bắc Âu,... thì lo tranh cãi về biện pháp giải
quyết.</p><p>Trước
tình trạng kinh tế nội bộ bết bát hiện nay, Mỹ không đủ tư cách chỉ đạo hay cố
vấn Âu Châu làm sao giải quyết khủng hoảng kinh tế tại đây. Cũng hợp với chủ trương
lãnh đạo từ sau lưng của TT Obama thôi. Chỉ còn cách khoanh tay ngồi nhìn mấy
ông bà Âu Châu loay hoay tìm giải pháp. Tìm được thì tốt, không được thì cả khối
Âu Châu bị đe dọa sụp đổ, với những hậu quả khủng khiếp mà không ai đoán được.
Chỉ biết là sự tan vỡ này sẽ có nhiều hy vọng đưa cả thế giới vào khủng hoảng
kinh tế nặng gấp bội cuộc khủng hoảng của mấy năm vừa rồi. Và hy vọng tái đắc cử
của TT Obama sẽ mù mịt hơn bao giờ hết.</p><p>Muốn
chắc ăn, TT Obama tiếp tục đi kiếm một tỷ tiền tranh cử, bằng tiền dân đóng thuế.
Từ đầu năm đến giờ, ông đã tham dự gây quỹ 18 lần, từ Cali tới Florida. Đi bằng
Air Force One, chỉ tốn có gần 180.000 đô một giờ bay. Không kể chi phí an ninh,
tùy tùng, ..., chuyến đi mới nhất qua ba tiểu bang để tham dự tám cuộc gây quỹ
của ông đã tốn hai triệu tiền máy bay, để ông thu được tám triệu tranh cử. Hai
triệu do dân trả, tám triệu để tổng thống xài.</p><p>Chuyện
TT Obama có tái đắc cử hay không là chuyện khó ai biết trước, vì tùy thuộc rất
nhiều yếu tố. Thành ra còn làm tổng thống ngày nào thì còn cần tranh thủ cho nhanh
trước khi mất hết quyền lợi. Đệ Nhất Phu Nhân, vừa từ Hawaii trở về, lại đã lên
đường đi trượt tuyết ở Aspen, Colorado. Một anh nhà báo cắc cớ của báo điện tử
The Examiner đã tính ra bà Michelle Obama vì làm Đệ Nhất Phu Nhân suốt ngày dự
tiệc tùng, tiếp tân, quá vất vả nên đã phải đi nghỉ hè sơ sơ chỉ có 16 lần
trong ba năm qua. Đại khái cứ hai tháng đi nghỉ ngơi một lần, mỗi lần tốn từ
vài trăm ngàn cho đến một hai triệu. Toàn là những nơi du hý của khối 1%, nhờ
tiền thuế của khối 99% hồ hởi đóng góp. </p><p>Dĩ
nhiên vài triệu đô chỉ là chuyện quá nhỏ không đáng nói so với thâm thủng ngân
sách 1.300 tỷ. Mười lần đi chung với chồng, còn lại đi riêng với các con, mẹ,
hay bà con, bạn bè. Một người làm nên, cả họ được hưởng. (26-2-12)</p><p>Vũ
Linh</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a184462/nhung-moi-lo-cua-tt-obama

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/