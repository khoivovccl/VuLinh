# New Hampshire: Ánh Sáng Ngoài Bìa Rừng?

17/01/2012

<p>New
Hampshire: Ánh Sáng Ngoài Bìa Rừng?</p><p>Vũ Linh</p><p>...Trong 12
tiểu bang xôi đậu quyết định kết quả tranh cử tổng thống, Romney dẫn TT Obama với
5%...</p><p>Thứ Ba vừa
qua có cuộc bầu sơ bộ lần thứ hai, tại tiểu bang New Hampshire. Ai cũng biết cựu
thống đốc Massachusetts là Mitt Romney đã thắng lớn bên đảng Cộng Hòa. Nhưng chẳng
ai rõ bên đảng Dân Chủ có bầu sơ bộ gì hay không vì... không thấy báo nào đăng
tin. Dĩ nhiên là cũng có và ứng viên chính thức duy nhất Obama đã được phê chuẩn
với tỷ lệ 81%. Cử tri cũng được quyền viết tên bất cứ ai khác mình muốn vào phiếu:
bà Hillary được 1%, số còn lại là cho một vài chính khách địa phương vô danh.</p><p>Chiến thắng của
ông Romney thì ai cũng biết trước rồi. Đài truyền hình CNN tuần trước phải đợi
đến ba giờ sáng – giờ Hoa Thịnh Đốn – sau khi phát ngôn viên đảng Cộng Hòa chính
thức công bố kết quả, mới dám xác định ông Romney đã thắng tại Iowa, với tám
phiếu hơn ông Santorum. Lần này tại New Hampshire, tám giờ tối thì các phòng
phiếu đóng cửa. Tám giờ một giây, đài CNN tiên đoán ông Romney sẽ thắng, tuy
chưa biết với tỷ lệ nào.</p><p>Ai cũng biết
kết quả này, nhưng vẫn chưa ai hiểu rõ ý nghĩa chiến thắng của ông Romney thực
sự như thế nào.</p><p>Nhìn dưới
khía cạnh bi quan thì ông Romney vẫn thấy tương lai rất mù mờ.</p><p>Tiểu bang New
Hampshire tương đối ít bảo thủ, là láng giềng của Massachusetts, ông Romney có
nhà riêng và đã ở cả năm nay rồi, đi vận động không ngừng từ năm 2007. Tại một
nơi thuận lợi như vậy mà cuối cùng ông vẫn chỉ có được chưa tới 40% phiếu, thì
cũng là điều đáng nhìn kỹ hơn. Có nghĩa là trong mười đảng viên tại đây cũng đã
có tới sáu người vẫn chưa chấp nhận ông Romney và đã phân phiếu ra cho bốn ứng
viên khác. </p><p>Kết quả tại
New Hampshire cho thấy trong đảng Cộng Hoà lại có một ngôi sao nữa mới xuất hiện.
Ngôi sao thứ tám đó là ông Huntsman, là người từ trước đến giờ luôn luôn ngồi
cuối lớp. Tại Iowa, nơi mà tư thế tương đối ôn hoà của ông không có chút hy vọng
thành công nào, ông nhận được chưa tới 1% phiếu. Bây giờ ông lãnh được 17%.</p><p>Ông Jon
Huntsman năm nay 51 tuổi, từ năm 2005 đến 2009 là thống đốc Cộng Hòa của tiểu bang
Utah. Sau đó được TT Obama bổ nhiệm đại sứ tại Trung Cộng, cho đến tháng Tư năm
2011, khi ông từ chức để ra tranh cử tổng thống. Ông cũng là một doanh gia rất
thành công trước khi nhẩy vào chính trị.</p><p>Việc ông
Huntsman leo lên hàng thứ ba là kết quả trực tiếp của chiến lược tranh cử của
ông: bỏ Iowa, tập trung mọi nỗ lực vào New Hampshire, dùng chiến thắng tại đây
làm trớn đi tiếp. Cũng không khác gì chiến lược của ông Rick Santorum tại Iowa.
Nhưng chiến lược này có vẻ không hiệu nghiệm lắm. Ông Santorum không khai thác
được chiến thắng của mình tại Iowa, về hạng năm tại New Hampshire. Chẳng có gì
dẫn chứng hai ông Santorum và Huntsman sẽ thành công lớn tại hai tiểu bang kế
tiếp là South Carolina và Florida. Không ai tin ông Huntsman có chút một hy vọng
đại diện cho Cộng Hoà được. Với nhiều người bảo thủ và cực đoan, việc ông làm đại
sứ cho TT Obama đã là cái tội lớn rồi, trong khi đó, ông cũng há miệng mắc
quai, khó đả kích TT Obama được trong khi ra tranh cử.</p><p>Nếu như trong
tương lai, các ứng viên lẻ tẻ này lần lượt bị loại, thì câu hỏi đặt ra là cử
tri của họ sẽ bầu cho ai. Nếu khối cử tri này tập trung phiếu vào một ứng viên
bảo thủ cuối cùng còn lại, thì ông Romney sẽ mất ngay hy vọng làm đại diện cho
Cộng Hòa.</p><p>Một khía cạnh
bi quan khác cho Cộng Hòa là tư thế của ông Ron Paul. </p><p>Ông này về
nhì như các thăm dò trước bầu bán đã cho thấy trước. Ông là thành phần cực đoan
và các cử tri bầu cho ông cũng thuộc loại cực đoan không kém, tức là không bỏ
cuộc dễ dàng. Có thể với tư thế hạng nhì như vậy, ông sẽ kéo dài cuộc chiến
theo kiểu bà Hillary đánh nhau với ông Obama trước đây. Đáng ngại hơn nữa, ông
Paul cũng không giấu diếm ý định ra tranh cử với tư thế độc lập nếu thua trong
đảng Cộng Hoà. Chuyện này nếu xẩy ra thì ông Paul bảo đảm sẽ là người được TT
Obama tuyên dương công trạng vì giúp tổng thống dễ dàng tái đắc cử mà chẳng cần
đi vận động gì nữa. Có nhà bình luận đã viết đùa rằng Ron Paul mới là người đứng
phó cho ông Obama!</p><p>Nhìn dưới
khía cạnh lạc quan, ông Romney là người đầu tiên trong lịch sử bầu sơ bộ đã chiến
thắng tại cả hai tiểu bang đầu tiên là Iowa và New Hampshire, một thành tích có
vẻ xác nhận ông sẽ đắc cử làm đại diện cho đảng Cộng Hòa. Nói cách khác, dường
như đảng Cộng Hoà trong cái rừng ứng viên bùng lên rồi lặn mất như lửa rơm, đã
nhìn thấy ánh sáng ngoài bìa rừng.</p><p>Nếu Mitt
Romney tiếp tục thắng lớn tại South Carolina và Florida, thì có nhiều hy vọng
cuộc “nội chiến” Cộng Hòa sẽ chấm dứt. Và ông Romney cũng như đảng Cộng Hoà có
thể tập trung nỗ lực để chĩa mũi tên về phiá TT Obama sớm. Ngược lại, nếu như
ông chỉ về nhì hay ba thì bảo đảm cuộc chiến sẽ tiếp tục dài dài và sẽ mỗi ngày
mỗi giảm hy vọng Cộng Hòa lấy lại Tòa Bạch Ốc năm tới.</p><p>Tin mừng cho
ông Romney là những thăm dò mới nhất cho thấy ông đã vọt lên ngang ngửa với cựu
chủ tịch Hạ Viện Newt Gingrich tại hai tiểu bang tới. Tin mừng đó cũng có thể
là tin không vui lắm. Theo truyền thống chính trị Mỹ, hễ có ông bà nào ngoi lên
hàng đầu, trở thành một mối đe dọa lớn là lập tức sẽ bị các ông bà đồng chí
khác xúm lại đánh hội đồng. Các ông bà Cộng Hoà nổi lên trước đây, nhất là ông
Gingrich, đã được nếm tình đồng chí đậm đà này rồi.</p><p>Một tin có thể
nói đáng mừng hơn cho ông Romney, là theo tất cả các thăm dò, trong con mắt của
các cử tri Cộng Hòa, yếu tố quan trọng nhất là khả năng hạ được TT Obama, và
người có nhiều hy vọng nhất trong yếu tố này, chính là ông. </p><p>Chiến lược
tranh cử của TT Obama là cố tô vẽ lên đảng Cộng Hòa bức hình của một đảng cực
đoan, bị khống chế bởi nhóm quá khích Tea Party. Nếu các ông Gingrich và
Santorum mà đắc cử làm đại diện cho đảng Cộng Hòa thì bảo đảm chiến lược này sẽ
được tận dụng tối đa. Nhưng chiến lược này hiển nhiên sẽ khó áp dụng với ông
Romney là người được coi như có khuynh hướng cấp tiến, vẫn chưa được khối bảo
thủ Cộng Hòa chấp nhận mà lại còn bị nhóm Tea Party hoài nghi đến cùng. Mặt
khác, ưu tư lớn nhất của dân Mỹ hiện là vấn đề phục hồi kinh tế, trong khi ông
Romney lại là một doanh gia có thành tích kinh doanh không ai chối cãi được.</p><p>Dù sao thì ta
cũng thấy bức tranh bên phía Cộng Hòa ngày càng sáng tỏ và có chiều hướng thuận
lợi. Trong khi đó thì tình hình bên đảng Dân Chủ không có gì sáng sủa hơn.</p><p>Cái tin đáng
phấn khởi nhất cho TT Obama là tỷ lệ thất nghiệp đã giảm từ 9% xuống 8.5%. Chẳng
có nghĩa gì ghê gớm lắm. Sự suy giảm này chẳng những quá nhỏ quá chậm, mà còn
có thể chỉ phản ảnh số người chính thức đi xin tiền thất nghiệp hay ghi danh kiếm
việc làm đã suy giảm vì họ thất nghiệp đã quá lâu, không còn được hưởng trợ cấp
thất nghiệp nữa, hay là nản chí không đi tìm việc nữa. Nhưng trong cái khoảng
trống vắng thành tích hiện nay thì đây quả là một chuyện vĩ đại cần phải được
khai thác tối đa, khua chiêng gõ trống rầm rộ ngay.</p><p>Về viễn ảnh đắc
cử của TT Obama, một nhà báo đã viết một bài phân tích chi tiết. Ông nêu lên một
số điểm đáng suy gẫm:</p><p>- Cuối năm
2008, tỷ lệ dân Mỹ thỏa mãn với tình trạng hiện tại là 17%. Cuối năm 2011, tỷ lệ
đó vẫn y chang, không thay đổi. Nói cách khác, ba năm Obama đã chẳng có chút tiến
bộ gì.</p><p>- Thăm dò
Gallup cho thấy TT Obama hiện được hậu thuẫn của 42% dân. Đây là tỷ lệ thấp nhất
vào thời điểm ba năm chấp chánh so với tất cả các tổng thống trong lịch sử cận
đại Mỹ, thấp hơn cả tỷ lệ của các tổng thống đã rớt đài như Johnson, Ford,
Nixon, Carter, và Bush cha. Sau khi giết được Bin Laden, tỷ lệ ủng hộ vọt lên
63%, nhưng chỉ một tháng sau thì đâu lại vào đấy, tỷ lệ tụt xuống mức trên dưới
40%.</p><p>- Cũng cơ
quan thăm dò Gallup này phân loại dân Mỹ theo tiêu chuẩn cấp tiến hay bảo thủ,
và so sánh điểm cách biệt giữa các ứng viên tổng thống và điểm trung bình của
đa số dân. Gallup khám phá ra TT Obama thuộc thành phần cấp tiến đứng xa điểm
trung bình nhất, trong khi tất cả các ứng viên Cộng Hòa đều đứng gần với điểm
trung bình hơn, tức là gần với quan điểm chung của dân Mỹ hơn.</p><p>- Gallup cũng
khám phá ra 52% dân Mỹ ủng hộ chủ trương tăng trưởng kinh tế (pro-growth) của Cộng
Hòa, so với 40% ủng hộ chủ trương công bằng xã hội (pro-equality) của Dân Chủ.</p><p>- Trong 12 tiểu
bang xôi đậu quyết định kết quả tranh cử tổng thống, ông Romney dẫn TT Obama với
5%. Chỉ cần thua ở một nửa các tiểu bang này là TT Obama sẽ là tổng thống một
nhiệm kỳ.</p><p>- Tương lai của
TT Obama không sáng sủa lắm: ông rất có thể thua nếu tình trạng hiện tại không
khả quan hơn; chắc chắn sẽ thua nếu có biến cố bất lợi như khủng hoảng kinh tế
Âu Châu, biến động tại Trung Đông; hay một cuộc tấn công của khủng bố. Cho dù
ông thắng thì ông sẽ hoàn toàn bị chi phối bởi việc chống đỡ các cố gắng của đối
lập bảo thủ muốn lật ngược các quyết định của TT Obama trong nhiệm kỳ đầu. </p><p>Bài viết có vẻ
khá bi quan cho TT Obama. Để sáng tỏ vấn đề, đây không phải là bài viết của “Vũ
Linh trên Việt Báo” đâu, mà là của nhà báo cấp tiến Charles Lane viết trên
Washington Post ra ngày 2 Tháng Giêng, 2012 (Charles Lane: Gloomy numbers for
Obama).</p><p></p><p>Tạp chí US
News & World Report hỏi độc giả mối lo sợ lớn nhất của họ là gì? Kết quả,
hai mối lo lớn nhất: 33% sợ TT Obama sẽ được bầu lại, 31% sợ TT Obama tăng thuế.</p><p>Tình trạng
khó khăn của TT Obama cũng được chứng minh không thể nào rõ hơn bằng một bài viết
của nhà báo Bill Keller trên báo phe ta New York Times. Ông Keller, nguyên chủ
bút chính (Executive Editor) của NYT, đã công khai cổ võ cho một liên danh mới,
Obama-Hillary thay thế liên danh Obama-Biden. Theo ông, uy tín, khả năng, và
kinh nghiệm chính trị của bà Hillary là phương pháp cứu hỏa chẳng những bảo đảm
cứu được TT Obama, mà còn bảo đảm bà Hillary sẽ kế vị làm tổng thống và đảng
Dân Chủ sẽ nắm quyền ít ra là đến năm 2024. Cái nhìn của ông Keller có vẻ hơi lạc
quan mà quên mất những “hành trang” rất lớn của bà Hillary, nhưng dù sao cũng
nói lên cảnh tang gia bối rối trong ê-kíp Obama.</p><p>Tuần qua, ông
Chánh Văn Phòng thứ hai, Bill Daley bất ngờ từ chức “để về vui sống với gia
đình”. Trong truyền thống chính trị Mỹ, mỗi lần có ông lớn nào mất job mà chưa
có job gì khác thay thế thì thông thường là vì thương vợ nhớ con, muốn về giúp
vợ rửa chén, giặt quần áo, và dắt con đi chơi baseball. Báo điện tử The Hill
(10/1/12) đã bàn đến hai lý do khiến ông Daley từ chức: thứ nhất là Đệ Nhất Phu
Nhân không ưa ông từ ngày bà còn là nhân viên trong tòa thị trưởng Chicago khi
ông Daley còn làm thị trưởng tại đó – và thực tế giúp bà có được cái job này –
và thứ nhì, ông Daley không đồng ý chính sách bất thân thiện của TT Obama với
giới kinh doanh, luôn luôn chỉ trích giới này là nguyên nhân của mọi khó khăn
kinh tế hiện nay. Ông Daley làm Chánh Văn Phòng được xấp xỉ một năm.</p><p>TT Obama mau
mắn bổ nhiệm ông Jacob Lew, Giám Đốc Văn Phòng Quản Trị Ngân Sách (Office of
Management and Budget) thay thế.</p><p>Cả hai ông cựu
và tân Chánh Văn Phòng đều xuất thân là tài phiệt nặng ký của Wall Street. Ông
Daley trước đây là viên chức cao cấp của đại ngân hàng JP Morgan Chase, kiêm
thành viên Hội Đồng Quản Trị các đại công ty Boeing, Merck, và Fanny Mae, là cơ
quan tái tài trợ nợ mua nhà, thủ phạm lớn nhất của vụ khủng hoảng gia cư và tài
chánh của mấy năm qua. </p><p>Ông Lew cũng
không thua gì, trước đây là viên chức lãnh đạo của đại ngân hàng Citigroup, là
ngân hàng đã nhận được mấy chục tỷ tiền “cứu nguy” trong khi ông Lew lãnh lương
và tiền thưởng sơ sơ có khoảng hai triệu đô một năm thôi. Một điều đáng nói,
khi còn làm cho Citigroup, ông Lew chịu trách nhiệm quản lý khối “Alternatives
Investment Unit”, là khối mua các gói nợ mua nhà, tức là đầu tư vào các nhà có
nhiều hy vọng bị mất giá và bị xiết bởi ngân hàng, hầu hết là nhà của dân trung
lưu và nghèo. Nôm na ra, Citigroup có một khối kinh doanh cho mấy người không đủ
tiêu chuẩn mượn tiền mua nhà, mặt khác lại có một khối khác ngồi chờ những người
này không trả được nợ để hưởng lợi. </p><p>Ông Lew là
người ngồi chờ, và đó là cách ông làm giàu, trở thành triệu phú. Và bây giờ được
làm Chánh Văn Phòng cho ông tổng thống của dân nghèo.</p><p>TT Obama luôn
miệng xỉ vả tài phiệt Wall Street và ủng hộ chủ trương chống “nhà giàu” của
nhóm cực đoan Occupy Wall Street. Thực tế, ông chỉ dùng những tay tài phiệt này
thôi. Chừng nào thì nhóm “99%” này mới sáng mắt để “đừng nghe những gì …”?</p><p>***</p><p>TT Obama xác
nhận cuộc chiến trước mắt khá cam go cho ông vì những thành tích khiêm nhường của
mình. Nhưng hy vọng của Đảng Cộng Hoà cũng chẳng khá hơn vì những tranh giành
trong nội bộ. Hiện giờ cũng vẫn còn một nửa tá ứng viên, tuy trên thực tế chỉ
có hai người có hy vọng đạt được mục tiêu, là hai ông Romney và Gingrich, và cuộc
chiến Romney-Gingrich có thể sẽ hấp dẫn không thua gì cuộc chiến Obama-Hillary
trước đây. (1-15-12) </p><p>Quý độc giả
có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác
giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a182639/new-hampshire-anh-sang-ngoai-bia-rung

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/