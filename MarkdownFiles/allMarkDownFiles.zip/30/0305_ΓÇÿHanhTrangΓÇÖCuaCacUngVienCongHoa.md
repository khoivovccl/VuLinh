# ‘Hành Trang’ Của Các Ứng Viên Cộng Hòa

24/01/2012

<p>‘Hành Trang’
Của Các Ứng Viên Cộng Hòa</p><p>Vũ Linh</p><p>Chiến thắng của
ông Gingrich hứa hẹn cuộc chiến bên Cộng Hoà sẽ rắc rối to... </p><p>Kết quả bầu
sơ bộ hôm Thứ Bảy tại South Carolina đã đánh dấu một khúc quanh quan trọng
trong cuộc chạy đua vào ghế Tổng thống của phíA Cộng Hòa. Tiểu bang tương đối bảo
thủ này đã chọn ông ứng viên bảo thủ cựu chủ tịch Hạ Viện Newt Gingrich. </p><p>Đây là một ngạc
nhiên lớn vì ông Gingrich thắng với 40% trong khi những thăm dò mới nhất cho thấy
ông ngang ngửa với cựu thống đốc Massachusetts Mitt Romney ở mức 30%. Kết quả
cũng đẩy cuộc chạy đua vào... ngõ cụt. Ba cuộc bầu sơ bộ tại Iowa, New
Hampshire và South Carolina, ba người khác nhau thắng (tin giờ chót sau khi kiểm
phiếu lại thì cựu thượng nghị sĩ Rick Santorum đã thắng tại Iowa với 34 phiếu
hơn ông Romney trong khi ông này thắng lớn tại New Hampshire). </p><p>Người có thể
nói đại bại lần này là ông Romney. Chiến thắng mạnh của ông Gingrich đã đưa ông
Romney từ tư thế nhiều hy vọng nhất rớt xuống tư thế lung lay nhất. </p><p>Romney thất bại
vì thật ra ông có nhiều hành trang rất nặng nề.</p><p>Trên nguyên tắc,
ông Romney là ứng viên được hậu thuẫn của guồng máy đảng và các nhân vật tai to
mặt lớn của đảng Cộng Hoà. Từ cựu TT Bush cha cho đến TNS McCain, rồi đến Thống
đốc Nikki Haley của South Carolina, là nhân vật bảo thủ cực đoan được hậu thuẫn
mạnh của phong trào Tea Party. </p><p>Nếu nhìn một
cách phiến diện – theo kiểu truyền thông của phe ta – vào các ứng viên bảo thủ
Cộng Hòa nói chung thì người ta có cảm tưởng như đảng này chủ trương cắt hết trợ
cấp cho dân chúng, hủy bỏ bảo hiểm y tế cho thiên hạ chết ráng chịu, thả lỏng
cho các tài phiệt tru diệt dân lao động, hủy bỏ mọi thứ thuế, thậm chí giải tán
chính phủ luôn cho tiện việc sổ sách và kéo nước Mỹ về thế kỷ thứ 19, hay 18
thì càng tốt. Dĩ nhiên đây chỉ là cái nhìn phiến diện của học sinh tiểu học
thôi. </p><p>Các chính trị
gia của Cộng Hoà chưa bị bệnh mất trí Alzheimer nặng như vậy, nhưng dù sao thì
cũng bảo đảm là phe TT Obama sẽ triệt để khai thác cái nhìn phiến diện này, và
không thiếu người sẵn sàng tin ngay.</p><p>Cái may mắn lớn
là ít ra cũng còn một người chưa đến nỗi khùng điên như vậy. Người đó chính là
ông Romney. Với quá trình có thể nói bảo thủ ôn hòa nếu không muốn nói cấp tiến
của ông này, không ai có thể dán những chủ trương cực đoan, nô lệ của nhóm cực
đoan Tea Party lên ngực ông Romney. Và đó có thể là cách tốt nhất để hoá giải
thế đánh của phe Dân Chủ trong cuộc chạy đua sắp tới. Nói cách khác, ông Romney
là người ít cực đoan, ít sai lầm để TT Obama có thể đánh được, và như vậy có
nghĩa là trong cả đám ứng viên Cộng Hòa, ông cũng sẽ là người có nhiều hy vọng
hạ được TT Obama.</p><p>Thực tế phức
tạp hơn nhiều.</p><p>Ngay trong nội
bộ của Cộng Hoà, phần lớn những lá phiếu bỏ cho ông thực sự không phải vì hoàn
toàn tin tưởng, hay cùng quan điểm với ông mà chỉ vì thấy ông là người có nhiều
hy vọng hạ được TT Obama nhất. Đây là những lá phiếu lỏng lẻo dễ mất nhất. Chỉ
cần TT Obama từ giờ đến lúc bầu cử, làm được một chuyện thành công gì lớn khiến
thiên hạ không thấy nhu cầu phải thay thế ông nữa là những lá phiếu này sẽ bị mất.</p><p>Điều quan trọng
thứ hai, Cộng Hòa là đảng bảo thủ trong khi ông Romney vẫn chưa thuyết phục được
mọi người ông là thành phần bảo thủ thứ thiệt. Chuyện này thật ra khó vì quá
trình của ông Romney rõ hơn ban ngày. Ngày trước, ông Obama ra tranh cử với một
quá trình trống rỗng, nên chẳng ai biết ông thực sự là người như thế nào, bảo
thủ, cấp tiến, ôn hoà hay gì gì khác. Đằng này, ông Romney là thống đốc
Massachusetts trong bốn năm, để lại một chuỗi diễn văn, hành động, quyết định,
luật lệ ai cũng nhìn thấy.</p><p>Và những điều
mà khối bảo thủ Cộng Hòa nhìn thấy, không lấy gì là hấp dẫn họ cả. </p><p>Họ thấy ông
Romney chủ trương chấp nhận phá thai, ủng hộ ân xá di dân bất hợp pháp, ủng hộ
các biện pháp chống ô nhiễm bất lợi cho các công ty sản xuất và quan trọng hơn
cả, ông là cha đẻ ra bảo hiểm y tế toàn dân đầu tiên của Mỹ, một chính sách đã
được chính TT Obama dùng làm khuôn mẫu cho luật cải tổ y tế của ông mà giới bảo
thủ coi như cái tội lớn nhất của TT Obama. Những thành tích ấy không có gì đáng
ngạc nhiên khi ta biết từ xưa đến nay Massachusetts luôn luôn là tiểu bang cấp
tiến hàng đầu của Mỹ. Không có những chủ trương này thì ông Romney không thể
nào làm thống đốc được.</p><p>Bây giờ, ông
Romney thay đổi lập trường hoàn toàn trên hầu hết các vấn đề nêu trên. Ông cũng
khẳng định chế độ bảo hiểm y tế toàn dân của ông mang tính đặc thù của
Massachusetts, khác xa cái luật của TT Obama.</p><p>Cho dù biện
minh cách nào thì ông cũng sẽ gặp khó khăn lớn trong vấn đề này. Chắc chắn là
phe Dân Chủ sẽ khai thác chuyện ông Romney thay đổi lập trường như là bằng chứng
của tính thời cơ hay bất nhất. Tính bất nhất –Mỹ gọi là flip-flop – là yếu tố
chính khiến các ứng viên tổng thống Al Gore và John Kerry bị thua Bush trước
đây. Còn chuyện bảo hiểm y tế thì khối bảo thủ cho là điểm yếu nhất có thể khai
thác để chống TT Obama lại là điểm há miệng mắc quai của ông Romney, bất chấp mọi
biện minh của ông.</p><p>Ông Romney
cũng có cái tội lớn nữa là tội… rất giống cựu ứng viên tổng thống John Kerry của
đảng Dân Chủ trước đây: chẳng những lập trường bất nhất mà còn thuộc giai cấp
giàu sang, có thể nói là quý tộc của vùng đông-bắc Mỹ, nhà cao cửa rộng đếm
không hết, cả đời sung túc, con nhà tông, lại còn biết… tiếng Pháp nữa (ối chao
ơi, cái tội này đối với mấy ông bà Mỹ ruộng thì thật là tội đáng chu di tam tộc!),
có thể rất xa cách dân Mỹ và khó có thể hiểu được nhu cầu của họ.</p><p>Những chuyện
này đã gây những câu hỏi rất lớn trong khối bảo thủ, và cho đến nay, bất kể mọi
giải thích, họ chưa thể thực sự tin ông được. Do đo, từ cả năm họ vẫn loay hoay
tìm người khác đáng tin hơn và hoàn hảo hơn, mà vẫn chưa tìm ra được.</p><p>Một điểm lợi
mà cũng là bất lợi nữa cho ông Romney là thành tích kinh doanh của ông.</p><p>Trong thời buổi
kinh tế khó khăn hiện nay, ai cũng thấy TT Obama loay hoay mãi vẫn chẳng có kết
quả gì khả quan, chỉ giỏi đổ thừa, hết người này đến người khác, hết lý do này
đến cớ nọ. Thay đổi ê-kíp kinh tế hàng loạt cũng chẳng có kết quả gì khác. Sau
ba năm, tỷ lệ thất nghiệp sau khi tăng ba bốn điểm (từ 6%-7% lên đến trên 10%)
mới bớt được nửa điểm (từ 9% xuống 8.5%) là đã có cớ hò hét thành công vĩ đại.
Nợ công, thâm thủng ngân sách đã lên đến những mức vô tiền khoáng hậu, khó có
thể mường tượng được.</p><p></p><p>Trong bối cảnh
đó, một doanh gia có thành tích rõ ràng phải là một thứ bửu bối nước Mỹ cần có
để giải quyết khó khăn kinh tế. Và ông Romney chính là người lý tưởng đó. Với
tư cách thống đốc Massachusetts, ông lãnh cái gia tài hơn ba tỷ thâm thủng ngân
sách, nhưng thành công mau mắn xóa bỏ cái thâm thủng đó mà không phải tăng thuế.
Ông là người cứu vãn được tổ chức Thế Vận Hội Mùa Đông 2002 tại Salt Lake City
khỏi bị phá sản. Trước đó, ông cũng là người được thuê để điều hành công ty
Bain Capital là công ty chuyên đầu tư vào các doanh nghiệp bị đe dọa phá sản.
Qua công ty Bain, ông Romney giúp các công ty gặp khó khăn cần phải thay đổi
cách điều hành, chiến lược, chiến thuật kinh doanh để thoát nạn. Và ông thành
công, cứu được cả trăm cả ngàn công ty, mang lại lợi nhuận lớn cho Bain
Capital. </p><p>Thành công thật,
nhưng mặt trái của vấn đề là hàng trăm hàng ngàn nhân viên bị sa thải để cứu
các công ty đó. Trong thời buổi thất nghiệp tràn lan, mang một người có thành
tích sa thải nhân công ra trình làng hiển nhiên không phải là cách làm hay ho
nhất. Đúng ra, đây là cách nhìn không chính xác. Rõ ràng là ông Romney đã khuyến
cáo sa thải nhân viên và nhiều người mất việc vì khuyến cáo này. Nhưng ngược lại,
vấn đề đặt ra là nếu không sa thải một số nhân viên như vậy thì các công ty sẽ
phá sản toàn diện và số nhân viên mất việc thật sự sẽ cao hơn rất nhiều.</p><p>Các đối thủ của
ông Romney đã và sẽ triệt để khai thác khía cạnh này. Ta đã và sẽ thấy những quảng
cáo, phỏng vấn người bị mất việc vì khuyến cáo của ông Romney, được đưa lên màn
ảnh truyền hình để tả cảnh khổ của họ và gia đình họ sau khi mất job. Ông
Romney dù sao cũng sẽ bị ảnh hưởng rất tai hại từ những cảnh này. Mọi người ai
cũng sẽ nhìn thấy những cảnh đau lòng mà không ai nghĩ đến chuyện hàng trăm
hàng ngàn người khác đã được cứu thoát khỏi cảnh sa thải tập thể vì công ty phá
sản.</p><p>Riêng TT
Obama có lẽ sẽ khó khai thác chuyện Bain này. TT Obama vừa bổ nhiệm ông Jeffrey
Zients làm tân Giám Đốc Văn Phòng Quản Trị Ngân Sách, trực thuộc Tòa Bạch Ốc.
Ông Zients trước đây cũng làm việc tại Bain Capital từ 1988 đến 1990. TT Obama
vẫn tiếp tục “truyền thống” dùng “1% tài phiệt Wall Street” làm cánh tay trái
trong chính quyền của ông, bất chấp những sỉ vả đối với tài phiệt ngoài cửa miệng
của ông.</p><p>Mới đây, báo
chí đòi ông Romney công khai hoá chuyện thuế má. Các đồng chí Cộng Hòa hùa theo
ngay. Nhưng ông Romney nhất định chưa chịu công bố chi tiết mà chỉ trả lời đại
khái ông đóng thuế ở mức 15%. Dĩ nhiên là báo chí nhẩy bổ vào chỉ trích là
trong khi mấy ông bà công chức phải đóng thuế ở mức 20%-25%, thì ông triệu phú
này lại đóng có 15%. Sau này TT Obama thế nào cũng sẽ không bỏ qua.</p><p>Thực tế không
phải vậy. </p><p>Báo điện tử
CNN Money ngày 18/1/2012 phân tích vấn đề rõ ràng hơn: 20%-25% là mức thuế lợi
tức tối đa dân trung lưu phải đóng. Trên thực tế, họ đóng ít hơn nhiều, vì được
khấu trừ nhiều thứ. Người dân với mức lương từ 40.000 đến 50.000 đóng thuế ở mức
trung bình 3.2%, từ 50.000 đến 75.000 đóng 5.7%, và từ 75.000 đến 100.000 đóng
7.2%. Tất cả đều thấp hơn xa mức thuế của ông Romney.</p><p>Có người so
sánh mức thuế 15% của ông Romney với mức thuế 26% của TT Obama. So sánh kiểu
này là không hiểu gì. Mức thuế ông Romney đóng là thuế trên lợi nhuận đầu tư
(investment return) vì ông chỉ có lãnh tiền đó thôi, chứ không có lợi tức
(income). Mức thuế lợi nhuận đầu tư cao nhất là 15%, nghĩa là ông Romney đã
đóng thuế tới mức tối đa. TT Obama đóng 26% thuế trên lợi tức –lương và tiền
bán sách – trong khi mức thuế lợi tức tối đa là 35%. Thuế lợi nhuận đầu tư thấp
hơn vì đầu tư có rủi ro mất hết tiền trong khi lợi tức – ví dụ từ lương bổng
–bảo đảm không thể mất. </p><p>Nhìn vào những
vấn đề trên, ta thấy hành tranh của ông Romney quả là nặng nề và cần khá nhiều
giải thích phức tạp và dài dòng.</p><p>Trong khi đó,
ông Gingrich cũng không thiếu gì “hành trang”. Từ tính bốc đồng, nóng nẩy, đến
chuyện tiền bạc không rõ ràng, những vụ điều tra của quốc hội, và vụ ông phải từ
chức khi đang làm chủ tịch Hạ Viện. Nhưng đó không phải là suy nghĩ của dân South
Carolina. Bất chấp những “hành trang” nặng nề không kém của ông Gingrich, đa số
đã chọn ông.</p><p>Điều đáng nói
là đúng một ngày trước bầu cử, bà vợ thứ hai của ông Gingrich (ông này có ba đời
vợ) được đài ABC và báo Washington Post dụ dỗ công khai lên tiếng khui ra chuyện
kín phòng the với ông Gingrich để bôi bác.</p><p>Nhiều người
cho rằng sự tăng vọt hậu thuẫn này là hậu quả trực tiếp của chuyện ông “đấu võ”
với nhà báo John King của CNN trong cuộc tranh luận Thứ Năm tuần rồi. Ông King
mở màn cuộc tranh luận bằng câu hỏi về chuyện bà vợ thứ nhì của ông Gingrich. Lập
tức John King bị Gingrich quạt thẳng là đã hạ thấp cuộc tranh luận bầu tổng thống
bằng cách mở đầu bằng một câu hỏi thuộc phạm vi lá cải. Câu trả lời của ông
Gingrich được cử tọa đồng loạt nhảy nhỏm vỗ tay hết mình. Có lẽ dân South
Carolina cũng phản đối thái độ thiên vị của CNN, ABC, và Washingon Post nên dồn
phiếu cho ông Gingrich.</p><p>Với tất cả những
“hành trang” bàn ở trên, cả Romney lẫn Gingrich đều không phải là những ứng
viên hoàn hảo. Nhưng sự thật trong chính trường Mỹ không bao giờ có thể có một ứng
viên hoàn hảo, bên Cộng Hòa như bên Dân Chủ. Trong cuộc chạy đua giữa bà
Hillary và ông Obama năm 2007-2008, ta có dịp thấy những hành tranh nặng nề và
to lớn của cả hai ứng viên này. Bà Hillary như một người đàn bà đầy tham vọng
và thủ đoạn, ông Obama như một bạch diện (hay hắc diện cho đúng hơn?) thư sinh
trống rỗng kêu to.</p><p>Chiến thắng của
ông Gingrich hứa hẹn cuộc chiến bên Cộng Hoà sẽ rắc rối to và người ta có thể
mường tượng cuộc chiến sẽ kéo dài hơn dự đoán, và cuộc bầu tới tại Florida sẽ
mang ý nghĩa cực lớn. (22-1-12)</p><p>Quý độc giả
có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác
giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a182942/hanh-trang-cua-cac-ung-vien-cong-hoa

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/