# Quyền Biến Trong Mùa Bầu Cử

14/02/2012

<p>Quyền
Biến Trong Mùa Bầu Cử</p><p>Vũ
Linh</p><p></p><p>...xỉ
vả tài phiệt trên truyền hình, nhưng âm thầm trấn an họ và xin tiền trong hậu
trường. </p><p></p><p>Trong
một cuộc phỏng vấn của Matt Lauer trên đài truyền hình phe ta MSNBC tuần rồi,
TT Obama tuyên bố ông xứng đáng được bầu thêm một nhiệm kỳ nữa. Câu tuyên bố
này có lẽ hơi thừa vì chẳng lẽ ông lại nói tôi thấy tôi không xứng đáng? Đây
là chuyện người dân quyết định chứ đâu phải chuyện một ứng viên tuyên bố. </p><p>Điều
đáng nói ở đây là ngay sau khi nhậm chức, tháng Hai năm 2009 TT Obama đã dõng dạc
tuyên bố nếu tôi không giải quyết được khủng hoảng kinh tế này trong ba năm
thì coi như tôi sẽ là tổng thống một nhiệm kỳ. Bây giờ, ai cũng biết kinh tế vẫn
loạn xà bần, với tỷ lệ thất nghiệp cao ở mức kỷ lục từ ba năm qua, và tỷ lệ tăng
trưởng kinh tế thấp hơn Phi Châu. Không ai nói TT Obama đẻ ra khủng hoảng kinh
tế, mà chỉ bàn đến chuyện tổng thống đã cam đoan giải quyết trong ba năm mà hiển
nhiên là không làm được. Thế nhưng không thấy bạn ta Matt Lauer dám hỏi ý TT
Obama về câu tuyên bố một nhiệm kỳ năm 2009 của ông.</p><p>TT
Obama viện dẫn tỷ lệ thất nghiệp giảm mạnh trong tháng Giêng như là thành quả
vĩ đại xác nhận ông đang thành công và do đó cần tiếp tục ngồi lại Toà Bạch Ốc để
hoàn thành công tác.</p><p>Sự
thật có hơi khác chút xíu.</p><p>Thống
kê cho biết trong tháng Giêng vừa qua, 243.000 người mới có việc làm lại, và tỷ
lệ thất nghiệp đã giảm từ 8,5% xuống 8,3%. Trong thời buổi hạn hán tin tốt, cái
tin trên đã bùng nổ như cơn mưa lũ trong giới Dân Chủ mặc dù chỉ là vài giọt mưa
phùn. </p><p>Quả
là Đấng Tiên Tri có phép mầu đúng lúc. Một năm trước ngày bầu cử, với những thăm
dò dư luận không có gì là đáng hồ hởi nếu không muốn nói là thật đáng lo, bất
ngờ các con số về tỷ lệ thất nghiệp do các công chức của Nhà Nước tính toán
(Bureau of Labor Statistics - Văn Phòng Thống Kê Lao Động) đổi màu từ đen thui
qua nâu rồi bây giờ qua hồng. </p><p>Một
độc giả của Việt Báo bênh vực TT Obama với lý luận là trong ba năm qua, TT
Obama tạo ra được hơn 3,5 triệu jobs, nghĩa là mỗi tháng tạo được 130.000 jobs
và theo đà này, từ giờ đến bầu cử tổng cộng sẽ tạo ra được 4,6 triệu jobs. Nghe
thì thật là hoành tráng. Vấn đề là cũng giống như bài diễn văn Báo Cáo Liên
Bang của TT Obma, lý luận này vừa sai vừa chưa đủ.</p><p>Sai
là vì theo tuyên bố chính thức của Obama, trong thời gian 22 tháng qua, ông chỉ
tạo ra được có ba triệu jobs. Báo Mỹ nhận định thật ra, chỉ có hai triệu. TT
Obama phóng đại ra ba triệu, bây giờ ông độc giả tiếp tục truyền thống, phóng đại
ra 3,5 triệu. Rồi trong phỏng vấn truyền hình, TT Obama tiếp tục thổi phồng
thành 3,7 triệu trong ba năm chấp chánh. Con số việc làm tăng vùn vụt theo mỗi
lời tuyên cáo, khiến cho thiên hạ như lạc vào bát quái trận của Khổng Minh vậy,
chẳng còn biết con số nào đúng, con số nào sai, con số nào là phóng đại.</p><p>Cứ
cho là 3,5 triệu đi, và mỗi tháng có thêm 130.000 jobs mới như vị độc giả cao
minh nọ đưa ra thì nhìn kỹ lại vẫn như là muối bỏ biển. </p><p>Kinh
tế Mỹ cần 150.000 jobs mới mỗi tháng để đáp ứng gia tăng dân số bình thường và
giữ mức thất nghiệp không thay đổi. Nếu chỉ có được 130.000 mỗi tháng thì tỷ lệ
thất nghiệp sẽ gia tăng trở lại vì vẫn thiếu hụt 20.000 jobs một tháng, và đến
tháng Mười năm 2012, có thể sẽ leo lên mức 10% lại, và như vậy có nghiã là 3,5
triệu jobs mới vẫn chẳng ăn thua gì.</p><p>Mà
ngay cả các con số do Nhà Nước chính thức đưa ra cũng rất đáng nhìn lại cho kỹ.</p><p>Theo
Nhà Nước, tỷ lệ thất nghiệp trong thời gian gần đây đã giảm dần từ hơn 9% xuống
8.3%, nhưng đó chỉ là hậu quả của một tình trạng chưa hẳn là đẹp đẽ. Tỷ lệ thất
nghiệp được tính trên số dân trong thị trường lao động, gồm những người đang đi
làm, hay không có việc làm nhưng ghi tên kiếm việc và nhận trợ cấp thất nghiệp.
Nếu có người thất nghiệp lâu quá, chán nản không ghi tên kiếm việc nữa, hay là
quá thời hạn lãnh trợ cấp thất nghiệp, thì người đó bị loại ra khỏi thành phần
thất nghiệp. Tình trạng thất nghiệp nặng kéo dài ba năm nay, cả trăm ngàn người
thất nghiệp đã rơi vào trường hợp này, do đó dĩ nhiên là con số người chính thức
được ghi nhận là thất nghiệp có thể giảm. Chuyện kỹ thuật thống kê mà thôi.</p><p>Chính
quyền Obama giữ kín con số này nên chẳng ai rõ những người thất nghiệp bị lọt đài
là mấy trăm ngàn hay mấy triệu.</p><p>Theo
tính toán của nhà báo Joseph Curl trên tờ Washington Times, thì con số người bị
lọt sổ khỏi thị trường lao động từ ngày TT Obama nhậm chức đến giờ là 1,2 triệu
người. Nếu kể thêm loại người thiếu may mắn này thì tỷ lệ thất nghiệp thực sự
hiện nay vẫn là trên 18%, chứ không phải 8,3%.</p><p>Đó
chỉ mới là vấn đề thứ nhất. </p><p>Vấn
đề thứ nhì là cách tính của các chuyên gia Nhà Nước. Trên thực tế, không ai có
thể đếm rõ bao nhiêu người có việc, bao nhiêu thất nghiệp. Tỷ lệ thất nghiệp và
số việc làm mới tạo ra đều chỉ là những ước lượng của Nhà Nước. Ước lượng đó
cũng được điều chỉnh để bù trừ những trồi sụt theo mùa. Chẳng hạn như vào thời điểm
thu-đông trước các dịp lễ lớn, các hãng xưởng thuê nhân công nhiều hơn để đáp ứng
nhu cầu mua sắm dịp lễ, rồi qua đầu năm là các hãng xưởng sa thải bớt người vì
mua sắm suy giảm.</p><p>Dựa
trên lý luận này, các chuyên gia điều chỉnh số lượng việc làm cuối năm thấp xuống
và đầu năm lên cao hơn. Thấp hơn hay cao hơn bao nhiêu là tùy thuộc ước tính của
các chuyên gia Nhà Nước. Do đó, con số 243.000 việc làm mới tạo ra trong tháng
Giêng không là con số đếm được mà chỉ là do các chuyên gia Nhà Nước ước đoán
sau khi điều chỉnh theo mùa (seasonal adjustments). Việc điều chỉnh theo mùa thường
đưa đến kết quả có thể gọi là tùy hỷ các công chức Nhà Nước. </p><p>Không
ai có thể biết được những con số này chính xác đến độ nào. Do đó cũng không ai
biết được sự thật bao nhiêu việc mới đã được tạo ra. Và bao nhiêu việc được tạo
ra bởi chỉ thị của tổng thống trong mùa tranh cử. </p><p>Viết
như vậy, có lẽ sẽ không thiếu độc giả phản đối vì cho rằng TT Obama không giống
nhưTT Nixon! Không quyền biến đến độ đó. </p><p>Nhưng
chuyện TT Obama quyền biến đến mức nào cũng có thể được thẩm định qua thái độ
của ông đối với việc gây qũy tranh cử.</p><p>Năm
2007, thượng nghị sĩ vô danh Barrack Obama ra tranh cử tổng thống chống lại thượng
nghị sĩ Hillary Clinton. Vì chưa ai biết đến nên ông Obama hiểu là khó vận động
tiền tranh cử so với một người nổi tiếng và có uy tín như bà Hillary. TNS Obama
dõng dạc đả kích chyện các chính trị gia bị đồng tiền chi phối và muốn mua Tòa
Bạch Ốc. Ông thách thức bà Hillary từ chối nhận tiền cử tri mà chỉ nhận tiền từ
Nhà Nước, là một số tiền nhất định cấp đồng đều cho mọi ứng viên. Dĩ nhiên bà
Hillary trong thế thượng phong đã từ khước đề nghị này. </p><p>Sau
khi thắng được bà Hillary, TNS Obama tranh cử cùng ứng viên Cộng Hoà John
McCain. Ông McCain lập lại những lời đả kích của Obama, và kêu gọi hai bên
không nhận tiền cử tri mà chỉ nhận tiền của Nhà Nước để tranh cử, đúng như Obama
đã kêu gọi bà Hillary. Lần này thì TNS Obama từ chối, viện dẫn lý do ông McCain
được sự hậu thuẫn của tài phiệt sẽ gây quỹ được rất nhiều một cách gián tiếp
qua các Ủy Ban Hành Động Chính Trị (Political Action Committees - PAC) và như vậy
cuộc đấu sẽ không công bằng. Ông McCain nhất quyết nhận tiền Nhà Nước và từ khước
tiền yểm trợ của cử tri. Kết quả, ông McCain nhận được 80 triệu của Nhà Nước
trong khi ông Obama vận động được hơn 700 triệu từ cử tri, phần lớn là các đại
gia tài phiệt như George Soros, Warren Buffett, Bill Gates, các chủ tịch tập đoàn
tài chánh khổng lồ ở Wall Street, và các nghiệp đoàn. Và mua được Tòa Bạch Ốc.
</p><p>Cái
này nếu không phải là quyền biến thì là gì?</p><p>Năm
nay, một dự luật giới hạn chuyện các công ty đóng góp tiền vận động tranh cử
vào các Ủy Ban Hành Động Chính Trị bị Tối Cao Pháp Viện bác bỏ vì vi phạm quyền
tự do đóng góp của cử tri. Trên nguyên tắc, các PAC này hoàn toàn độc lập với
các ứng viên tranh cử, do đó không bị giới hạn bởi luật lệ tranh cử rất khắt
khe. Trên thực tế, ai cũng biết những PAC này đứng sau lưng các ứng viên.</p><p>Nghị
sĩ Obama thì không thấy vấn đề gì khi gây quỹ cả trăm triệu để tranh cử. Nhưng
sau khi đắc cử thì không muốn thấy ai có tiền để tranh cử chống mình, nên đòi
giới hạn số tiền gây quỹ của các ứng viên và đả kích quyết định của Tối Cao
Pháp Viện. Ông cho rằng quyết định này chẳng những khiến các chính trị gia hoàn
toàn bị chi phối bởi đồng tiền, mà còn là một đe dọa trực tiếp đến thể chế dân
chủ của Mỹ. Ông mạnh mẽ tố cáo các Ủy Ban Hành Động chỉ là công cụ bình phong
cho việc mua bán chức quyền. Dĩ nhiên là ông không hề nhắc đến chuyện tranh cử
năm 2007-08 khi ông nhận 700 triệu tiền vận động.</p><p>Thế
rồi, cách đây một tuần, TT Obama công khai thay đổi lập trường, và chính thức
lên tiếng kêu gọi các cử tri của ông hãy thành lập các PAC để hậu thuẫn ông.
Cái này gọi là uyển chuyển.</p><p>Một
chuyện không có gì bí mật hết: mấy cái PAC nay, còn gọi là siêu PAC, nhận
toàn là tiền giấy lớn của các đại gia và các đại công ty, chứ không phải là
loại quỹ nhận vài chục hay vài trăm của các cử tri nghèo. Nói cách khác, TT
Obama đang kêu gọi các tài phiệt ủng hộ ông.</p><p>Mới
đây, TT Obama còn gửi ông Jim Messina, phụ tá tổng thống, trước đây là giám đốc
vận động tranh cử của ông, đi tham dự một buổi tiệc với các tài phiệt Wall
Street, để trấn an giới này rằng TT Obama thực sự không chống đối họ, mà trái lại
chỉ muốn bảo vệ các tài phiệt chống lại dư luận quần chúng bất mãn với những
chuyện lương lậu và tiền thưởng ngút ngàn của các tài phiệt trong khi kinh tế bị
khủng hoảng với cả triệu người thất nghiệp. </p><p>Ông
Messina giải thích rằng TT Obama không về hùa với đám Occupy Wall Street, nhưng
bất đắc dĩ phải công khai chỉ trích tài phiệt để có lý do dễ bảo vệ họ hơn. Hơn
ai hết, TT Obama biết rõ trong thời buổi kinh tế khó khăn hiện nay, nếu không năn
nỉ tài phiệt thì không có cách nào kiếm ra được một tỷ, là mục tiêu vận động
tài chánh cho cuộc tranh cử của ông. </p><p>Công
khai xỉ vả tài phiệt trên truyền hình, nhưng âm thầm trấn an họ và xin tiền
trong hậu trường. Ban ngày là 99%, ban đêm là 1%. Cái này gọi là lắt léo.</p><p>Năm
2007-08, ứng viên Obama kêu gọi thay đổi toàn diện cơ cấu chính trị Mỹ, từ đại đoàn
kết các đảng phái và khuynh hướng, cho đến minh bạch hoá các quyết định của Nhà
Nước, và thanh liêm hoá chính quyền. Ông cũng kêu gọi mọi người hãy tin tưởng
ông, tin tưởng vào khả năng của ông là thay đổi không khí ô nhiễm chính trị Hoa
Thịnh Đốn. Change We Can Believe In.</p><p>Bây
giờ thì mọi người đều đã thấy có những thay đổi thật. Nhưng không là thay đổi
trong chính quyền Mỹ, mà là thay đổi trong con người Obama theo kiểu hứa một đàng
làm một nẻo. </p><p>Từ
tôn chỉ đại đoàn kết dân tộc, ông trở thành tổng thống tạo phân hoá lớn nhất lịch
sử Mỹ. Từ minh bạch hoá chính quyền đến việc xào nấu thống kê thất nghiệp mà chẳng
ai đoán được trong đó có bao nhiêu hành tỏi. Từ thanh liêm hoá chính quyền đến
việc kêu gọi tài phiệt thành lập PAC gây quỹ cho mình.</p><p>Tất
cả những chuyện quyền biến này đều chỉ có mục đích duy nhất: tái đắc cử tháng
Mười Một.</p><p>Thật
ra việc TT Obama tái đắc cử hay không tùy thuộc phần lớn vào hai yếu tố: kinh tế
có thực sự phục hồi hay không, và phe Cộng Hoà đưa ai ra tranh cử.</p><p>Yếu
tố thứ nhất quan trọng hơn cả vì đó là túi tiền của cử tri. Kinh tế không vực
lên được mà cứ trì trệ như hiện nay thì quyền biến đến đâu cũng không giúp được
gì. Có giải thích gì thì dân chúng vẫn thấy nếu mình không thất nghiệp thì
chung quanh cũng đầy bà con, bạn bè đang thất nghiệp và những thống kê đẹp đẽ
chỉ là... ước đoán do công chức xào nấu. Dân da đen, là cử tri trung thành nhất
của TT Obama là khối bị ảnh hưởng tai hại nhất, với tỷ lệ thất nghiệp thực sự
lên đến trên 20%-25%, tại một vài thành phố lớn như Detroit, Cleveland,</p><p>Đó
là chưa kể đến ảnh hưởng của kinh tế Âu Châu. Nếu Âu Châu bị khủng hoảng thì dù
muốn hay không, kinh tế Mỹ cũng sẽ bị tác hại nặng. TT Obama có quyền biến đến
đâu cũng vẫn sẽ được mời về nhà viết hồi ký.</p><p>Yếu
tố thứ hai là ứng viên Cộng Hoà. </p><p>Tin
mừng cho TT Obama là đảng này cho đến nay vẫn mò mẫm tìm đường đi. Khối bảo thủ
vẫn chưa chấp nhận được ông Romney. Muốn hậu thuẫn mấy ông khác thì họ lại đều
quá nhiều hành trang. Do đó, vẫn chưa rõ ai sẽ là người chiến thắng cuối cùng.
Trong tám trận bầu sơ bộ cho tới nay, ông Romney thắng được ba (New Hampshire,
Florida, Nevada), ông Gingrich thắng được một (South Carolina), ông Santorum thắng
được bốn (Iowa, và tuần rồi Colorado, Missouri, Minnesota). </p><p>Tình
trạng xâu xé nội bộ có thể tiếp tục dài dài. Cứ theo đà này thì TT Obama chẳng
cần phải quyền biến, lắt léo làm chi cho mệt, cứ tiếp tục đi nghỉ hè, tắm biển,
đánh gôn, cũng vẫn thắng. (12-2-12)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a183847/quyen-bien-trong-mua-bau-cu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/