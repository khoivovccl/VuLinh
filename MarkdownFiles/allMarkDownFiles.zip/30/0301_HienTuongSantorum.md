# Hiện Tượng Santorum

21/02/2012

<p>Hiện
Tượng Santorum</p><p>Vũ
Linh</p><p></p><p>...Gingrich
và Santorum vẫn chưa phải là đối thủ của TT Obama...</p><p>Cuộc
chạy đua vào Tòa Bạch Ốc bên phía Cộng Hòa tiếp tục không khác gì một vụ quay xổ
số. Không ai biết tuần tới số độc đắc rớt vào đâu. Tất cả các thăm dò dư luận, ước
đoán của các chuyên gia chính trị đều sai bét. Ngay cả cấp lãnh đạo Cộng Hòa
cũng như chiến lược gia của TT Obama đều gãi đầu gãi tai với các quyết định của
cử tri Cộng Hòa. Sau khi các ứng viên tương đối nhẹ ký bất ngờ nổi đình nổi đám,
rồi lặn mất bất ngờ không kém, chung quy còn lại bốn vị có thể gồng mình chạy đường
trường.</p><p>Cho
đến cách đây một tuần, người nổi bật nhất, coi như thái tử chờ ngày đăng quang
là cựu thống đốc Mitt Romney. Người thứ hai, có vai vế, nhiều hy vọng gây khó
khăn lớn cho ông Romney là cựu chủ tịch Hạ Viện Newt Gingrich. Người thứ ba, cựu
thượng nghị sĩ Pennsylvania ít người biết, dường như đang cố ngoi ngóp để giữ
tiếng, hy vọng kiếm được chức Phó, hay một chức bộ trưởng nào đó trong một
chính quyền Cộng Hoà tương lai, hay có khi đang chuẩn bị cho mùa tranh cử 2016.
Đó là ông Rick Santorum. Và cuối cùng là một ông già gàn gàn dở dở, trường kỳ
kháng chiến ra tranh cử lần này là lần thứ ba, là ông dân biểu kiêm bác sĩ đỡ đẻ
Ron Paul, 79 tuổi với chủ trương "libertarian", có thể gọi là "tự
do tuyệt đối" đến độ kỳ lạ. </p><p>Đó
là bức tranh bên Cộng Hoà cách đây hai tuần.</p><p>Thế
rồi trong tuần đầu tháng hai, có ba cuộc bầu sơ bộ trong một ngày. Tại cả ba nơi
này, ông Gingrich hầu như không chút hy vọng nào vì chưa kịp ghi tên tranh cử,
vì thiếu nhân sự và tiền bạc, và phần vì biết mình ít hy vọng, nên không đi vận
động. Chỉ còn ba ông tranh cử, là các ông Romney, Santorum và Paul.</p><p>Ông
Ron Paul trải qua không biết bao nhiêu thăm dò dư luận và bầu sơ bộ, vẫn ì ạch ở
mức 10%. Ông Rick Santorum bất ngờ thắng ông Romney với vài chục phiếu tại
Iowa, nhưng trên quy mô toàn quốc, chưa bao giờ mức hậu thuẫn leo qua được 5%.
Ông Mitt Romney, bất kể con đường khó khăn gian nan, vẫn được coi là sẽ bỏ túi
cả ba cuộc bầu tại Missouri, Colorado, và Minnesota.</p><p>Cuộc
bầu tại Colorado, ông Romney nắm chắc phần thắng trong tay, tin tưởng vào đa số
dân theo đạo Mormon cùng với ông nên đi vận động cho có lệ. Kết quả không ai ngờ,
ông Santorum hạ ông Romney dễ dàng 41%-35%. Ba tháng trước, trong tiểu bang
Colorado, không ai biết Rich Santorum là ai.</p><p>Tại
Missouri, ông Romney cũng nắm chắc phần thắng vì hầu như không có đối thủ. Đối
thủ chính là ông Gingrich, nhưng ông này không ghi danh kịp nên không có trong
danh sách ứng viên. Ông Paul không được coi là ứng viên nghiêm chỉnh. Ông
Santorum thì chẳng ai biết là ai. Kết quả là một ngạc nhiên khổng lồ. Ông
Santorum đại thắng với hơn 55% so với 25% của ông Romney. Ông Santorum thắng đã
là một ngạc nhiên, ông Romney chỉ được có một phần tư phiếu lại là một ngạc
nhiên lớn hơn nữa.</p><p>Tại
Minnesota, một tiểu bang tương đối cấp tiến nhưng chẳng giống ai, trước đây đã
bầu một anh võ sĩ đô vật làm thống đốc, bây giờ thì đang có một danh hài diễu dở
làm thượng nghị sĩ. Tại đây, bà dân biểu Michele Bachmann, gây sóng gió trong
những ngày đầu mùa tranh cử, rồi đã rút lui, tuy không nói ra rõ ràng, nhưng có
khuynh hướng hậu thuẫn ông Romney. Đương kim thống đốc Tim Pawlenty công khai ủng
hộ ông Romney. Do đó, ông Romney cũng nắm chắc phần thắng. Lại một bất ngờ, ông
Santorum về đầu với 45% trong khi ông già Ron Paul được 27%, và ông Romney lọt
xuống hạng chót với 17%. Đây hiển nhiên là thất bại lớn nhất của ông Romney.</p><p>Cả
ba cuộc bầu sơ bộ này trên thực tế chẳng có hậu quả cụ thể và trực tiếp quan trọng
gì vì cử tri đoàn đại diện cho cả ba tiểu bang tham gia đại hội đảng mùa hè năm
tới đều sẽ do các đại hội địa phương của đảng tại tiểu bang lựa chọn và bổ nhiệm
sau này, chứ không phải được chỉ định qua các cuộc bầu vừa rồi. Thua hay thắng
qua bầu sơ bộ thật sự chỉ mang ý nghĩa tâm lý, là đo lường mức hậu thuẫn thôi,
nhưng là ý nghĩa tâm lý rất lớn, vang vọng đến cả nước.</p><p>Qua
đó thì ta thấy Thứ Ba tuần trước là ngày đại nạn cho ông Romney. Trong khi ai
cũng nghĩ ông sẽ toàn thắng tại cả ba tiểu bang và cho các địch thủ cơ hội rút
lui khỏi cuộc chạy đua để thống nhất lại đảng, hầu đối phó hữu hiệu hơn với TT
Obama, thì cử tri cả ba tiểu bang lại suy nghĩ và quyết định khác, hoàn toàn
trong bất ngờ. </p><p>Cuộc
bầu sơ bộ tại Michigan ngày 28 tháng 2 tới đây sẽ có ý nghĩa quan trọng hơn nữa
cho ông Romney. Đây là "sân nhà" của ông, nơi mà phụ thân là George
Romney đã làm thống đốc từ 1963 đến 1969. Ông này thuộc thành phần tương đối cấp
tiến, ra tranh cử tổng thống năm 1968 với chủ trương chống Mỹ tham chiến tại Việt
Nam, nhưng bị thua Nixon. Lần này ông Romney còn được coi như là gà nhà, chắc
chắn sẽ thắng lớn. Nhưng những thăm dò mới nhất cho thấy ông Romney có thể thua
ông Santorum. Nếu chuyện này xẩy ra, hy vọng của ông Romney làm đại diện cho Cộng
Hoà chống TT Obama sẽ bị lủng một lỗ lớn.</p><p>Kết
quả bầu cử tại ba tiểu bang là đại nạn - tuy có thể là ngắn hạn - cho ông
Romney, nhưng cũng là thảm họa cho ông Gingrich. Sau chiến thắng lớn tại South
Carolina, người ta đều nghĩ ông này sẽ là đối thủ trực diện ông Romney trong cuộc
chiến tay đôi bên phe Cộng Hoà, nhưng việc ông Santorum nổi lên đã đe dọa dìm hậu
thuẫn của ông Gingrich xuống và có thể loại ông ra khỏi cuộc chiến luôn. Dĩ
nhiên ông Gingrich hạ thấp tầm quan trọng của ba cuộc bầu mà chúng ta đang bàn
và xác nhận trọng tâm của ông là ngày 6 tháng 3 tới, được gọi là "Super
Tuesday" khi mười tiểu bang cùng bầu một ngày, trong đó có nhiều địa phương
miền Nam nằm trong địa bàn ông Gingrich, như tiểu bang nhà Georgia, hay
Tennessee, Oklahoma và Virginia. Cho đến nay, các thăm dò cho thấy ông Gingrich
đang đứng đầu khá xa tại những nơi này.</p><p>Nhưng
từ đây đến ngày Super Tuesday còn rất xa và chẳng ai biết được chuyện gì sẽ xẩy
ra. </p><p>Chỉ
biết là một tuần sau chiến thắng của ông Santorum, các thăm dò dư luận trên
toàn nước Mỹ cho thấy ông Santorum đã từ chỗ vô danh leo lên hàng đầu, hạ cả
hai ông Gingrich và Romney. Kết quả trung bình một nửa tá thăm dò cả nước tính
vào ngày 14 tháng 2: Santorum 30%, Romney 28%, và Gingrich 16%, theo báo điện tử
Real Clear Politics. Cứ cho là các thăm dò không chính xác lắm và có thể trồi sụt
hàng ngày, thì ta vẫn có thể nhận định hai ông Romney và Santorum đang ở thế
ngang ngửa với nhau trong khi ông Gingrich tụt dù khá mạnh. </p><p>Với chiến thắng của ông Santorum, thông điệp của
khối bảo thủ tại cả ba tiểu bang không thể nào rõ ràng hơn: chúng tôi vẫn chưa
tin và do đó vẫn không thể chấp nhận cựu thống đốc tiểu bang cấp tiến nhất Mỹ
Massachusetts làm đại diện cho khối bảo thủ chúng tôi. Chúng tôi muốn quay qua
ông Gingrich, nhưng ông này bị khui ra nhiều thói hư tật xấu quá, chúng tôi chỉ
thấy còn có ông Santorum là sáng giá nhất. </p><p>Nếu
so sánh hai ông Romney và Santorum thì quả ông Santorum có dấu triện bảo thủ
trên trán không chối cãi được. Ông tượng trưng cho những giá trị luân lý gia đình
đúng theo gương mẫu công giáo, kịch liệt chống phá thai, chống đồng tính, là người
công giáo thuần hành, từ mấy chục năm nay, không bao giờ bỏ đi lễ nhà thờ ngày
chủ nhật một lần nào, là một người chủ gia đình hết sức gương mẫu, có bẩy con -
chuyện hy hữu trong xã hội Mỹ - nhất định không ngừa thai bằng những phương
pháp y khoa tân thời; khi con út của ông bị đau, bỏ vận động tranh cử ngay, trở
về lo cho con.</p><p>Ông
chủ trương cân bằng ngân sách, mọi người sống trong phương tiện của mình, không
hoang phí, không ỷ lại vào trợ cấp của Nhà Nước trong khi Nhà Nước tôn trọng tự
do cá nhân và không áp dụng chế độ sưu cao thuế nặng, đè xấn dân lấy tiền làm
những chuyện vô bổ và phí phạm. Ông đả kích cải tổ y tế của ông Romney là cha đẻ
của cải tổ y tế tại hại của TT Obama.</p><p>Đối
với ông Romney, ông Santorum còn có một điểm lợi lớn. Trong khi ông Romney mang
cái tội là quá giàu trong thời buổi kinh tế khó khăn mà lại nổi tiếng với
thành quả sa thải nhân công, thì ông Santorum là người xuất thân trong gia đình
di dân từ Ý, trung lưu bình thường, từng đắc cử thượng nghị sĩ Pennsylvania nhờ
hậu thuẫn của dân lao động da trắng (white blue-collar) của tiểu bang này. Khối
dân lao động da trắng là thành phần cử tri cột trụ trong các cuộc bầu tổng thống
ở Mỹ, không có không thể đắc cử được. Các tổng thống Cộng Hoà như Nixon,
Reagan, và Bush đều thắng cử nhờ khối cử tri này. Hiện nay, khối này có vẻ ủng
hộ ông Santorum và hết sức dè dặt với ông Romney.</p><p>So
với ông Gingrich, ông Santorum cũng có giá hơn: bảo thủ như nhau, nhưng ông
Santorum có đời sống gia đình gương mẫu không lem nhem như Gingrich, ông cũng
là người có vẻ điềm tĩnh, chín chắn, không bốc đồng tuyên bố vung vít như ông
Gingrich, cũng không díu líu gì đến bất cứ xi-căng-đan nào, ít hành trang
chính trị, đã vậy trông ăn ảnh, trẻ tuổi và đẹp trai hơn ông già Gingrich.
Trong sáu năm là thượng nghị sĩ, ông chứng tỏ mình có lập trường bảo thủ kiên định
không nhập nhằng hợp tác với kẻ thù Dân Chủ như Gingrich đã làm, hay chao đảo
lập trường như ông Romney.</p><p>Đảng
Cộng Hòa có vẻ vẫn chia làm hai khuynh hướng: nhóm trí thức, lợi tức cao, cùng
với phụ nữ, ủng hộ ông Romney với chủ trương ôn hòa, và nhóm lợi tức thấp hơn,
ít học hơn, thành phần lao động, Tea Party, và nam giới, ủng hộ bất cứ ai ngoài
ông Romney, với chủ trương chống cấp tiến và TT Obama đến cùng.</p><p>Sự
thành công bất ngờ và mau lẹ của ông Santorum cũng chưa hẳn là đoạn kết của
hành trình của ông. Từ trước đến giờ, ông bị coi thường như là ứng viên hạng ruồi,
chẳng ai để ý đến nhiều. Nhưng cũng như các ứng viên khác trước đây, một khi
tên tuổi ông leo lên trang nhất các báo và các thăm dò dư luận, thì bảo đảm ông
sẽ bị đánh. Từ phía các đồng chí địch thủ trong đảng Cộng Hòa, và từ phe Dân Chủ
và đồng minh của phe này là truyền thông dòng chính.</p><p>Không
cần phải chờ đợi lâu lắc, một tuần sau khi ông Santorum đại thắng tại ba tiểu
bang miền trung bắc, trong khi ông Romney chuẩn bị hàng loạt quảng cáo trên
truyền hình đả kích ông Santorum thì nhà báo Stephanie Coontz mau mắn viết một
bài dài thòng chỉ trích ông Santorum trên báo điện tử phe ta CNN, rằng ông
Santorum muốn đưa phụ nữ trở về thời đồ đá vì lập trường chống phá thai cũng như
chuyện ông Santorum kêu gọi phụ nữ nên chú tâm nhiều hơn vào trách nhiệm gia đình
thay vì tranh thắng công danh sự nghiệp ngoài đời. Đại ý, quan điểm của bà
Coontz tiêu biểu cho suy nghĩ của phụ nữ cấp tiến: nói trách nhiệm lớn của phụ
nữ là lo cho gia đình đúng là lạc hậu, tại sao đàn ông không ở nhà lo cho gia đình
để đàn bà ra đời lo cho sự nghiệp?</p><p>Nhìn
chung vào cuộc diện, tình hình không có gì sáng sủa cho đảng Cộng Hoà. Trái lại,
theo các thăm dò mới nhất, TT Obama đúng là ngư ông đang thủ lợi. Hậu thuẫn của
tổng thống từ khoảng trên 40% trước đây, đã leo dần lên trên 50%. Ông Romney trước
đây có tỷ lệ hậu thuẫn ngang ngửa với TT Obama, bây giờ đã thua lại từ sáu đến
mười điểm. Các ông Gingrich và Santorum vẫn chưa phải là đối thủ của TT Obama.</p><p>Điều
đáng nói và thật hiển nhiên là diễn biến này hoàn toàn không nhờ thành quả đặc
biệt nào của TT Obama, mà đáng tiếc thay cho đảng Con Voi, chỉ là kết quả của
những cuộc đánh đá trong nội bộ Cộng Hoà, với các ứng viên luôn phiên tố giác
nhau, khui các thói hư tật xấu của nhau cho thiên hạ thấy. Nhiều người còn lo
ngại cuộc đấu sẽ tiếp diễn đến cùng, đưa đến tình trạng bế tắc tại Đại Hội Đảng
mùa hè tới. Có thể là sẽ không đến nỗi tệ như vậy, nhưng thực tế là trong các
cuộc bầu sơ bộ vừa qua, con số cử tri Cộng Hòa đi bầu đã thấp hơn hồi 2008, có
nghĩa là sự hồ hởi cần thiết để có thể hạ được TT Obama dường như đã không còn
nữa. </p><p>Đây
mới là yếu tố đáng lo nhất cho đảng Cộng Hoà. Cũng là điều đáng lo nhất cho tương
lai lâu dài của nước Mỹ. Nếu TT Obama đắc cử, trong nhiệm kỳ cuối sẽ không có
nhu cầu lấy điểm dân chúng để được bầu lại nữa, mà chỉ có nhu cầu làm một cái
gì để đời bất kể tốn kém đến đâu. Lúc đó, chỉ còn hy vọng là khối đối lập Cộng
Hòa vẫn còn giữ được quốc hội để kéo tay tổng thống lại thôi. </p><p>Điểm
đặc biệt của cuộc chạy đua năm nay: chẳng có một ông đối lập nào nói gì về chuyện
thế giới vì chẳng có ông nào có chút kinh nghiệm gì về đối ngoại hay quốc
phòng. Những năm trước, ta còn thấy những Nixon, Bush (cha), Kerry, McCain,
Biden,..., năm nay, trực diện với khủng hoảng Âu Châu, sóng thần dân chủ tại
Trung Đông, nguy cơ nguyên tử Iran, mộng bá quyền của Trung Cộng tại biển Đông,
và biết bao vấn đề lớn khác, nhưng nước Mỹ hình như trùm chăn chỉ thắc mắc ông
nào đóng bao nhiêu tiền thuế, ông nào mấy vợ, ông nào cho phá thai, ... trong
khi ông tổng thống đương nhiệm vẫn loay hoay gỡ rối.</p><p>TT
Obama đang vất vả năn nỉ Do Thái đừng đánh Iran, nhắm mắt để Syria giết hàng
ngàn dân chống đối, bất lực chấp nhận Ai Cập bắt cả chục chuyên viên thiện nguyện
Mỹ, ém nhẹm chuyện nội chiến đang lan rộng tại Iraq để lo chuẩn bị tháo chạy khỏi
Afghanistan, bắt tay làm thân với ông chủ nợ lớn nhất là Tập Cận Bình để tiếp tục
bán công khố phiếu hầu vay tiền tăng chi và mua phiếu.</p><p>Một
viễn tượng không mấy sáng sủa cho cả nước Mỹ. (19-2-12)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a184154/hien-tuong-santorum

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/