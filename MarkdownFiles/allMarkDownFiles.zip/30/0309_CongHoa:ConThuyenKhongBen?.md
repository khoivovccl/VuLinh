# Cộng Hòa: Con Thuyền Không Bến?

27/12/2011

<p>Cộng
Hòa: Con Thuyền Không Bến?</p><p>Vũ
Linh</p><p></p><p>Việc
các ứng viên Cộng Hoà đấm đá nhau đã mang lợi lớn cho TT Obama...</p><p>Mùng
ba Tháng Giêng tới là ngày tiểu bang Iowa sẽ chính thức mở màn cuộc tranh cử tổng
thống Mỹ, với cuộc bầu sơ bộ đầu tiên trong nội bộ đảng Cộng Hòa. Đếm lại thì
không còn bao lâu nữa, nhưng vẫn chưa ai nhìn thấy một hình ảnh rõ nét nào từ
phía đảng này. Vẫn chưa ai biết ai sẽ có hy vọng thắng.</p><p>Trong
khi bên Dân Chủ hoàn toàn ổn định, không ai ra tranh chức với đương kim tổng thống
thì bên Cộng Hòa lại quả là rối hơn tơ vò.</p><p>Chỉ
có một ứng viên duy nhất là ở trong tình trạng ổn định, đó là cựu thống đốc
Massachusetts Mitt Romney, nhưng ông chỉ có hậu thuẫn của không tới một phần tư
đảng viên. Còn lại thì vẫn là một lô chính khách nhẩy lên nhẩy xuống, chạy ra
chạy vào, chẳng ai biết đâu mà đoán. Cột báo này đã bàn ra tán vào về bốn nhân
vật Cộng Hòa, luôn phiên nổi lên rồi lặn xuống. Từ bà dân biểu Michele
Bachmann, đến thống đốc Texas Rick Perry, rồi doanh gia Herman Cain, và cuối
cùng là cựu chủ tịch Hạ Viện Newt Gingrich. Nhưng rồi hình như ông này cũng vẫn
chưa phải là ngườicuối cùng.</p><p>Cũng
không khác gì những người đi trước, ông Gingrich vào cuộc với những tỷ lệ hậu
thuẫn lẹt đẹt dưới mắt cá chân, rồi bất ngờ vọt lên như hỏa tiễn, để rồi rớt xuống
cũng rất mau chóng. Ông Gingrich bắt đầu với những tỷ lệ cỡ 5% hậu thuẫn, ì ạch
mãi mới lên tới mức 10%, rồi bất ngờ vù lên trên 40%, để rồi chỉ hai tuần sau
là tuột xuống khoảng 25% lại. Một phần tư hậu thuẫn cũng còn khá cao so với những
người đi trước ông, như bà Bachmann và ông Perry bây giờ lẹt đẹt ở mức dưới
10%, hay ông Cain đã bỏ cuộc. Tuy nhiên cái hướng rõ ràng của ông Gingrich là đang
đi xuống khá nhanh.</p><p>Một
lần nữa, điều đáng nói là trong khi ngôi sao mới Gingrich tuột dốc thì ông
Romney vẫn không ngoi lên được. Chỉ xác định thế đứng cứng ngắc của ông này.</p><p>Để
rồi ta thấy lại xuất hiện một ngôi sao mới. Hình như vậy thôi, chứ cũng không
chắc là ngôi sao thật. Ngôi sao mới nổi này là ông Ron Paul, Dân biểu Texas. Từ
trước đến giờ, ông chỉ được hậu thuẫn lác đác của dưới 5% đảng viên Cộng Hoà, rồi
dần dần bò lên gần 10%. Theo thăm dò trên toàn quốc thì ông cũng chẳng có gì đáng
quan tâm, vì vẫn xấp xỉ 10%-15%, thua xa các ông Romney và Gingrich. </p><p>Nhưng
điểm đáng nói là tại Iowa, ông Paul đã vọt lên hàng đầu, với 24%, và tại New
Hampshire, ông nhẩy lên hạng nhì sau ông Romney, với 20%. Đây là hai tiểu bang
có bầu sơ bộ đầu tiên. Ông Paul mà giữ được vị trí nhất nhì ở đây thì sẽ được
truyền thông thổi phồng để từ đó lấy trớn leo lên cao hơn, không khác gì chuyện
Obama từ vô danh mà về nhất tại Iowa và nhì tại New Hampshire, rồi vào Nhà Trắng
luôn hồi năm 2008.</p><p>Ông
Paul năm nay 77 tuổi, là bác sĩ phụ sản (Ob-Gyn), cũng là dân biểu Cộng Hòa từ
15 năm, đại diện cho một đơn vị phía Tây-Nam Houston, gồm cả Galveston là cửa
biển của Houston, Texas. Ông có điểm rất đặc biệt. Mặc dù ghi danh và tranh cử
với tư cách Cộng Hòa, nhưng ông có quan điểm khác xa với lập trường chung của Cộng
Hoà mà theo xu hướng tự do cực đoan gọi là "libertarian". </p><p>Đây
là lần thứ ba ông Ron Paul ra tranh cử tổng thống, và từ trước đến giờ không ai
coi là thành phần đáng chú ý. Ngay cả kẻ viết này cũng đã từng gọi ông này là ông
già gàn trên cột báo này.</p><p>Ông
Paul thật sự là người chủ trương khuynh hữu cực đoan, đòi hỏi tự do tối đa, đến
độ gần như theo khuynh hướng vô chính phủ -anarchist- tuyệt đối tin tưởng ở quyền
tự do cá nhân và kinh tế thị trường sẽ tự động điều chỉnh tất cả mọi chuyện,
không cần Nhà Nước phải làm gì hết. Danh sách những chuyện ông chống sẽ làm cho
nhiều người gãi đầu gãi tai: </p><p>-
chống lại chính sách thu thuế tối đa để chi trả cho những chương trình vĩ đại của
TT Obama, khiến cho nước Mỹ nợ hơn chúa chổm; mỗi lần đọc diễn văn đòi cắt chi
tiêu 1.000 tỷ là ông được thiên hạ hoan hô rầm rộ;</p><p>-
chống mọi loại chiến tranh, kể cả cuộc chiến chống khủng bố, chỉ giữ quân lực ở
mức tối thiểu bảo vệ lãnh thổ thôi, còn Mỹ rút quân hết khỏi thế giới. Theo ông
Paul, Mỹ là một đế quốc hắc ám, đã gây ra chiến tranh triền miên trên thế giới
từ Thế Chiến Thứ Nhất đến giờ; khủng bố tấn công 9/11 chỉ là hậu quả của chính
sách đối ngoại hung hãn của Mỹ thôi;</p><p>-
chống mọi viện trợ cho các nước khác, nước Mỹ đóng cửa không chơi với ai hết, đặc
biệt là chống Do Thái, đồng minh quan trọng nhất của Mỹ ở Trung Đông; </p><p>-
đóng cửa CIA, giải tán hàng loạt bộ, sở của Nhà Nước;</p><p>-
đóng cửa Ngàn Hàng Dự Trữ Liên Bang, chống cải cách tài chánh, để các ngân hàng
tự do làm gì thì làm;</p><p>-
chống luật Dân Quyền Civil Rights Act cho dân da màu được quyền đi bầu;</p><p>-
nhân danh tự do cá nhân, chống mọi hình thức kiểm soát việc sở hữu vũ khí và chống
mọi hạn chế trong việc sử dụng ma túy;</p><p>-
chống các hình thức trợ cấp, cứ việc để cho các quỹ tiền già social security,
hay bảo hiểm y tế medicare từ từ phá sản rồi dẹp luôn.</p><p>Đã
vậy, báo chí mới khui lại chuyện cách đây 20 năm, ông Paul xuất bản một loại bản
tin, trong đó đầy những bài viết sặc mùi kỳ thị dân da đen, ca tụng Đức Quốc
Xã. Năm 1992, trong một bài bàn về cuộc nổi loạn của dân da màu tại Los Angeles
năm đó, bản tin viết tình hình sẽ chỉ ổn định khi mấy anh đen đi lãnh chi phiếu
oe-phe thôi. Năm 1996, một bài viết khác cho rằng 95% đàn ông da đen của vùng
Washington DC là thành phần phạm pháp. Một bài viết nữa cho rằng mục sư Martin
Luther King, thần tượng giải phóng dân da đen, chỉ là tay chơi gái hạng quốc tế,
vũ phu chuyên đánh đập phụ nữ. Ông Paul nhìn nhận có những bài đó trong bản tin
của ông phát hành, nhưng xác nhận không để ý, không biết ai viết, và bây giờ
lên tiếng kết án những quan điểm kỳ thị đó. </p><p>Với
chủ trương chống đủ thứ và kỳ thị trắng trợn như vậy, đang lẽ thiên hạ phải coi
ông Paul này như người bất bình thường. Và đúng vậy, mấy lần trước, ông này ra
tranh cử tổng thống chẳng ai để ý, và ông chỉ lảng vảng cỡ 5%-7% hậu thuẫn từ
những nhóm quá khích cực đoan. </p><p>Nhưng
đặc biệt năm nay ông leo lên cao hơn bình thường. Một yếu tố quan trọng trong sự
thành công của ông Paul hiện nay là chủ trương cho hút sách tự do của ông đã được
giới trẻ, nhất là sinh viên cấp tiến và dân gọi là hyppies, ủng hộ hết mình.
Không thiếu gì những người trong nhóm Occupy Wall Street đã hoan hô ông Paul vì
chuyện hút sách này, cũng như vì chủ trươngchống lung tung, rất hợp nhĩ với đám
tự nhận là 99%!</p><p>Nhìn
vào tình hình chung của Cộng Hòa trong thời gian qua, nhất là qua việc ông
Gingrich đang tuộc dốc và ông Paul đang lên, các quan sát viên chính trị đã nhận
định được một số yếu tố quan trọng:</p><p>- Cựu thống đốc Romney vẫn không thể nào tạo được
niềm tin trong khối bảo thủ Cộng Hòa. Bất kể chuyện gì xẩy ra, hậu thuẫn của
ông vẫn đứng yên tại mức 20%-25%, không xuống thấp hơn mà cũng không lên cao hơn
được. </p><p>-
Khối cử tri bảo thủ vẫn loay hoay đi tìm người đáng tin hơn ông Romney, và cho đến
nay chưa tìm ra ai khác. Họ nhẩy qua nhẩy lại với bốn người, mà vẫn chẳng thấy
ai hoàn hảo, không thiếu sót cái này thì cũng khiếm khuyết chỗ kia. Và không ai
có sức thu hút bền vững lâu dài hết.</p><p>-
Bất cứ người nào vừa ngoi đầu lên là bị các ông bà đồng chí xúm lại kéo giò xuống
ngay. Nhất là ông Gingrich, bị cho là có hy vọng nhiều nhất, nên cũng bị đánh mạnh
nhất. Tại Iowa, trong hai tuần qua, truyền thông đã tràn ngập quảng cáo đả kích
ông Gingrich, và kết quả là tại tiểu bang then chốt này, hậu thuẫn của ông
Gingrich vọt lên trên 30%, nhưng chỉ một tuần sau, tuột mất một nửa ngay. </p><p>Những
quảng cáo chống báng này đều từ các ông bà đồng chí Cộng Hòa của ông Gingrich
tung ra. Các ứng viên chính trị miệng thì luôn đả kích những chiến thuật tranh
cử tiêu cực, khui chuyện không tốt đẹp, nhưng thực tế, chiến thuật này rất hữu
hiệu và chẳng ai e lệ không dám sử dụng, bên Cộng Hòa cũng như bên Dân Chủ. Một
đời làm chính trị của ông Gingrich đã để lại quá nhiều thành tích và vết tích,
như tỳ vết của phe này hay nhóm kia. Trong chính trị Mỹ, bất cứ lời nói nào hay
hành động nào, bảo đảm cũng có nửa dân Mỹ chống, tuy chưa ấu trĩ đến độ chụp mũ
vớ vẩn và phỉ báng nhảm nhí.</p><p>-
Việc ông Paul nổi lên chỉ xác nhận khối bảo thủ quyết tâm chống TT Obama và đường
lối cấp tiến của ông đến cùng, một thứ phản ứng ngược đối với chính sách Nhà Nước
vú em quá mức của TT Obama khiến nhiều người bực mình, ủng hộ ông Paul, gọi là cho
bõ ghét, hay là gửi thông điệp cho Obama. Bất cứ ai cũng được, dù khùng hay
gàn, miễn là không phải Obama.</p><p>Chuyện
ông Paul đang dẫn đầu hậu thuẫn tại Iowa đang là mối đau đầu lớn nhất cho cấp
lãnh đạo đảng Cộng Hoà nói chung, và tại tiểu bang Iowa nói riêng. Tuy không có
bằng chứng rõ ràng, nhưng đã có nhiều triệu chứng cho thấy đảng Dân Chủ đang vận
động đảng viên của mình ghi danh là Cộng Hòa để đi dồn phiếu cho ông Paul, gây
xáo trộn vĩ đại cho Cộng Hòa, vì không ai tin ông ta sẽ thành ứng viên đắc cử đại
diện cho Cộng Hoà chống TT Obama, mà nếu có đi nữa thì TT Obama sẽ nuốt sống
ông này thôi.Ngoài ra, còn có thể có trường
hợp ông Paul nếu không đắc cử trong đảng Cộng Hoà, sẽ nhẩy ra tranh cử với tư
cách độc lập, chia phiếu Cộng Hòa và làm cỗ cho TT Obama xơi.</p><p>Việc
các ứng viên Cộng Hoà đấm đá nhau đã mang lợi lớn cho TT Obama. Thiên hạ nhìn
thấy rõ những khuyết điểm của các ứng viên đó, do chính họ tố giác lẫn nhau,
trong khi bên Dân Chủ thì dĩ nhiên ai cũng lo ca tụng TT Obama thôi. Kết quả cụ
thể là hậu thuẫn của TT Obama, có lúc xuống đến dưới 40%, bây giờ đã leo lên đến
khoảng 49%, cao nhất từ gần cả năm nay, dù chẳng có biến cố nào đặc biệt xẩy ra
trong thời gian qua hết, không kể cái tăng vọt nhất thời sau khi giết được Bin
Laden.</p><p>Người
ta cũng đã nhìn vào bế tắc về vấn đề thuế an sinh xã hội (social security tax)
tại Quốc hội có thể đã giúp TT Obama. TT Obama và Thượng Viện đồng ý gia hạn việc
giảm thuế này thêm hai tháng nữa, coi như là một hình thức kích cầu kinh tế, chứng
tỏ cái thuyết bớt thuế sẽ giúp phục hồi kinh tế thực tế cũng đã được TT Obama
chấp nhận.Đây là lần thứ ba TT Obama muốn
tiếp tục chính sách giảm thuế của TT Bush dù luôn luôn lớn tiếng đả kích Bush.
Tuy nhiên, đề nghị này lại bị các dân biểu Cộng Hòa bác tại Hạ Viện. Cãi cọ mãi
rồi cuối cùng cũng thôngqua. Họ cho rằng
những hình thức tạm bợ vá víu tháng này qua tháng nọ khôngthể là giải pháp. Mà vấn đề chính là phải cắt
giảm những chi tiêu ngút ngàn của TT Obama và phe Dân Chủ cấp tiến.</p><p>Một
yếu tố quan trọng hơn nữa: quỹ an sinh bị đe dọa phá sản từ mấy năm nay, bây giờ
chẳng những chẳng ai đưa ra được đề nghị cứu vãn, mà lại còn đòi cắt bớt tiền đóng
góp vào quỹ, bảo đảm quỹ sẽ khánh tận sớm hơn, có nghiã là các cụ sẽ lãnh ít tiền
hưu trí hơn và tình trạng này sẽ xẩy ra sớm hơn thôi.</p><p>Một
vài chính khách Dân Chủ mau mắn tố giác việc không gia hạn giảm thuế này sẽ gây
khó khăn cho kinh tế và khiến việc phục hồi trở nên gai góc hơn. Chuyện tố giác
này nghe cũng lạ tai: chính khách Dân Chủ cũng như TT Obama bây giờ lại nằng nặc
đòi bớt thuế và đe dọa không bớt thuế sẽ kéo dài suy trầm kinh tế. Nghe cứ tưởng
là mấy ông Cộng Hoà đang vận động tranh cử.</p><p>Nhìn
vào đây, ta mới thấy bản chất thể chế dân chủ của Mỹ: tất cả đều bị chi phối bởi
các cuộc bầu cử, và chẳng có gì đáng lấy làm lạ nếu các chính khách thay đổi lập
trường chính trị như hiện ta đang chứng kiến. Phe Dân Chủ bình thường chủ trương
tăng thuế bây giờ lại đòi giảm thuế, trong khi phe Cộng Hoà bình thường đòi giảm
thuế bây giờ lại phản đối chuyện giảm thuế. Tất cả chỉ là tính toán chính trị
nhất thời cho cái ghế của mình thôi.</p><p>Gần
một nửa dân Mỹ cho rằng cả hai bên, chẳng bên nào đáng được bầu vì chẳng bên
nào đưa ra được người tài năng xuất chúng. Một bên là một ông tổng thống đã thất
bại, chả làm nên trò trống gì ngoài chuyện làm bánh vẽ rất đẹp khiến cho đến giờ
nhiều người vẫn còn ngẩn ngơ hy vọng. Bên kia là các ứng viên hạng B hay C, người
nào cũng đầy khiếm khuyết và chẳng ai có khả năng thu hút thiên hạ hay có được
một kế sách an bang tế thế đáng kể nào, ít ra là cho đến bây giờ. </p><p>Có
nhiều chuyên gia lo sợ kỳ bầu cử năm tới đây sẽ là cuộc bầu với ít cử tri đi bầu
nhất. Cá mè một lứa, ta đi câu sướng hơn là xếp hàng đi bầu, dù biết như vậy sẽ
có lợi lớn cho những người đương nhiệm. (25-12-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a181749/cong-hoa-con-thuyen-khong-ben

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/