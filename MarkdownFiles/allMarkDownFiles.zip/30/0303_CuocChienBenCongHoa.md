# Cuộc Chiến Bên Cộng Hòa

07/02/2012

<p>Cuộc Chiến
Bên Cộng Hòa </p><p>Vũ Linh</p><p>...Romney mắc
cái tội nhiều tiền và Gingrich mắc cái tội nhiều vợ...</p><p>Cách đây một
tháng, thiên hạ nhìn vào đảng Cộng Hòa là nhìn thấy hình ảnh một đảng ển ển xìu
xìu, với một lô ứng viên nhạt hơn nước lã, đứng đầu bởi một người có vẻ chính
trị gia chuyên nghiệp cổ điển, với những bài diễn văn hấp dẫn như những liều
thuốc ngủ, vận động tranh cử có thể nói toàn thời từ hơn bốn năm nay, mà vẫn
không thu hút được hơn một phần tư đảng viên. Đa số dân Mỹ thất vọng với TT
Obama và muốn có sự thay đổi, nhưng nhìn vào khối đối lập Cộng Hòa thì gần như…
mất hứng.</p><p>Thế rồi tình
hình bất ngờ chuyển biến. Qua các cuộc tranh luận liên tục như bất tận, các
ngôi sao của đảng nổi lên rồi lặn như chong chóng. Con thuyền Cộng Hòa với gần
một tá bến nước trước mặt vẫn lơ lửng tìm chỗ thả neo. Nhưng dường như cho đến
giờ, sau cuộc bầu sơ bộ tại Florida, chỉ còn lại hai nơi có thể ghé bến.</p><p>Ứng viên đầu
đàn, ông Mitt Romney, là người từ trước đến giờ vẫn được coi là người cuối cùng
rồi sẽ chiến thắng, bây giờ phải trực diện với một ứng viên lúc đầu chỉ có được
khoảng 1% hậu thuẫn trong chính nội bộ đảng, ông Newt Gingrich.</p><p>Tại Florida,
ông Romney đè bẹp ông Gingrich với tỷ số 46% - 32%, lớn hơn mọi dự đoán. Lẹt đẹt
tuốt phiá sau là ông Santorum có vẻ tranh cử kiếm ghế phó và ông Paul gàn gàn dở
dở không chịu bỏ cuộc. Hai ông đồng chí, đồng đảng Romney và Gingrich thì không
thể nào khác biệt nhiều hơn. Như mặt trời mặt trăng. </p><p>Ông Romney là
người có lập trường tương đối cấp tiến, rồi chuyển qua bảo thủ ôn hoà. Là thống
đốc tiểu bang, sau trở thành doanh gia giàu sụ. Ông gần như là hiện thân của sự
điềm tĩnh, chính chắn, hoàn hảo, kỷ luật, luôn cân nhắc tính toán mọi hành động
cũng như lời nói. Ăn mặc lúc nào cũng chỉnh tề, đầu chải mướt không một cọng
tóc nào phất phơ ra ngoài. Ăn nói nhạt phèo, buồn ngủ nhất, thỉnh thoảng lên
cơn nói hăng hái thì lại... nói hớ bị đối thủ khai thác chết thôi. Ông theo đạo
Mormon, một tôn giáo trước đây chấp nhận đa thê và bị coi như tà đạo, nhưng lại
là người có đời sống gia đình gương mẫu nhất. Ông được coi như thuộc giai cấp
quý tộc vùng Đông Bắc. Mặc dù chưa bao giờ đặt chân đến Hoa Thịnh Đốn, nhưng
ông lại là người được hậu thuẫn đồng loạt của guồng máy và cấp lãnh đạo của đảng.</p><p>Trong khi đó,
ông Gingrich lại là hình ảnh trái ngược. </p><p>Ông này không
phải là doanh gia mà là chính trị gia chuyên nghiệp. Cách đây gần hai thập
niên, đã lãnh đạo sự phục hồi của khuynh hướng bảo thủ và giúp đảng Cộng Hoà
chiếm lại được cả hai viện quốc hội sau bốn thập niên thống trị của đảng Dân Chủ.
Ông cũng là người với đời sống riêng tư gây ra tranh cãi không ngừng, bị mang
tiếng –thật hay oan- về tiền bạc, lạm quyền. Về tính tình thì ông cũng là người
nổi tiếng bốc đồng, nói năng hùng hổ mạnh bạo, gần như bất chấp hậu quả, rất là
thiếu kỷ luật tự chế. Ông là công giáo, coi như là phe chính đạo, nhưng lại có
tới ba đời vợ, mà mỗi lần đổi vợ lại là một vụ xì-căng-đan. Ông này được coi
như thành phần redneck –nôm na ra là Mỹ ruộng- của miền Nam (tiểu bang
Georgia). </p><p>Ngược ngạo
thay, ông cả đời hoạt động chính trị tại thủ đô, chủ tịch Hạ Viện, quen biết mật
thiết với hầu hết nghị sĩ dân biểu và cấp lãnh đạo đảng, mà bây giờ lại bị cả
guồng máy đảng chống.</p><p>Trong chính
trị Mỹ, mặc dù cả hai đảng Cộng Hoà và Dân Chủ đều tuyển lựa đại diện theo
phương thức phổ thông đầu phiếu trong khối đảng viên trên tất cả năm chục tiểu
bang, trên thực tế, kết quả thường khác nhau xa.</p><p>Đảng Cộng Hoà
bảo thủ có khuynh hướng tuyển chọn những ứng viên trong tôn ti trật tự, có
nghĩa là lấy những người đã hoạt động lâu năm cho đảng, có vai vế lãnh đạo hay
uy tín lớn trong đảng, được guồng máy của đảng chấp nhận. Từ tướng Eisenhower,
đến phó tổng thống Nixon, lãnh đạo Hạ Viện Ford, thống đốc Reagan, chủ tịch đảng
Bush (cha), chủ tịch thượng viện Dole, thống đốc Bush (con), thượng nghị sĩ
thâm niên McCain.</p><p>Đảng Dân Chủ
trái lại, hễ đưa ra những nhân vật lớn có uy tín hay thâm niên trong đảng như
các phó tổng thống Humphrey, Mondale và Gore, hay thượng nghị sĩ McGovern,
Kerry thì đều bị thảm bại dưới tay Cộng Hoà. Chỉ thành công khi tuyển chọn những
nhân vật mới lạ, từ ngoài đột kích vào bên trong đảng và được hạ tầng đưa lên.
Từ các thống đốc vô danh của các tiểu bang nhỏ như Carter, Clinton, đến một người
tuyệt đối không ai biết, không có thành tích hay uy tín gì là Obama. Cả ba ông
đều phải tranh đấu chống lại guồng máy đảng, để rồi thắng được guồng máy đảng
và cả đảng đối lập Cộng Hòa luôn.</p><p>Nói rõ ra, muốn
thắng trong Cộng Hoà phải là người được lãnh đạo đảng tấn phong, trong khi muốn
thắng bên Dân Chủ phải là người từ hạ tầng đưa lên, chống lại guồng máy của đảng.</p><p>Trong truyền
thống đó, thì ông Romney đã là người mà guồng máy đảng Cộng Hòa coi như đã tấn
phong. Ông được cựu TT Bush cha, và các cựu ứng viên tổng thống McCain, Bob
Dole, mạnh mẽ ủng hộ. Nhưng lần này, ứng viên của đảng bị khó khăn bất ngờ với
ông Gingrich. Nhiều người đã cho rằng sự nổi bật bất ngờ của ông Gingrich phản
ánh một cuộc nổi loạn trong nội bộ đảng, nổi loạn của thành phần hạ tầng đảng
viên chống lại cấp lãnh đạo đảng.</p><p>Cuộc nổi loạn
này là của khối hạ tầng bảo thủ chẳng những bất mãn với những sắp xếp trước của
cấp lãnh đạo đảng, mà hơn thế nữa, còn cực kỳ bất mãn với chính sách sưu cao
thuế nặng của TT Obama, nhất định chống TT Obama bằng mọi giá, trong khi lãnh đạo
đảng Cộng Hòa lại hậu thuẫn một ứng viên nửa mùa, cấp tiến không cấp tiến, bảo
thủ cũng chẳng bảo thủ, chưa chống đối TT Obama một cách rõ ràng.</p><p>Ông Gingrich
với lập trường cực đoan hơn, đả kích TT Obama mạnh hơn, và nhất là đã đưa ra được
một bức tranh bảo thủ rõ ràng khác biệt với mô thức Obama, đã gãi đúng chỗ ngứa
của khối đảng viên hạ tầng, nên được hậu thuẫn mạnh của họ. Họ cũng nhìn thấy
cách ông Gingrich đối đáp với các nhà báo trong các cuộc tranh luận và thấy là
có người dám mạnh miệng với truyền thông cấp tiến ăn phải bả của TT Obama.
Thông điệp của hạ tầng đảng không thể không rõ ràng hơn: họ muốn một người chống
TT Obama một cách rõ ràng, trắng ra trắng đen ra đen, mạnh mẽ, không cần biết
người đó có hành trang chính trị hay cá nhân nặng đến cỡ nào. Đặc biệt là các cựu
ứng viên bảo thủ như thống đốc Perry, doanh gia Herman Cain, sau khi rút lui,
đã lên tiếng ủng hộ mạnh ông Gingrich. Cũng như cựu thống đốc Alaska bà Sarah
Palin. </p><p>Đối với nhiều
người, ông Romney có thể là người ít cực đoan, ít sai lầm, nên dễ thắng TT
Obama nhất, nhưng khối bảo thủ cực đoan nghĩ khác. Trước hết họ muốn một người
thực sự phản ảnh quan điểm bảo thủ của họ, sau đó, họ nghĩ là cần phải có một
người có quyết tâm đánh mạnh như ông Gingrich mới thắng được TT Obama, chứ một
người ôn hòa nửa chừng xuân – gần như rất hiền hòa lịch sự- như ông Romney thì
không thể thắng được. </p><p>Đây chính là
quan điểm tiêu biểu của dân cao bồi Mỹ: thắng bằng công thật mạnh, chứ thủ thì
chỉ thua thôi.</p><p>Ở đây, ảnh hưởng
của nhóm cực đoan Tea Party cũng được thể hiện rõ ràng. Sau khi chứng minh sức
mạnh của mình trong cuộc bầu cử giữa mùa tháng Mười Một 2010, nhóm Tea Party lại
chứng minh rõ ràng họ vẫn còn là một sức mạnh dài hạn trong chính trường Mỹ có
thể nổi loạn chống cả đảng Cộng Hòa luôn, so với ảnh hưởng có tính “phiến loạn
chống lung tung” vô tổ chức và không có ảnh hưởng chính trị của nhóm Occupy
Wall Street.</p><p>Ngay sau khi
ông Gingrich đại thắng tại South Carolina, người ta thấy phản ứng rất mạnh của
ông Romney cũng như của cấp lãnh đạo đảng. Những tấn công hướng về ông Gingrich
trở nên mạnh bạo hơn nhiều. Hai ông McCain và Dole không phải chỉ lên tiếng ủng
hộ ông Romney mà còn công khai đả kích ông Gingrich là người có tính cực đoan,
phiêu lưu và nguy hiểm, một việc làm thật hiếm thấy trong hàng ngũ các bậc “trưởng
thượng” trong đảng.</p><p>Mặc dù những
cái thói hư tật xấu của ông Gingrich chẳng là bí mật gì, tất cả mọi người đều
biết và vẫn chẳng có tác hại gì cho ông Gingrich tại South Carolina, nhưng phe
ông Romney đã quyết định ra tay mạnh hơn nữa, đả kích mạnh hơn nữa, đưa đến kết
quả ông Gingrich thua đậm tại Florida sau khi leo lên ngang ngửa với ông này
ngay sau khi kết quả tại South Carolina được công bố.</p><p>Trong một
tháng tới đây, cuộc chiến hứa hẹn sẽ có phần sôi nổi hơn. Những tuần tới, sẽ có
bầu sơ bộ tại những tiểu bang phiá Tây và phiá Bắc, thân thiện với ông Romney,
bảo đảm thắng lợi cho ông này. Nevada và Colorado là những tiểu bang có nhiều
người theo đạo Mormon. Michigan là tiểu bang mà ông bố của ông Romney trước đây
là thống đốc, trong khi Minnesota là tiểu bang hàng xóm, cả hai đều là những
bang cấp tiến dĩ nhiên là ông Gingrich không có chút hy vọng nào. Nhưng qua đầu
tháng Ba thì lại có bầu tại những tiểu bang miền Nam, như Georgia, Tennesse,
Virginia..., địa bàn của ông Gingrich.</p><p>Một cách thú
vị, ta thấy Cộng Hoà hình như đang trong tình trạng giống như đảng Dân Chủ năm
2007-08, khi toàn thể guồng máy đảng nằm trong tay bà Hillary và ủng hộ bà, mà
đảng viên hạ tầng lại nhất loạt hậu thuẫn ông Obama. Bà Hillary đã đánh ông
Obama những đòn chí tử, như cái quảng cáo gọi là “Ba giờ khuya” để nhắc nhở mọi
người ông Obama chỉ là tay mơ, trong khi ông Obama thì chỉ trích hai vợ chồng
Clinton là kỳ thị da đen. Obama sau khi đắc cử ứng viên Dân Chủ đã từ chối
không nhận bà Hillary làm phó vì chê ông Clinton quá nhiều hành trang, thuộc loại
ngựa chứng không kiểm soát được. Trong cuộc chiến này, phải đợi đến giữa mùa hè
2008, sau khi bà Hillary thua liên tục và mất hết hy vọng thắng ông Obama, bà
Hillary nhìn nhận đã thua, thì guồng máy đảng Dân Chủ mới chịu quay qua chấp nhận
và hậu thuẫn ông Obama.</p><p>Nhưng giữa cuộc
chiến Obama-Hillary và Romney-Gingrich, có hai khác biệt rất lớn ngoài chuyện hậu
thuẫn của guồng máy đảng: tiền và tổ chức. Trong khi Obama vận động được cả mấy
trăm triệu tiền của cử tri để đánh nhau với bà Hillary, thì ông Gingrich cho đến
nay vẫn gần như là tay trắng, không tiền và không tổ chức, trong cuộc chiến chống
Romney. Ông sau này có tiền, có tổ chức trên khắp 50 tiểu bang, và hậu thuẫn của
guồng máy đảng khắp nơi. Bức tường trước mặt ông Gingrich rất là cao. </p><p>Thế đang lên
của ông Gingrich cũng sẽ đặt ông Romney vào thế khó xử. Muốn chiến thắng, ông
Romney bắt buộc phải tấn công ông Gingrich mạnh hơn nữa, tức là gây mâu thuẫn với
hạ tầng đảng viên bảo thủ hơn nữa. Mặt khác, lại phải tìm cách lấy điểm với khối
bảo thủ này bằng cách chứng minh mình bảo thủ hơn, hay ít nhất cũng bảo thủ
không thua gì ông Gingrich. Một cách đu dây thật khó. Nhất là khi ta biết ông
Romney chưa bao giờ chứng tỏ mình là một người có tài vận động thu hút quần
chúng kiểu như Obama được.</p><p>Nhìn chung,
có nhiều triệu chứng cuộc chiến Romney-Gingrich sẽ tiếp diễn lâu dài và ngày
càng hung hãn. Chỉ có ngư ông Obama là đang ung dung thủ lợi, lâu lâu đổ tý dầu
vào lửa. Chuyện đổ dầu này không có gì khó lắm khi ông Romney mắc cái tội nhiều
tiền và ông Gingrich mắc cái tội nhiều vợ.</p><p>Đi xa hơn cuộc
chạy đua Romney-Gingrich, có nhiều người cho rằng đây đúng ra là một cuộc chiến
ý thức hệ trong đảng Cộng Hòa chứ không là một cuộc tranh chấp cá nhân. Trên
căn bản, Cộng Hoà vẫn là đảng bảo thủ, nhưng đang loay hoay phản ứng lại chính
sách thiên tả của TT Obama. Một khuynh hướng chống TT Obama theo lối tương đối
ôn hoà, với mục đích thu hút khối độc lập bất mãn với chính sách của TT Obama,
và một khuynh hướng bực mình cao độ muốn bằng mọi giá chống và đánh Obama đến
cùng. Người ta thấy trong đảng Cộng Hoà, khuynh hướng bảo thủ cực đoan, dưới ảnh
hưởng của nhóm cực đoan Tea Party, càng ngày càng lớn mạnh.</p><p>Dường như đảng
Cộng Hoà đang tìm hướng đi lâu dài, và trong cuộc tìm kiếm đó, vấn đề tranh chấp
cá nhân Romney-Gingrich không là chủ điểm. Ngay cả chuyện thua hay thắng TT
Obama có lẽ cũng không quan trọng bằng vì dù sao thì cũng chỉ là chuyện ngắn hạn
so với viễn ảnh dài hạn của đảng. Cuộc chiến Romney-Gingrich thật sự là cuộc
chiến về viễn ảnh lâu dài của đảng, khác xa cuộc chiến Obama-Hillary là cuộc
tranh dành giữa hai cá nhân.</p><p>Nói trắng ra,
trong khi đảng Dân Chủ dưới sự lãnh đạo của TT Obama càng ngày càng đi về phía
tả, thì đảng Cộng Hòa, như là một phản ứng tự nhiên, càng ngày càng đi về phía
hữu. Hay nói cho đúng hơn, đang cân nhắc là phải đi về phía hữu tới đâu.</p><p>Điều trớ trêu
nhất là trong khi ứng viên Obama tranh cử và đắc cử dưới chiêu bài đại đoàn kết
dân tộc, thì bây gìờ tổng thống Obama lại là vị tổng thống tạo phân hoá lớn nhất
trong lịch sử Mỹ. Đây chính là nhận định của hai nhà báo cấp tiến viết trên báo
phe ta là Washington Post ngày 30 tháng Giêng, 2012 (Obama: The most polarizing
president. Ever.) Nhận định của Washington Post thật ra hơi muộn, chỉ xác định
một chuyện mà thiên hạ chẳng còn lạ gì từ lâu rồi. Chỉ có dưới sự lãnh đạo của
TT Obama người ta mới thấy sự ra đời của các tổ chức cực đoan như Tea Party và
Occupy Wall Street. (5-2-12)</p><p>Quý độc giả
có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác
giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a183550/cuoc-chien-ben-cong-hoa

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/