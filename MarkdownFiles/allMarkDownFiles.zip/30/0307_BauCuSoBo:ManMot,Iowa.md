# Bầu Cử Sơ Bộ: Màn Một, Iowa

10/01/2012

<p>Bầu Cử Sơ Bộ:
Màn Một, Iowa</p><p>Vũ Linh</p><p></p><p>...Romney và
Obama đều được hậu thuẫn ngang hàng nhau, 47% mỗi người...</p><p></p><p>Ngày Thứ Ba vừa
qua đánh dấu hồi thứ nhất của cuộc tranh cử tổng thống Mỹ khi tiểu bang Iowa tổ
chức bầu sơ bộ.</p><p>Bên đảng Dân
Chủ, bầu sơ bộ được tổ chức âm thầm lặng lẽ, không ai biết, không ai hay. Có lẽ
phải đọc báo kỹ lắm thì mới thấy một mẫu tin ba dòng trong mục Rao Vặt mới biết
được đảng Dân Chủ cũng có bầu sơ bộ. TT Obama lên truyền hình video trực tiếp
nói chuyện với các đồng chí: ông nhắc nhở họ cuộc bầu cuối năm sẽ gay go lắm, đừng
nằm nhà ngủ mà không đi bầu vì tổng thống sẽ gặp khó khăn và cần lá phiếu của mỗi
người. Theo tin báo chí, cuộc nói chuyện bị cắt quãng, mất cả hình lẫn tiếng
nhiều lần vì trục trặc kỹ thuật. Không biết có phải vì lý do đó mà các đảng
viên nghe Đấng Tiên Tri nói chuyện mà hầu như ngủ gật hết. Không có gì mới lạ,
không ai vỗ tay, hò hét, nhẩy tưng tưng, thổn thức khóc, hay té xỉu như bốn năm
trước.</p><p>Bên đảng Cộng
Hoà, tình trạng hoàn toàn khác. Cả nước hồi hộp theo dõi đến gần ba giờ sáng –
giờ thủ đô Hoa Thịnh Đốn – thiên hạ mới biết kết quả bỏ phiếu. Và kết quả vừa
đáng ngạc nhiên vừa... không đáng ngạc nhiên chút nào.</p><p>Không đáng ngạc
nhiên vì kết quả vẫn ... như tất cả mọi người đã dự đoán.</p><p>Cựu thống đốc
Massachusetts, ông Mitt Romney, về đầu. Đó là điều các cuộc thăm dò đã cho thấy
từ gần một năm nay, bất kể những trồi xụt bất ngờ trong khối ứng viên Cộng Hòa.
Điều đáng nói là ông Romney nhận được đúng 25% phiếu. Đó là con số màu nhiệm của
ông đã có từ cuộc bầu sơ bộ đầu năm 2008 và trong suốt thời gian sơ bộ mở màn từ
năm ngoái. Đặc biệt hơn thế, cuối cùng ông Romney nhận được hơn 30.000 phiếu,
đúng y chang con số ông lãnh được bốn năm trước.</p><p>Điều này nói
lên sự hậu thuẫn của ông Romney chắc như đinh đóng cột, nhưng con số đệ tử của
ông không tăng mà cũng chẳng giảm, cho dù ông đã chuẩn bị vận động gần như
không ngừng từ bốn năm qua. Nôm na ra, một phần tư đảng viên Cộng Hòa tại Iowa
sống chết với ông trong khi ba phần tư vẫn không tin tưởng mà loay hoay tìm người
khác.</p><p>Tìm đi tìm lại,
sơ sơ đã thử qua sáu người, từ đại gia Donald Trump, đến nữ dân biểu Michele
Bachmann, thống đốc Texas Rick Perry, doanh gia Herman Cain, cựu chủ tịch Hạ Viện
Newt Gingrich, và dân biểu Ron Paul. Mà vẫn chưa vừa ý. Cuối cùng, kết quả cuộc
bầu sơ bộ đã lại đưa ra một ngôi sao mới của Cộng Hòa, ngôi sao thứ bẩy.</p><p>Và đây là ngạc
nhiên lớn của cuộc bầu tại Iowa: cựu thượng nghị sĩ Rick Santorum bất ngờ vọt
lên ngang ngửa với ông Romney trong khi các ứng viên bảo thủ nặng ký khác lẹt đẹt
ở mức dưới đầu gối. Bà Bachmann, ngôi sao hàng đầu hồi tháng Tám, là nạn nhân
chiến cuộc đầu tiên, đã bỏ cuộc. Ông Perry thì đang xét lại thế đứng, có nhiều
hy vọng sẽ rút lui nếu không đứng hạng nhì hay ba ở vài tiểu bang tới.</p><p>Ông Santorum,
năm nay 54 tuổi, là một luật sư chuyên nghiệp, trước đây là thượng nghị sĩ Cộng
Hoà của tiểu bang Pennsylvania. Ông đắc cử vào chức vụ này năm 1995, làm hai
nhiệm kỳ, nhưng thất bại nặng khi ra tranh cử lại cuối năm 2006, thua tới 18 điểm.
Trước đó, ông là dân biểu được hai nhiệm kỳ. Ông nội là di dân từ Ý Đại Lợi,
qua Mỹ làm thợ hầm mỏ, tức là có gốc lao động thuộc thành phần “99%” thứ thiệt.</p><p>Cũng không
khác gì những ngôi sao trước, từ ngày đầu vận động tranh cử đến giờ, bao giờ
cũng ông Santorum cũng ngoi ngóp ở mức dưới 5% hậu thuẫn trong đảng. Thế rồi
cách đây ba tuần, khi ngôi sao Ron Paul bắt đầu phai nhạt thì ngôi sao Santorum
mới nổi lên. Ông là người gần chót trong danh sách các ứng viên Cộng Hòa. Bất
ngờ trong tuần cuối cùng trước ngày bầu cử, tên tuổi ông bắt đầu nổi lên, hiển
nhiên là vì Cộng Hoà... hết người.</p><p>Phải nói là
ông Santorum nổi lên không thể nào đúng lúc hơn: khi Cộng Hòa gần hết người, và
nhất là quá cận ngày bầu, các đối thủ và nhất là báo chí, chưa kịp khui rác
trong quá trình của ông cũng như chưa kịp đánh ông. </p><p>Kết quả bầu
sơ bộ Iowa cho thấy ông Santorum thua ông Romney đúng tám phiếu trong khoảng
120.000 người đi bầu. Có lúc, khoảng hai giờ sáng, giờ Washington, ông dẫn đầu
ông Romney với đúng... một phiếu, nói lên tính ngang ngửa của cuộc chạy đua
Romney-Santorum. Với tư thế hàng đầu này, chúng ta có thể tin chắc trong những
ngày tới, những chuyện không tốt đẹp gì về ông Santorum sẽ tràn ngập báo chí và
trên quảng cáo truyền hình. </p><p>Hai nhiệm kỳ
dân biểu và hai nhiệm kỳ thượng nghị sĩ bảo đảm sẽ dư sức cung cấp hàng kho tài
liệu để các đối thủ khui rác và tấn công. Báo Philadelphia Daily News trong số
ra ngày 4/1 đã mở màn với một bài dài hạch đủ thứ tội từ hai chục năm trước rồi.</p><p>Nhưng chắc chắn
đó không phải là mối lo lớn nhất của ông Santorum. </p><p>Chiến lược của
ông khá độc đáo. Trong suốt năm qua, ông gần như trở thành cư dân của Iowa, sống
thường trực tại tiểu bang, và là ứng viên duy nhất đích thân đi vận động trong
tất cả 99 quận (counties) của Iowa. Có nghĩa là chiến lược tranh cử của ông
hoàn toàn dựa vào chiến thắng tại Iowa, rồi từ đó làm bàn đạp để có cái thế của
ứng viên hàng đầu. </p><p>Nhưng vấn đề
không giản dị như vậy vì ông phải tranh cử trong tất cả 50 chứ không phải một
tiểu bang. Hiện nay, ông Santorum chỉ có mặt và thực sự vận động tại Iowa, chưa
có người, chưa có tiền, chưa có kế hoạch, chưa có hậu thuẫn gì trong 49 tiểu
bang còn lại, ngoại trừ tiểu bang Pennsylvania của ông. Một hòn núi khổng lồ mà
ít người tin ông sẽ vượt qua được. </p><p>Ông Santorum
thuộc thành phần công giáo, bảo thủ triệt để, chống hôn nhân đồng tính, chống
phá thai, chống tăng thuế, chống Nhà Nước vú em. Nhưng ông bị khối bảo thủ chỉ
trích vì chuyện ủng hộ TT Bush trong hai dự luật Medicare (Plan D tăng tiền thuốc
cho người già lãnh Medicare) và giáo dục (No Child Left Behind mà TT Bush đề ra
cùng TNS cấp tiến Ted Kennedy). </p><p>Khối bảo thủ
cực đoan chống rất mạnh hai luật này của TT Bush vì cho rằng hai luật đó tốn tiền
và mang tính can thiệp quá đáng của Nhà Nước, đi ngược lại chủ trương của bảo
thủ Cộng Hòa.</p><p>Chiến thắng của
ông Santorum mang tính tâm lý nhiều hơn là thực tế. Iowa có 25 đại biểu tham dự
đại hội đảng Cộng Hòa. Trên nguyên tắc ông Romney là người chiến thắng – dù chỉ
với tám phiếu – nên sẽ lãnh hết số phiếu này, và ông Santorum chẳng có phiếu
nào. Nhưng đặc biệt theo luật tiểu bang Iowa, các đại biểu lại có quyền muốn bỏ
phiếu cho ai thì bỏ, nên ông Santorum vẫn hy vọng có vài người sẽ nhìn vào kết
quả ngang ngửa và cho ông vài phiếu.</p><p>Nhìn kỹ vào kết
quả tại Iowa, người ta có cảm tưởng đảng Cộng Hòa vẫn gặp và sẽ còn gặp khó
khăn tầy trời trong cuộc chạy đua vào Nhà Trắng năm nay.</p><p>Ông ứng viên
dẫn đầu Romney vẫn không tìm ra phương thức nào đạt được hậu thuẫn của khối đa
số đảng viên bảo thủ. Các ứng viên khác thì chẳng ai hoàn hảo hay có sức thu hút
cao. Như đã viết trong mục này cách đây vài tuần, Cộng Hoà đang lang thang như
con thuyền không bến, chỉ biết có mục tiêu cuối cùng là mời TT Obama về nhà viết
hồi ký thôi.</p><p>Iowa là một
trong những tiểu bang nông nghiệp bảo thủ nhất Mỹ, do đó, ông Romney là thành
phần ôn hoà nếu không muốn nói là hơi quá cấp tiến trong mắt của giới bảo thủ,
mặc dù tả xông hữu đột, vẫn không ngoi lên được trên 25% từ 2008 đến giờ.</p><p>New Hampshire
là tiểu bang kế tiếp sẽ có bầu sơ bộ Thứ Ba này. Đây là tiểu bang tương đối ôn hoà
hơn, và là láng giềng của Massachusetts, nên tất cả thăm dò đều cho thấy ông
Romney sẽ đại thắng, đạt được xấp xỉ gần một nửa số phiếu. Sẽ không có gì bất
ngờ cả. Vấn đề là ai sẽ là người về nhì.</p><p>Các thăm dò gần
đây cho thấy ông Ron Paul là người có hậu thuẫn cao thứ nhì. Nhưng kết quả yếu
kém của ông ở Iowa, và hiện tượng mới nổi Santorum đã thay đổi thế cờ, và rất
có thể ông Paul sẽ mất cơ hội về nhì.</p><p>Cựu đại sứ Mỹ
tại Trung Cộng, ông Huntsman đã tập trung mọi nỗ lực trong suốt cả năm qua tại
New Hampshire, nhưng không ai nghĩ ông này sẽ hy vọng về nhì vì có cái “tội” rất
lớn là đã hợp tác với “kẻ thù Obama”, làm đại sứtại Bắc Kinh cho Obama. Theo định nghĩa của Mỹ,
đại sứ là sứ thần đại diện cho cá nhân tổng thống (personal emissary of the
President). Đối với phe đối lập Cộng Hòa, cái tội này nặng lắm. </p><p>Nhưng điều
quái lạ của New Hampshire là tiểu bang này cho phép bất cứ ai cũng được tham
gia vào cuộc bầu cử nội bộ của đảng Cộng Hòa, cho dù là độc lập hay Dân Chủ, chỉ
cần đến nơi, ghi tên vào đảng Cộng Hòa là được vào bỏ phiếu. Bầu rồi, bỏ đảng
là xong. Có thể có nhiều ông bà Dân Chủ ghi tên đi bầu với chủ ý gây rối loạn
lung tung trong nội bộ Cộng Hòa.</p><p>Thử thách
quan trọng nhất cho ông Romney là hai cuộc bầu tới tại South Carolina và
Florida. Đây là hai tiểu bang tương đối bảo thủ, nhất là South Carolina là nơi
có nhiều căn cứ quân sự, với quân nhân là thành phần bình thường khá bảo thủ.
Cách đây không lâu, ông Gingrich đứng đầu cách rất xa ông Romney. Nhưng ông đã
chìm xuồng mau lẹ, nên bây giờ chỉ còn lại những câu hỏi như ông Romney sẽ được
khối bảo thủ chấp nhận hay không, rồi sau ông ta thì ai sẽ được hậu thuẫn của
khối này. Ngôi sao Santorum mới nổi mà chưa có tổ chức, chưa có tiền, chưa có
đi vận động ở South Carolina hay Florida gì hết, sẽ được hậu thuẫn như thế nào?
Các ông Gingrich, Paul và Perry sẽ như thế nào? </p><p>Mấy ông sau
này đều có “hành trang” nặng nề, nếu không ngóc đầu lên được thì cuộc chạy đua
sẽ thành cuộc đua tay đôi giữa ông ôn hoà Romney và ông cực đoan Santorum. Ông
Romney mà thắng ở South Carolina và Florida thì coi như là cuộc đua trong nội bộ
Cộng Hòa đã xong và ông Romney sẽ là đại diện cho đảng Cộng Hoà. </p><p>Và điều đáng
lưu ý là biết đâu chừng hai ông Romney và Santorum sẽ kết hợp lại với nhau để gồm
thâu cả hai khối bảo thủ ôn hòa và bảo thủ cực đoan. Ông Romney ra tranh cử tổng
thống và ông Santorum đứng phó. Việc ông Santorum ngồi chung với ông Romney sẽ
khiến khối bảo thủ dễ dàng chấp nhận ông Romney hơn, và rất quan trọng, tiểu
bang then chốt Pennsylvania có thể sẽ trở về tay Cộng Hòa.</p><p>Đây dĩ nhiên
là chuyện không thể không xẩy ra. Truyền thống dân chủ Mỹ là như vậy. Các địch
thủ đánh nhau chí chóe, chỉ trích nhau thậm tệ, nhưng cuối cùng vẫn ngồi với
nhau được.</p><p>Cuộc chạy đua
bên Dân Chủ năm 2008 cũng khởi đầu bằng tám ứng viên đánh nhau túi bụi. Cuối
cùng còn lại hai kình địch Obama và Hillary, vẫn tiếp tục đánh nhau cho đến sát
ngày đại hội đảng. Nhưng rồi ứng viên Obama sau khi thắng đã mời ông địch thủ
Joe Biden là phó, rồi sau khi vào Nhà Trắng, đã mời bà Hillary làm ngoại trưởng.
Sau cuộc chiến, họ vẫn vì quyền lợi chung của đất nước và quyền lợi đảng, ngồi
lại với nhau, hợp tác chân thành với nhau được vì dù sao thì trong lúc đấm đá
nhau, vẫn còn sự tôn trọng nhau, không xỉ vả nhục mạ nhau như hàng tôm hàng cá
chợ Cầu Ông Lãnh. Xứ văn minh và người trưởng thành có khác.</p><p>Ông Romney,
dù muốn hay không, cũng là địch thủ đáng ngại nhất của TT Obama. Thời buổi kinh
tế rối loạn như hiện nay, với TT Obama chẳng làm nên trò trống gì suốt ba năm
nay, sẽ là yếu tố quan trọng có lợi cho ông Romney, vì ông này là doanh gia có
thành tích kinh tế rõ ràng. Dân Mỹ lo cho túi tiền của mình nhiều hơn, sẽ tạm
biệt TT Obama dễ dàng, cho ông Romney cơ hội cứu vãn.</p><p>Thăm dò
Rasmussen ngay sau bầu cử tại Iowa cho thấy cả hai ông Romney và Obama đều được
hậu thuẫn ngang hàng nhau, 47% mỗi người. Có nghĩa là chẳng ai có thể mang nhà
mình đi Las Vegas đánh cá xem bên nào thắng được.</p><p>Còn gần một
năm nữa mới đến ngày bầu thật. Từ giờ đến đó, chẳng ai biết chuyện gì sẽ xẩy
ra. Theo các chuyên gia, yếu tố quyết định chính là kinh tế. Từ giờ đến đó, nếu
kinh tế tiếp tục èo uột, thất nghiệp tiếp tục nằm trên ngọn cây, thì bảo đảm
qua năm tới, chúng ta sẽ có tổng thống mới. Một phần lớn sẽ tùy thuộc tình hình
Âu Châu, nếu Âu Châu sụp đổ thì kinh tế thế giới sẽ khủng hoảng nặng, kể cả
kinh tế Mỹ. Nhưng nếu kinh tế có tiến triển khả quan rõ ràng, thì Romney hay
Santorum hay bất cứ ai khác cũng sẽ khó thắng được TT Obama. </p><p>Tin mừng cho
TT Obama là tỷ lệ thất nghiệp đã bất ngờ tuột xuống khoảng 8.5%, tuy còn rất
cao, nhưng ít ra thì cũng đã có tiến bộ, xuống mức thấp nhất của ba năm Obama.
Nhiều chuyên gia hy vọng kinh tế đã bắt đầu phục hồi, và nếu tiếp tục thì dân Mỹ
sẽ cho TT Obama thêm thời gian để giải quyết những khó khăn và ông sẽ nhiều hy
vọng đắc cử lại. Nhất là nếu khối bảo thủ cực đoan vẫn không thể chấp nhận ông
Romney và thà ngồi nhà hay đi câu cá chứ không đi bầu cho ông ta. </p><p>Đảng Cộng Hoà
đã nghĩ đến trường hợp này và sẽ tập trung nỗ lực nhiều hơn vào việc bầu cử quốc
hội, với hy vọng duy trì thế đa số ít nhất tại Hạ Viện để ngăn cản TT Obama
vung tay quá trán như trong hai năm 2009-2010. Không hạ được TT Obama thì chỉ
còn cách vô hiệu hoá ông ta, và như vậy TT Obama sẽ có nhiều dịp đi nghỉ hè, du
lịch và đánh gôn hơn. (8-1-12).</p><p>Quý độc giả
có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác
giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a182340/bau-cu-so-bo-man-mot-iowa

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/