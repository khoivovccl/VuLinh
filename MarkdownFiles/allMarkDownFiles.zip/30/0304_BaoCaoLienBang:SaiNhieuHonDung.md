# Báo Cáo Liên Bang: Sai Nhiều Hơn Đúng

31/01/2012

<p>Báo Cáo Liên
Bang: Sai Nhiều Hơn Đúng</p><p>Vũ Linh</p><p>...thất nghiệp
chính thức vẫn cứ lơ lửng ở mức 9%, và thực tế là 18% từ ba năm nay...</p><p></p><p>Tối thứ ba vừa
qua, TT Obama ra trước lưỡng viện quốc hội đọc diễn văn báo cáo tình trạng liên
bang năm 2011.</p><p>Theo nhận định
chung, bài diễn văn đánh dấu màn đầu cuộc vận động tranh cử của ông. TT Obama
đã kể thành tích tạo được trong ba năm qua, kêu gọi thiết lập một chế độ công bằng
kinh tế, tự phong là người tranh đấu cho dân nghèo và trung lưu chống nhà giàu,
chứ không là tổng thống của toàn thể dân Mỹ. Rồi đưa ra một loạt thách thức quốc
hội có giỏi thì hãy biến những đề nghị của ông thành luật để ông ký ngay ngày
mai. Một bài diễn văn nặng mùi mỵ dân mà báo Mỹ lịch sự gọi là populist.</p><p>Ngay sau đó,
vài báo Mỹ kiểm tra sự thật trong các lời tuyên bố của tổng thống, và đã khám
phá ra nhiều chuyện... coi dzậy mà hổng phải dzậy chút nào.</p><p>Chủ đề chính
của bài diễn văn là vấn đề công bằng kinh tế -economic fairness-. Đây là cách
TT Obama ám chỉ chuyện “bất công xã hội” hiện nay, kết quả của chính sách thuế
khoá bất công trong đó theo ông, tỷ phú Warren Buffett trả thuế ít hơn bà thư
ký của ông ta. Để nhấn mạnh điểm này, TT Obama cho mời bà thư ký chẳng có một
chút công trạng ghê gớm gì với đất nước lên chễm chệ ngồi cạnh Đệ Nhất Phu Nhân
trong hàng ghế danh dự. Có lẽ đây là sáng kiến của một đạo diễn đến từ
Hollywood.</p><p>Vấn đề thuế
luôn luôn dễ gây xúc động vì thiên hạ phần lớn không hiểu nhiều về tính phức tạp
của vấn đề, mà chỉ nghe thấy những hò hét giản dị của các chính trị gia mỵ dân
rồi nhẩy nhổm lên chống đối vì đụng đến túi tiền của họ. TT Obama tuyên bố việc
“đòi hỏi các tỷ phú phải đóng thuế ít nhất là bằng thư ký của họ” chỉ là chuyện
hợp tình hợp lý (…asking a billionaire to pay at least as much as his secretary
in taxes? Most Americans would call that common sense).</p><p>Bà thư ký này
trả thuế lợi tức ở mức 20%-25% (income tax rate), cao hơn mức thuế lợi nhuận đầu
tư 15% (capital gain -hay investment return tax rate) của ông Buffet, nhưng ở
đây TT Obama so sánh thuế xuất của hai loại thuế khác nhau. Cũng như so sánh
con gà hai chân với con mèo bốn chân. Khác biệt thuế suất giữa hai loại thuế
này đã có từ thời khai quốc, và cũng có trong luật thuế của tất cả các nước Tây
Phương chứ không phải là phát minh của TT Bush hay “đảng Cộng Hoà bóc lột”. </p><p>Khác với lợi
tức là cái gì tất cả mọi người đều cần có, không có không sống được, đầu tư là
chuyện ai muốn thì làm, không có gì bắt buộc, do đó thuế suất cần nhẹ hơn để
khuyến khích thiên hạ đầu tư phát triển đất nước, cũng như để bù đắp rủi ro có
thể mất hết nếu đầu tư trật chỗ. Ngoài ra, ai có lợi tức cũng phải đóng thuế rồi.
Có nhiều người có mức lợi tức cao hơn nhu cầu sinh sống, nên có thể để dành và
đầu tư sanh lời, và như vậy đánh thuế trên tiền lời đầu tư này không khác nào
đánh thuế hai lần vào lợi tức của họ, do đó, thuế suất trên đầu tư là thuế lần
thứ hai, phải nhẹ hơn thuế suất trên lợi tức, là thuế lần thứ nhất. Chỉ trong
các nước theo xã hội chủ nghĩa mới không có khác biệt thuế suất này vì thật sự
chẳng ai có dư tiền để đầu tư hết. </p><p>Theo tài liệu
của ABC News (From Eisenhower to Obama: What the Wealthiest Americans Pay in
Taxes, 18/1/2012) thuế suất trên lợi tức từ thời khai quốc đến giờ luôn luôn
cao hơn thuế suất trên lợi nhuận đầu tư. Thời TT Kennedy, thuế xuất tối đa trên
lợi tức là 90% trong khi thuế xuất trên đầu tư tối đa là 25%. Nói cách khác, bà
thư ký dưới thời tổng thống Dân Chủ Kennedy có thể đã phải đóng tới 90% thuế
trong khi tỷ phú Buffett chỉ phải đóng có 25% thôi. </p><p>Những năm sau
đó, mức thuế lợi tức xuống rất nhanh. Dưới thời TT Clinton, mức thuế lợi tức tối
đa là 39% trong khi mức thuế đầu tư tối đa là 21%. Đến thời TT Bush, thuế lợi tức
tối đa được giảm xuống 35% trong khi thuế đầu tư giảm xuống còn 15%. </p><p>Thuế suất của
TT Bush được duy trì cho đến ngày nay. Người ta vẫn thắc mắc là cuối năm 2010
khi TT Obama và các đồng chí Dân Chủ nắm trọn quyền, tại sao lại gia hạn luật
giảm thuế của TT Bush? TT Obama đã có cơ hội sửa đổi “bất công xã hội” này, tại
sao không làm để rồi bây giờ suốt ngày sỉ vả TT Bush?</p><p>Như trong bài
viết tuần rồi đã ghi nhận, mức thuế trung bình của những người lãnh dưới
100.000 đô một năm chỉ là khoảng dưới 7%. Do đó, theo tạp chí Forbes, nếu bà
thư ký Debbie Bosanek này phải đóng thuế lợi tức cao hơn mức 15% của ông tỷ phú
Buffett, thì mức lương của bà phải là trong khoảng từ 200.000 đô đến 500.000 đô
một năm (thư ký của tỷ phú có khác, cũng thuộc thành phần đại gia 1% chứ đâu có
vừa). </p><p>Cho là bà
lãnh lương mấy trăm ngàn đô và đóng 20% thuế tức là bà đã đóng từ 40.000 đến
100.000 đô thuế, trong khi ông Buffet có thu nhập trên dưới 100 triệu, đóng 15%
thuế, tức là đóng 15 triệu đô thuế. Khác biệt rõ ràng, không thể nói mập mờ là
bà thư ký đóng thuế nhiều hơn ông Buffet được. Nói “đòi hỏi tỷ phú phải đóng
thuế ít nhất là bằng thư ký” là lập luận mỵ dân mập mờ để kích động đấu tranh
giai cấp tân thời trong quần chúng.</p><p>Cũng trong vấn
đề thuế, TT Obama than phiền tình trạng các công ty chạy ra khỏi Mỹ để được hưởng
thuế suất thấp hơn trong khi các công ty ở lại Mỹ thì bị đánh thuế rất cao.
Thay vì đề nghị giảm thuế thì ông đề nghị một mức thuế tối thiểu đối với các
công ty có chi nhánh tại nước ngoài để không cho các công ty này trốn chạy nữa.</p><p>Nước Mỹ có mức
thuế công ty cao thứ nhì trên thế giới, chỉ sau Nhật. Do đó, các công ty đều muốn
trốn chạy ra ngoại quốc, qua những xứ có thuế thấp và nhân công rẻ như Trung Cộng,
Ấn Độ, Việt Nam, Mễ… Đảng Cộng Hoà đề nghị miễn thuế một thời gian hay đánh thuế
nhẹ nếu các công ty này mang cơ sở kinh doanh về lại Mỹ. Đây là việc TT Bush đã
làm và đã kéo về được khá nhiều công ty, giúp tạo công ăn việc làm lại cho Mỹ.
Nhưng TT Obama chủ trương đánh thuế tối thiểu như một hình thức trừng phạt các
công ty mang cơ sở ra nước ngoài. </p><p>Người ta chưa
biết mức thuế tối thiểu này là bao nhiêu, nhưng nếu quá thấp thì các doanh gia
vẫn mang cơ sở của họ ra ngoài như thường, ngược lại quá cao thì sẽ giết chết
các doanh nghiệp này thôi. Cả hai trường hợp đều không thể giúp gia tăng công
ăn việc làm tại Mỹ được. Đây chỉ là nguyên lý kinh tế học cơ bản chẳng có gì phức
tạp nhưng vẫn được TT Obama và phe cấp tiến lờ đi để chỉ đưa ra lập luận mỵ dân
“đánh thuế đại công ty và đại gia” dễ dụ những người không có ý thức kinh tế. Đề
nghị này chỉ là đề nghị trên lý thuyết và sẽ chẳng bao giờ áp dụng được.</p><p>Về vấn đề thất
nghiệp, TT Obama khoe đã tạo thêm ba triệu việc làm mới trong 22 tháng qua. Vẫn
theo ABC News (ABC News: State of the Union: Fact Checking the President,
24/1/2012), trong thời gian đó, con số việc làm mới chỉ có hai triệu thôi, TT
Obama phóng đại thành ba triệu. Theo các chuyên gia kinh tế, nước Mỹ cần có
thêm 150.000 việc làm mới mỗi tháng để đáp ứng nhu cầu của người mới đến tuổi
gia nhập thị trường lao động, tức là tối thiểu cần 3,3 triệu việc làm mới trong
22 tháng. Cho dù ta chấp nhận con số phóng đại của TT Obama thì ông mới chỉ đáp
ứng được phần nào nhu cầu việc làm do tăng trưởng dân số thôi, chưa giải quyết
được tình trạng 15 triệu người đang thất nghiệp thường trực. </p><p>Bởi vậy mà tỷ
lệ thất nghiệp chính thức vẫn cứ lơ lửng ở mức 9%, và thực tế là 18% từ ba năm
nay.</p><p>TT Obama khoe
công đã cứu kỹ nghệ sản xuất xe Mỹ. Ông tuyên bố ngày ông nhậm chức, ngành này
trên bờ vực phá sản. Bất chấp nhiều chống đối, ông nhất quyết cứu, và bây giờ
thì General Motors đã trở thành hãng bán xe nhiều nhất thế giới, Chrysler tăng
trưởng mạnh nhất và Ford đầu tư hàng tỷ vào các hãng xưởng mới ở Mỹ. </p><p>Nghe thì đáng
phục lắm, nhưng có điều là có hơi nhiều chi tiết sai. Theo Fox News, (Fox News:
FACT CHECK: Obama's 2012 State of the Union, 24/1/2012), việc cứu nguy các hãng
xe là quyết định của TT Bush cuối năm 2008, TT Obama chỉ tiếp tục thi hành
thôi. GM từ hồi nào đến giờ vẫn là hãng bán nhiều xe nhất thế giới. Chrysler
tăng trưởng mạnh nhờ hãng Fiat của Ý bơm tiền vào để mua 51% cổ phần. Ford chưa
hề nhận một đồng cứu nguy của Nhà Nước.</p><p>TT Obama quảng
bá một kế hoạch mới để giúp những người gặp khó khăn trả nợ nhà. </p><p>Khủng hoảng
gia cư khởi đầu từ 2008, đến nay là bốn năm, mà TT Obama vẫn loay hoay hết kế
hoạch này đến chương trình khác để giải quyết mà vẫn chẳng đi đến đâu. Đây có lẽ
là kế hoạch thứ sáu hay thứ bẩy gì rồi.</p><p>Theo kế hoạch
mới, mỗi chủ nhà sẽ được giảm khoảng 3.000 đô tiền nợ nhà, trong khi các ngân
hàng bị ép phải giúp chỉnh cố lại nợ cho thiên hạ. TT Obama quảng cáo luật này
rất giản dị, không có thủ tục hành chánh rườm rà và cũng không cho phép các
ngân hàng kiếm cớ thoái thác. Sự thật, các kế hoạch trước đây cũng được quảng
bá như vậy, nhưng cũng chẳng có kết quả xuất sắc gì. Kế hoạch HARP tốn 75 tỷ
năm 2009 hứa hẹn sẽ giúp bốn triệu gia đình, thực tế đã chỉ giúp tái tài trợ
cho chín trăm ngàn gia đình. Ngay cả trong số gần một triệu gia đình đó, hầu hết
đã tiếp tục bị khó khăn và lại rơi vào tình trạng nợ xấu trong vòng sáu tháng
sau.</p><p>Về đối ngoại,
TT Obama khoe ông đã thách thức Trung Cộng nhiều hơn TT Bush, thưa kiện Trung Cộng
vi phạm hiệp ước thông thương quốc tế WTO gấp hai lần Bush. Theo ABC News, TT
Bush khiếu nại bẩy lần trong khi TT Obama khiếu nại có năm lần. TT Obama làm
tính rất giản dị: năm lần trong ba năm, nếu ông làm tổng thống tám năm, thì
theo đà này, ông sẽ khiếu nại tổng cộng là 13 lần, tức là gần bằng hai lần TT
Bush. Nhưng đây chỉ là nói chuyện lý thuyết. Không có gì bảo đảm ông sẽ làm tổng
thống thêm một nhiệm kỳ, cũng như không có gì bảo đảm ông sẽ tiếp tục khiếu nại
thêm tám lần nữa vì tất cả tùy thuộc con số vi phạm của Trung Cộng. Nếu Trung Cộng
chỉ vi phạm hai lần nữa thì không có lý do gì ông phải khiếu nại tới tám lần nữa.
Ngược lại, nếu Trung Cộng vi phạm năm chục lần mà ông chỉ khiếu nại tám lần nữa
thì chẳng có gì đáng khoe. Tiểu xảo vớ vẩn và trẻ con.</p><p>Dĩ nhiên chuyện
giết Bin Laden là chiến tích duy nhất nên không thể không nhắc đến. Và TT Obama
đã nhắc đến hai lần, mở đầu và kết luận bài diễn văn. Trong năm tới, chúng ta sẽ
còn nghe nhắc đến nhiều hơn nữa.</p><p>Trong cả hai
đoạn, ông đã bỏ ra nhiều thời gian ca tụng thành tích của nhóm người nhái, từ
viên phi công lái trực thăng bị rớt đến anh quân nhân lo bảo vệ đám đàn bà trẻ
con khỏi bị đạn lạc, … Ông không ngớt tâng bốc quyết định can đảm của nhóm quân
nhân, đồng thời cũng kêu gọi mọi người nên coi đó là gương sáng nên noi theo:
can đảm, đoàn kết, … Trên nguyên tắc là ca tụng các quân nhân, nhưng không ai
ngây ngô đến độ không nhìn thấy ông đang tự ca tụng quyết định “can đảm” của
chính mình, và kêu gọi mọi người đoàn kết sau lưng ông.</p><p>TT Obama cũng
lớn tiếng khoe Mỹ đã rút hết quân ra khỏi Iraq, không còn một người nào. Báo
phe ta Washington Post xác nhận là đúng vậy, nhưng cũng bình luận thêm là TT
Obama đã cố tình không nói đến chuyện rút hết quân về không phải vì muốn như vậy,
mà thực sự vì không thoả thuận được với Iraq về việc duy trì một lực lượng tối
thiểu, mới đầu được TT Obama đề nghị là 50.000 quân, cãi đi cãi lại Mỹ phải nhượng
bộ xuống 5.000, cuối cùng vẫn không có đồng thuận, đành phải chấp nhận zero
(Washington Post: Fact-checking the 2012 State of the Union speech, 25/1/2012).
TT Obama cũng không đả động đến chuyện sau khi Mỹ rút quân, Iraq đã trở nên bất
ổn nhất vùng. Xả rác xong rồi phủi tay ra đi sống chết mặc bay thì có đáng khoe
không?</p><p>TT Obama cũng
không quên nhắc lại chống đối của đối lập Cộng Hòa. Vẫn chỉ là chuyện loay hoay
đổ thừa. TT Obama chấp chánh đã ba năm, trong đó có hai năm đảng Dân Chủ kiểm
soát trọn vẹn Toà Bạch Ốc và cả hai viện quốc hội, chỉ có một năm là Cộng Hòa
kiểm soát được Hạ Viện trong khi Thượng Viện vẫn trong tay Dân Chủ. Thế thì
trong hai năm đầu đó, TT Obama đã làm được gì để giảm thất nghiệp phục hồi kinh
tế? </p><p>Phải nói ngay
đây không phải lần đầu tiên một tổng thống phải đối đầu với quốc hội do đối lập
kiểm soát. Chuyện này đã xẩy ra thường xuyên từ thời George Washington. Dĩ
nhiên là đối lập luôn luôn chống phá, chỉ trong chế độ xã hội chủ nghĩa mới thấy
đối lập hồ hởi hoan hô Nhà Nước. Cái tài của vị quốc trưởng trong chế độ dân chủ
là vẫn ứng biến hữu hiệu để làm việc được với đối lập, vẫn làm được cái gì khác
ngoài chuyện... ăn vạ và đổ thừa. TT Bush là người bị tố là vô tài bất tướng tạo
phân hóa lớn, cũng đã thông qua được luật giáo dục, luật an ninh quốc gia, luật
trả tiền thuốc Medicare, và hai lần giảm thuế mặc dù quốc hội do Dân Chủ kiểm
soát.</p><p>Một điểm cuối
cùng đáng ghi nhận. Trong ba năm qua, có hai vấn đề lớn nhất đã chiếm nhiều
trang báo nhất, vậy mà trong suốt bài diễn văn báo cáo tình trạng liên bang, TT
Obama không hề nhắc đến một lần nào: đó là chuyện cải tổ y tế mà đa số dân Mỹ
đang chống mạnh, và chuyện tiêu xài vung vít của chính quyền Obama đưa đến thâm
thủng ngân sách vĩ đại cũng như công nợ chất núi, đưa đến hạ điểm tín dụng lần
đầu trong lịch sử. Hiển nhiên, đây không phải là những đề tài vận động tranh cử
hấp dẫn, nên tốt hơn hết là lờ đi cho tiện. Mỹ gọi là “two elephants in the
room” nhưng TT Obama không muốn ai nhìn thấy.</p><p>Tóm lại, Báo
Cáo Liên Bang chỉ là một diễn văn vận động tranh cử, và giống như tất cả các diễn
văn tranh cử, hứa hẹn trời biển mà không sát với sự thực cho lắm. (29-1-12) </p><p>Ghi chú:
trong bài viết này có trích dẫn ba tờ báo điện tử ABC News, Fox News, và
Washington Post khi kiểm chứng lại những tuyên bố của TT Obama trong Báo Cáo
Liên Bang. Cả ba bài đều viện dẫn khá nhiều chuyện “sai sự thật” của TT Obama.
Độc giả nào có hứng thú có thể vào đó để đọc thêm chi tiết.</p><p>Quý độc giả
có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác
giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a183235/bao-cao-lien-bang-sai-nhieu-hon-dung

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/