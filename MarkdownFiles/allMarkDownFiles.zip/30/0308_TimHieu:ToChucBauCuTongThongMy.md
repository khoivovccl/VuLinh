# Tìm Hiểu: Tổ Chức Bầu Cử Tổng Thống Mỹ

03/01/2012

<p>Tìm
Hiểu: Tổ Chức Bầu Cử Tổng Thống Mỹ</p><p>Vũ
Linh</p><p></p><p>...nước
Mỹ này không phải là Congo trong đó ai muốn vặn vẹo bầu cử thế nào cũng được...</p><p>Ngày
bài viết này lên báo là nước Mỹ bước vào giai đoan then chốt của cuộc bầu cử
lãnh đạo tháng Mười Một năm 2012. Sẽ có hàng chục ngàn người được bầu vào các
trách nhiệm quan trọng đủ mọi cấp. Hầu hết các cuộc tranh cử chỉ thực sự bắt đầu
khoảng hai hay ba tháng trước ngày bầu thôi. Nhưng có một cuộc bầu đặc biệt thực
tế đã khởi sự từ cả năm nay, đó là bầu tổng thống. Trong phạm vi bài này, chúng
ta sẽ tìm hiểu về cuộc bầu tổng thống vì đó là cuộc bầu quan trọng nhất. </p><p>Trên
căn bản, dĩ nhiên, trong tinh thần tự do đa dạng của chính trị Mỹ, cả chục đảng
đang hoạt động và có thể đưa ra ứng viên cho mọi chức vụ, kể cả chức vụ tổng thống.
Các đảng hiện diện thuộc đủ mọi khuynh hướng, kể cả một đảng Cộng sản Mỹ.</p><p>Trên
thực tế, chỉ hai đảng có vai trò thực sự đáng kể trong guồng máy chính quyền Mỹ,
là Dân Chủ và Cộng Hòa. Cả hai đảng đều hoạt động từ lâu đời và đã biến thể rất
nhiều. Ví dụ đảng Cộng Hòa được thành lập giữa thế kỷ 19 để tranh đấu cho việc
khai phóng dân nô lệ da đen chống lại các điền chủ da trắng miền Nam. Hơn một
trăm năm sau, Cộng Hòa biến thể thành đảng của giới điền chủ da trắng miền Nam
trong khi dân da màu được Cộng Hòa giải phóng đều chạy qua Dân Chủ gần hết. Quá
trình biến thể đó cực kỳ phức tạp mà không phải là đề tài câu chuyện ngày hôm
nay.</p><p>Ở
đây, ta chỉ tìm hiểu về thủ tục bầu cử để hiểu rõ vấn đề hơn. Cũng phải nói
ngay sinh hoạt chính trị Mỹ hết sức phức tạp, không thể viết cho đầy đủ trong
khuôn khổ một bài báo ngắn. Những khẩu hiệu đảng của dân nghèo hay đảng nhà
giàu, đảng da trắng hay đảng dân thiểu số chỉ là những cái mũ thô thiển chỉ
thể hiện những cái nhìn nông cạn bề ngoài. Trong một bài viết gần đây, tác giả đã
cố tóm lược triết lý chính trị của hai đảng, nhưng dù sao cũng vẫn chỉ là những
tóm lược rất phiến diện. Cách thức bầu bán cũng vậy, cực kỳ phức tạp, khác biệt
từng tiểu bang, từng quận này đến hạt kia. Các ứng viên tổng thống phải trả bạc
triệu cho các chuyên gia hiểu rõ thủ tục bầu cử của các địa phương vì đó chính
là chìa khoá của thành công. </p><p>Sau
đó phải bỏ thêm bạc triệu để thực hiện những quảng cáo có tính đặc thù gần như
cho riêng mỗi đơn vị bầu cử. TT Obama đã bỏ ra hơn bẩy trăm triệu để được đắc cử,
một số tiền vô tiền khoáng hậu trong lịch sử tranh cử thế giới.</p><p>Những
tổng thống đắc cử như Obama hay Bush đều là những người nắm vững thể thức bầu cử
và nhu cầu đặc biệt của hàng ngàn đơn vị bầu cử qua việc dùng những nhóm chuyên
gia kiệt xuất. Bush không bao giờ có thể trở thành tổng thống nếu không có phụ
tá Karl Rove, trong khi Obama cũng chẳng thể nào vào Nhà Trắng nếu không có cố
vấn David Axelrod. Một việc làm cực kỳ ý nghĩa của TT Obama: ông cho cố vấn
Axelrod nghỉ việc tại Tòa Bạch Ốc từ cả năm nay để về Chicago nghiên cứu toàn
thời chiến lược tranh cử cho năm 2012, nghiên cứu lại toàn diện bản đồ tranh cử.
TT Obama là người có tính kỹ lưỡng, không muốn thất bại kỳ bầu tới nên chuẩn bị
thật chu đáo. Tất cả chỉ là vấn đề tổ chức.</p><p>Trước
hết, ta thử tìm hiểu về bầu sơ bộ.</p><p>Đây
là cuộc bầu nội bộ để chỉ định đại diện cho đảng. Như đã nói, thủ tục bầu sơ bộ
khác biệt ở từng tiểu bang, từ trong đảng Dân Chủ đến trong đảng Cộng Hoà, do đó,
ở đây chỉ có thể bàn đến một cách tổng quát.</p><p>Khác
với các đảng Cộng Sản trong đó các lãnh tụ được một tá người trong Bộ Chính Trị
quyết định, ở Mỹ chẳng có đảng nào có Bộ Chính Trị hết. Mỗi đảng đều có một Ủy
Ban phối hợp, dù có gọi là Ủy ban Quốc gia thì chỉ có vai trò giới hạn là vận động
gây quỹ cho các ứng viên của đảng và phối hợp việc tranh cử của họ, chứ không đề
ra cương lĩnh hay chương trình gì cho đảng. </p><p>Chương
trình hành động của mỗi đảng do một ủy ban đặc nhiệm gồm cả trăm đại diện các
tiểu bang được bầu trong đại hội đảng đề ra trong đại hội đó luôn. Cái oái ăm của
chính trị Mỹ là chương trình của đảng có khi chẳng giống chương trình của ứng
viên tổng thống chút nào, kiểu ông nói gà bà nói vịt.</p><p>Vì
không có Bộ Chính Trị nào chỉ định nên tất cả các đảng viên trên 35 tuổi, sanh
tại Mỹ đều có quyền ra tranh cử làm đại diện đảng trong cuộc bầu tổng thống. Họ
phải tự đưa ra chương trình hành động, có thể khác nhau một trời một vực với
các đồng chí cùng đảng, rồi tự tìm cách vận động lấy hậu thuẫn của đảng viên chứ
không phải của cấp lãnh đạo đảng, và kiếm phiếu của cử tri đoàn của mỗi tiểu
bang. </p><p>Tính
chất độc lập của các ứng viên nói riêng và đảng viên nói chung cũng đưa đến nhiều
tình trạng quái lạ. Năm 2000, thượng nghị sĩ Dân Chủ Joe Liebermann đứng chung
liên danh làm Phó TT cho Gore. Năm 2008, cũng ông Liebermann đó công khai chống
Obama và đi vận động cho ứng viên Cộng Hòa McCain, và xém chút nữa đã trở thành
ứng viên Phó TT của McCain.</p><p>Thứ
tự bầu sơ bộ của các tiểu bang là đề tài tranh chấp tay ba triền miên giữa các
tiểu bang, các ứng viên, và ủy ban lãnh đạo đảng. Trên căn bản, cả hai đảng đều
không muốn các tiểu bang nhỏ bị lép vế, nên dành các cuộc bầu đầu tiên cho các
tiểu bang nhỏ, có tính tiêu biểu. Tiểu bang đầu tiên là Iowa, miền trung nước Mỹ,
rồi đến New Hamshire miền đông bắc, rồi đến South Carolina miền nam, rồi chạy
qua Nevada miền tây. Tuy là các tiểu bang nhỏ hay ít dân, nhưng kết quả được
truyền thông thổi phồng lên để rồi chiến thắng hay thất bại tại những nơi này sẽ
mang tính quyết định. Ứng viên vô danh Obama năm 2008 chỉ nhờ thắng tại Iowa mà
sẵn trớn đánh bại guồng máy khổng lồ của bà Hillary luôn. Đương kim TT Johnson,
sau khi thua Robert Kennedy tại New Hampshire Tháng Giêng 1968, đã bỏ cuộc,
không ra tranh cử nữa.</p><p>Tình
trạng này đưa đến cái lủng củng là các tiểu bang có bầu sơ bộ muộn, tháng Năm
hay tháng Sáu, đều không còn tiếng nói gì đáng kể vì đến khi họ bầu thì ứng
viên gần như đã được chọn xong từ trước. Trong thời gian gần đây, nhận thấy ảnh
hưởng của mình quá ít, nhiều tiểu bang lớn bèn tự ý cãi chỉ thị của ủy ban lãnh
đạo đảng, tổ chức bầu sơ bộ sớm hơn để dành tiếng nói. Chẳng hạn như Florida và
Michigan năm 2008.</p><p>Vòng
bầu sơ bộ kéo dài từ Tháng Giêng đến Tháng Sáu, phần lớn tập trung vào Tháng
Hai và Ba, rồi đại hội đảng được tổ chức, thường vào Tháng Bẩy hay Tám, để các đại
diện tiểu bang chính thức bầu đại diện đảng. Ở đây, phải nói cho rõ ta đang nói
về cử tri đoàn đại diện các tiểu bang trong cuộc bầu sơ bộ trong nội bộ đảng,
chưa nói đến cử tri đoàn bầu tổng thống.</p><p>Hình
thức bầu cử sơ bộ cũng khác biệt từ tiểu bang này qua tiểu bang khác. Có tiểu
bang tổ chức bầu cử trực tiếp cho các đảng viên, có tiểu bang cũng bầu trực tiếp
nhưng mở rộng cho mọi người tham gia, kể cả người ngoài đảng (có thể đưa đến
tình trạng tréo cẳng ngỗng là đảng viên đảng đối lập xâm nhập, dồn phiếu cho ứng
viên yếu nhất), có tiểu bang bầu qua hình thức hội thảo nhóm rồi bỏ phiếu nhiều
vòng như Iowa (đưa đến tình trạng các ứng viên điều đình trước với nhau, nếu bị
loại ở những vòng đầu thì sẽ dồn phiếu cho ai, như Obama và Edwards đã tìm cách
hợp tác với nhau để đánh bà Hillary năm 2008). </p><p>Đến
khoảng mùa hè là hai đảng tổ chức đại hội đảng để đại diện tiểu bang đến bầu đại
diện của đảng tranh cử tổng thống.</p><p>Tại
đại hội đảng, mỗi tiểu bang gửi đến đại hội một số đại biểu - xin gọi là cử tri
đoàn - với con số ấn định tùy theo dân số của tiểu bang. Ví dụ, California là
tiểu bang lớn nhất với nhiều đại biểu nhất, được 441 đại biểu bên Dân Chủ,
trong khi bên Cộng Hòa thì Cali được 173 đại biểu. Thông thường, các đại biểu
thăm dự đại hội đảng phải bỏ phiếu cho ứng viên chiếm được nhiều phiếu nhất
trong tiểu bang. Nhưng có tiểu bang phân phiếu cử tri đoàn theo tỷ lệ phiếu của
cử tri. Cũng có tiểu bang cho các đại biểu bỏ phiếu tùy ý mà không cần phải bỏ
phiếu cho ứng viên đã thắng tại tiểu bang của mình. Ứng viên nào chiếm được đa
số phiếu của tổng số đại biểu của tất cả các tiểu bang sẽ đắc cử đại diện cho đảng
trong cuộc tranh cử tổng thống. </p><p>Rồi
đến bầu tổng thống.</p><p>Sau
khi hai đảng có đại diện chính thức, hai bên sẽ tranh chức tổng thống được tổ
chức qua một cuộc phổ thông đầu phiếu mở rộng cho mọi công dân Mỹ không phân biệt
đảng phái, được cử hành trên toàn quốc ngày Thứ Ba đầu của tháng Mười Một.</p><p>Cuộc
bầu cử này cũng là bầu cử gián tiếp, để bầu một cử tri đoàn chính thức đại diện
cho 50 tiểu bang và quận Columbia, tham gia một cuộc bầu tổng thống chính thức.
Mỗi tiểu bang được ấn định một số đại biểu là tổng kết của số dân biểu và nghị
sĩ liên bang của tiểu bang đó. Ví dụ Cali là tiểu bang lớn nhất, có 2 thượng
nghị sĩ và 53 dân biểu, do đó được đại diện bởi 55 đại biểu, với 55 phiếu.
Thông thường thì ứng viên nào thắng tại một tiểu bang sẽ lãnh hết số phiếu của
tiểu bang đó. Nhưng cũng có tiểu bang chia số phiếu theo tỷ lệ của cuộc phổ
thông đầu phiếu.</p><p>Sau
đó, các đại biểu của tất cả 50 tiểu bang và quận Columbia sẽ chính thức họp và
bỏ phiếu bầu tổng thống Mỹ vào tháng Mười Hai. Đây mới là cuộc bầu tổng thống
chính thức của Mỹ, dù chỉ có tính cách tượng trưng vì hầu hết các đại biểu đều
bị bắt buộc phải bỏ phiếu theo kết quả của phổ thông đầu phiếu tại tiểu bang chứ
không có thể bỏ phiếu theo ý mình.</p><p>Tổng
cộng có 540 phiếu cử tri đoàn, tức là 535 ghế dân biểu và thượng nghị sĩ, cộng
thêm một vài đại diện cho các nơi chưa có đại biểu tại quốc hội như Puerto
Rico, Guam, District of Columbia (DC). Ứng viên nào thu được 271 phiếu sẽ đắc cử
tổng thống Mỹ. Sau đó, quốc hội liên bang họp tháng Giêng để chính thức phê duyệt
và kết quả được đương kim Phó Tổng Thống kiêm Chủ Tịch Thượng Viện tuyên đọc
(do vậy mà ông Phó Al Gore đã bị đặt trong tình trạng bối rối là phải tuyên đọc
ông Bush đã thắng mình mà đắc cử tổng thống năm 2000).</p><p>Thể
thức bầu cử gián tiếp này có mục đích xác nhận Hoa Kỳ là một liên bang của 50
tiểu bang chứ không phải là một nước thuần nhất. Vì là một liên bang nên có nhu
cầu phải cho các tiểu bang nhỏ hay thưa dân cũng có một tiếng nói quan trọng. Nếu
chỉ dựa trên tổng số phiếu của dân chúng thì các ứng viên của hai đảng chỉ cần
thắng lớn ở các tiểu bang lớn như New York, Cali, New Jersey, Florida, Texas,
Ohio, Pennsylvania, Illinois... là đủ thắng trong khi hoàn toàn lơ là các tiểu
bang ít dân như Dakota, Idaho, Alaska,hay nhỏ bé như Maine, Delaware.</p><p>Thể
thức này hợp lý trên căn bản vì tạo cơ hội đồng đều cho tất cả các tiểu bang
cùng có tiếng nói tương đối. Nhưng lại có thể đưa đến nghịch cảnh là dù lãnh được
nhiều phiếu của quần chúng hơn mà vẫn có thể không đắc cử vì thua phiếu cử tri đoàn
như trường hợp Gore thua Bush năm 2000.</p><p>Chìa
khoá thành công thực tế không phải là kiếm được đa số trong hơn 250 triệu phiếu
của cử tri Mỹ, mà là kiếm được 271 phiếu trong khối 540 cử tri đoàn. Bởi vậy mà
Al Gore hơn George Bush nửa triệu phiếu nhờ các tiểu bang đông dân Nữu Ước và
Cali, nhưng vẫn thua vì Bush thắng tại nhiều tiểu bang hơn, 30 tiểu bang so với
20 bầu cho Al Gore, và nhất là thắng tại Florida với hơn 500 phiếu.</p><p>Chỉ
khi nào ta hiểu ra tính chất triệt để phức tạp của cách bầu cử ở Mỹ thì mới có
thể hiểu được cái khó khăn vô cùng tận để đắc cử tổng thống Mỹ. Truyền thông Mỹ
thường tô vẽ hình ảnh của Bush như tên ngốc của làng, nhưng tên ngốc đó đã hạ được
không biết bao nhiêu chính khách nặng ký nhất của Cộng Hòa để rồi hạ luôn đương
kim phó tổng thống Al Gore năm 2000, rồi sau đó lại hạ thượng nghị sĩ lão làng
nhất của Dân Chủ là John Kerry năm 2004, để làm tổng thống đủ hai nhiệm kỳ.
Trong lịch sử cận đại Mỹ từ sau Thế Chiến Thứ Hai tới ông Bush con, đã có 12 tổng
thống, trong đó chỉ có bốn người là làm được đủ hai nhiệm kỳ.</p><p>Chuyện
Bush thắng như thế nào tại Florida đã được hàng ngàn bài báo bàn đến, khỏi cần
viết dông dài, chỉ cần nhắc nhở một vài người suy nghĩ đơn giản không hiểu gì về
tính phức tạp của cách bầu cử Mỹ, nước Mỹ này không phải là Congo trong đó ai
muốn vặn vẹo bầu cử thế nào cũng được, mà Tối Cao Pháp Viện (TCPV) Mỹ cũng
không phải toà án tỉnh Đắc Lắc đâu. Lý do quan trọng nhất mà TCPV đưa ra là lý
do công bằng trước Hiến Pháp. Nếu bắt buộc phải kiểm lại từng phiếu một tại một
vài đơn vị tại Florida cho đến hết thì nguyên tắc đó phải áp dụng trên tất cả mấy
ngàn đơn vị bầu cử trong 50 tiểu bang của Mỹ cho hơn hai trăm triệu lá phiếu,
và như vậy kiểm phiếu và cãi cọ sẽ kéo dài vĩnh viễn. </p><p>Phó
TT Gore chấp nhận quyết định của Tối Cao Pháp Viện và 535 dân biểu và thượng
nghị sĩ lưỡng đảng Quốc Hội chính thức phê duyệt chiến thắng của Bush ngày 6
tháng 1, 2001, với 20 phiếu phản đối không đủ tiêu chuẩn bị chính PTT Gore với
tư cách Chủ Tịch Thượng Viện bác bỏ. Sau khi TT Bush nhậm chức, báo Miami
Herald và USA Today tổ chức kiểm phiếu Florida lại hết. Kết quả cuối cùng khác
nhau tùy theo cách kiểm phiếu. Dưới tất cả mọi tiêu chuẩn (thủng bốn góc, ba
góc, hai góc, một góc) Bush đều thắng, trừ trường hợp duy nhất theo tiêu chuẩn
dễ nhất - hơi có một vết lõm, mà không cần lỗ phiếu phải bị thủng dù chỉ một
góc - thì Gore thắng. </p><p>Chuyện
xưa lắm rồi, nhưng ông Gore vẫn ấm ức không nuốt được cục tức. Câu hỏi cần đặt
ra là tại sao đương kim phó tổng thống lại chỉ thắng được có 20 tiểu bang trong
khi Bush lại có thể thắng tại 30 tiểu bang, kể cả tiểu bang Tennessee là tiểu
bang của Gore.</p><p>Sau
hai cuộc bầu sơ bộ đầu tiên tại Iowa và New Hampshire, người ta có thể sẽ thấy
bức tranh rõ ràng hơn về phía Cộng Hoà. Hy vọng là vậy. (1-1-12)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a182031/tim-hieu-to-chuc-bau-cu-tong-thong-my

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/