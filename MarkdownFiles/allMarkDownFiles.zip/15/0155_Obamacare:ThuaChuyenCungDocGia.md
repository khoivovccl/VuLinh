# Obamacare: Thưa Chuyện Cùng Độc Giả

24/12/2014

<p><b>Obamacare: Thưa Chuyện Cùng Độc Giả</b></p>
<p></p>
<p></p>
<p>Tuần qua, cột báo này có bàn về Obamacare và đã nhận được nhiều ý kiến của độc giả, đồng ý cũng như không đồng ý. Cái hay của nước Mỹ mà ta đã đến xin tỵ nạn là cho tất cả mọi người có quyền có tiếng nói, bất cứ theo chiều hướng nào. Và cái hay của Việt Báo là chấp nhận đăng ý kiến trái ngược của người viết bài cũng như độc giả. Kẻ viết này xin cám ơn nước Mỹ, cám ơn Việt Báo, và cám ơn quý độc giả đã góp ý.</p>
<p>Bây giờ xin phép quý vị để được bàn lại vài ý kiến của độc giả đối với bài viết tuần trước. Dựa trên những ý kiến được đăng trên trang mạng Việt Báo online, đại khái ta thấy ngoài những bài ủng hộ, có ý kiến thắc mắc, đặc biệt liên quan đến vài vấn đề chính:</p>
<p class="ListParagraphCxSpFirst">- thiếu hụt bác sĩ tại Cali;</p>
<p class="ListParagraphCxSpMiddle">- giảm bệnh nhân tại các phòng cứu cấp;</p>
<p class="ListParagraphCxSpMiddle">- tiền nào của nấy của Obamacare;</p>
<p class="ListParagraphCxSpLast">- vấn đề nhân đạo.</p>
<p>Ta bàn từng chuyện một.</p>
<p></p>
<p>THIẾU HỤT BÁC SĨ TẠI CALI</p>
<p>Đã có nhiều người cho rằng tình trạng thiếu hụt bác sĩ là không chính xác, chỉ là báo động hão của những người không ủng hộ Obamacare. Ở đây vấn đề rất giản dị, chỉ là bài tính toán học. Nếu trung bình phải cần 10 năm mới đào tạo được một bác sĩ trong khi Obamacare tăng số người có bảo hiểm và được phục vụ y tế đầy đủ lên tới xấp xỉ 30 triệu trong vòng 4 năm, từ 2010 tới 2014, thì thử hỏi làm sao không thiếu bác sĩ được?</p>
<p>Trên căn bản, tình trạng thiếu hụt bác sĩ là tình trạng chung của cả nước Mỹ, nhưng tương đối, tiểu bang Cali là nơi bị ảnh hưởng nặng hơn nhiều tiểu bang khác, nhất là vùng Nam Cali, là vùng đời sống đắt đỏ nhất nhì nước Mỹ, cũng như có thuế lợi tức của tiểu bang cao nhất Mỹ, cũng như có số dân Nam Mỹ và Á Đông lợi tức thấp khá nhiều. Những yếu tố này đã khiến nhiều bác sĩ, nhất là bác sĩ tổng quát bỏ tiểu bang đi nơi khác, hay ít ra thì cũng không nhận các bệnh nhân có Medical hay Medicare, vì Nhà Nước quy định số tiền bồi hoàn càng ngày càng thấp.</p>
<p>Phải nói ngay cho rõ, kẻ viết này bình luận tin tức chỉ dựa trên tin tức và bình luận của truyền thông Mỹ, không thể phiạ ra bất cứ chuyện gì. Kẻ viết này xin giới thiệu 3 bài báo về vấn đề này để quý độc giả tùy nghi tham khảo. Tất cả đều được viết sau khi Obamacare đã được ban bố tháng 3, năm 2010. Tất cả những bài báo được trích dẫn trong bài viết này đều là trích dẫn từ những cơ quan truyền thông cấp tiến, luôn cổ võ cho Obamacare, không phải từ Fox News hay từ National Review, là những cơ quan truyền thông bảo thủ không có thiện cảm với Obamacare. Tất cả các bài báo này đều được đăng trước khi biết tin TT Obama hoãn trục xuất cả triệu di dân bất hợp pháp. Dưới đây là phần tóm lược rất ngắn gọn.</p>
<p></p>
<ol>
<li>“Doctor Shortage Likely to Worsen With Health Law” (Tình Trạng Thiếu Hụt Bác Sĩ Có Triển Vọng Sẽ Trầm Trọng Hơn Với Luật Y Tế) của Annie Lowrey và Robert Pear đăng trên New York Times tháng 7, 2012.</li>
</ol>
<p>Bài báo cho biết tình trạng thiếu bác sĩ sẽ nguy kịch nhất tại Cali. Như tại vùng Inland Empire (quận Riverside và San Bernardino), phiá đông Los Angeles, Obamacare sẽ giúp cho thêm hơn 300.000 người có bảo hiểm tính đến năm 2014. Tình trạng sẽ trầm trọng hơn nữa sau đó khi mà Obamacare sẽ giúp cho 30 triệu người có bảo hiểm y tế.</p>
<p>Qua Obamacare, số bác sĩ thiếu hụt trên cả nước sẽ tăng từ dưới 30.000 lên đến trên 60.000, rồi đến năm 2025 sẽ thiếu 140.000.</p>
<p>Tình trạng sẽ nghiêm trọng hơn nữa trong những năm tới khi mà số người cao niên nhận Medicare tăng từ 50 triệu năm 2012 lên đến 73 triệu năm 2025, tức là gần 2 triệu người mỗi năm.</p>
<p>Nhu cầu của dân Mỹ đòi hỏi phải có khoảng 60-80 bác sĩ tổng quát cho mỗi 100.000 dân. Vùng Inland Empire chỉ có 40 bác sĩ tổng quát cho mỗi 100.000 dân. Tệ hơn nữa, chưa tới một nửa số bác sĩ đó nhận bệnh nhân Medicaid (hay Medical) trong khi vùng Inland Empire là vùng tương đối nhiều dân gốc Nam Mỹ với lợi tức thấp.</p>
<p>Các viên chức tiểu bang Cali hoan nghênh việc tăng người được bảo hiểm vì lý do nhân đạo, nhưng họ nhìn nhận tiểu bang Cali chưa sẵn sàng để đối phó. Không những thiếu bác sĩ, mà cũng còn cần xây thêm bệnh viện, đào tạo thêm y tá. Nhà Nước cũng cần phải chấm dứt việc cắt tiền bồi hoàn bác sĩ trong Medicaid để tránh chuyện bác sĩ từ chối bảo hiểm này. Điều cuối này khó tránh được khi có thêm cả chục triệu người tham gia vào Medicaid trong khi ngân sách Medicaid không tăng.</p>
<p class="ListParagraphCxSpFirst"></p>
<ol>
<li>“State Lacks Doctors to Meet Demand of National Healthcare Law” (Tiểu Bang Không Đủ Bác Sĩ Để Đáp Ứng Nhu Cầu của Luật Y Tế) của Michael Mishak đăng trên Los Angeles Times tháng 2, 2013.</li>
</ol>
<p>Theo bài này, vì Obamacare, tiểu bang Cali sẽ gặp phải nguy cơ thiếu bác sĩ trầm trọng, đến độ chính quyền tiểu bang đang phải cứu xét một đề nghị cho phép một số trợ tá bác sĩ (physician assistants) và y tá chuyên nghiệp (nurse practitioners), dù không có bằng bác sĩ vẫn có quyền chẩn bệnh và chữa bệnh. Trong 58 quận (counties), chỉ có 16 hiện nay có tạm đủ bác sĩ. Trong tương lai, sẽ thiếu hụt toàn diện vì Obamacare. Chưa kể 30% bác sĩ đã trên 60 tuổi, sắp sửa về hưu.</p>
<p>Hiệp hội các bác sĩ đã chính thức phản đối việc cho các phụ tá và y tá chữa bệnh, nhưng chính quyền tiểu bang không thấy có biện pháp thỏa đáng nào khác.</p>
<p>Bà Diana Dooley, Bộ Trưởng Y Tế tiểu bang, đã thẳng thắn nhận định “chúng ta phải chấp nhận giảm phẩm chất các dịch vụ y tế”.</p>
<p></p>
<ol>
<li>“California Facing Doctor Shortage Amid Obamacare Implementation” (Cali Trực Diện Với Tình Trạng Thiếu Hụt Bác Sĩ Trong Bối Cảnh Thi Hành Obamacare) của Michael Bastasch đăng trên diễn đàn The Daily Caller tháng 12, 2013.</li>
</ol>
<p>Bài báo mở đầu với câu tuyên bố của một nghị sĩ tiểu bang, ông Ed Hernandez, đặt câu hỏi “nếu tất cả mọi người đều có thẻ bảo hiểm y tế nhưng không có bác sĩ để khám họ thì có ích lợi gì?”.</p>
<p>Phần lớn những bình luận đều tương tự như hai bài trên.</p>
<p></p>
<p>GIẢM BỆNH NHÂN TẠI CÁC PHÒNG CỨU CẤP</p>
<p>Một độc giả nhận định Obamacare giúp giảm bệnh nhân vô phòng cấp cứu (Emergency room), tức là giảm chi phí cấp cứu rất nhiều, trong khi chi phí cấp cứu mới là chi phí cao nhất.</p>
<p>Cũng như vấn đề thiếu bác sĩ, kẻ viết chỉ theo tin tức của truyền thông Mỹ, hoàn toàn không tự ý phiạ tin. Dưới đây là 3 bài báo xin giới thiệu đến quý độc giả để rộng đường dư luận.</p>
<p></p>
<ol>
<li>“Emergency Visits Are Increasing, New Poll Finds; Many Patients Referred by Primary Care Doctors” (Số Cấp Cứu Gia Tăng, Thăm Dò Mới Nhất; Nhiều Bệnh Nhân Do Bác Sĩ Tổng Quát Giới Thiệu) của American College of Emergency Physicians (Hiệp Hội Bác Sĩ Cấp Cứu), tháng 4, 2011.</li>
</ol>
<p>Báo của Hiệp Hội Những Bác Sĩ Cấp Cứu công bố kết quả một nghiên cứu của hiệp hội thực hiện qua hơn 20.000 bác sĩ cấp cứu cho biết 80% các bác sĩ cấp cứu đã thấy số khách hàng của họ gia tăng mạnh. Hầu hết (97%) bệnh nhân cấp cứu cho biết họ đã được các bác sĩ tổng quát chính (primary care doctor) của họ bảo họ hãy đi vô phòng cấp cứu. Lý do giản dị là các bác sĩ chính này không muốn chữa trị cho họ vì tiền bồi hoàn Medicaid ngày một thấp và sẽ còn xuống thấp nữa dưới Obamacare.</p>
<p>Gần 90% các bác sĩ cấp cứu nghĩ rằng con số bệnh nhân cấp cứu sẽ gia tăng ngày một mạnh hơn với Obamacare, sau khi Obamacare mở rộng chương trình trợ cấp Medicaid.</p>
<p>Bản nghiên cứu được thực hiện tháng Ba năm 2011, đúng một năm sau khi Obamacare thành luật.</p>
<p></p>
<ol>
<li>“Emergency Room Visits Are Increasing Especially Among Adult Medicaid Patients” (Số Cấp Cứu Gia Tăng, Đặc Biệt Với Bệnh Nhân Người Lớn Có Medicaid) của Sheila Guillerton đăng trên diễn đàn mạng Examiner.com, tháng 10, 2010.</li>
</ol>
<p>Bài viết trích dẫn một nghiên cứu của tập san Journal of American Medical Association (Tập San Của Hiệp Hội Y Khoa Mỹ) cho thấy việc sử dụng phòng cấp cứu đã gia tăng mạnh nhất từ trước đến giờ, đặc biệt là trong giới những người có Medicaid. Theo bác sĩ Ning Tang, con số bệnh nhân vào phòng cấp cứu đã tăng hơn gấp đôi con số dự phóng trong năm qua (2010).</p>
<p>Lý do chính là vì các bác sĩ chính từ chối nhận bệnh nhân có bảo hiểm Medicaid.</p>
<p></p>
<ol>
<li>“Emergency Visits Seen Increasing With Health Law<i>” </i>(Số Cấp Cứu Gia Tăng Với Luật Y Tế) của Sabrina Tavernisejan đăng trên New York Times, tháng 2, 2014.</li>
</ol>
<p>Bài báo mở đầu bằng nhận định của những người cổ võ cho Obmacare là luật này sẽ cắt giảm số người không có bảo hiểm, nên không chịu ngừa bệnh, mà đợi tới khi bệnh rồi mới chạy vào phòng cấp cứu, nơi mà chi phí chữa trị rất cao, chưa kể chuyện nhiều khi quá muộn cho bệnh nhân. Đây là một trong những luận cứ chính của Obamacare. Chính TT Obama cũng đã công khai quảng bá chuyện này.</p>
<p>NYT cho biết một nghiên cứu của tiểu bang Oregon trên khoảng 90.000 người có lợi tức thấp, so sánh số người có bảo hiểm mà vào phòng cấp cứu, với số người không có bảo hiểm sử dụng phòng cấp cứu. Cuộc nghiên cứu cho thấy số người mới có bảo hiểm chạy vào phòng cấp cứu cao hơn số người không có bảo hiểm vào phòng cấp cứu tới 40%. Nôm na ra, hiện nay số người vào phòng cấp cứu chẳng những không giảm, mà trái lại còn tăng mạnh. Ngược lại với lập luận của những người rao bán Obamacare.</p>
<p>Tình trạng này đặc biệt rất phổ biến trong giới lợi tức thấp có Medicaid vì Medicaid trả hết tiền phòng cấp cứu, bất kể giá nào.</p>
<p>Lý do việc gia tăng sử dụng phòng cấp cứu rất giản dị, không cần phải tìm đâu xa.</p>
<p>Ngoài chuyện các bác sĩ tổng quát đẩy bệnh nhân của họ vào phòng cấp cứu, bây giờ thiên hạ bắt đầu phải chờ lâu hơn mới lấy hẹn bác sĩ được, rồi sau khi có hẹn, đến phòng mạch cũng chờ dài người. Những người bị bệnh khẩn cấp, hay không đủ kiên nhẫn, hay không có thời giờ rảnh rỗi ngồi đọc báo cọp trong phòng đợi của bác sĩ, đã lựa chọn giải pháp thực tế hữu hiệu hơn nhiều: chạy vào phòng cấp cứu. Cũng đỡ tốn tiền co-pay và deductible càng ngày càng cao mỗi khi đi bác sĩ để gọi là phòng bệnh. Ít người dư tiền và rảnh rỗi đi khám bác sĩ thường xuyên để ngừa bệnh cho dù bây giờ đã có bảo hiểm.</p>
<p>Bà Heidi Allen, giáo sư Đại Học Columbia, một trong những chuyên gia tác giả bản nghiên cứu của tiểu bang Oregon đã cho biết phần lớn những người sử dụng phòng cấp cứu mà bà phỏng vấn đã nói họ vào phòng cấp cứu vì không thể lấy hẹn cùng ngày với bác sĩ tổng quát chính của họ được nữa.</p>
<p>Bài nghiên cứu còn đặt vấn đề trong tương lai, với áp lực cung cầu, các phòng cấp cứu sẽ lại tăng giá hơn nữa, tăng thêm gánh nặng chi phí y tế chung cho tất cả mọi người.</p>
<p>Bài báo của NYT cũng nêu lên một nghiên cứu “lạc quan hơn” của tiểu bang Massachusetts cho thấy việc sử dụng phòng cấp cứu không thay đổi gì hết.</p>
<p>Tức là cũng chẳng giảm như TT Obama hứa hẹn. Kết quả “không thay đổi gì” của tiểu bang Massachusetts dễ hiểu vì trong tiểu bang này, tất cả dân chúng đều đã bị bắt buộc có bảo hiểm hết từ thời Thống Đốc Mitt Romney rồi, do đó, Obamacare rất ít có tác dụng.</p>
<p></p>
<p>TIỀN NÀO CỦA NẤY CỦA OBAMACARE</p>
<p>Một độc giả nêu vấn đề trả bảo phí thấp thì tiền túi phải bỏ ra sẽ cao hơn, và ngược lại. Dĩ nhiên chỉ là chuyện tiền nào của đó. Rất chính xác, không sai. Nhưng xin thưa ngay là ở đây chúng ta không so sánh các chương trình bảo hiểm khác nhau trong chương trình Obamacare, mà đặt vấn đề so sánh các chương trình bảo hiểm trước khi có Obamacare và sau khi có Obamacare.</p>
<p>Câu hỏi là tại sao vẫn một chương trình bảo hiểm không thay đổi mấy mà bây giờ ta phải lựa chọn một là trả bảo phí cao hơn để may ra có thể trả tiền túi ít hơn? Hoặc là trả bảo phí cao hơn để tiền túi phải trả được ít đi hơn?</p>
<p>TT Obama khi quảng bá cho Omabacare đã nói rõ hai chuyện: không có gì thay đổi hết, vẫn hãng bảo hiểm cũ, bác sĩ cũ, và chi phí y tế sẽ giảm trung bình 2.500 đô một năm cho mỗi gia đình. Quý độc giả tự kiểm điểm xem có đúng với tình trạng gia đình mình không. Kẻ viết này không thể bàn thêm.</p>
<p></p>
<p>VẤN ĐỀ NHÂN ĐẠO</p>
<p>Một độc giả nêu lên vấn đề ta cũng không nên ích kỷ không cho những bệnh nhân khác được chăm sóc, dù sao khi qua đây chúng ta cũng là dân bần cùng.</p>
<p>Xin nhắc lại vấn đề cho rõ.</p>
<p>Trước hết kể viết này hay bất cứ ai khác trên đất Mỹ này, không bao giờ chủ trương “ích kỷ không cho những bệnh nhân khác được chăm sóc”. Không có ai trên đất Mỹ này muốn thấy tình trạng có người bị bệnh mà không được chăm sóc, để cho chết. Cũng không ai phủ nhận việc nước Mỹ đại giàu xụ mà có mấy chục triệu người không có bảo hiểm là chuyện không chấp nhận được. Vì lý do nhân đạo, cần phải phát triển hệ thống bảo hiểm sao cho tất cả mọi người đều có bảo hiểm.</p>
<p>Cung cấp bảo hiểm cho cả nước là chuyện mà TT Nixon đã cố gắng thực hiện ngay từ năm 1972 mà thất bại vì chống đối của đảng Dân Chủ khi đó kiểm soát cả Thượng Viện lẫn Hạ Viện. Như vậy có phải là đảng Dân Chủ đã từng chủ trương “ích kỷ không cho những bệnh nhân khác được chăm sóc” không?</p>
<p>Ai cũng muốn cả nước có bảo hiểm. Vấn đề là có nhiều cách làm. Mà cách làm của TT Obama là cách giúp cho một chục triệu người có bảo hiểm, nhưng lại đưa đến tình trạng cả trăm triệu người phải trả chi phí y tế nặng hơn, với kết quả ngoài lề là các hãng bảo hiểm, hãng thuốc, nhà thương, … vẫn ngày một giàu xụ thêm.</p>
<p>Đó là kết quả của việc làm hấp tấp, chưa cân nhắc đầy đủ tất cả hậu quả, dựa trên lừa dối, trên sự “ngu xuẩn” của cử tri, đưa đến hết luộm thuộm này đến lủng củng kia, tốn tiền thuế không biết bao nhiêu. Như vụ hấp tấp tung ra Obamacare trên mạng khi chưa sẵn sàng, đưa đến khủng hoảng, đóng cửa tiệm, sửa chữa, … trong khi Nhà Nước đã chi hơn 500 triệu đô cho chương trình điện toán đó.</p>
<p>Một điều cuối cùng: không thể nào nói Obamacare có hại cho tất cả mọi người vì như vậy không chính xác. Obamacare cũng như tất cả các luật gì khác tất nhiên phải có lợi cho nhiều người cũng như có hại cho nhiều người khác. Đó là chuyện bình thường đương nhiên. Trên cột báo này cũng đã có bài viết phân tích rõ ràng ai được lợi và ai bị thiệt. Một cách tổng quát:</p>
<p class="ListParagraphCxSpFirst">- giới lợi tức thấp được lợi về tiền bạc (trợ cấp) nhưng sẽ bị bớt bác sĩ, nhà thương, phải chờ lâu hơn,</p>
<p class="ListParagraphCxSpMiddle">- những người bị bệnh nặng không mua bảo hiểm được sẽ có bảo hiểm,</p>
<p class="ListParagraphCxSpMiddle">- giới đại gia chẳng bị đụng tới,</p>
<p class="ListParagraphCxSpMiddle">- trong khi đại đa số giới trung lưu là bị thiệt hại nặng, vừa thấy chi phí y tế tăng mạnh, vừa phải đổi nhà thương bác sĩ, vừa phải chờ lâu,</p>
<p class="ListParagraphCxSpLast">- cùng với giới trẻ dù còn sức khoẻ nhưng vẫn đóng bảo phí nặng để tài trợ cho bảo hiểm của người nghèo và người cao niên.</p>
<p>Trong vấn đề Obamacare này, kẻ viết chỉ trình bày tình trạng chung của cả nước Mỹ, không phải là bàn về cộng đồng tỵ nạn Việt. Quý độc giả đọc kỹ sẽ thấy chẳng hạn tôi có ghi rõ tình trạng thiếu bác sĩ do bác sĩ không nhận Medicaid và Medicare ít ảnh hưởng đến cộng đồng tỵ nạn chúng ta. Cũng phải nói ngay, cộng đồng tỵ nạn bàn ở đây là cộng đồng thế hệ thứ nhất, phần lớn lãnh Medicaid và Medicare, chứ cộng đồng thế hệ thứ nhì thì đã vào khối trung lưu, sẽ bị ảnh hưởng của Obamacare nhiều hơn. Nhất là giới trung lưu trẻ.</p>
<p>Obamacare là một vấn đề được bàn cãi rất nhiều. Quý độc giả có hứng thú có thể vào Google truy cập đủ loại thông tin. Tất cả các bài báo trích dẫn ở trên đều có thể tìm thấy trên trang Google. (21-12-14)</p>
<p></p>
<p>Vũ Linh</p>
<p></p>
<p><i>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: </i><a href="http://mail.google.com/mail/h/qws5krbo3ovv/?v=b&cs=wh&to=Vulinh11@gmail.com"><i>Vulinh11@gmail.com</i></a><i>. Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.</i></p>
<p></p>
<p class="ListParagraph"></p>
<p></p>

### Nguồn:

Viet Bao: https://vietbao.com/a231425/obamacare-thua-chuyen-cung-doc-gia

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/