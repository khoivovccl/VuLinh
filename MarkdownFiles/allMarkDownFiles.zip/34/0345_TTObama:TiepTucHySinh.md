# TT Obama: Tiếp Tục Hy Sinh

12/04/2011

<p>TT Obama: Tiếp Tục Hy Sinh</p><p>Vũ Linh</p><p>...quyền lợi Medicare và Medicaid đã giảm rõ ràng
trong thời gian gần đây...</p><p>Tuần qua, TT Obama lẳng lặng chính thức tuyên bố sẽ ra
tranh cử tổng thống vào cuối năm 2012, không kèn không trống, trái với lần ra
quân đầu tiên, được trịnh trọng công bố tại tiểu bang Illinois. Kể từ bây giờ,
tổng thống có quyền chính thức bắt đầu thu tiền yểm trợ.</p><p>Lần thông báo này khác với lần trước vì lý do hiển
nhiên. Năm 2007, không ai biết Barack Obama là ai nên ông bắt buộc phải làm đình
đám để gây tiếng vang. Năm nay, ông là tổng thống đương nhiệm nên cần làm nhẹ
nhàng để nhấn mạnh ông là tổng thống, việc cai trị đất nước quan trọng hơn, ông
không rảnh rỗi coi tranh cử là ưu tiên mà chỉ làchuyện nhỏ.</p><p>Đúng ra tổng thống chỉ mới thông báo sẽ tham gia cuộc
chạy đua, tức là trên nguyên tắc, sẽ vẫn phải qua thủ tục tranh cử qua vòng sơ
khởi trong nội bộ đảng Dân Chủ, sau đó, nếu thắng thì mới có quyền đại diện Dân
Chủ tranh cử cùng ứng viên của Cộng Hòa.</p><p>Trong truyền thống chính trị Mỹ, ít khi mà tổng thống đương
nhiệm bị một đồng chí cùng đảng thử thách. Nếu có thì chỉ vì lý do tổng thống đương
nhiệm bị coi như đã có hành động hay chính sách "phản đảng", hay trắng trợn đi
ngược lại những lời hứa khi tranh cử. Như TT Bush cha đã bị ông đồng chí Pat
Buchanan chỉ trích là không bảo thủ đúng mức, ra tranh cử trong vòng sơ bộ, rồi
sau đó bị ông đồng chí khác Ross Perot ra tranh cử với tư cách độc lập, chỉ vì
TT Bush đã chấp thuận cho tăng thuế trong nhiệm kỳ, trái với lời hứa long trọng
khi tranh cử. Kết quả phiếu Cộng Hòa bị phân tán, đưa đến chiến thắng bất ngờ của
một Thống đốc của tiểu bang nhỏ nhít Arkasas là Bill Clinton khi các đại gia
Dân Chủ khác đều lánh mặt người hùng của trận chiến vùng Vịnh George H. Bush.
Nhờ Perot, ông Clinton đắc cử với 43% số phiếu, như ông Obama năm 2008.</p><p>TT Obama hiện nay có nhiều hy vọng không gặp sự chống đối
nào trong nội bộ Dân Chủ. Chẳng những ông không phạm tội "phản đảng" nào, trái
lại ông đã có một chính sách còn cấp tiến hơn chương trình của đảng Dân Chủ nữa,
và rất được lòng truyền thông. Ông cũng thực hiện được một số chương trình vĩ đại
như cải tổ y tế và tài chánh rất vừa lòng cánh tả của đảng. Dĩ nhiên là sau cuộc
thảm bại tháng 11 vừa qua, ông phải "điều chỉnh" lại chính sách, nhưng những điều
chỉnh đó, dù không làm cho cánh tả hài lòng, nhưng cũng chưa đến nỗi bị cho vào
sổ đen như TT Bush cha.</p><p>Có nhiều tờ báo, vì mục đích bán báo rõ rệt, đã "quậy
nồi cơm" bằng cách bàn chuyện bà Ngoại Trưởng Hillary Clinton có thể nhẩy rào,
ra tranh cử chống TT Obama. Hiện nay bà Hillary đang được hậu thuẫn của hơn 60%
dân Mỹ, một tỷ lệ hết sức cao, hơn xa tỷ lệ của TT Obama, như của tất cả những
nhân vật tai to mặt lớn của đảng Dân Chủ trong nội các và bên quốc hội. Dựa
trên sự kiện đó, nhiều nhà bình luận đã "bàn ra" chuyện bà Hillary có thể sẽ ra
tranh cử, đánh bại Obama trong vòng sơ bộ, rồi đánh bại bất cứ ứng viên Cộng
Hòa nào trong vòng kết, để trở thành phụ nữ đầu tiên làm tổng thống Mỹ.</p><p>Nghe thì vui vui, nhưng thực tế là chuyện hầu như
không thể xẩy ra, trừ phi TT Obama gặp đại họa, đại họa cá nhân hay đại họa
trong một quyết định nào đó. Ngoại trường Hillary Clinton có thể đang được hậu
thuẫn mạnh, nhưng hậu thuẫn đó sẽ mau chóng tan biến nếu bà có hành động thiếu
tôn ti trật tự, ra giành giựt với tổng thống, là lãnh tụ của đảng. Trong lịch sử
cận đại Mỹ, chuyện đó chưa xẩy ra, chưa có tổng thống đương nhiệm nào bị đồng
chí trong đảng đánh gục, kể cả các tổng thống yếu kém nhất như Jimmy Carter (bị
thượng nghị sĩ Ted Kennedy thử thách), Gerald Ford (bị thống đốc Ronald Reagan
thử thách), hay tổng thống bị chống đối mạnh như Lyndon Johnson (bị bộ trưởng Tư
Pháp Robert Kennedy chống đối vì chiến tranh Việt Nam).</p><p>Thật ra, việc bà Hillary được mang ra bàn luận không
phải là chuyện lạ, chẳng những vì sự hậu thuẫn mạnh mà bà đang có, mà còn vì thế
rất yếu của TT Obama hiện nay. Theo thăm dò dư luận, hậu thuẫn của TT Obama đang
ở mức thấp nhất kể từ ngày ông đắc cử, và cũng thấp nhất so với các tổng thống
tiền nhiệm khác trong cùng giai đoạn này. Mà chuyện này cũng chẳng phải là chuyện
đáng ngạc nhiên.</p><p>Nhìn vào thành quả hơn hai năm chấp chánh, không thấy
có gì có thể nói là xuất chúng khả dĩ khoe với thiên hạ. Cũng chẳng có gì thể
hiện khẩu hiệu tranh cử "Thay Đổi mà chúng ta có thể tin được".</p><p>Thành quả lớn nhất là cải tổ y tế thì đang bị đe dọa bởi
Hạ Viện trong tay đối lập Cộng Hòa, cũng như bị đe dọa bởi quyết định của các
tòa tại Virginia và Florida như là bất hợp hiến, lại bị chống đối ngày càng mạnh
trong quần chúng vì, trái với lời hứa hẹn, chi phí y tế đã chẳng giảm mà trái lại,
phần lớn các hãng bảo hiểm đều tăng giá bảo phí, cũng như thiên hạ đều thấy quyền
lợi Medicare và Medicaid đã giảm rõ ràng trong thời gian gần đây. Tất cả những
người đang lãnh Medicare và Medicaid đều đã thấy rõ, không còn là chuyện tranh
luận lý thuyết nữa.</p><p>Cải tổ tài chánh thì chẳng ai thấy rõ đã có thay đổi
gì, chỉ thấy mấy đại gia Wall Street vẫn lãnh bạc chục triệu tiền thưởng, ngân hàng
vẫn không chịu cho vay tiền làm kinh doanh, khủng hoảng gia cư vẫn còn đó, thị
trường địa ốc vẫn ứ đọng, nhà vẫn bị kéo.</p><p>Kích cầu kinh tế tốn gần ngàn tỷ vẫn chưa có kết quả cụ
thể nào. Thất nghiệp vẫn ở mức 9%, gấp hai lần thời Bush. Kinh tế được gọi là
phục hồi với những mức lời kỷ lục của các đại công ty, và sự tăng vọt của thị
trường chứng khoán, chỉ làm giàu những tay nhà giàu sở hữu hay chơi cổ phiếu chứ
chẳng giúp gì dân lính thợ bán buôn. Người ta có cảm tưởng có hai nền kinh tế
song hành trên đất Mỹ: kinh tế của nhà giàu đã hồi phục, trong khi kinh tế của
nhà nghèo vẫn èo uột. Một thành quả chéo cẳng ngỗng của "đảng nhà nghèo".</p><p>Nhà Nước thì đang đi vào bế tắc sau khi phe đối lập Cộng
Hòa chiếm được Hạ Viện vì sự bất mãn của dân chúng đối với chính sách của TT
Obama. Hầu như chẳng luật nào còn có thể thông qua được nữa. Thậm chí, ngân
sách hết tiền, cãi nhau cả mấy tháng trời mới tạm thỏa thuận được một ngân sách
vá víu cho đến tháng Chín này. Thâm thủng ngân sách của một mình TT Obama bằng
thâm thủng của tất cả 43 vị tổng thống tiền nhiệm - từ tổng thống khai quốc
George Washington đến tổng thống George W. Bush - cộng lại. Bởi vậy đảng Cộng
Hòa mới được dân Mỹ trao cho đa số tại Hạ Viện để cắt giảm công chi.</p><p>Cuộc chiến chống khủng bố vẫn dây dưa. Sau những chỉ
trích ồn ào nổi đình nổi đám chống chính sách của TT Bush thì mối đe dọa vẫn
còn đó. Đi phi trường bị mấy ông bà cảnh sátnhìn thấu xương, rờ thấu đáy, mà
vẫn chẳng cảm thấy an toàn hơn. Hơn hai năm qua, nhà tù Guantanamo vẫn chưa đóng
cửa được, chưa một ông khủng bố nào bị đưa ra tòa hết.</p><p>Cuộc chiến tại Iraq biến khỏi mặt báo nhờ thành quả của
chiến thuật đôn quân nhưng dĩ nhiên chẳng ai mất công cám ơn ông Bush làm gì
cho phiền. Cuộc chiến tại Afghanistan dậm chân tại chỗ, mặc dù đã đôn quân theo
mô thức Bush.</p><p>Chưa nuốt xong hai khúc xương Iraq và Afghanistan thì
bây giờ lại dính vào vụ Libya vì "nghĩa vụ quốc tế", chưa biết sẽ đi về đâu" Mỹ
sẽ nhúng chàm và chìm đắm trong một cuộc chiến mới trong thế giới Hồi giáo" Hay
Mỹ sẽ cày nát xứ Libya nhân danh những lý tưởng nhân bản nhân đạo cao thượng nhất,
rồi phủi tay đứng ngoài, không can dự chuyện nội bộ Libya, theo mô thức
Afghanistan ngày xưa" </p><p>Ở đây ta cũng cần nhắc lại, Mỹ can dự vào cuộc chiến của
du kích Hồi giáo Afghanistan chống Hồng Quân Liên Xô và chính quyền cộng sản
tay sai thập niên 70. Sau khi đồng minh Nga tháo chạy, chế độ cộng sản tại
Afghanistan mau chóng sụp đổ, đưa đến loạn sứ quân. Mỹ thấy Nga rút cũng rút
theo. Kết quả nhóm quá khích Taliban chiến thắng, biến Afghanistan thành sào
huyệt khủng bố Al Qaeda. Nếu lịch sử tái diễn tại Libya thì chẳng nên lấy làm lạ.</p><p>Khi nhìn vào những thành quả trên thì chuyện TT Obama
có được bầu lại hai năm nữa hay không là câu hỏi lớn. Nhiều thăm dò dư luận cho
thấy nếu cuộc bầu cử tổng thống được tổ chức ngay bây giờ, thì TT Obama sẽ mất
job. TT Obama đã mất rất nhiều hậu thuẫn của dân da trắng, mà cũng mất luôn một
phần hậu thuẫn của dân da mầu, từ 95% hai năm trước xuống 85% bây giờ. Theo thăm
dò mới nhất, 44% dân Mỹ nghĩ TT Obama xứng đáng được bầu lại, trong khi 48%
nghĩ nước Mỹ cần tổng thống mới. </p><p>Thế nhưng, hai năm trong chính trị Mỹ dài bằng hai thế
kỷ. Trong hai năm tới, biết bao chuyện có thể xẩy ra. Có những chuyển biến sẽ
có lợi cho TT Obama, cũng có thể có những chuyển biến bất lợi. Trạng Trình tái
sinh cũng chẳng đoán được gì. </p><p>Có hai điều chắc chắn sẽ là yếu tố quyết định:</p><p>- Kinh tế: đối với cử tri Mỹ, công ăn việc làm và túi
tiền của họ vẫn là yếu tố then chốt để bầu tổng thống. Kinh tế èo uột như bây
giờ thì TT Obama sẽ khó hy vọng. Kinh tế khá lên thì ông sẽ khó bị đánh bại. Nếu
thất nghiệp không xuống dưới 7% mà xăng lên hơn 5 đô một ga-lông thì có nhiều
hy vọng TT Obama sẽ có dịp về nhà viết hồi ký.</p><p>- Khả năng vận động: TT Obama có thể là một nhà trị nước
dở, nhưng vẫn là siêu chuyên gia vận động chính trị, không ai có thể coi thường
được. Sự kiện ông là một chính khách da đen, vô danh, chẳng ai biết, chẳng có
kinh nghiệm hay thành tích gì mà vẫn hiên ngang đi vào Tòa Bách Ốc đã trở thành
dữ kiện lịch sử. Đó là bằng chứng hùng hồn nhất về thiên tài chính trị của ông.
Trong kỳ tranh cử năm 2008, ông huy động được hơn 750 triệu đô la để dàn quân
tranh cử. Lần này, ông có kế hoạch gây quỹ tới một tỷ đô mặc dù không phải chạy
đua gì trong nội bộ Dân Chủ. Cả nước đang lo lắng chuyện Nhà Nước đóng cửa tiệm
vì thiếu tiền, nhưng TT Obama thì bận lo kiếm một tỷ để ở lại Nhà Trắng.</p><p>Trong khi đó thì những đối thủ Cộng Hòa của ông dường
như vẫn toàn là những tay mơ, chưa ai có vẻ hấp dẫn, có sức mạnh cần thiết của
một trận cuồng phong để hạ được một tổng thống đương nhiệm.</p><p>Nhìn cho kỹ, người ta có thể kết luận hiện nay không
có một chính khách Cộng Hòa nào có thể hạ được Obama. Chỉ có chính ông Obama mới
hạ được ông Obama thôi. Nếu ông không học được những bài học kinh nghiệm của
hai năm qua, điều chỉnh lại chính sách, tạo được vài thành quả cụ thể để lấy lại
tin tưởng của người dân, thì ông sẽ bị dân Mỹ sốt ruột cho về vườn và ứng viên
Cộng Hòa, bất cứ ai, cũng đều có hy vọng thắng được Obama.</p><p>Trước đây, sau khi dân Mỹ được nếm mùi cấp tiến cực đoan
của TT Clinton và bà vợ qua dự luật cải tổ y tế để thiết lập bảo hiểm y tế toàn
dân, đảng Dân Chủ đại bại trong kỳ bầu giữa mùa năm 1994, Cộng Hòa chiếm quyền
kiểm soát cả Thượng Viện lẫn Hạ Viện. TT Clinton bị bó tay, chuyển hướng, cất cải
tổ y tế và các chương trình cấp tiến vĩ đại vào kho, trở thành ôn hòa, hợp tác
với quốc hội Cộng Hòa, và được bầu lại năm 1996. </p><p>Lịch sử có vẻ đang tái diễn.</p><p>Sự thành công của đảng Cộng Hòa trong kỳ bầu cử tháng
11 vừa qua cũng là con dao hai lưỡi cho đảng. Nó khiến Cộng Hòa chiếm được Hạ
Viện và có được tiếng nói mạnh hơn tại Thượng Viện, nhưng cũng ép TT Obama vào
thế ôn hòa hơn. Chính nét ôn hòa đó sẽ giúp TT Obama lấy lại phần nào niềm tin
của dân Mỹ và nâng cao hy vọng tái đắc cử của ông. Còn lại, đảng Cộng Hoà có xứng
đáng và khả năng đảo ngược tình hình hay chăng"</p><p>Nếu chỉ nhìn vào hai người đẹp Sarah Palin và Michele
Bachmann thì chúng ta thấy.... nghi quá! Phải chờ tới vòng sơ bộ Iowa hay New
Hampshire hay sao"</p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua
email: Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a170140/tt-obama-tiep-tuc-hy-sinh

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/