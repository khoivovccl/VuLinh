# Obama Giết Osama

10/05/2011

<p>Obama
Giết Osama </p><p>Vũ
Linh</p><p></p><p>...manh
mối đầu đã được khui ra từ dưới thời TT Bush, trong trại giam Guantanamo...</p><p></p><p>Tựa
bài viết này cũng sẽ là khẩu hiệu tranh cử lớn trong thời gian tới. Hàng vạn áo
thung T-shirt sẽ xuất hiện với khẩu hiệu này.</p><p>Cái
tin Osama Bin Laden bị giết đã được TT Obama và phe ta khai thác triệt để. Từ
cách phổ biến tin tức từ từ, mỗi ngày thêm vài chi tiết, cho đến chuyện đích
thân TT Obama lên truyền hình hai ba lần để loan tin, rồi rình ràng đi Nữu Ước
làm lễ truy điệu các nạn nhân của Bin Laden, tất cả đều được tính toán kỹ lưỡng
để mang lại "ấn tượng" tối đa.</p><p>Một
ký giả phe ta nhận định đây là biến cố mang tính cách "khúc quanh lịch sử", làm
như thể Osama chết là nạn khủng bố Hồi giáo quá khích sẽ chấm dứt, Al Qaeda sẽ
tự giải thể, và dân Mỹ quên ngay hình ảnh hai tòa cao ốc sụp đổ với ba ngàn người
chết oan. Một ký giả khác mau mắn "nói đùa", rằng cuộc bầu cử tổng thống năm tới
sẽ bị hủy bỏ vì Cộng Hòa ý thức sẽ vô phương chạy đua cùng Đấng Tiên Tri nên đã
rút lui hết.</p><p>Đúng
ra, đây là biến cố quan trọng nhất trong suốt hai năm nhiệm kỳ đầu của TT
Obama, vì hiển nhiên đây là thành quả rõ rệt, không tranh luận, không chối cãi,
và nặng ký nhất của tổng thống. Nói cách khác, thành quả cụ thể duy nhất. </p><p>Đây
là viên thuốc mầu nhiệm có hy vọng cải tử hoàn sinh cho sự nghiệp tổng thống.
Như đã được viết nhiều lần trên cột báo này, TT Obama không có được thành tích
hiển hách nào để khoe với quần chúng trong suốt hai năm qua, đang phải chống đỡ
những tấn công tới tấp của phe đối lập Cộng Hòa. Đến độ ngay cả ông tỷ phú Donald
Trump - một chính khách tay mơ mà không ai nghĩ có thể đắc cử thành tổng thống
- cũng có thể nhẩy ra hô hào, áp lực được TT Obama phải phổ biến giấy khai sanh
của mình, một chuyện hơi mất mặt mà ông đã kiên quyết từ chối không làm từ bốn
năm qua, kể từ lúc ông bắt đầu tranh cử tổng thống trong nội bộ đảng Dân Chủ.</p><p>Viên
thuốc "Viagra" này đã làm tăng ngay mức hậu thuẫn của TT Obama lên sáu điểm (hậu
thuẫn của TT Bush khi bắt được Saddam Hussein vọt lên 9 điểm). Chẳng những vậy,
biến cố này cũng ép các đối thủ Cộng Hòa phải xếp hàng ca tụng TT Obama, trong đó
có tất cả các ứng viên tổng thống tương lai, và có cả Bush và cựu PTT Cheney, một
người đã từng mạnh mẽ chỉ trích chiến lược chống khủng bố ển ển xìu xìu của
Obama. Vấn đề là viên thuốc này có tác dụng bao nhiêu lâu.</p><p>Cuộc
truy lùng tên khủng bố có thể nói là nguy hiểm nhất lịch sử nhân loại đã chấm dứt
khi tên này bị đột kích bởi hai trực thăng "người nhái" hay hải kích (Navy
SEALS), dựa trên tin tức của CIA.</p><p>Tin
tức tình báo CIA từ tháng Tám năm ngoái đã đoán biết - không có gì chắc chắn -
Bin Laden đang ở trong một biệt thự đáng giá triệu đô, xây năm 2005 tại ngay
trung tâm thành phố Abbottabad, một thành phố quân sự với nhiều lực lượng quân đội
Pakistan trấn đóng vì sát vùng tranh chấp biên giới với Ấn Độ. Bin Laden đang ở
trong căn biệt thự cách trường võ bị lớn nhất của Pakistan có vài trăm thước.
Không phải đang trốn chui trốn nhủi trong hang động vùng biên giới hiểm hóc. </p><p>Đến
tháng Ba năm nay thì đã có nhiều dấu hiệu chắc chắn hơn. </p><p>Rồi
đến cách đây một tuần, thì CIA tin rằng có hơn 70% xác xuất Bin Laden ở trong căn
nhà đó. Mặc dù theo dõi ngày đêm nhưng vẫn không xác định được vì Bin Laden
không bao giờ bước ra khỏi nhà hay ra ngoài sân. Trong nhà thì không có điện thoại,
hay mạng internet gì. Thậm chí rác trong nhà cũng được đốt trong vườn mỗi ngày
chứ không mang ra ngoài đường cho xe rác của thành phố chở đi. Có thể vì mục đích
đánh lạc hướng máy bay thám thính của Mỹ, hay có thể vì đã có được sự bảo vệ của
quân đội Pakistan trong vùng, Bin Laden không có một tên lính võ trang nào bảo
vệ. Trái lại, trong căn nhà chỉ toàn là đàn bà trẻ con. Ít ra là chín phụ nữ và
hai tá con nít. Cộng với Bin Laden và hai tên giao liên. </p><p>CIA
trình cho TT Obama ba giải pháp:tiếp tục
theo dõi nhưng có nguy cơ Bin Laden sẽ trốn mất bất cứ lúc nào, cho máy bay thả
bom phá tan căn nhà, nhưng sẽ khó có bằng chứng Bin Laden ở trong đó, chưa kể sẽ
giết nhiều đàn bà trẻ con, và thứ ba là cho đặc công đột kích, với nguy cơ bị
chống trả gây bị thương hay tử vong cho nhóm đặc công. Khác với những lần trước,
đắn đo lưỡng lự tuần này qua tháng khác, lần này TT Obama ý thức ngay ý nghĩa
chính trị vĩ đại của việc giết được hay bắt được Bin Laden. Ông mau mắn (mất 16
tiếng đồng hồ suy nghĩ, đó là "mau mắn" lắm rồi, theo tiêu chuẩn của TT Obama)
ra lệnh đột kích để bảo đảm việc có được bằng chứng rõ ràng về Bin Laden hầu có
thể biện minh việc dùng trực thăng từ Afghanistan bay qua Pakistan đánh vào nhà
một thường dân Pakistan mà không xin phép chính quyền Pakistan trước. </p><p>Vi
phạm chủ quyền Pakistan một cách trắng trợn như vậy sẽ tạo ra nhiều vấn đề pháp
lý và chính trị quốc tế. Nếu bắt sống được hay ít nhất là có xác của Bin Laden
thì mới có lý do để biện minh trước công luận. </p><p>Việc
giết được Bin Laden là một thành tích lớn lao không chối cãi được. Vấn đề chúng
ta muốn bàn là chuyện luận công và hậu quả.</p><p>Công
trạng của TT Obama không thể chối cãi. Nếu ông bắt hụt Bin Laden trong khi cả
chục người khác bị chết oan thì thiên hạ sẽ xúm vào chỉ trích. Do đó, nếu thành
công thì cũng phải nhìn nhận công trạng cho công bằng.</p><p>Thành
tích của nhóm người nhái đột kích giết được Bin Laden và hai tên giao liên
không chết một người nào, và rút ra trước khi lực lượng an ninh của Pakistan kịp
tới can thiệp, cũng không thể chối cãi, cho dù có tin nhóm này đã không gặp chống
cự nào vì Bin Laden và hai tên giao liên chẳng có súng ống gì để chống cự. </p><p>Còn
công trạng của CIA thì sao" </p><p>Ta
còn nhớ ứng viên Obama trong suốt thời gian tranh cử đã hùa với phe cấp tiến chỉ
trích CIA rất mạnh, rồi vừa nhậm chức là đã vội vã giải tán nhóm đặc nhiệm điều
tra tù khủng bố của CIA để thành lập nhóm đặc nhiệm khác điều tra tội ác của CIA! Hàng loạt viên chức CIA bị treo giò chờ kết quả điều tra và ngày hầu tòa.
Bây giờ thì tổng thống tính sao với CIA đây" </p><p>Rồi
còn cựu tổng thống Bush" Trong khi các cơ quan truyền thông bảo thủ như Fox và
Drudge nhắc đến công của Bush, thì "phe ta" đều phớt lờ. TT Obama và tất cả các
viên chức cao cấp khi tuyên bố về vụ giết được Bin Laden đều nhất loạt nhấn mạnh
sự "chỉ đạo" trực tiếp của TT Obama qua những phiên họp liên tục của Hội Đồng
An Ninh Quốc Gia, nhưng không ai đả động đến tên của TT Bush. </p><p>Báo
New York Times, qua bài viết dài bốn trang trên mạng của một tập thể sáu ký giả
viết chung, đã tường trình chi tiết về cuộc truy lùng trong mười năm qua, cũng
như đưa đầy chi tiết về sự "chỉ đạo xuất chúng" từng giờ của TT Obama, đã tuyệt
nhiên không nhắc đến tên Bush một lần nào hết. </p><p>Đầu
giây mối nhợ cuộc truy lung phải nói là việc bắt giữ và hỏi cung một số tù khủng
bố trong trại giam Guantanamo dưới thời Bush.</p><p>Vì
sự truy lùng cực kỳ gay gắt của Bush, Bin Laden không dùng các phương tiện tân
tiến như điện thoại hay internet để liên lạc, thậm chí cũng không viết gì hết,
chỉ truyền khẩu lệnh qua các tên giao liên thân cận nhất. Từ đó, CIA cho rằng
chỉ có một cách duy nhất bắt đựợc Bin Laden là bám theo mấy tên giao liên.</p><p>Năm
2004, quân Mỹ bắt được một lãnh tụ Al Qaeda, tên là Hassan Ghul tại Iraq. Theo
lời khai của tên này tại nhà giam Guantanamo, CIA khám phá ra tên của liên lạc
viên thân cận với Bin Laden nhất, Abu Ahmed al-Kuwaiti. Năm 2005, quân Mỹ bắt được
Faraj al-Libi, một nhân vật lãnh đạo đứng hàng thứ ba của Al Qaeda, vừa được bổ
nhiệm thay thế Khalid Sheikh Mohamed, nhân vật chủ chốt của vụ tấn công 9/11 đã
bị bắt. Mang al-Libi về hỏi cung, anh này xác nhận al-Kuwaiti là giao liên chủ
chốt, nhưng vẫn chỉ là bí danh trong khi không ai biết hắn thực sự là ai, ở đâu.
</p><p>Đến
cuối năm 2008, CIA mới tìm ra được tung tích tên này, biết được hắn còn có một
người em. Cuộc truy lùng hai anh em này bắt đầu. Tất cả dưới thời TT Bush. Mãi đến
giữa năm ngoái, tình cờ CIA nghe lén được một cú điện thọai từ al-Kuwaiti, và
truy lùng ra một căn nhà sang trọng tại Abbottabad. Đưa đến kết quả cuối cùng
là giết chết được Bin Laden cùng với cả hai anh em giao liên.</p><p>Nhìn
vào diễn tiến này, ta sẽ không khỏi lưu ý đến chuyện manh mối đầu đã được khui
ra từ dưới thời TT Bush, trong trại giam Guantanamo mà TT Obama nhất quyết đòi đóng
cửa, qua các phương thức "hỏi cung mạnh bạo" mà TT Obama từng lớn tiếng công
kích là vi phạm đủ thứ luật mà chẳng mang lại kết quả gì. Khiến cho nhiều người
thắc mắc. Nếu TT Bush và CIA không tích cực truy lùng các lãnh tụ Al Qaeda, và
không nhốt chúng tại Guantanamo, không "hỏi cung" bằng những phương thức mạnh bạo,
thì liệu ngày nay Obama sẽ truy lùng ra tên giao liên quan trọng nhất của Bin
Laden và tìm ra dấu tích của ông trùm khủng bố này không" </p><p>Có
thể có, cũng có thể không. Nhưng đó là chuyện giả tưởng. </p><p>Chuyện
thực tế là Bush là người đã tìm ra đầu giây. Không nhìn nhận vai trò của Bush
cũng như không nhìn nhận hiệu quả của phương thức "hỏi cung" của Bush chỉ phản
ánh thái độ phe đảng thiên vị thiếu lương thiện, hay vùi đầu dưới cát để bảo vệ
quan điểm ngây ngô của mình. TT Obama khi lo kể công mình mà không nhắc đến vị
tiền nhiệm chỉ chứng minh tínhkhông quân tử lắm.</p><p>Điều
quan trọng hơn là tương lai sẽ ra sao"</p><p>Chính
quyền Pakistan đã xác định không hề biết gì về chuyện Bin Laden sống tại đây.
Nhưng điều này khó tin khi căn nhà lớn này được xây sát nách trường võ bị lớn
nhất nước, ngay giữa các căn cứ quân sự khác, mà nhà chức trách an ninh quân sự
địa phương lại không biết ai đang ở trong đó từ sáu năm qua. Một là các cơ quan
an ninh quân sự địa phương hoàn toàn vô tài bất tướng, hai là chính quyền trung
ương Pakistan đã bị quan chức địa phương che giấu sự thật, báo cáo láo, ba là
chính quyền Pakistan nói láo. Cả ba giả thuyết đều phản ánh một tình trạng đáng
quan ngại khi Pakistan vẫn còn là xứ đầu cầu trong cuộc chiến chống khủng bố. </p><p>Một
khúc mắc quan trọng khác là phản ứng của khối Hồi Giáo, nhất là khối quá khích.
TT Obama cố tránh khiêu khích nhóm này nên đã loan tin và kêu gọi Bin Laden đầu
hàng nhưng bị Bin Laden núp đàng sau lưng bà vợ bắn lại, nên đành phải bắn chết
Bin Laden, và quyết định không cho phổ biến hình Bin Laden bị bắn hai phát đạn
công phá vào đầu, phía trên mắt trái khiến sọ bị vỡ nát một bên. </p><p>Tin
tức cho đến nay chưa rõ ràng, nhưng một bức hình chụp một tiếng đồng hồ sau khi
quân Mỹ đã rút mang theo xác của Bin Laden cho thấy có ba người đàn ông - chứ
không phải chỉ có hai anh em giao liên như chính quyền Obama loan tin - nằm
trên vũng máu, chẳng người nào có súng trên tay. Chính phát ngôn viên Tòa Bạch Ốc
sau đó cũng xác nhận Bin Laden không có vũ khí gì, cũng như không có chuyện Bin
Laden núp sau lưng vợ bắn vào lính Mỹ. </p><p>Bức
hình và lời xác nhận Bin Laden không có súng dĩ nhiên đã gây thắc mắc và phẫn nộ
trong giới Hồi giáo, cho rằng Mỹ đã không hề có ý định bắt sống mà thật ra cố
tình bắn chết Bin Laden mặc dù hắn không có vũ khí hay chống cự gì hết. Sự phẫn
nộ này hầu như đã hóa giải hết những lời xin lỗi liên tục trước đây của TT
Obama.</p><p>Tổ
chức Al Qaeda có thể đã bị đánh tan tác từ mười năm qua, nên sẽ không đủ khả năng
tổ chức trả thù quy mô như hăm dọa, nhưng chắc chắn là không thiếu gì thanh
niên Hồi giáo quá khích sẽ tìm cách trả thù lẻ tẻ. Nói cách khác, cái chết của
Bin Laden không làm cho dân Mỹ an toàn hơn, ít nhất là trong ngắn hạn.</p><p>Dù
sao, cái chết của Osama Bin Laden cũng là điều mà cả nước Mỹ mong chờ từ gần mười
năm nay, không cần biết trong tay hắn có súng hay không, cũng không cần biết
hành động có hợp pháp theo công pháp quốc tế hay không. Vấn đề là không nên biến
chuyện này thành chiến thắng chính trị để khỏa lấp tất cả những thất bại khác
trong mùa bầu cử tới. Nước Mỹ đang trực diện với nhiều vấn đề quan trọng hơn
cái mạng của Bin Laden, một tên khủng bố hết thời sống chui rúc sau lưng đàn bà
trẻ con từ cả chục năm nay. (8-5-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a171434/obama-giet-osama

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/