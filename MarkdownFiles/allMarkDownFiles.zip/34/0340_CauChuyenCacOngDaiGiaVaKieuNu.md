# Câu Chuyện Các Ông Đại Gia Và Kiều Nữ

24/05/2011

<p>Câu
Chuyện Các Ông Đại Gia Và Kiều Nữ</p><p>Vũ
Linh</p><p></p><p>...Cả
hai ông đều là đại đại gia trong khi cả hai bà đều là người làm bồi phòng...</p><p></p><p>Có
người đã từng nói "đằng sau một người đàn ông thành công là có hình bóng một người
đàn bà". Ta cũng có thể nói ngược chơi là "đằng sau một người đàn ông thất bại
cũng có hình bóng một người đàn bà". Thành ra thành công hay thất bại không phải
là ở người đàn bà đứng sau lưng, mà là ở chính mấy ông.</p><p>Trong
mấy ngày qua, hai ông tai to mặt lớn đã bị dính dáng vào hai vụ xì-căng-đan
tình áichẳng giống ai.</p><p>Ông
Dominique Strauss-Kahn là Tổng Giám Đốc của Qũy Tiền tệ Quốc Tế -International
Monetary Funds hay IMF, một tổ chức tài chánh quốc tế ngang ngửa với Ngân Hàng
Thế Giới World Bank. Không phải công ty hạng bét nào. Theo thông lệ quốc tế được
tôn trọng từ ngày hai định chế này được thành lập sau Đệ Nhị Thế Chiến, Tổng
Giám Đốc Ngân Hàng Thế Giới luôn luôn là một người Mỹ do tổng thống Mỹ đề cử,
trong khi Tổng Giám Đốc IMF phải là người Âu Châu. Ông Strauss-Kahn, vì tên dài
quá nên thường được gọi tắt là DSK, là người Pháp, giáo sư kinh tế, nguyên Bộ
Trưởng Tài Chánh, và là ngôi sao sáng của đảng Xã Hội Pháp, có nhiều hy vọng hạ
được đương kim tổng thống Sarkozy trong kỳ bầu tổng thống Pháp năm tới. IMF trước
đây có lúc thoi thóp gần chết, nhưng được ông DSK cứu vớt, trở thành một định
chế vững mạnh, có uy tín lớn trên thế giới. Trong khi đó, TT Sarkozy lại mau mắn
trở thành một trong những tổng thống ít hậu thuẫn nhất của Pháp. Tỷ lệ hậu thuẫn
của ông lửng lơ ở mức của cựu TT Bush khi cuối nhiệm kỳ. Trên dưới 30%. </p><p>Nói
cách khác, nhiều người nghĩ rằng chuyện ông DSK trở thành tổng thống có nhiều
hy vọng thành sự thật. </p><p>Ông
thuộc giai cấp đại đại gia, chỉ nói chuyện với tổng thống, thủ tướng, tỷ phú, đi
đâu cũng đều tiền hô hậu ủng. Một câu nói của ông có thể làm thị trường chứng
khoán lên xuống vài trăm điểm như chơi, hay đồng đô-la lên giá xuống giá so với
tiền Euro dễ dàng. Ông qua Nữu Ước ở khách sạn sơ sơ có ba ngàn đô một đêm.</p><p>Ông
cũng là người có thành tích rấtTây! Tức là đào nhí đào già lung tung. </p><p>Nhưng
vì là dân Tây nên dân Tây và báo Tây chẳng thèm thắc mắc. Có lần bị một bà truy
tố ra tòa vì tội nhiễu sách tình dục - không rõ nhiễu sách như thế nào- nhưng
các quan tòa Tây coi nhưchuyện nhỏ, nhất là không có bằng chứng gì rõ rệt,
nên tha bổng. Cũng chẳng ai thắc mắc. Ông DSK vẫn hiên ngang làm Tổng Giám Đốc
IMF với tràn trề hy vọng làm tổng thống Pháp năm tới.</p><p>Cho
đến một ngày gần đây. Ông lên tàu bay, ghế hạng nhất dĩ nhiên, chờ cất cánh về
Pháp. Bất ngờ, cảnh sát Nữu Ước lên tàu bay, còng tay ông lôi về bót.</p><p>Ông
bị bắt về tội bắt giữ người trái phép và hiếp dâm. Một bà di dân người Guinea
bên Phi Châu, sống một mình với con gái, làm phục dịch trong khách sạn Sofitel,
tố cáo ông đã mưu toan hãm hiếp bà. Bà khai bà vào phòng ông DSK lúc một giờ trưa
để làm phòng, tưởng ông DSK đã trả phòng rồi. Không ngờ đang lui hui làm giường
thì ông DSK bất ngờ trong phòng tắm bước ra, trong bộ y phục của trẻ sơ sinh,
không có tới cái khăn tắm che mình. Bà làm phòng hoảng sợ, tung cửa chạy ra khỏi
phòng, bị ông DSK đuổi theo, bắt được lôi vào phòng đè ra bắt phảiBà làm
phòng chống trả mãnh liệt, thoát khỏi tay ông DSK và chạy ra ngoài phòng. Ông
DSK sau đó hấp tấp lấy taxi ra phi trường. Đi gấp quá quên cả cái điện thoại cầm
tay. Chính cái điện thoại đókhiến ông bị
bắt. Ông ra phi trường, khám phá ra mình quên điện thoại nên ra điện thoại công
cộng gọi về khách sạn để hỏi. Do đó cảnh sát mới biết ông đang ở phi trường. Phải
chi ông đừng kiếm điện thoại thì cảnh sát có truy ra cũng muộn rồi, ông đã về
Pháp mất rồi. Và chắc chắn chính quyền Pháp sẽ không bắt ông trao lại cho cảnh
sát Nữu Ước làm gì. Có khi chính phủ Mỹ phải can thiệp để cảnh sát Nữu Ước bỏ
qua luôn để tránh xì-căng-đan cho cả Pháp, Mỹ và IMF.</p><p>Đó
là câu chuyện theo báo chí. Chưa chắc đã là chuyện thật. </p><p>Luật
sư và các chính khách Pháp đồng minh của ông DSK thì lại có một câu chuyện trái
ngược. Ông DSK chẳng có hành vi đồi bại nào, và cũng không có chuyện dùng bạo lực
gì hết. Việc luật sư của ông DSK nói "không có bạo lực" được diễn giải ngay là
không có hãm hiếp mà là đồng thuận. Có thể bà làm phòng đã liếc mắt đưa tình
ông này và theo đúng truyền thống dân Tây rất lịch sự với mấy bà, nhất là mấy
bà Phi Châu hay Á Châu, ông DSK đã chiều ý mỹ nhân, rồi bị bà này cào mấy cái
vào lưng cho có vết máu và DNA trên lưng ông ta và trên móng tay bà này, rồi
tông cửa chạy ra la hoảng. Tất cả chỉ là cái bẫy của đối thủ chính trị của ông
DSK. Ý muốn ám chỉ TT Sarkozy dĩ nhiên. </p><p>Nhưng
cũng có dư luận ông DSK là thành phần cấp tiến, một lãnh tụ của đảng Xã Hội
Pháp, nên bị cánh hữu trong IMF gài bẫy để bứng ông đi. Cũng tương tự nhu trước
đây, Tổng Giám Đốc Paul Wolfowitz của Ngân Hàng Thế Giới cũng đã bị mất job vì
lem nhem tình ái với cô nhân viên, ký giấy tăng chức tăng lương ào ào cho cô
này. Ông này là thành phần bảo thủ cực đoan (neo-conservative), trước đó khi
còn làm Thứ Trưởng Quốc Phòng trong nội các Bush, là người đầu tiên đòi đánh
Saddam. Cuộc chiến Iraq bị sa lầy, Bush bị áp lực phải đẩy ông qua Ngân Hàng Thế
Giới. Sau khi vào làm tại đây, ông đã có thái độ ngạo mạn, coi thường các đồng
minh cấp tiến Âu Châu đã từng chống lại cuộc chiến Iraq, nên bị cánh này gài bẫy
rồi đánh đến rớt đài luôn.</p><p>Sự
thật là mấy ông chính khách, mỗi lần dính dáng vào xì-căng-đan đều luôn luôn la
hoảng bị đối thủ chính trị gài bẫy. TT Clinton hồi trước cũng đã la hét om sòm
là nạn nhân của một âm mưu vĩ đại của cánh hữu (vast right wing conspiracy) trước
khi cái váy của cô Monica được khám phá ra.</p><p>Thật
sự chuyện gì xẩy ra với ông DSK thì ta chưa biết rõ. Chỉ biết là có vết máu và đã
có thử nghiệm DNA nhưng kết quả không được công bố. Và bà quan tòa Mỹ mới đầu đã
không cho ông DSK tại ngoại, sau đó đổi ý cho tại ngoại với cả triệu đô ký quỹ.
Tức là đã "có gì" rồi. Như bà ký giả cấp tiến Maureen Dowd đã viết rất chua
ngoa trên tờ New York Times: trong khi ông DSK ra lệnh cả thế giới thắt lưng buộc
bụng trong thời buổi kinh tế khó khăn, thì chính ông lại lo cởi thắt lưng thả
quần xuống.</p><p>Câu
chuyện "xe cán chó" này còn phải chờ ít lâu mới biết được sự thật. Chỉ có điều
chắc chắn là cho dù cố tình hãm hiếp hay đồng thuận, thì tương lai chính trị của
một người với nhiều hy vọng làm tổng thống Pháp coi như đã trôi theo mây nước.</p><p>Cái
hình ảnh mà nước Mỹ tặng cho thế giới là hình ảnh một ông già, mặt bơ phờ, râu
ria lởm chởm, quần áo lôi thôi, bị còng tay nhốt vào một trong những nhà tù nổi
tiếng độc địa của Nữu Ước. Ông DSK chưa bị tòa nào kết án, nhưng đã bị truyền
thông Mỹ kết án rồi. Mà cái án của truyền thông này đã lôi đời ông xuống bùn,
không còn vớt vát được gì nữa. Cho dù bà làm phòng sau này bị khám phá ra là đã
ăn tiền của ai đó hay đã dùng bùa mê Phi Châu nào đó để đẩy ông DSK vào bẫy thì
sự nghiệp chính trị của ông cũng đã tiêu tan rồi.</p><p>Cái
sai lầm của ông DSK là đã không hiểu được văn hoá Mỹ. Những chuyện lem nhem
tình ái vớ vẩn ở bên Pháp thì không ai coi là chuyện đáng nói, nhưng xẩy ra ở Mỹ
thì sẽ là chuyện động trời. Ông Mitterand lúc còn làm tổng thống Pháp, đã có "phòng
nhì" và con riêng. Khi chết, bà phòng nhì và con gái hoang đều đến tham dự đám
ma, chẳng ai thắc mắc, kể cả bà goá phụ phòng chính cũng chấp nhận. Khi TT
Clinton bị quốc hội Mỹ lôi ra hỏi giấy vụ Monica, dân Pháp gãi đầu gãi tai
không hiểu ông này đã phạm tội tày trời gì đến độ có thể mất job. Bà vợ TT
Sarkozy đi chụp hình ở truồng đăng đầy báo Pháp, cũng chẳng ai thắc mắc, kể cả
ông chồng tổng thống cũng coi như pha. Ta hãy thử tưởng tượng một đệ nhất phu
nhân Mỹ làm chuyện này thì dân Mỹ sẽ phản ứng ra sao" Phải chi ông DSK làm trò
này ở một khách sạn bên Pháp thì có lẽ đã chẳng sao. Hay là tại ông đã làm nhiều
lần như vậy rồi nên quen thói, qua Mỹ vẫn tiếp tục"</p><p>Câu
chuyện còn đang nóng bỏng trên mặt báo và trên truyền hình thì bất ngờ lại lòi
ra vụ ông cựu thống đốc lực điền của Cali.</p><p>Chỉ
vài tháng sau khi mãn nhiệm kỳ thống đốc thì ông này ra bản tin thông báo ly
thân với bà vợ, tương đối còn trẻ và đẹp. Thiên hạ ngỡ ngàng. Ông thống đốc lực
điền này nổi tiếng là thần tượng của giới trẻ, là người chuyên đóng phim vai người
tốt, không bao giờ đóng những vai kẻ xấu. Ông và bà vợ là cặp vợ chồng lý tưởng
của chính trường Mỹ. Một ông chồng đành hoàng, gương mẫu, với một bà vợ trẻ đẹp,
giòng dõi thế gia, thuộc gia đình Kennedy. Chồng Cộng Hòa bảo thủ, vợ Dân Chủ cấp
tiến, vẫn sống chung đề huề được. Không giống như mấy ông các nước chậm tiến, hễ
khác biệt chính kiến là lôi nhau ra bắn giết, hay ít ra thì cũng dùng thậm từ
nhiều khi thô tục để bôi bác nhau. Dân xứ văn minh có khác.</p><p>Chuyện
phải đến đã đến. Ông cựu thống đốc phải trình làng lý do tại sao. Thì ra ông đã
có con hoang từ hơn mười năm nay. Ông thú nhận đó là một sai lầm to lớn, chính
thức xin lỗi bà vợ, xin lỗi các con, và xin lỗi dân chúng.</p><p>Hoá
ra ông này đã lem nhem với một bà người làm, giúp việc. Vừa to lớn, vừa già, vừa
không đẹp. Có lẽ đứng cạnh ông thống đốc lực điền có vẻ hợp nhãn hơn. Và ông đã
phải cần đến hơn mười năm mới biết là mình đã sai lầm. Cũng chẳng hiểu ông giao
du với bà này trong bao lâu, mà chỉ biết là ông thống đốc nhận thức được lỗi lầm
đúng lúc, sau khi đã hết nhiệm kỳ, chứ nhận thức được lúc còn đang làm thống đốc
thì quả là rắc rối. Thật đúng lúc.</p><p>Đúng
lúc quá, đến độ thiên hạ thắc mắc, câu chuyện có phải thực sự như vậy không" Người
ta cũng thấy bà vợ lên truyền hình trên show của bà Oprah Winfrey, nói chuyện
vui vẻ, không có vẻ gì là xúc động hay bực tức ghê gớm.</p><p>Thế
thì lạ thật. Hay là "coi dzậy mà hổng phải dzậy"" Hay là bà vợ đã biết câu chuyện
từ lâu rồi, nhưng đồng ý im lặng và vui vẻ làm bà đệ nhất phu nhân Cali cho đến
sau khi phu quân hết nhiệm kỳ thì bà sẽ tính sổ" </p><p>Chuyện
các bà tai to mặt lớn rộng lượng với chồng không có gì mới lạ. Bà Hillary chẳng
đã tha thứ cho ông chồng sao" Nếu không tha thứ thì chẳng những TT Clinton đã mất
job mà bà Hillary sau này cũng chẳng thể làm thượng nghị sĩ, hay ứng cử tổng thống,
hay làm ngoại trưởng gì hết. Trên đời này, có nhiều chuyện quan trọng hơn cái "chuyện
ấy".</p><p>´´´Trong
cả hai câu chuyện, ta đều thấy có chuyện khá lạ lùng. Cả hai bà dính dáng vào
chuyện lem nhem, chẳng bà nào là Tây Thi hay Dương Quý Phi gì hết. Một người
thì là một bà Phi châu, mới ngoài ba chục tuổi đã có con mười lăm tuổi. Nhan sắc
thì không ai biết vì báo không đăng hình. Báo đăng là chồng đã chết, chẳng biết
có đúng không. Bà kia thì già khằng chẳng có nhan sắc gì. Cả hai ông đều là đại
đại gia trong khi cả hai bà đều là người làm bồi phòng chứ chẳng phải là kiều nữ
chân dài gì cho cam.</p><p>Người
ta có cảm tưởng cái bệnh thích ăn phở hình như chẳng tha đấng nam nhi nào.
Nghèo hèn ăn phở kiểu nghèo, giàu sang ăn phở nhà giàu. Chuyện đó bình thường.
Nhưng trong câu chuyện hai ông này, ta khám phá thấy mấy ông nhà giàu hình như
lại thích phở nhà nghèo hơn. Ngay cả ông TT Clinton cũng thích phở bình dân
Monica. Mê ăn phở bình dân đến độ để tiêu tan cả sự nghiệp. Có đáng không"
(22-5-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a172077/cau-chuyen-cac-ong-dai-gia-va-kieu-nu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/