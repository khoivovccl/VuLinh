# Vô Chiêu Thắng Hữu Chiêu"

05/04/2011

<p>Vô Chiêu
Thắng Hữu Chiêu"</p><p>Vũ Linh</p><p>...không làm
gì ở Cote d’Ivoire" Vì cái xứ này không có dầu hỏa" </p><p>Chúng ta
không ai lạ gì Kim Dung và những bộ truyện chưởng đã thu hút hàng triệu người
đọc. Có một câu chuyện của Kim Dung mang nhiều ý nghĩa là chuyện anh chàng Lệnh
Hồ Xung, luôn luôn say bí tỉnh đánh đấm lung tung, chẳng có chiêu thức gì, thế
mà lại thành vô địch thiên hạ. Ngày nay TT Obama dường như cũng đi theo môn võ
công “vô chiêu thắng hữu chiêu” này.</p><p>Nhận định về
chính sách của TT Obama, một chuyên gia đã cho rằng “chính sách của TT Obama
là… chính sách vô chính sách” (policy of no policy), theo kiểu tới đâu hay tới
đó, phản ứng gọi là “đột xuất” theo ngôn ngữ “hiện đại”. Nhiều khi nói và làm
trái ngược nhau. Hay nay nói thế này, mai nói thế khác, gọi là tùy cơ ứng biến,
đi đến tình trạng trống đánh xuôi kèn thổi ngược, hay tiền hậu bất nhất là
chuyện thường.</p><p>Về cải tổ y
tế, khi tranh cử thì ứng viên Barack Obama cực lực chống lại ý kiến bảo hiểm y
tế toàn dân của bà Hillary Clinton, để rồi sau khi đắc cử thì ông lại làm đúng
y như đề nghị của bà Clinton. Khi mới đề nghi chương trình thì ông cổ võ cho
giải pháp thành lập một công ty bảo hiểm y tế công, rồi sau đó bác bỏ, rồi bênh
vực lại, để rồi cuối cùng không ai thấy giải pháp này nữa trong luật y tế được
thông qua.</p><p>Trong vấn đề
chiến tranh Afghanistan-Iraq, ông đả kích chiến lược của TT Bush, nhất là
chuyện đôn quân tại Iraq, để rồi thi hành đúng chính sách đôn quân đó tại
Afghanistan, cuối cùng khoe nhờ “chiến lược của ông” mà Mỹ đã chiến thắng tại
Iraq và quân Mỹ mới đang rút về được đúng như hiệp ước ký kết giữa Thủ Tướng
Maliki và tổng thống… Bush!</p><p>Trong trận
chiến chống khủng bố, ông chỉ trích chính sách của TT Bush một cách nặng nề,
hăm dọa đưa các viên chức của Bush ra tòa, ký lệnh đóng cửa trại giam
Guantanamo một ngày sau khi tuyên thệ nhậm chức, ra lệnh đưa mấy ông khủng bố
ra tòa dân sự Nữu Ước. Ðể rồi mọi sự… từ từ đi vào lãng quên, đâu vẫn vào đấy,
vũ như cẩn. Trại tù vẫn còn đó, ý kiến dùng tòa dân sự tại Nữu Ước chẳng đi đến
đâu, TT Obama vẫn nhấn mạnh phải dùng tòa dân sự, nhưng rồi mặt khác lại ký sắc
lệnh tái lập lại tòa quân sự để xét xử năm tay khủng bố đầu xỏ, kể cả kẻ chủ
mưu vụ 9-11 là Khalid Sheikh Mohammed</p><p>Trong vụ
tranh chấp giữa chính quyền tiểu bang Wisconsin với nghiệp đoàn, TT Obama nhẩy
vào cuộc, bênh nghiệp đoàn, rồi ý thức được mình xâm phạm vấn đề nội bộ tiểu
bang, vội nhẩy ra lại, không nói gì nữa, nhưng rồi lại lên tiếng chỉ trích
Thống Ðốc Wisconsin.</p><p>Trong vấn đề
kinh tế, ứng viên Obama gọi TT Bush là vô trách nhiệm vì tiêu xài vung vít gây
thâm thủng ngân sách. Sau đó thì TT Obama lại chủ trì cho những vụ tiêu xài
vung vít gấp mười lần Bush. Nhưng ông lại lên truyền hình tuyên bố “chính
quyền” (chính quyền nào, Bush hay Obama") không thể tiếp tục xài tiền vô trách
nhiệm như vậy được, hô hào thắt lưng buộc bụng, để rồi vài hôm sau, tung ra đề
nghị ngân sách mới với những thâm thủng kỷ lục, lớn nhất lịch sử hơn hai trăm
năm của nước Mỹ này.</p><p>Tất cả đều
là những chuyện chéo cẳng ngỗng chỉ khiến thiên hạ rối mù. Nhưng dù sao thì
cũng còn tương đối sáng tỏ hơn cái “chính sách vô chính sách” của TT Obama
trong vụ khủng hoảng chính trị tại Trung Ðông và Bắc Phi.</p><p>Khởi đi với
biến động tại Tunisia, dân chúng trong vùng nổi lên hàng loạt chống đối các
chính quyền đương nhiệm, bất kể các nước đó là quân chủ hay dân chủ, giàu hay
nghèo, bảo thủ hay cấp tiến, chống Mỹ hay theo Mỹ. Ðúng là “loạn” theo đúng
định nghĩa của “loạn”. Trước cảnh loạn lạc đó thì chính sách của TT Obama cũng…
loạn không kém. Dĩ loạn trị loạn"</p><p>Trước tình
hình Tunisia thì chính quyềnObama im lặng nhận xét, gọi là chẩn bệnh,
đến khi quá muộn, con bệnh chết ngắc, TT Tunisia bỏ trốn mà bác sĩ Obama vẫn
chưa kịp nói gì. Qua đến Ai Cập thì đầu tiên, PTT Biden tuyên bố TT Mubarak là
“đồng minh quan trọng nhất của Mỹ từ hơn ba chục năm nay”, ông này “không phải
là độc tài, không cần từ chức”. Nhưng rồi TT Obama tuyên bố “cần có cải tiến”,
rồi đổi giọng qua “cần thay đổi từ từ”, rồi đến “cần thay đổi ngay”, và cuối
cùng giúp quân đội Ai Cập lật đổ ông đồng minh quan trọng nhất từ hơn ba chục
năm nay.</p><p>Khi rối loạn
lan tràn qua các nước khác như Libya, Algeria, Maroc, Jordan, Ả Rập Saudi, và
nhất là Yemen, Bahrain, và Syria thì TT Obama bối rối không biết phản ứng thế
nào, đành trở lại chủ trương cổ võ cho dân chủ trong vùng, là chính sách của
Bush mà ông đã từng mạnh mẽ chỉ trích trước đây. Nhưng vận động chodân
chủ nghĩa là gì"</p><p>Ở đây phản
ứng của chính quyền Obama đối với các nước Trung Ðông và Phi Châu cho thấy rõ
chính sách vô chính sách.</p><p>Tại Bahrain,
là vương quốc dầu hỏa đồng minh hàng đầu, cũng là căn cứ của Ðệ Ngũ Hạm Ðội Mỹ,
TT Obama nhắm mắt nhìn chính quyền đàn áp, nhắm mắt nhìn Ả Rập Saudi gửi hơn
một ngàn quân qua giúp Bahrain đàn áp dân đa số thuộc hệ phái Shia vì có bàn
tay của Iran trong hệ phái này. Tại Yemen, cũng là đồng minh quan trọng trong
cuộc chiến chống khủng bố, TT Obama im lặng nhìn quân đội bắn giết dân. Ðại
khái ta có thể hiểu TT Obama ủng hộ các cao trào dân chủ trên nguyên tắc, nhưng
nếu gặp trường hợp đồng minh thì nhắm mắt lại. </p><p>Có nghĩa nếu
không phải đồng minh thì TT Obama sẽ ủng hộ các cuộc nổi dậy sao" Chưa chắc.</p><p>Tại Syria,
là nước gần như thù địch, đã từng tiếp tay cho quân khủng bố gây rối loạn tại
Iraq, hậu thuẫn nhóm khủng bố Hamas tại Palestine, yểm trợ lực lượng Hizbollah
gây rối loạn tại Lebanon, thì mới tuần rồi, Ngoại trưởng Hillary lại ca tụng TT
Assad là một nhà cải cách (reformer) trong khi xe tăng của Assad bắn vào đám
biểu tình!</p><p>Ðặc biệt là
tại Libya, như ta đã biết, TT Obama, không cần tham khảo ý kiến quốc hội hay
giải thích cho dân Mỹ mà chỉ lo tuân theo quyết định của Hội Ðồng Bảo An, tung
máy bay vào đánh quân đội của TT Gaddhafi, bắn giết hàng ngàn lính để cứu vài
trăm dân khỏi cảnh bị Gaddhafi thảm sát - mạng dân quan trọng hơn mạng lính. TT
Obama tuyên bố Mỹ không chủ trương lật đổ Gaddhafi, nhưng lại kêu gọi thay đổi
chế độ, rồi đồng thời bí mật gửi cả toán CIA vào Libya mà không ai biết để làm
gì. Làm sao thay đổi chế độ mà không lật đổ Gaddhafi" Hy vọng ông ta tự giác,
từ độc tài giết người không chớp mắt, tự giác biến thành Ðức Ðạt Lai Lạt Ma"</p><p>Mỹ nhẩy vào
tham chiến dưới quyết định của Hội Ðồng Bảo An Liên Hiệp Quốc, lãnh 80% trách
nhiệm đánh bom, nhưng rồi lại nhường cho Liên Minh Bắc Ðại Tây Dương (NATO)
lãnh đạo. Nghe thì có vẻ như đã không còn như thời cao bồi Bush đè đầu thiên hạ
nữa. Nhưng nhìn kỹ lại thì thấy liên quân NATO tại Libya dưới quyền chỉ huy của
một ông tướng Mỹ tại Bộ Tư Lệnh đồng minh đóng tại Naples bên Ý. </p><p>Ông xếp của
ông tướng Mỹ đó là một ông tướng Mỹ khác, Tổng Tư Lệnh quân lực NATO đóng tại
Bỉ, và ông xếp của ông Tổng Tư Lệnh đó chính là Tổng Tư Lệnh quân đội Mỹ,
Barack Obama. Nói cách khác, trong cuộc chiến Libya này, Liên Hiệp Quốc chủ
trì, NATO lãnh đạo, Mỹ chỉ huy, và dân Mỹ chi tiền. Nghe hao hao như chuyện
“nhân dân làm chủ, đảng lãnh đạo, Nhà Nước quản lý” mà chẳng ai hiểu ai làm gì,
chỉ biết chắc chắn nhân dân không làm chủ cũng như Liên Hiệp Quốc cũng chẳng
chủ trì gì hết.</p><p>Sau khi bàn
giao cho NATO xong thì TT Obama tuyên bố đang tính chuyện võ trang cho quân nổi
dậy, nhưng Tổng Thư Ký NATO mau mắn cải chính không có chuyện đó. Bộ trưởng
Quốc Phòng Robert Gates nhấn mạnh Mỹ không có quyền lợi gì cần phải bảo vệ tại
Libya. Hai ngày sau, TT Obama lên truyền hình tuyên bố can dự vào Libya là do
nhu cầu bảo vệ quyền lợi trọng yếu của Mỹ. TT Obama nhấn mạnh hậu thuẫn của
khối Ả Rập, nhưng ngay sau ngày đầu thả bom, Tổng Thư Ký Liên Ðoàn Ả Rập lên án
cuộc tấn công, yêu cầu chấm dứt oanh tạc, và xác nhận chưa hề yêu cầu ai thả
bom Gaddhafi bao giờ. </p><p>Ngoại trưởng
Hillary Clinton công khai khuyến khích các viên chức của Gaddhafi nhẩy rào.
Ngoại trưởng Libya mau mắn đáp ứng, đào ngũ trốn qua Anh, nhưng lại bị cơ quan
an ninh Anh và Mỹ vồ ngay để điều tra vụ Libya đặt bom đánh rớt máy bay dân sự
Mỹ cách đây hơn hai chục năm. Còn ông bộ trưởng hay tướng tá nào của Gaddhafi
muốn đào ngũ nữa không"</p><p>Nếu quý độc
giả cảm thấy rối mù chẳng hiểu gì, thì không cần lo lắng mình chậm tiêu. Cả thế
giới đều như vậy. Chẳng ai hiểu chuyện gì đang xẩy ra và chính sách hay chiến
lược của TT Obama là gì. Tại sao can thiệp" Ðể làm gì" Ðang làm gì" Sẽ làm gì" </p><p>TT Obama
trong bài diễn văn giải thích chuyện Libya, tuyên bố nếu không hành động thì
thiên hạ sẽ coi thường nghị quyết của Hội Ðồng Bảo An và sẽ không còn ai tin
tưởng vào Liên Hiệp Quốc nữa (“the writ of the U.N. Security Council would have
been shown to be little more than empty words, crippling its future
credibility”). Ðây nghe như là nguyên văn một đoạn trong diễn văn của TT Bush
đọc trước phiên họp khoáng đại của Liên Hiệp Quốc trước khi Mỹ đánh Iraq vậy.
Vậy tại sao TT Obama đả kích Bush đánh Iraq"</p><p>Cái cớ chính
viện dẫn là nếu không can thiệp, nhân loại sẽ trực diện với một thảm hoạ vĩ đại
với hàng ngàn người có thể bị Gaddhafi giết. Theo TT Obama, nước Mỹ với những
tư tưởng nhân bản làm nền tảng, không thể vô trách nhiệm khoanh tay ngồi nhìn
người dân vô tội bị giết. Nếu vậy thì kính hỏi tổng thống, nước Mỹ tính làm gì
ở Cote d’Ivoire" Tại Cote d’Ivoire, miền tây Phi Châu, hai ông tổng thống -
đương nhiệm và tân cử - đang đánh nhau. Cả nước bị chia đôi. Hàng ngàn thường
dân hiện nay đang bị chết oan mỗi ngày dưới bom đạn, hơn một triệu người đang
chạy loạn, sống chui rúc trong những trại tạm trú mà tình trạng còn kinh hoàng
gấp ngàn lần tình trạng của New Orleans trong cơn bão Katrina. Không tờ báo Mỹ
nào đăng tin không có nghĩa là chuyện đó không xẩy ra. </p><p>Cũng trong
bài diễn văn về Libya, TT Obama tuyên bố: nước Mỹ khác với thiên hạ, không thể
nào nhắm mắt trước những thảm họa tại các nước khác ("Some nations may be
able to turn a blind eye to atrocities in other countries. The United States of
America is different. And as president, I refused to wait for the images of
slaughter and mass graves before taking action."). Thế tại sao không làm
gì tại Cote d’Ivoire" Tại vì cái xứ này không có dầu hỏa" Hay tại vì Cote
d’Ivoire ở trên hành tinh khác"</p><p>Báo Mỹ đăng
tin về chuyện Libya, cho rằng TT Obama can thiệp vì lý tưởng nhân bản của phe
cấp tiến Mỹ, bị áp lực nặng nề của bố bà: Hillary Clinton, Suzanne Rice (Ðại sứ
Mỹ tại Liên Hiệp Quốc) và Samantha Power cùng Gayle Smith (Cố Vấn Tòa Bạch Ốc),
đều thuộc khuynh hướng cấp tiến cực đoan. Họ không muốn nhìn thấy cảnh Libya
trở thành như Rwanda cách đây hơn một chục năm, với hơn tám trăm ngàn người bị
giết trong khi TT Clinton ngó lơ, mắc bận chuyện gió mưa trong Phòng Bầu Dục.
Hình như mấy bà này chỉ đọc báo Mỹ, không thấy tin tức gì bên Cote d’Ivoire nên
không biết đang có họa diệt chủng tại đây. </p><p>TT Obama đã
mất hậu thuẫn quá nhiều của phe cấp tiến, không dám chống lại nhóm cấp tiến cực
đoan nữa. Chính cái nhu cầu thỏa mãn đủ mọi khuynh hướng đưa TT Obama đến chính
sách vô chính sách, tùy cơ ứng biến, tùy áp lực mạnh yếu của phe nào vào từng
thời điểm.</p><p>Nhìn vào
tình trạng trên, ta thấy thêm một bức tranh oái ăm của chính trị Mỹ. TT Bush
trước đây bị lôi cuốn vào cuộc chiến Iraq vì áp lực mạnh của khối tân bảo thủ
(neo-conservative), bây giờ TT Obama nhẩy vào cuộc chiến vì áp lực nặng nề của
khối cấp tiến (neo-liberalism) cũng cực đoan không kém. Cả hai khối cực đoan tả
hữu đều chủ trương hiếu chiến như nhau. Cái khác biệt là chiến tranh… của ai"
Của anh thì tôi chống, của tôi thì anh chống, bất kể mọi yếu tố khác.</p><p>***</p><p>TT Obama là
ai" Muốn gì" Chủ trương gì" Khối bảo thủ chỉ trích Obama còn cấp tiến hơn cựu
TT Carter. Phe cấp tiến gọi ông là “Bush nhiệm kỳ ba”. Bản thân kẻ viết này,
trên nguyên tắc không ủng hộ chủ trương cấp tiến của TT Obama, nhiều khi cũng
phải suy nghĩ lại, có thật là TT Obama cấp tiến không" Hay ông là bảo thủ" Có
lẽ kết luận đúng hơn cả là… ông là Lệnh Hồ Xung. Nhưng giỏi hơn Lệnh Hồ Xung,
không say bí tỷ mà vẫn áp dụng môn võ vô chiêu được. (3-4-11)</p><p>Quý độc giả
có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác
giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a169844/vo-chieu-thang-huu-chieu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/