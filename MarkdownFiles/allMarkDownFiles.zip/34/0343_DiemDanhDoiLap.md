# Điểm Danh Đối Lập

26/04/2011

<p>Điểm
Danh Đối Lập</p><p>Vũ
Linh</p><p></p><p>...Romney
tự vỗ ngực xưng là bảo thủ, nhưng khối bảo thủ nhìn ông như là "cấp tiến nằm
vùng"</p><p></p><p>Cách
đây hai tuần, TT Obama chính thức tuyên cáo sẽ ra tranh cử cho nhiệm kỳ hai, và
ngay sau đó, đã không bỏ phí thời gian, bay đi Chicago, San Francisco và Los
Angeles tham gia các sinh hoạt gây quỹ vận động tranh cử. Đối nội trong đảng
Dân Chủ, không ai dám nhẩy ra thách thức ông tổng thống da đen đầu tiên của nước
Mỹ. Ông không có đối thủ nội bộ trong đảng Dân Chủ, không phải tốn tiền, mất
công chạy đua trong các vòng sơ bộ như trong những năm 2007-2008, nhưng vẫn
không lơ là và đã hăng hái nhẩy vào cuộc tuy còn 19 tháng nữa mới có bầu cử. </p><p>Trong
khi đó, bên phía Cộng Hòa vẫn chưa có gì ngã ngũ. Cả chục tên tuổi đã được truyền
thông nhắc đến, nhưng chính thức thì chỉ mới có loe ngoe hai ba người nhẹ ký chường
mặt, còn phần đông vẫn chân trong chân ngoài.</p><p>Điều
này cũng không có gì đáng ngạc nhiên. Thông thường, dân Mỹ hay có khuynh hướng
bầu lại tổng thống đương nhiệm, ngoại trừ vài trường hợp khá đặc biệt khi đương
kim tổng thống quá yếu, hay gây mất lòng quá nhiều. Dựa trên sự tính toán này,
các chính khách đối lập thường rất dè dặt khi nhẩy ra tranh cử chống tổng thống
đương nhiệm.</p><p>Năm
1991, đương kim tổng thống Bush (cha) ra tranh cử nhiệm kỳ hai, cho cuộc bầu cuối
năm 1992. Ông vừa huy động được một khối đồng minh lớn, đuổi Saddam Hussein ra
khỏi Kuwait. Tiếng tăm ông nổi như cồn, tỷ lệ hậu thuẫn trong dân Mỹ lên đến xấp
xỉ 90%, một con số chưa từng thấy. Các chính khách tai to mặt lớn của đối lập
Dân Chủ đều theo thuyết tránh voi chẳng xấu mặt nào, ngồi im nhìn TT Bush ra
tranh cử. Chính TT Bush cũng tự tin, ung dung ngồi trong Tòa Bạch Ốc lo việc quốc
gia đại sự chứ không màng chuyện tranh cử.</p><p>Dù
sao thì đảng Dân Chủ cũng phải tiến cử người ra tranh cử. Một thống đốc được đề
cử: Bill Clinton của tiểu bang Arkansas. Lúc đầu, hy vọng đắc cử của ông
Clinton coi như con số không khổng lồ. Ông là thống đốc vô danh quá trẻ, của một
tiểu bang vừa nhỏ vừa có vẻ lạc hậu. Ông này lại có vài cái "tội" khá lớn. </p><p>Thứ
nhất là trong đại hội đảng Dân Chủ năm 1988, ông được đề cử ra đọc diễn văn tiến
cử Thống Đốc Mike Dukakis ra tranh cử chống ông Bush. Ông lợi dụng cơ hội xuất
hiện trên truyền hình cả nước để tự quảng bá chính mình, đọc bài diễn văntràng giang đại hải. Dài đến độ tất cả các đài truyền hình đều cắt ngang không
thu hình nữa, dài đến độ khi ông nói "để chấm dứt" thì cả hội trường đứng dậy
vỗ tay hoan hô kịch liệt. Cái tội thứ hai là ông thống đốc trẻ này nổi tiếng
bay bướm, tiếng tai về các vụ "ăn phở" đầy dẫy.</p><p>Một
tổng thống đương nhiệm với hậu thuẫn ở mức tuyệt đối, chống lại một thống đốc
trẻ vô danh. Ấy vậy mà ông tổng thống đương nhiệm thua. Chỉ vì nước Mỹ không phải
là nước có chính sách "chỉ đạo chính trị", không có chuyện đảng "giới thiệu" ứng
viên và dân chúng hồ hởi bầu với 99,99% phiếu (ghi chú: cái khoảng thiếu hụt là
do một vài cụ vừa qua đời một ngày trước ngày bầu cử, danh sách cử tri chưa kịp
cập nhật, nếu không thì đã là 110% cho đúng chỉ tiêu rồi). </p><p>TT
Obama học bài học của TT Bush nên không muốn lơ là, trên quan điểm "cẩn tắc vô
áy náy". Nhất là khi các thăm dò dư luận hiện nay cho thấy ông đang gặp nhiều vấn
đề khá rắc rối. So với kết quả bầu cử năm 2008, tỷ lệ hậu thuẫn của ông đã rớt đài
trong tất cả các khối cử tri, trắng, đen, nâu, giàu hay nghèo, trí thức hay thợ
thuyền, nam hay nữ, bắc hay nam, đông hay tây, thành thị hay thôn quê, bảo thủ
hay cấp tiến, hay độc lập.</p><p>Thăm
dò dư luận mới nhất của báo "phe ta" Washington Post, cho thấy tỷ lệ hậu thuẫn
của ông chỉ còn 47% ủng hộ, 50% chống, 3% lưỡng lự. Thăm dò của đại học độc lập
Marist không phải phe ta, cho thấy chỉ có 37% dân Mỹ chịu bầu lại TT Obama, 44%
chống lại ý kiến đó, và 18% lưỡng lự. Theo cả hai thăm dò, cứ cho là khối lưỡng
lự sẽ chia đều làm hai thì TT Obama sẽ rớt đài.</p><p>Đó
là vấn đề nhìn từ phía Dân Chủ. Từ phía Cộng Hòa thì bức tranh cũngchẳng có
gì sáng láng hơn.</p><p>Có
thể tương tự như tình hình năm 1991-92, các chính khách đối lập hoặc là còn dè đặt
không muốn bị cháy, hoặc là đã tránh né ngồi chờ bốn năm nữa, khi TT Obama
không ra tranh cử được nữa và Dân Chủ sẽ đề cử một người mới. Như vậy thì có vẻ
cân bằng hơn. Nhưng rồi nhìn vào những thất bại của TT Obama và tỷ lệ hậu thuẫn
thấp kỷ lục của ông, nhiều ông bà Cộng Hoà lại ngứa ngáy muốn nhẩy vào cuộc. Biết
đâu mình sẽ thành một Bill Clinton thứ hai ngáp phải ruồi thì sao"</p><p>Một
số người đã thả bong bóng thăm dò tình hình, một ít người khác đã chính thức
vào cuộc. Ta hãy thử xét lại danh sách đối lập này.</p><p>Một
người chính thức nhẩy vào vòng chiến một cách rất ồn ào, là tỷ phú Donald
Trump. Hy vọng đắc cử tổng thống của ông có lẽ là rấtkhiêm tốn. Ông này rất
giàu, có thể tung rất nhiều tiền để tranh cử. Ông ta cũng rất nổi tiếng, tên tuổi
lúc nào cũng có trên truyền hình và mặt báo. Nhưng thực tế ông ta chỉ là một
doanh gia muốn nhẩy vào lấy thêm tên tuổi để làm bi-di-nét, hay để thoả mãn cái
tôi lớn hơn vũ trụ của ông, hay quảng bá cho cái show truyền hình của ông. Ông
cũng nổi tiếng là tay ăn chơi thứ thiệt, đang sống với bà vợ thứ ba, chưa kể
hàng tấn đào nhí lúc nào cũng bay quanh như ruồi. </p><p>Cũng
chưa kể cái bi-di-nét chính của ông là khách sạn và sòng bạc. </p><p>Kinh
nghiệm chính trị và ngoại giao của ông tuyệt đối không có gì hết. Dân Mỹ có lẽ
chưa sẵn sàng chấp nhận ông playboy chủ casino làm tổng thống. Nhưng nước Mỹ
này không thiếu người bỏ phiếu theo cảm hứng nhất thời, hay bỏ phiếu bậy bạ cho
bõ ghét, hay bị đồng tiền mua chuộc. Ai biết được"</p><p>Một
người khác cũng đã chính thức nhẩy vào là bà dân biểu Michele Bachmann. Bà này
cũng na ná như bà cựu Thống Đốc Sarah Palin, trẻ và đẹp, cực kỳ bảo thủ, được hậu
thuẫn mạnh của khối Tea Party. Nhưng cũng nổi tiếng nói năng vung vít bất kể
chiều sâu. Thành tích lớn của bà này là tuyên bố những câu nẩy lửa mà truyền
thông rất mê vì có thể dùng chạy tít lớn trên báo.</p><p>Một
người nghiêm chỉnh và có uy tín hơn, đó là cựu thống đốc Tim Pawlenty của tiểu
bang Minnesota. Bảo thủ thuần túy, chủ trương chống phá thai, chống tăng thuế. Điểm
bất lợi lớn nhất: chẳng ai biết ông là ai. Trong 100 người Mỹ, chỉ có 5 người đã
nghe đến tên Pawlenty. Cũng chưa hẳn là khó khăn không vượt qua được. Năm 2007,
hầu hết dân Mỹ cũng chưa bao giờ nghe đến cái tên Barack Obama hết.</p><p>Đó
là những khuôn mặt mới. Cũng có những khuôn mặt cũ rích.</p><p>Trước
hết là ông Newt Gingrich. Ông này trước đây là Chủ Tịch Hạ Viện dưới thời TT
Clinton. Tên tuổi ông nổi lên như là một siêu chính khách đã đưa Cộng Hòa đến
thắng lợi lớn nhất trong lịch sử Mỹ (trước thắng lợi tháng Mười Một năm 2010),
chiếm được đa số tuyệt đối tại cả Hạ Viện lẫn Thượng viện trong cuộc bầu cử giữa
mùa năm 1994. Ông cũng nổi tiếng là người đã cãi nhau tay đôi với TT Clinton về
vấn đề ngân sách, đưa đến việc hai lần đóng cửa Nhà Nước mất mấy tuần. </p><p>Trong
vụ xì-căng-đan Monica Lewinsky, ông là tiếng nói lãnh đạo cuộc điều tra và đàn
hặc TT Clinton. Thành tích và tên tuổi của ông rất lớn trong khối bảo thủ Cộng
Hòa. Ông leo lên nấc thang lãnh đạo đảng rất nhanh chóng, để rồi rớt đài còn
nhanh hơn. Trong lúc ban ngày ông gân cổ sỉ vả tính đồi trụy của TT Clinton trước
Hạ Viện thì buổi tối ông bận bịu hú hý với cô thư ký riêng. Xì-căng-đan nổ ra,
ông bị các lãnh tụ Cộng Hòa ép từ chức ngay để tránh tiếng giả nhân giả nghĩa
cho Cộng Hoà.</p><p>Ông
Gingrich hy vọng dân Mỹ trí nhớ kém hay rộng lượng, sẽ không để ý đến chuyện
lem nhem trước đây. Chuyện hơi khó. Thế nào trong cuộc tranh cử các đối thủ của
ông sẽ khai thác, nhắc nhở sự giả dối của ông cho đến khi chúng ta điếc tai hết
vẫn chưa ngừng.</p><p>Rồi
đến cựu Thống Đốc Mitch Romney của tiểu bang Massachusetts. Ông này năm
2007-2008 đã ra tranh cử tổng thống nhưng bị thua ông đồng chí John McCain. Ông
Romney tự vỗ ngực xưng là bảo thủ, nhưng khối bảo thủ nhìn ông như là "cấp tiến
nằm vùng". Ông từng là thống đốc của tiểu bang cấp tiến nhất Mỹ. Khi đó ông chủ
trương ủng hộ phá thai, hôn nhân đồng tính, bây giờ thay đổi quan điểm nhưng
không thuyết phục được ai.</p><p>Ông
cũng chủ trì việc thiết lập một hệ thống bảo hiểm y tế toàn dân cho tiểu bang. Đây
chẳng những là chương trình duy nhất trong năm mươi tiểu bang Mỹ, mà lại còn được
TT Obama lấy làm mẫu cho chương trình của chính TT Obama. Trong suốt thời gian
tranh cử lần trước, ông phải bỏ tất cả thời giờ để phân trần, biện bạch. Người
ta không thấy có gì thay đổi giữa hai lần tranh cử. Ông này cũng vẫn sẽ bị nghi
ngờ và cũng suốt ngày phân trần mà chẳng ai tin. Ông Romney trước đây là nhà
kinh doanh thành công. Ông sẽ khai thác khả năng này để quảng bá kế hoạch cứu
nguy kinh tế của ông. Nhưng ông đã bị ngay nhà tỷ phú Donald Trump chê chỉ là
loại kinh doanh tép riu so với các khách sạn và casinos vĩ đại của ông Trump.</p><p>Tiếp
theo là ông Mike Huckabee, cựu Thống Đốc Arkansas, người kế vị Bill Clinton khi
ông này vào Tòa Bạch Ốc. Ông Huckabee là bảo thủ chính hiệu, không thuộc loại
chao đảo. Nhưng vấn đề là ông này cũng là nhà truyền giáo Tin Lành. Ông được hậu
thuẫn của một số dân bảo thủ gần như cực đoan, nhưng ông khó bành trướng ảnh hưởng
ra ngoài khối này. Trong cái xã hội Mỹ của thế kỷ 21, khó ai có thể tin rằng
dân Mỹ sẽ bầu một nhà truyền giáo làm tổng thống. Thiên hạ đang bàn đến những
chuyện hôn nhân đồng tính và phá thai tự do thì ai mà nghe ông Huckabee" </p><p>Ông
Jimmy Carter ngày xưa chưa phải là nhà truyền giáo mà đã mang lại đủ tai họa
cho nước Mỹ vì tính "hiền lành, ngây ngô" của ông. Bây giờ bầu cho ông truyền
giáo thứ thiệt thì tình hình sẽ như thế nào"</p><p>Rồi
đến ngôi sao một thời sáng chói của Cộng Hòa, bà cựu Thống Đốc Alaska và cựu ứng
viên phó tổng thống của McCain, bà Sarah Palin. </p><p>Theo
một thăm dò mới đây, tên tuổi của bà này được nhiều người biết hơn cả tên của
bà Michelle Obama. Nhưng bà cũng đạt được một kỷ lục khác, bà cũng là người phụ
nữ bị ghét nhiều nhất. Có thể đó là hậu quả của phong trào đánh hội đồng của
truyền thông cấp tiến, nhưng dù sao thì bà cũng đã thành nạn nhân rồi. Tiếng tốt
khó đi xa, tiếng xấu thì bay rất nhanh, mà cũng khó tẩy rửa. Bà vẫn là hình ảnh
của một bà nhà quê chẳng biết mô tê ất giáp gì về chính trị "cao cấp" quốc tế
hay quốc nội. Dù nổi tiếng nhất, ồn ào nhất, lên báo thường xuyên nhất, nhưng tỷ
lệ hậu thuẫn của bà trong cuộc chạy đua vào Tòa Bạch Ốc vẫn lẹt đẹt gần cuối sổ.
</p><p>Còn
một số nhân vật Cộng Hòa đang ngấp nghé, nhưng chưa ai để lại được dấu ấn gì,
ít nhất là cho đến nay. Hai năm là một thời gian rất dài có thể thay đổi cuộc
diện chính trị Mỹ, nếu không thì ta nên chuẩn bị tư tưởng để sống với TT Obama
thêm sáu năm nữa, chỉ vì ông đang đối diện với khoảng trống bên Cộng Hòa.
(24-4-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a170827/diem-danh-doi-lap

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/