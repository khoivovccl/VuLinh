# Trò Chơi Ngân Sách

19/04/2011

<p>Trò Chơi Ngân Sách</p><p></p><p>Vũ Linh</p><p></p><p>...thâm thủng ngân sách TT Obama cao bằng thâm thủng của
tất cả 43 đời tổng thống tiền nhiệm...</p><p>Tuần vừa qua, TT Obama lên truyền hình đọc diễn văn đưa
ra những đề nghị cụ thể để cắt giảm thâm thủng ngân sách đang leo lên những mức
vô tiền khoáng hậu.</p><p>Bài diễn văn được đọc xấp xỉ một tuần sau khi bế tắc
ngân sách cho năm nay được tạm thời giải tỏa, và hai tuần sau khi dân biểu Paul
Ryan đưa ra kế hoạch cắt giảm thâm thủng của đảng Cộng Hòa. Đề nghị cắt giảm
thâm thủng này cũng được đưa ra vài tuần trước khi tổng thống xin quốc hội phê
chuẩn việc tăng mức công nợ tối đa, coi như chút đường lót miệng thiên hạ trước
khi cho uống thuốc đắng.</p><p>Cuộc tranh cãi về ngân sách này đưa ra ánh sáng nhiều điểm
đáng chú ý vì nó ảnh hưởng trực tiếp đến đời sống của dân Mỹ, trong đó có cả
các phó thường dân như dân tỵ nạn chúng ta. Ảnh hưởng lên job của chúng ta,
cũng như ảnh hưởng đến mức thuế chúng ta đóng, đến những quyền lợi an sinh
chúng ta lãnh.</p><p>Tại sao nêu vấn đề" Câu trả lời tất cả mọi người đều
biết từ cả chục tháng qua: những chi tiêu cho các chương trình khổng lồ của TT
Obama đang đe dọa đưa nước Mỹ vào vết xe đổ của Âu Châu, đến bờ vực của phá sản
cho cả nước, với những hậu quả không ai có thể mường tượng được. Như kẻ viết
này đã có dịp viết nhiều lần, kể cả trong bài tuần trước, mức thâm thủng ngân sách
của một mình TT Obama cao bằng mức thâm thủng của tất cả 43 đời tổng thống tiền
nhiệm cộng lại. Đó là cái giá mà TT Obama sẵn sàng trả để thay đổi cả xã hội Mỹ
theo "định hướng" của ông. Cái định hướng đó, có người gọi là xã hội, có người
nói là cấp tiến, có người cho là công bằng, có người nghĩ là văn minh tiến bộ.
Bất kể cái tên là gì, chỉ cần biết nó bảo đảm sẽ phá sản nước Mỹ trong một thập
niên nữa thôi. </p><p>Bên Âu Châu, các nước Hy Lạp, Aí Nhĩ Lan, Bồ Đào Nha,
Tây Ban Nha phá sản có Liên Âu nhẩy vào cứu. Kinh tế Mỹ lớn gấp mấy lần kinh tế
của toàn khối Liên Âu và thế giới hợp lại, nếu có phá sản, cả thế giới hùn tiền
lại cũng không cứu nổi.</p><p>Dĩ nhiên TT Obama khi tung ra những kế hoạch vĩ đại của
ông, không hề nghĩ rằng những thâm thủng bạc chục ngàn tỷ sẽ đưa đến tình trạng
nước Mỹ phá sản. Không phải ông cố ý muốn nước Mỹ phá sản. Ông chỉ lạc quan tin
tưởng ông là Đấng Tiên Tri sẽ thay đổi được xã hội, cái thâm thủng chỉ là nhất
thời rồi sẽ qua nhờ kinh tế sẽ vùng lên lại tạo công ăn việc làm cho tất cả mọi
người, nhờ công bằng xã hội khiến mọi người vui vẻ hạnh phúc bên nhau, v.vMột
bức tranh tuyệt đẹp.</p><p>Vấn đề là cái mô thức Nhà Nước in tiền để thay đổi xã
hội của TT Obama đã được chứng minh thất bại không biết bao nhiêu lần trong lịch
sử cận đại. Chỉ cần nhìn vào gương các nước tư bản "tiến bộ" của Âu Châu cũng
thấy. Thuyết kinh tế "Keneysian" và "tân Keneysian" chủ trương phát triển kinh
tế bằng thâm thủng ngân sách đã đưa Âu Châu chẳng những đến suy thoái kinh tế
mà đến cả suy thoái xã hội và văn hóa luôn. Văn minh huy hoàng lộng lẫy của Âu
Châu đã bị những McDonald, Nike, Madonna, Rap, hoàn toàn lấn áp. Không phải
TT Obama không nhìn thấy, nhưng chỉ vì ông tự tin hơn người. Cả thế giới thất bại,
nhưng riêng ông thì không thể.</p><p>Trên căn bản, chỉ có hai cách để cắt giảm thâm thủng
ngân sách: giảm chi hay là tăng thu. Không có tam thập lục chước.</p><p>Cách đây ít tuần phe Cộng Hòa đưa ra kế hoạch, phần lớn
dựa trên giảm chi. Theo phe này, những thâm thủng quá lớn là kết quả của những
vung tay quá trán của Nhà Nước. Bây giờ cần phải kéo thắng tay.</p><p>Vấn đề giảm chi là vấn đề cực kỳ khó khăn. Năm này qua
tháng nọ, các chính trị gia, Cộng Hòa cũng có, nhưng nhiều nhất là Dân Chủ, đã
mua lá phiếu của cử tri bằng cách tặng cho họ đủ loại quà cáp trợ cấp. Theo thống
kê mới nhất, gần một nửa dân Mỹ (46%) lãnh trợ cấp của Nhà Nước, dưới hình thức
này hay hình thức khác, như tiền già, tiền Medicare, tiền Medicaid, tiền thất
nghiệp, tiền hưu công chức, tiền hưu cựu quân nhân, trợ giúp tiền nhà, phiếu thực
phẩm (foodstamps), học bổng, miễn thuế, v.vNhững trợ giúp này, một khi đã ban
ra thì không thể thu hồi lại được nữa. </p><p>Và với những tiến bộ về khoa học, số người sống lâu
càng ngày càng nhiều nên những trợ cấp này chỉ có tăng mỗi năm, không thể nào
giảm. Năm vừa qua, TT Obama theo đúng truyền thống đảng Dân Chủ, lại thân tặng
ba chục triệu người bảo hiểm và dịch vụ y tế nữa. Không có trợ cấp nào là xấu cả,
tất cả đều tốt, đều có lý do nhân đạo chính đáng. Nhưng cũng không khác gì chuyện
muốn cho vợ con vui vẻ hạnh phúc, mua biệt thự huy hoàng, đi "con Mẹc", ngày
nào cũng đi ăn nem công chả phụng, bằng tiền vay mượn hàng xóm láng giềng, mà
không cần nghĩ đến ngày phải trả nợ.</p><p>Phe Cộng Hòa, qua dân biểu Paul Ryan, Chủ Tịch Ủy Ban
Ngân Sách Hạ Viện, đề nghị giảm chi đồng loạt trên mọi chi tiêu của Nhà Nước, kể
cả chi tiêu quốc phòng. </p><p>Nhưng quan trọng hơn cả là giảm chi trên trợ cấp bảo
hiểm y tế trong luật cải tổ y tế mới được thông qua (coi như là giết một phần lớn
luật cải tổ này), giảm chi về Medicare, không phải bằng cách giảm quyền lợi mà
bằng cách đổi hình thức (đưa tiền mặt để người dưới 55 tuổi dùng tiền này đi
mua bảo hiểm, đưa đến tình trạng những người giàu có có thể lấy thêm tiền túi
mua bảo hiểm đắt tiền thay vì bắt Medicare trả tiền nhiều hơn cho họ; không có
gì thay đổi cho những người trên 55 tuổi), giảm chi về Medicaid (Nhà Nước Liên
Bang sẽ đưa một số tiền nhất định cho chính quyền tiểu bang chứ không còn trợ cấp
vô giới hạn nữa), giảm thuế suất cho các công ty (để khuyến khích họ đầu tư, tạo
công ăn việc làm đưa đến phục hồi kinh tế và mức thu thuế sẽ tăng), nhưng đồng
thời cũng duyệt lại luật thuế để không cho các đại gia trốn thuế - như công ty
General Electric năm qua lời 14 tỷ mà không đóng một xu thuế nào (Chủ Tịch GE
hiện nay cũng là Chủ Tịch Hội Đồng Cố Vấn Kinh Tế cho TT Obama, một trùng hợp
thật lý thú"). Kế hoạch này sẽ đưa đến cắt giảm khoảng 6.000 tỷ thâm thủng
trong 10 năm tới.</p><p>Cuối tuần qua, Hạ Viện do Cộng Hòa kiểm soát đã thông
qua kế hoạch này. Tuy nhiên chỉ có tính cách tượng trưng, nhắm vào cuộc bầu cử
năm 2012 thôi, chứ luật này không thể qua lọt Thượng Viện trong tay Dân Chủ,
cũng như không thể được TT Obama chấp nhận.</p><p>Chương trình của TT Obama thì khác hẳn, dựa trên tăng
thu chứ không phải giảm chi tiêu. Phần chi tiêu không lồ của Nhà Nước không đụng
đến. Chỉ tìm cách thu thêm tiền thuế từ giới "nhà giàu". Kế hoạch của TT Obama
sẽ đưa đến cắt giảm thâm thủng tới 4.000 tỷ trong 12 năm tới (lưu ý là TT Obama
nói đến 12 năm chứ không phải 10 năm). </p><p>TT Obama chỉ lập lại lời hứa khi tranh cử cách đây hơn
hai năm mà ông đã không giữ được vì nhu cầu thực tế: tăng thuế "nhà giàu" sẽ
kéo dài thêm trì trệ kinh tế vì giới "nhà giàu" sợ đóng thuế cao hơn nên không
chịu đầu tư phát triển kinh tế, hay sẽ mang tiền ra nước ngoài đầu tư, khiến thất
nghiệp vẫn không giải quyết được. Nói nôm na ra, tăng thuế "nhà giàu" tức là những
người có tiền đầu tư phục hồi kinh tế, tạo công ăn việc làm cũng không khác nào
giết con gà đẻ trứng vàng.</p><p>Điều TT Obama không nói rõ là tại sao lại có thể đặt kế
hoạch mới dựa trên tăng thuế nhà giàu, điều mà ông đã không thực hiện được năm
ngoái khi đảng Dân Chủ còn kiểm soát cả Hạ Viện lẫn Thượng Viện. Bây giờ mất
quyền kiểm soát Hạ Viện, bớt phiếu ở Thượng Viện thì làm sao thực hiện được" </p><p>Chính điểm mâu thuẫn này đã khiến cho các quan sát
viên chính trị nhận định kế hoạch của TT Obama chỉ là lời hứa hẹn đầu tiên của
cuộc tranh cử tổng thống năm tới, không phải là giải pháp thực tế. Một ngày sau
bài diễn văn đòi tăng thuế nhà giàu, TT Obama bay đi Chicago tham dự bữa tiệc
gây qũy đầu tiên trong kế hoạch gây quỹ một tỷ đô để tái tranh cử. Cuộc tranh cử
tổng thống đúng là đã bắt đầu.</p><p>Báo kinh doanh Wall Street Journalđã làm một bài toán sơ đẳng. Theo thống kê của
sở thuế IRS, tổng cộng số lợi tức của tất cả những người làm lương trên 100.000
đô một năm tại Mỹ là 1.600 tỷ trong năm 2009. Nếu bây giờ TT Obama thu thuế
100% trên lợi tức của tất cả những người này, không chừa lại một xu nào cho họ
sống, thì vẫn chưa đủ để bù đắp thâm thủng 1.650 tỷ của TT Obama trong một năm
2011, đừng nói tới thâm thủng cả chục ngàn tỷ trong mười năm tới. </p><p>TT Obama đề nghị tăng thuế của những người làm trên
250.000 (chứ không phải 100.000) thì dĩ nhiên khoảng thiếu hụt còn lớn hơn nữa.
Các chuyên gia của TT Obama không biết cộng trừ nhân chia" Hay là "hy vọng"
thiên hạ đều không biết cộng trừ nhân chia"</p><p>Ít ra thì phe Cộng Hòa cũng có gan dám đụng đến
Medicare và Medicaid, hai con khủng long đang trên đà chết già nếu không được cải
tổ, trong khi TT Obama trực diện với cuộc tranh cử sắp tới đã không dám đả động
gì.</p><p>Chính trị gia đều là những chuyên gia về "đại ngôn",
nhưng có lẽ ít ai so sánh được với TT Obama. Nói về chuyện Cộng Hòa chống tăng
thuế "nhà giàu", ông đã không ngần ngại so sánh đây giống như là sự lựa chọn đứng
về phe các triệu phú chống lại các trẻ em bị bệnh chậm phát triển (autism). Cựu
Chủ Tịch Hạ Viện, bà Nancy Pelosi cũng không chịu thua, phụ đề thêm là chương
trình của phe Cộng Hoà là chấm dứt Medicare, Medicaid để có thể bớt thuế cho tỷ
phú dầu hỏa. Bất kể chuyện chương trình của phe Cộng Hoà chẳng có gì liên quan đến
trẻ em bị bệnh tật hay chấm dứt Medicare, Medicaid, hay bớt thuế cho tỷ phú dầu
hỏa gì hết. Cứ nói bừa như vậy, thế nào cũng có người tin. Cộng Hòa chỉ đề nghị
thiên hạ nhìn nhận chúng ta đang sống trong khủng hoảng và xiết hầu bao lại vì
tương lai lâu dài, đi xe Kia thay vì con Mẹc, không phải đòi hỏi mọi người phải
đi xe đạp hay đi bộ.</p><p>Cách đây hai tuần, TT Obama, trưởng khối đa số Dân Chủ
trong Thượng Viện Harry Reid, và Chủ Tịch Hạ Viện Cộng Hòa John Boehner đi đến
thỏa hiệp ngân sách cho đến tháng Chín, cắt giảm 38 tỷ đô, tránh cho Nhà Nước
khỏi đóng cửa tiệm. </p><p>TT Obama mau mắn khoe ông đã chủ trì việc cắt giảm chi
tiêu lớn nhất lịch sử Mỹ. Điều ông không nói ra là những cắt giảm đó đến từ đòi
hỏi của phe bảo thủ Cộng Hòa để cắt giảm chi tiêu của TT Obama. Nếu ông đừng
chi tiêu vung vít từ đầu thì đâu có nhu cầu cắt giảm gì nữa! Đặc biệt hơn nữa,
ông cũng không nói là cắt giảm này chỉ chưa bằng 2,5% cái thâm thủng 1.650 tỷ của
ngân sách năm nay do chính ông gây ra. Kiểu như ông nhà nghèo chơi ngông đi mua
chiếc đồng hồ 1.000 đô rồi về khoe với vợ ông đã trả giá bớt được 2,5 đô, chỉ
còn có 997,50 đô thôi !</p><p>Điều đáng nói hơn nữa là Văn Phòng Ngân Sách Quốc Hội
CBO, một cơ quan chuyên gia trung lập, đã phúc trình là cắt giảm thực sự chỉ là
trên 350 triệu chứ không phải 38 tỷ. Phần lớn những "cắt giảm" là tiền còn dư thừa
của nhiều dự án đã hết hạn không xài đến nữa, hay là tiền dự phòng có thể chẳng
bao giờ đụng đến của nhiều kế hoạch trong tương lai, hay chỉ là kết quả của những
bùa phép kế toán.</p><p>Ứng viên Barack Obama tranh cử bằng khẩu hiệu "mang lại
trong sáng trong chính trị", nhưng dường như ông lại trị nước bằng hỏa mù.
(17-4-11)</p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua
email: Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a170499/tro-choi-ngan-sach

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/