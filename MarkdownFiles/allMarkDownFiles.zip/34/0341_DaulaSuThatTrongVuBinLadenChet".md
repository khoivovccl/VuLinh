# Đâu là Sự Thật Trong Vụ Bin Laden Chết"

17/05/2011

<p>Đâu
là Sự Thật Trong Vụ Bin Laden Chết"</p><p>Vũ
Linh</p><p></p><p>...Thế
thì tổng thống và cả nội các chăm chú nín thở coi cái gì trong 40 phút vậy"</p><p></p><p>TT
Obama là người đầu tiên xuất hiện trước truyền thông gần nửa đêm mùng một rạng
mùng hai tháng 5 - giờ miền Đông nước Mỹ -để thông báo tin giựt gân nhất của thế kỷ: Osama Bin Laden đã bị giết chết.
Ngắn gọn, không chi tiết. Thiên hạ nín thở chờ đợi chi tiết.</p><p>Rồi
màn hài kịch bắt đầu. </p><p>Phát
ngôn viên Toà Bạch Ốc mô tả đã xẩy ra cuộc đấu súng ghê gớm. Bin Laden được yêu
cầu đầu hàng, đã không chịu thì chớ, lại còn núp sau lưng bà vợ bắn vào lính Mỹ,
đưa đến cuộc đấu súng dữ dội và Bin Laden bị bắn vào đầu vỡ tan sọ, chết tại trận.
Một ký giả phe ta đã dùng danh từ "fierce firefight" để mô tả cuộc chiến mà anh
ta không hề chứng kiến. Toà Bạch Ốc phổ biến hình ảnh các vị tai to mặt lớn
trong Tòa Bạch Ốc nín thở theo dõi cuộc đấu súng được trực tiếp truyền hình về
cho TT Obama theo dõi từng giây từng phút, kéo dài 40 phút. </p><p>Nhìn
bức hình, kẻ viết này không biết phải mừng hay lo. Trong hình, có một người được
biết là Giám Đốc đặc trách Chống Khủng Bố của TT Obama. Người ta tưởng người đó
chắc phải là một ông tướng già cứng cựa, kinh nghiệm đánh nhau cùng mình. Nhưng
không phải. Trong bức hình đó, có một cô bé mặt non choẹt núp sau mấy ông già,
ló mặt ra thôi. Đó chính là bà Audrey Tomason, người chịu trách nhiệm bảo vệ
chúng ta chống khủng bố. Có yên tâm được không" </p><p>(Xin
vào link này xem hình: http://en.wikipedia.org/wiki/Audrey_Tomason)</p><p>Câu
chuyện đột kích này, có lẽ các đạo diễn Hollywood chỉ có thể mơ tưởng thôi, chứ
cũng không thể nào làm phim gay cấn hồi hộp được như vậy. Nghĩ cho cùng, chỉ có
Mỹ mới làm được chuyện này: lính Mỹ nửa đêm đi đột kích một căn nhà tuốt bên
kia địa cầu mà vẫn có phó nhòm đi theo quay phim trực tiếp cho tổng thống coi để
trực tiếp chỉ đạo cuộc đấu súng. Tổng Tư Lệnh Quân Lực Hiệp Chủng Quốc đang điều
binh khiển tướng như chơi video games vậy.</p><p>Nhưng
rồi hình như có gì không ổn.</p><p>Ngày
hôm sau, ông phát ngôn viên được hỏi thế bà vợ Bin Laden bị dùng làm lá chắn như
thế nào và Bin Laden bắn súng gì" Ông ta ú ớ trả lời không có chuyện Bin Laden
núp sau lưng vợ, hai người đứng cạnh nhau, cả hai được mô tả là có hành động
kháng cự nên bà vợ bị bắn vào chân còn Bin Laden thì bị bắn vào đầu. </p><p>-
Bin Laden dùng súng gì" </p><p>-
Ờ, ờ, Bin Laden không có súng!</p><p>-
Thế sao lại nói Bin Laden kháng cự"</p><p>-
Bin Laden có kháng cự nhưng không phải bằng súng.</p><p>-
Thế thì kháng cự bằng gì" Bằng cách nào"</p><p>-
Ờ, ờ, nhiều chi tiết cho đến nay vẫn chưa rõ ràng!</p><p>Lạ
thật. Báo đăng hình TT Obama và cả nội các ngồi chăm chú coi khúc phim đấu súng
mà sao bây giờ lại nói chi tiết chưa rõ ràng" Thế thì tổng thống và cả nội các
chăm chú nín thở coi cái gì trong 40 phút vậy"</p><p>Ngày
hôm sau, Giám Đốc CIA Leon Panetta gặp báo chí, cho biết trong 40 phút giao
tranh ác liệt đó thì hệ thống truyền tin bị trục trặc, chỉ truyền hình được có đâu
15 phút đầu, trước khi toán đột kích tới hiện trường. Do đó, không có thu hình
trực tiếp trận đấu súng nào hết. Có nghĩa là bức hình chỉ là dàn dựng để phổ biến
ra báo, mai mốt mang đi tranh cử.</p><p>Cuối tuần rồi, đài CBS loan tin đã coi được
khúc phim cuộc đột kích qua các máy thu hình gắn trên mũ sắt của các quân nhân đột
kích. Khúc phim mà nội các Obama có vẻ như đang coi nhưng thực tế không coi được.
Theo CBS, toán đột kích vào căn nhà, bị một tên giao liên bắn một phát, tên này
bị bắn hạ ngay. Sau đó Bin Laden từ phòng mình trên lầu ba chạy ra, bị bắn ngay
lập tức, nhưng bắn hụt, tên này chạy vào phòng lại, bị toán Người Nhái xông vào
phòng, bắn hai phát, vào ngực, sau đó vào đầu.</p><p>Bin
Laden đã bị bắn chết trong quần lót (underwear), không có vũ khí gì trong tay
và cũng không kháng cự gì hết. Thấy là bắn. Chắc chắn đó chỉ có thể là lệnh từ
TT Obama: bắn chết chứ không bắt tù nhân. Cá nhân kẻ viết này không luyến tiếc
gì tên Bin Laden, nhưng cũng không khỏi thắc mắc. Theo TT Obama, TT Bush cho
phép trấn nước tù khủng bố bị bắt tại mặt trận độ 15 phút cho sặc sụa một hồi
là hành động dã man mà tính nhân bản và luật pháp Mỹ không chấp nhận được. Thế
nhưng TT Obama ra lệnh một giờ sáng xông vào phòng ngủ, bắn chết một người
không có súng trong tay, mặc quần lót trong phòng với vợ, thì lại là chuyện
chính danh sao" </p><p>TT
Bush coi chuyện chống khủng bố là "chiến tranh", do đó lính Mỹ có quyền bắn chết
kẻ địch mà không cần bắt đưa ra tòa. Nhưng TT Obama cho rằng TT Bush vi phạm
nhân quyền và Hiến Pháp, TT Obama cấm không cho nhân viên chính phủ dùng từ "chiến
tranh", và chuyển giao hồ sơ tù nhân cho bộ Tư Pháp, coi như là vấn đề an ninh
trật tự, phải tôn trọng luật lệ tuyệt đối. </p><p>Thế
bắn chết Bin Laden như vậy có phải là tôn thủ luật Mỹ không" Luật Mỹ rất rõ
ràng: chưa bị kết án có tội là không có tội. Bin Laden chưa bị một tòa án Mỹ
nào kết tội, nhưng đã bị TT Obama cho lệnh bắn chết. Có vi phạm nhân quyền, luật
lệ và và Hiến Pháp Mỹ không" </p><p>Một
cựu thẩm phán Tối Cao Pháp Viện, ông John Paul Stevens cho rằng việc giết Bin
Laden hoàn toàn hợp pháp vì tên khủng bố là một "kẻ thù muốn tấn công nước Mỹ".
Nhận định này có vẻ chéo cẳng ngỗng với nhận định cũng của ông năm 2004, dưới
thời Bush, khi đó ông chỉ trích Bush không có quyền giam giữ tù khủng bố vô hạn
định nếu không có bằng chứng. </p><p>Nói
cách khác, khi Bush làm tổng thống thì Mỹ không có quyền nhốt tù khủng bố nếu
không có bằng chứng, nhưng khi Obama làm tổng thống thì Mỹ có quyền giết Bin
Laden mà không cần bằng chứng. Một lý luận khá lạ lùng từ một thẩm phán Tối Cao
Pháp Viện, cho dù ông có khuynh hướng cấp tiến. Hay là vì ông có xu hướng đó"</p><p>Thời
ông cao bồi Bush, Saddam Hussein bị bắt sống, trao lại cho chính quyền Iraq,
mang ra xử án công khai, có luật sư biện hộ đầy đủ trước khi bị kết án tử hình,
chứ không bị bắn ngay tại chỗ. Đến thời luật gia Obama thì Bin Laden bị bắn chết
tại trận, không bị bắt hay đưa ra tòa làm gì cho phiền phức.</p><p>Chưa
hết, TT Obama lên truyền hình, bi thảm hoá câu chuyện thêm nữa. </p><p>Đây
là quyết định "khó khăn nhất trong đời ông". Ông nhấn mạnh ông chỉ biết được
xác xuất 55/45 là có thể có Bin Laden trong nhà đó, và quyết định của ông là một
quyết định cực kỳ phiêu lưu, khó khăn vì không chắc chắn 100%. Sự thật là CIA
tính xác xuất là 70%-80%, TT Obama giảm xuống 55% nghe cho hồi hộp hơn. Nếu CIA
nói có 70%-80% hy vọng giết được Bin Laden thì bất cứ anh cảnh sát hay anh lính
Mỹ nào cũng muốn nhẩy vào chộp lấy cơ hội, chẳng có gì là quyết định khó khăn
nhất và can đảm nhất trên đời. </p><p>TT
Obama mà không hành động để Bin Laden chạy thoát thì sẽ là lý do lớn nhất để
phe Cộng Hòa trở về Tòa Bạch Ốc lại năm tới.</p><p>TT
Obama lưu ý là tổng thống có khi phải có can đảm lấy quyết định khó khăn dựa
trên tin tức hết sức thiếu sót, và dân chúng cần phải hiểu khó khăn đó. Thế TT
Bush có can đảm không khi quyết định đánh Iraq mà chưa đầy đủ tin tức về kho vũ
khí giết người tập thể của Saddam Hussein" Và TT Obama có hiểu cho TT Bush đã
phải lấy quyết định bảo vệ nước Mỹ chống vũ khí đó ngay sau vụ 9/11 trong tình
trạng thiếu thông tin không"</p><p>Toàn
bộ câu chuyện nói đi nói lại dường như chỉ có đúng một chuyện là đúng sự thật: đó
là Osama Bin Laden bị giết chết. Người dân chẳng có cách nào biết rõ chuyện gì đã
xẩy ra. Chỉ vì câu chuyện do chính quyền phổ biến thay đổi như chong chóng, mỗi
ngày một chuyện. </p><p>Đâu
là châm ngôn "trong sáng" của mùa tranh cử" Khủng hoảng niềm tin nơi chính quyền
đã được giải quyết chưa" Theo thăm dò dư luận, cứ năm người thì đã có một người
cho rằng Bin Laden vẫn còn sống (20%), cho dù tổng thống nói gì cũng vậy!</p><p>Trong
cuộc chiến Việt Nam năm xưa, khó khăn lớn nhất của các chính quyền Mỹ không phải
là thắng được mấy ông du kích hay thắng được chiến xa Nga, mà là thắng được mấy
ông ký giả Mỹ.</p><p>Vì
lý do chính trị, lý do tuyên truyền, hay lý do tranh cử, các chính quyền Mỹ từ
Johnson đến Nixon, đã nhiều khi nói "sai" hay nói "thiếu" sự thật, để đến khi sự
thật lòi đuôi ra thì các ký giả mất niềm tin đối với chính quyền, tạo ra một "khoảng
cách niềm tin" - credibility gap. Rồi từ đó chính quyền - từ tổng thống đến
phát ngôn viên đến tướng tá - nói gì thì cũng bị đặt câu hỏi, không biết nói thật
hay nói láo.</p><p>Tình
trạng truyền thông và dân chúng mất niềm tin với chính quyền kéo dài lai rai từ
mấy chục năm qua mà chẳng tổng thống nào thay đổi được gì. Cho đến khi ứng viên
Dân Chủ Barack Obama ra tranh cử năm 2007. </p><p>Ông
lớn tiếng quảng bá sẽ thay đổi cách làm việc, sẽ mang lại trong sạch và trong
sáng vào chính quyền để tái tạo lại niềm tin nơi chính quyền. Dân chúng Mỹ vốn
dĩ dễ tin, ùn ùn bỏ phiếu cho ông Obama thay đổi cách làm việc của Hoa Thịnh Đốn.</p><p>Để
rồi bây giờ mới nhận thấy hình như ông tổng thống khác xa với ông ứng viên tổng
thống. TT Obama đã mau mắn biến một thành tích lớn thành một câu chuyện biểu tượng
cho sự luộm thuộm của cả chính quyền Obama. </p><p>Những
tin tức mới nhất được xì ra cũng đưa ra một hình ảnh không oai hùng lắm. Thay
vì hình ảnh một tổng tư lệnh xuất chúng chỉ đạo quân lực đại cường Cờ Hoa lùng
bắt tên trùm khủng bố trong một cuộc đấu súng kinh hoàng, thì người ta lại thấy
hình ảnh một chính quyền luộm thuộm nửa đêm cho lính vào bắn chết một ông già dơ
dáy, mặc quần lót trong phòng ngủ với vợ, chung quanh đầy băng video khiêu dâm
3-X, đang sống với ba bà vợ và hai tá con. Rồi sau đó loan tin lung tung kiểu "ông
nói gà bà nói vịt" khiến chẳng ai hiểu chuyện gì đã xẩy ra.</p><p>Cái
tính luộm thuộm được phản ánh ngay trong cái tên của chiến dịch. Mới đầu được đặt
tên là Chiến Dịch Geronimo. Geronimo là tên của một lãnh tụ dân Da Đỏ chống lại
các anh cao bồi Mỹ thời lập quốc. Bị dân Da Đỏ phản đối vì gắn tên thần tượng của
họ vào tên trùm khủng bố Bin Laden, chính quyền Obama vội vàng đổi tên là Chiến
Dịch Neptune Spear, cây đinh ba của thần Neptune - cũng là huy hiệu của nhóm Người
Nhái đột kích bắn Bin Laden.</p><p>Sau
đó thì người ta cũng thấy hình ảnh một ứng viên tổng thống không có bao nhiêu
thành tích để tranh cử, vội vã khai thác cái chết của Bin Laden như vũ khí
tranh cử quan trọng nhất, đi ngay Texas và Kentucky - đến chụp hình với lính dù
tại Fort Campbell - để kể công.</p><p>Cảnh
luộm thuộm, "coi dzậy mà hổng phải dzậy" trong câu chuyện giết chết Bin Laden,
cũng như việc khai thác quá mạnh thành tích này, đã giảm thiểu ngay tính "ấn tượng"
của chiến công này. Mức hậu thuẫn của Obama vọt lên 6 điểm trong những ngày đầu,
bây giờ đã mau mắn tuột xuống 3 điểm. Một năm rưỡi nữa, chắc dân Mỹ cũng chẳng
nhớ tên Osama Bin Laden là ai nữa không chừng.</p><p>Câu
chuyện này làm ta nhớ lại câu chuyện máy bay NATO đánh bom giết chết con trai
và ba đứa cháu nội của nhà độc tài Gaddhafi.</p><p>Trước
câu hỏi giết người con trai út và ba đứa cháu nội này có liên quan gì đến việc
cứu dân Benghazi, thì phát ngôn viên Tòa Bạch Ốc trả lời máy bay chỉ đánh bom
các mục tiêu quân sự thôi và chỗ họ bị giết là một bộ chỉ huy quân sự (military
command). Chẳng may cho ông phát ngôn viên này, Gaddhafi mau chóng phổ biến cho
báo chí hình ảnh cái bộ chỉ huy quân sự này thực ra chỉ là nhà riêng của ông con
trai út của Gaddhafi, chứ chẳng phải căn cứ quân sự gì. Chẳng qua, Mỹ và đồng
minh cố tình muốn truy giết Gaddhafi thôi vì có tin tình báo cho biết Gaddhafi đang
ở đó. Tin "bé cái lầm" này được truyền thông phe ta thông cảm không nhắc lại
làm gì. Dù sao thì chuyện mấy đứa cháu nội của Gaddhafi chết cũng là chuyện nhỏ.</p><p>Điều
chắc chắn là mặc dù với dưới danh nghĩa NATO, nhưng ông tướng Mỹ ra lệnh đánh
bom giết Gaddhafi phải được sự chấp thuận của TT Obama. Có thể cả nội các Obama
cũng đã ngồi coi khúc phim máy bay Mỹ thả bom không chừng, nhưng vì thất bại
nên hình không được phổ biến. Câu hỏi là như vậy TT Obama lấy quyết định khi
thiếu tin tức chính xác nên giết oan ba đứa bé, có được coi là can đảm không" Tại
vì Gaddhafi không chết mà chỉ có ba đứa bé bị chết oan, chứ nếu như Gaddhafi bị
chết trong trận đánh bom đó, thì câu chuyện này có thể đã trở thành một chiến
công hiển hách tốn rất nhiều trang báo, cũng đã là một quyết định khó khăn và
can đảm khác của TT Obama để mang ra tranh cử rồi. Thật đáng tiếc. (15-5-11)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a171765/dau-la-su-that-trong-vu-bin-laden-chet

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/