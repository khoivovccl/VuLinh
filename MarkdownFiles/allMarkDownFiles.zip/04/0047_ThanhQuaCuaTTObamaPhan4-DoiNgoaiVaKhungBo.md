# Thành Quả Của TT Obama Phần 4 - Đối Ngoại Và Khủng Bố

17/01/2017



### Nguồn:

Viet Bao: https://vietbao.com/a262936/thanh-qua-cua-tt-obama-phan-4-doi-ngoai-va-khung-bo

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/