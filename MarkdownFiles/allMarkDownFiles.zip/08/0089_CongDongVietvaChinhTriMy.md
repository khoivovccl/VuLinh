# Cộng Đồng Việt và Chính Trị Mỹ

05/04/2016



### Nguồn:

Viet Bao: https://vietbao.com/a251304/cong-dong-viet-va-chinh-tri-my

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/