# Đảng CH Đang Tự Chiếu Bí

26/04/2016



### Nguồn:

Viet Bao: https://vietbao.com/a252160/dang-ch-dang-tu-chieu-bi

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/