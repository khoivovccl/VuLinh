# Thư Ngỏ Của Vũ Linh Kính Thưa Quý Độc Giả

28/11/2017

Tôi xin phép thông báo cùng quý vị kể từ tuần này, tôi sẽ chính thức không còn hợp tác viết bài cho Việt Báo nữa.<br/><br/>Đối với những độc giả đã ủng hộ và kiên trì đọc bài của tôi trong suốt cả chục năm qua, tôi cũng không biết làm gì hơn là xin đa tạ và chân thành nhận lỗi đã đào nhiệm, với hy vọng sẽ có dịp phục vụ lại khi có điều kiện thuận tiện.<br/><br/>Tôi cũng xin cám ơn Việt Báo đã cho tôi cơ hội mang đến cộng đồng một tiếng nói khác, một cái nhìn khác với cái nhìn chung của truyền thông dòng chính Mỹ, cho dù đó là cái nhìn tạo nhiều tranh cãi, gây khó khăn cho Việt Báo.<br/><br/>Trân trọng<br/><br/>Vũ Linh

### Nguồn:

Viet Bao: https://vietbao.com/a274747/thu-ngo-cua-vu-linh-kinh-thua-quy-doc-gia

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/