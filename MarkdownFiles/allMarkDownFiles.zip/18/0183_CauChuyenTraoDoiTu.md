# Câu Chuyện Trao Đổi Tù

10/06/2014



### Nguồn:

Viet Bao: https://vietbao.com/a222597/cau-chuyen-trao-doi-tu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/