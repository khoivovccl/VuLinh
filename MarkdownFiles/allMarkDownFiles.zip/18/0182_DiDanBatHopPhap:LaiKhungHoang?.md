# Di Dân Bất Hợp Pháp: Lại Khủng Hoảng?

17/06/2014



### Nguồn:

Viet Bao: https://vietbao.com/a222920/di-dan-bat-hop-phap-lai-khung-hoang

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/