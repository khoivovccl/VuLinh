# Cộng Hòa và Những Ngôi Sao Mới

24/08/2011

<p>Cộng Hòa và Những Ngôi Sao Mới </p><p>Vũ Linh</p><p>Cộng Hòa vẫn còn mò đường đi...</p><p>Cuộc chạy đua vào Nhà Trắng bắt đầu sôi động bên Cộng Hòa.
Tổng cộng trên nửa tá ứng viên. Nhưng chưa là danh sách cuối cùng. Chẳng hạn
như bà cựu Thống Đốc Alaska Sarah Palin, hay cựu Thị Trưởng Nữu Ước Rudy
Giuliani vẫn còn ngấp nghé, hay cựu thống đốc Minnesota Tim Pawlenty đã rớt
đài. Rồi Thống Đốc Texas Rick Perry vừa nhẩy vào cuộc. </p><p>Nhìn vào hiện tại, ta thấy một bức tranh khá lạ lùng: sự nổi
bật của bà Michele Bachmann và ông Perry. </p><p>Bà Bachmann là dân biểu liên bang của Minnesota từ 2007. Trước đó, bà là nghị sĩ
tiểu bang từ 2001. Bà năm nay 55 tuổi, xuất thân từ một gia đình tin lành trung
lưu theo Dân Chủ. Thời sinh viên, bà tích cực vận động cho TT Jimmy Carter.
Nhưng rồi bà nhìn thấy chính sách kinh tế của TT Carter hoàn toàn thất bại, và
Dân Chủ cũng là đảng cho phá thai tự do. Bà bỏ Dân Chủ đi vận động cho ứng viên
Ronald Reagan của Cộng Hoà, lấy chồng có năm con và hơn hai chục "foster
child": thuần thành, ngoan đạo, chống phá thai...</p><p>Bà Bachmann giống như chị em sinh đôi với bà Sarah Palin. Cả
hai đều trẻ, đẹp, sắc xảo, có biệt tài ăn nói và xách động đám đông. Cả hai
cũng đều có quan điểm bảo thủ cực đoan, chống sưu cao thuế nặng, chống Nhà Nước
vú em. Nhưng Bachmann nổi tiếng là bạo miệng hơn xa Sarah Palin. Bà chỉ trích
TT Obama một cách cực kỳ hữu hiệu. Bà cũng khác Sarah Palin ở điểm nắm vững các
vấn đề chính trị, trả lời thông suốt những câu hỏi hóc búa có tính cách gài bẫy
của truyền thông cấp tiến. </p><p>Chuyện bà Bachmann là bảo thủ, được Phong Trào Tea Party
nhiệt tình ủng hộ, ai cũng biết. Nhưng gần đây, khi bà tuyên bố ra tranh cử đại
diện cho Cộng Hòa trong kỳ bầu cử tổng thống năm tới, thiên hạ vẫn ngạc nhiên
vì tham vọng có vẻ hơi lớn của bà. Nói chung, chẳng ai coi bà là một ứng viên
nặng ký. Một nữ chính khách bảo thủ khác – bà Palin - trước đây xuất hiện trên
chính trường cũng đã bị coi như võ sĩ hạng lông, vừa thượng đài đã bị truyền
thông cấp tiến đánh tơi bời và bươi móc mọi chuyện. Việc Bachmann tranh cử
không có gì đáng nói, mà trái lại mang tính tiêu khiển, cho cuộc bầu cử một tý
hương vị giữa đám đực rựa xồn xồn, toàn là mặc áo vét mầu xanh đậm với cà vạt
đỏ, giống nhau như đúc, chán phèo.</p><p>Tháng Sáu vừa qua, bà tham gia tranh luận trên truyền hình
với nửa tá chuẩn ứng viên chán phèo của phái nam. Chẳng mấy ai để ý. Thế rồi
thiên hạ bật tỉnh. Qua các thăm dò, bà Bachmann là người đại thắng trong cuộc
tranh luận. Trong khối những bóng mờ đó, bà nổi bật như là người nói hay nhất,
có ý kiến sáng tạo nhất, kích động thiên hạ mạnh nhất, và đả kích TT Obama
nghe… sướng tai nhất. </p><p>Đầu tuần qua, tại Iowa đã có tranh luận lần thứ nhì, và lạ
lùng thay, bà Bachmann cũng lại được đánh giá như người thắng lớn, hạ hết cả
mấy đấng mày râu địch thủ.</p><p>Rồi cuối tuần qua, tiểu bang Iowa mở cuộc bầu bán chính thức đầu tiên để
tuyển lựa ứng viên sẽ tham gia vào cuộc bầu nội bộ thực sự đầu năm tới. Bà
Bachmann đại thắng, về đầu, hạ hết các đối thủ, kể cả cựu thống đốc
Massachusetts, Mitt Romney là người đang dẫn đầu phiá Cộng Hòa. </p><p>Việc bà Bachmann nổi lên có thể là tin mừng cho khối bảo thủ
cực đoan, nhưng chưa chắc đã là tin vui cho đảng Cộng Hòa. Dân Mỹ nói chung có
khuynh hướng ôn hòa, nên thường không bầu cho các thành phần cực đoan. Vài tờ
báo đã cho chiến thắng của bà Bachmann tại Iowa cũng là chiến thắng của TT Obama vì bà
sẽ là đối thủ yếu nhất của ông. </p><p>Cho đến nay, chẳng ai đoán trước bà Bachmann sẽ là lửa rơm
hay tương lai thực sự của Cộng Hòa. Nhưng chuyện bà nổi bật quả đã là chuyện lạ
rồi. </p><p></p><p>´´´</p><p>Tuần vừa qua, Thống đốc Texas, Rick Perry chính thức ra tranh cử. </p><p>Việc ông Perry nhẩy vào cuộc đã thay đổi cục diện bên phiá
Cộng Hòa, trực tiếp đe dọa tất cả các ứng viên Cộng Hòa, từ bà Bachmann cho đến
ông Romney. Hiện nay, Perry là ngôi sao sáng giá nhất của đảng Cộng Hòa. Ông
Perry có nhiều đặc điểm:</p><p>- Bảo thủ được cả đảng Cộng Hòa cũng như Phong Trào Tea
Party ủng hộ.</p><p>- Nhân vật mới, không dính dáng đến không khí chính trị ô
nhiễm của thủ đô mà dân Mỹ đang quá ngán sợ.</p><p>- Có kinh nghiệm sau mấy chục năm làm dân biểu, bộ trưởng,
thống đốc một trong những tiểu bang lớn nhất Mỹ, đứng đầu khối các tiểu bang
bảo thủ miền Nam.
</p><p>- Trong khi nước Mỹ dưới TT Obama bị khủng hoảng kinh tế
liên tục thì Texas
lại dẫn đầu cả nước về thành quả tạo công ăn việc làm. Trong hai năm qua, Texas đã tạo việc mới
cho hơn 300.000 người. Trong mười người mới tìm được việc làm trong hai năm
qua, thì đã có bốn người ở Texas,
và sáu người ở 49 tiểu bang còn lại.</p><p>- Texas
cũng là tiểu bang không bị khủng hoảng địa ốc, giá nhà vững vàng hơn tất cả các
nơi khác, vì luật cho vay mua nhà gắt gao hơn các nơi khác. </p><p>- Texas
là một trong chín tiểu bang không thu thuế lợi tức cho tiểu bang mà vẫn cân
bằng được ngân sách, cũng là một trong những tiểu bang ít nợ nhất. </p><p>- Trong khi tại Cali, Nữu Ước và các tiểu bang kỹ nghệ vùng
Đại Hồ, thiên hạ đang lũ lượt trao nhà cho ngân hàng để di tản đi nơi khác vì
đời sống đắt đỏ và việc làm khó kiếm, thì Texas đã thu hút cả ngàn người đến
tiểu bang mỗi ngày vì thành quả kinh tế của thống đốc Perry.</p><p>Thống đốc Perry có bất lợi là người kế nhiệm TT Bush. Lại
một ông cao bồi bảo thủ Texas
làm người ta nhớ đến Bush mà có nhiều người bị dị ứng nặng. Nhưng đây không
phải là khó khăn lớn. Ông Perry trước đây là phó thống đốc khi Bush làm thống
đốc, sau đó lên thay thế Bush khi Bush dọn về Tòa Bạch Ốc. Nhưng ông cũng được
tiếng là người… chống Bush từ đầu. Không ai có thể nói ông là Bush tái sanh
hết. Và vừa xuất hiện với mấy câu đả kích chánh sách nới lỏng tiền tệ của Ngân
hàng Dự trữ Liên bang, Perry bị các cận thần cũ của ông Bush mắng cho tơi tả!</p><p>Một bất lợi khác nữa là Texas đứng gần cuối bảng trong trình độ giáo
dục, và đứng gần đầu bảng về số người không có bảo hiểm y tế. Cả hai điểm đã
được giải thích bằng việc có rất nhiều di dân Mễ sống tại Texas. Phe Dân Chủ bảo đảm sẽ chĩa mũi dùi
vào hai vấn đề này.</p><p>Thống đốc Rick Perry sanh năm 1950, xuất thân từ một gia
đình trồng bông vải (cotton) từ nhiều đời trong một tỉnh nhỏ của Texas. Tốt nghiệp về
chăn nuôi gia súc của đại học Texas A&M, chứ không từ một đại học ưu tú
loại Ivy League, sau đó gia nhập không quân, từ chức khi là đại úy. Ông tham
gia chính trường khi đắc cử dân biểu Dân Chủ của tiểu bang năm 1984. Năm 1988,
ông là Chủ Tịch Ủy Ban Vận Động Tranh Cử Tổng Thống của Al Gore tại Texas. Năm 1989, ông bỏ
Dân Chủ, theo Cộng Hoà. Năm 1990 ông đắc cử Ủy Viên Canh Nông – tương đương với
Bộ Trưởng - của Texas.
Năm 1998, ông đắc cử phó thống đốc và năm 2001 ngồi ghế thống đốc thay thế TT
Bush. Ông là thống đốc lâu đời nhất hiện nay của Mỹ, đã đắc cử ba lần, dựa trên
thành quả kinh tế nêu trên.</p><p>Ông Perry trực tiếp đe dọa bà Bachmann vì cũng bảo thủ nhưng
ít cực đoan hơn mà lại có kinh nghiệm thực tế của hành pháp. Ông cũng đe dọa
luôn ông Romney vì tuy trước đây theo Dân Chủ, nhưng có lập trường và thành quả
bảo thủ thật sự trong khi ông Romney vẫn bị nghi ngờ là cấp tiến nằm vùng vì
trước đây là thống đốc tiểu bang cấp tiến nhất Mỹ, lại bị dính chấu vì ban hành
luật bảo hiểm y tế chẳng khác gì kế hoạch của TT Obama.</p><p>Ông Perry chẳng những là ứng viên nguy hiểm nhất cho các ứng
viên Cộng Hòa khác mà cũng là người đe dọa TT Obama mạnh nhất, vì khuôn mặt mới
mẻ của ông và nhất là vì thành quả kinh tế của ông. Đó là điều mà tất cả cử tri
Mỹ chú ý khi nước Mỹ đang đi vào khủng hoảng kinh tế. </p><p>Nhưng mà dù TT Obama là người với khả năng kinh bang tế thế
đáng xét lại thật, nhưng không ai phủ nhận ông là một chính khách có tài vận
động tranh cử - tài ăn nói và hứa hẹn - ít người sánh kịp. Rất nhiều người vẫn
thích ăn bánh vẽ. Không dễ thắng đâu.</p><p>Phản ứng của phe Dân Chủ rất mau lẹ. Giới truyền thông “lề
phải”, từng bị chỉ trích đánh bà Palin quá đáng, bây giờ quay qua bà Bachmann.
Bà được đưa lên mặt báo Newsweek. Nhưng việc làm của Newsweek bị coi là hành
động… đểu cáng. Lựa một bức hình trông rất tệ của bà Bachmann đang trợn mắt,
kèm theo cái tựa lớn “Nữ Hoàng Của Giận Dữ” – The Queen of Rage. Trước đây,
Newsweek cũng cho bà Palin lên trang bìa, mặc quần cụt không thể ngắn hơn.
Thông điệp của Newsweek: bà Palin rất sexy, chân dài đùi đẹp nhưng không có óc.
Bà Bachmann thì điên. Tổ chức cấp tiến cực đoan chuyên tranh đấu cho nữ quyền
National Organization for Women – NOW - cũng phải chỉ trích Newsweek là khinh
thường và kỳ thị chính trị gia phái nữ. </p><p>Paul Begala, cựu cố vấn của TT Clinton thì lên tiếng nhận định ngay ông
Perry là người “không có óc” (lack of brain). Đúng theo chiến thuật sở trường
của phe cấp tiến, luôn luôn mô tả chính khách Cộng Hòa như một đám cà đụt, so
sánh với toàn là đỉnh cao trí tuệ nhân loại bên Dân Chủ. Ký giả Charles Blow
viết trên New York Times, mô tả tất cả các ứng viên Cộng Hòa chỉ là một đám
chẳng biết trời trăng gió cuội gì hết (a crop of Know-Nothings).</p><p>Những đả kích này chỉ mới là màn đầu, loại ăn chơi lót dạ
của mùa tranh cử. </p><p></p><p>´´´</p><p>Hậu thuẫn của TT Obama trên toàn quốc đã xuống mức thấp nhất
từ ngày nhậm chức, 39%, so với 54% chống theo thăm dò Gallup mới nhất. Trong khi hậu thuẫn trong
khối những người có nhiều hy vọng đi bầu chỉ còn là 31%, cũng là thấp kỷ lục.
Có 51% cho rằng TT Obama không xứng đáng được bầu lại. Thăm dò của Gallup giữa tháng Bẩy cho
thấy TT Obama sẽ thua ứng viên Cộng Hòa – bất cứ ứng viên nào – quãng tám điểm
39% - 47%. </p><p>Trong sáu tuần qua, Dow Jones đã rớt xấp xỉ 2.000 điểm, hay
như một độc giả cao minh diễn giải, làm kinh tế Mỹ đã mất gần 2.500 tỷ. Lại một
kỷ lục của tổng thống nhiều kỷ lục. Tuần lễ thứ nhì của Tháng Tám, có thêm
9.000 người mới thất nghiệp. Tỷ lệ dân Mỹ mãn nguyện với cuộc sống hiện nay:
11%. Tỷ lệ ủng hộ chính sách kinh tế: 26%.</p><p>Nguy hiểm nhất cho TT Obama: chỉ có 54% dân da màu cho rằng
chính sách của tổng thống đã phục hồi kinh tế. Năm 2008, ứng viên Obama nhận
được 95% phiếu của dân da màu. Bà dân biểu da màu Dân Chủ Maxine Waters gay gắt
kêu gọi cử tri da màu đặt vấn đề job với TT Obama. Mức thất nghiệp trong khối
da màu là 16%, có khi lên tới 20% tại trung tâm vài thành phố lớn như Detroit,
vượt xa mức trung bình cả nước là 9%.</p><p>Có người lý luận TT Obama bị chống đối - trong đó có cả kẻ
viết này – vì là… da đen. Với cách lý luận này thì phê phán một tổng thống da
đen là đồng nghĩa với kỳ thị! Khi nữ dân biểu da đen Maxine Walters của đảng
Dân Chủ tại Los Angeles
than phiền về TT Obama, bà có là người kỳ thị không" </p><p>Thật ra, thiên hạ ai cũng vậy, chỉ có một ưu tư là đời sống
của mình, job, nhà cửa, tiền chợ, tương lai con cái. Chỉ cần tổng thống nào bảo
đảm được những chuyện này là chúng ta hoan hô. Có là gốc Phi Châu, Ấn Độ, hay
Căm-Pu-Chia, cao bồi Texas hay lính thợ Ohio, đàn ông, đàn bà, hay nửa nạc nửa
mỡ, cao hay lùn, gầy hay mập, thì ăn thua gì"</p><p>Một tuần trước đây, khi đi vận động tại Iowa, TT Obama tuyên bố “Chúng ta đã phục
hồi kinh tế, nhưng trong sáu tháng qua gặp hàng loạt chuyện xui xẻo ” (We had
reversed the recession,… but over the last six months we've had a run of bad
luck).</p><p>Tổng thống là người lãnh đạo cả nước, quyết định mọi chuyện,
mà bây giờ tình hình rối tung, tổng thống hết chỗ đổ thừa, bây giờ đổ thừa là
tại xui" Chuyện lãnh đạo quốc gia là chuyện hên xui may rủi" Thế thì không hiểu
TT Obama có nghĩ là TT Bush trước đây cũng bị “bad luck” khi gặp vụ 9/11, Katrina,
khủng hoảng gia cư, khủng hoảng ngân hàng,… không" </p><p>Kẻ viết này, hay các anh thầy bàn nhăm nhi ly cà phê, có thể
bàn chuyện số mạng, chuyện hên xui, chứ người lãnh đạo cả nước – có thể nói cả
thế giới - làm sao có thể viện cớ hên xui được" Như vậy kẻ viết này cũng làm
tổng thống được, ăn thua là hên xui thôi.</p><p>TT Obama hiện đang nghỉ hè tại bãi biển đắt nhất thế giới là
Martha's Vineyard, trên một hòn đảo của triệu phú, tài tử Hollywood, và tài
phiệt Wall Street, đều là những bạn thân của tổng thống của dân nghèo. Hai ông
bà đi hai chuyến máy bay khác nhau, ở trong biệt thự 55.000 đô một tuần, chưa
kể chi phí cho cả trăm tùy tùng, do chúng ta hồ hởi đài thọ. Vấn đề không phải
là tổng thống không được nghỉ ngơi, mà là thời điểm và địa điểm. Bây giờ, trong
lúc dầu sôi lửa bỏng với hơn 15 triệu người xếp hàng xin tiền thất nghiệp và
tiền foodstamps, có phải là lúc đi nghỉ khỏe tại bãi biển của tụi tư bản bóc
lột không" </p><p>Xin quý độc giả đừng hiểu lầm, kẻ viết này cho rằng như vậy
cũng tốt thôi. Nếu TT Obama đi nghỉ hè luôn, đừng trở về Nhà Trắng nữa thì biết
đâu còn tốt hơn nữa" </p><p>Nói chuyện nghiêm chỉnh hơn, Cộng Hòa vẫn còn mò đường đi. </p><p>Dân Mỹ thường cho tổng thống hai nhiệm kỳ để có thời giờ
“làm chuyện lớn”, trừ phi quá bết bát như Carter thôi. Có thể dân Mỹ sẽ cho TT
Obama thêm thời giờ vì đã thấy rõ ông không phải là Đấng Tiên Tri với phép màu
vạn năng nữa. Sẽ cần thời gian để loay hoay tìm cách chữa bệnh. Giao việc chữa
bệnh cho Cộng Hòa thì còn phải chờ coi toa thuốc của mấy ông bà này như thế
nào. Cho đến giờ, toa thuốc chưa thấy đâu. Nếu ông bà Cộng Hòa nào đưa ra được
toa thuốc hữu hiệu, trong khi tình trạng kinh tế ngày càng lún bùn, thất nghiệp
vẫn 9%, giá xăng leo lên năm đô, cuộc diện sẽ thay đổi và cuộc chạy đua năm tới
sẽ hấp dẫn hơn nhiều. Cái ghế của TT Obama có nhiều hy vọng sẽ còn ba chân.
(21/8/11) </p><p>Quý độc giả có thể liên lạc với tác giả để góp ý qua email:
Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a175940/cong-hoa-va-nhung-ngoi-sao-moi

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/