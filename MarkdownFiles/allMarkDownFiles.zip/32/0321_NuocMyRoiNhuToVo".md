# Nước Mỹ Rối Như Tơ Vò"

04/10/2011

<p>Nước
Mỹ Rối Như Tơ Vò"</p><p>Vũ
Linh</p><p></p><p>...Bạch
Ốc lại hết sức hỗn loạn, với các buổi họp chỉ là những cuộc cãi vã không ngừng...</p><p></p><p>Tháng
Mười Một năm 2008, nước Mỹ làm một cuộc cách mạng chấn động cả thế giới. Lần đầu
tiên, một chính khách da đen, trẻ tuổi, kinh nghiệm không có tý gì, được bầu
làm tổng thống, với tỷ lệ đắc cử cũng như số phiếu cao nhất trong lịch sử Mỹ.
Cao nhất là vì dân số đông nhất. Dù sao, đây cũng là một chuyện mà cựu TT
Clinton ám chỉ là thần tiên -fairy tale- chỉ có thể xẩy ra ở cái đất nước của
hy vọng này.</p><p>Cả thế giới bang hoàng khâm phục sự cởi mở và
tiến bộ của nước Mỹ và ngưỡng mộ tân tổng thống có biệt tài thu hút lòng người
qua những hứa hẹn trời biển. Ngoại trừ một số nhỏ những người đa nghi, bị tố là
ngoan cố hay thậm chíkỳ thị.</p><p>Tháng
Sáu năm đó, sau khi hạ được đối thủ cuối cùng là bà Hillary Clinton, ứng viên
Barack Obama lớn tiếng tuyên bố "đây là lúc mà thủy triều đang lên sẽ bắt đầu hạ
xuống, và trái đất bắt đầu hàn gắn" (this was the moment when the rise of the
oceans began to slow and our planet began to healTác giả xin cáo lỗi cùng quý
độc giả vì không có khả năng dịch hết ý nghĩa câu nói bất hủ này được). Câu
tuyên bố cực kỳ dao to búa lớn, mặc dù chẳng ai hiểu ý ông ứng viên muốn nói
gì. </p><p>Nước
thủy triều đang dâng sẽ hạ xuống nghĩa là gì" Muốn ám chỉ chuyện gì" Dù không
hiểu rõ lắm, nhưng thiên hạ cũng mường tượng được ý định của ông chính khách trẻ
tuổi, nhiều tham vọng, muốn thay đổi cả nước thủy triều và gánh trên vai cả thế
giới mặc dù cả đời chưa quản lý một tổ chức hay công ty nào, ngoài văn phòng thượng
nghị sĩ với một thư ký và hai ba trợ lý.</p><p>Trong
suốt hai năm tranh cử, cho đến lúc tuyên thệ nhậm chức, ông Obama đã làm cả thế
giới ngây ngất vì những lời hứa hẹn vĩ đại nhất, đẹp đẽ nhất. Một nước Mỹ đoàn
kết không còn xâu xé nội bộ, hòa đồng trong cộng đồng thế giới, hoà bình trong
thịnh vượng, nhân bản và độ lượng, vượt qua được mọi khó khăn từ chiến tranh đến
kinh tế,Không có gì không thể làm được. "Yes We Can!" Tất cả những
mỹ từ mà những người giàu tưởng tượng nhất có thể nghĩ ra được đều đã mang ra tặng
cho đám cử tri với những đôi mắt ngơ ngác như nai vàng.</p><p>Gần
ba năm sau, chỉ cần liếc qua những tin tức báo chí hàng ngày là ta có thể thấy
một bức tranh khác xa những lời hứa hẹn.</p><p>Kinh
tế vẫn chưa ổn định chứ đừng nói tới hồi phục, thất nghiệp kỷ lục, thị trường
chứng khoán lên xuống mấy trăm điểm một ngày, Nhà Nước nợ cả chục ngàn tỷ, ngân
sách thâm thủng cũng hàng chục ngàn tỷ. </p><p>Fox
News đưa ra một ví dụ thật không thể rõ ràng hơn do nhóm Tea Party tính. </p><p>Nếu
nước Mỹ này là một anh công chức đi làm với mức lương khoảng 21.000 đô một năm,
thì anh ta đang xài 38.000, trong khi còn mắc nợ thẻ tín dụng gần 143.000 đô.
Và TT Obama vừa ra kế hoạch hết sức "hoành tráng" cho anh ta cắt bớt 385 đô tiền
nợ thẻ tín dụng này!</p><p>Chiến
tranh Trung Đông càng ngày nhiều tử vong chứ không xuống cường độ. Nhà Trắng đang
cuống cuồng lo chuyện tại Libya, hai chục ngàn hỏa tiễn tầm nhiệt nhỏ viện trợ
cho lực lượng chống Kaddafi đãbiến mất, với nhiều rủi ro là rơi vào tay các
nhóm khủng bố Hồi giáo quá khích. Chỉ cần một hỏa tiễn là có thể dễ dàng bắn rớt
một chiếc máy bay lớn chở hành khách. Hai chục ngàn hỏa tiễn" Chưa nghe ai giải
thích tại sao lại có nhu cầu viện trợ hai chục ngàn hỏa tiễn tầm nhiệt hết,
trong khi cả lực lượng không quân của Khaddafi chỉ vỏn vẹn vài chục chiếc máy
bay đã bị tiêu hủy ngay từ ngày đầu Mỹ bắt đầu thả bom Libya.</p><p>Đối
nội, ông tổng thống của đại đoàn kết dân tộc bây giờ đang chủ trì một nội các
chỉ giỏi cãi nhau (sẽ bàn thêm phần dưới), chỉ lo đánh giặc "khủng bố" Tea
Party, đã thay thế những lời kêu gọi đoàn kết bằng những hô hào không lấy gì
làm đoàn kết, kiểu "bầu cho đảng đối lập Cộng Hòa là nước Mỹ sẽ bị bại liệt
-crippled- ngay". </p><p>"Yes
We Can" bây giờ đã trở thành "No We Can't". Tất cả chung quanh là thất bại, chẳng
có gì có thể gọi là thành công được. Đến độ dân chúng đã mất niềm tin vào Nhà Nước
ở những mức kỷ lục chưa từng thấy. Cơ quan thăm dò dư luận Gallup mới đây đã
công bố hàng loạt kết quả thăm dò. Trong 10 người dân thì đã có: </p><p>-
Tám người (81%) bất mãn với cách "trị quốc" của TT Obama, và hơn tám người
(84%) bất tín nhiệm quốc hội.</p><p>-
Tám người này cũng cho rằng nước Mỹ đang đi sai hướng.</p><p>-
Sáu người không tin Nhà Nước có khả năng giải quyết những khó khăn nội bộ.</p><p>-
Năm người cho rằng guồng máy chính quyền đã quá lớn, trực tiếp đe dọa tự do và
quyền lợi của người dân.</p><p>-
Sáu người thuộc đảng Dân Chủ bất mãn.</p><p>-
Chín người thuộc đảng Cộng Hòa bất mãn.</p><p>-
Chính sách cấp tiến -liberal- của TT Obama đã làm thiên hạ sợ đến độ chỉ còn có
một người (11%) dám nhận mình là thành phần cấp tiến, năm người tự cho là bảo
thủ, bốn người tự nhận là độc lập.</p><p>-
Mức ủng hộ TT Obama xuống thấp đến mức kỷ lục, dưới bốn người.</p><p>Nói
cách khác, dân chúng bất mãn và bất tín nhiệm cả hành pháp lẫn lập pháp, cũng
như guồng máy chính quyền, bất kể thuộc đảng nào.</p><p>Nhìn
vào những con số này, người ta không thể không lo ngại cho tương lai nước Mỹ.
Dù muốn dù không, guồng máy chính quyền cũng là bộ phận cực kỳ cần thiết cho việc
điều hành hay quản lý một nước lớn và phức tạp như nước Mỹ này. Mức tín nhiệm
thấp như vậy sẽ làm tê liệt bộ máy công quyền đó, nếu chưa muốn nói đến chuyện
tạo ra xung khắc nội bộ càng ngày càng trầm trọng sẽ đưa đến tê liệt cả guồng
máy.</p><p>Vì
sao ra nông nỗi này"</p><p>Nước
Mỹ đến những năm 2007-2008 đi vào giai đoạn khủng hoảng nặng. Khủng hoảng kinh
tế tài chánh lớn nhất nhì của thế kỷ, nhưng cũng kèm theo khủng hoảng quân sự với
hai cuộc chiến dai dẳng tại Trung Đông, khủng hoảng chính trị khi Nhà Trắng
trong tay Cộng Hòa và quốc hội trong tay Dân Chủ để hai bên kình chống nhau khiến
cả hành pháp lẫn lập pháp đều tê liệt, và khủng hoảng niềm tin khi đại đa số
dân Mỹ bất mãn với những thất bại của TT Bush. Không cần biết bao nhiêu phần
trách nhiệm thật sự là của Bush, bao nhiêu là sai lầm tích lũy từ nhiều đời tổng
thống, bao nhiêu là của tình hình thế giới, chỉ biết con tàu Cờ Hoa đã đi vào
vùng biển động cấp bốn hay cấp năm gì đó.</p><p>Trong
tình trạng nguy kịch đó, dân Mỹ nhắm mắt đặt niềm tin vào một "thuyền trưởng" ăn
nói giỏi, nhưng chưa từng chèo xuồng chứ đừng nói đến chuyện lái tàu.</p><p>Đối
với những người tin tưởng vào ứng viên Obama, việc ông này không có chút kinh
nghiệm chính trị, kinh tế, ngoại giao, quân sự, xã hội, là chuyện không có gì
đáng thắc mắc. Lý luận của họ là tổng thống Mỹ không bao giờ là người đơn thân độc
mã gánh vác chuyện cả nước. Chung quanh ông sẽ có cả trăm cả ngàn chuyên gia, cố
vấn tuyết đỉnh, giải Nobel hàng rổ. Họ quên mất giữa cái rừng thầy dùi đó sẽ có
cả trăm ý kíến khác biệt, và người cuối cùng phải lấy quyết định chính là tổng
thống. Nếu tổng thống không biết gì thì làm sao lấy quyết định, làm sao lựa chọn
giải pháp thích ứng trong cái rừng ý kiến đó"</p><p>Cái
khó khăn này là một sự thật trong chính quyền Obama. Một sự thật được một tác
giả vạch trần ra trong một cuốn sách mới phát hành, đang gây chấn động chính trường
Mỹ.</p><p>Nhà
báo đã từng đoạt giải Pullitzer (tương đương với giải Nobel hay giải Oscar
trong ngành báo chí) Ron Suskind vừa mới phát hành cuốn sách "Confidence Men:
Wall Street, Washington and the Education of a President" viết về chuyện chính
quyền Obama đối phó với khủng hoảng tài chánh năm 2009. Để làm sáng tỏ mọi chuyện
trước khi đi xa hơn, ông Suskind trước đây đã viết hai cuốn sách về chính quyền
của cựu TT Bush (The Price of Loyalty và The One Percent Doctrine), đã được
truyền thông dòng chính nức nở ca tụng vì đã chỉ trích, chê bai Bush về đủ chuyện.
Lần này, ông Suskind bị chính giới truyền thông này đả kích kịch liệt, từ viết
dở đến dữ liệu sai lầm, thành kiến, chỉ vì ông đãdám chê bai Obama. </p><p>Ông
Suskind nhận định TT Obama ngay từ cuối năm 2008, trực diện với cuộc khủng hoảng
tài chánh của thế kỷ, đã ý thức ngay là mình chưa sẵn sàng làm tổng thống (The
President realized he was not ready to serve as president). Người ta còn nhớ
trong thời gian đó, ứng viên và sau đó tổng thống tân cử Obama gần như không
tuyên bố gì, không có ý kiến gì về cuộc khủng hoảng. Sự im lặng của ông phản
ánh sự bối rối, chưa hiểu rõ vấn đề, chưa biết phải làm gì, nhưng lại được truyền
thông phe ta lúc đó ca tụng là "bình tĩnh, chín chắn, không phát ngôn bừa bãi,
không hành động phiêu lưu". Do đó TT Obama phải lệ thuộc rất nhiều vào các cố vấn
và phụ tá.</p><p>Thế
nhưng, Tòa Bạch Ốc lại hết sức hỗn loạn, với các buổi họp chỉ là những cuộc cãi
vã không ngừng, đến độ cố vấn kinh tế Larry Summers phải than phiền "không có
người trưởng thành nào trong phòng (There's no adult in the room). Giữa những ý
kiến trái ngược, TT Obama lấy quyết định tùy áp lực các phe nhóm, tùy thăm dò dư
luận. Có những quyết định mà các phụ tá thấy không áp dụng được, đã lờ luôn. Điển
hình là Bộ Trưởng Tài Chánh Tim Geithner đã lờ đi một số chỉ thị của tổng thống.</p><p>Một
đại diện của nghiệp đoàn United Steel Workers tham dự một buổi họp đã nhận định
trong cả phòng họp chưa có một người nào đã có dịp ngồi uống bia với một người
lao động thật sự. Ý muốn nói đây toàn là các trí thức khoa bảng chẳng biết gì về
thực trạng cuộc sống.</p><p>Ông
James Carville, một chiến lược gia Dân Chủ, nguyên quân sư của TT Clinton, đã đề
nghị TT Obama cho về vườn vài phụ tá cao cấp đã xúi dại tổng thống. Thật ra, TT
Obama đã thay đổi nhân sự rất nhiều rồi. Toàn bộ ê-kíp năm cố vấn hàng đầu về
kinh tế tài chánh đã bị thay đổi. Phụ tá số một Rahm Emanuel đã về làm thị trưởng
Chicago. Quân sư Axelrod đã về lo chuyện vận động tranh cử năm tới. Phát ngôn
viên Gibbs cũng ra khỏi chính quyền. Giám Đốc Ngân Sách đã đổi. Bộ trưởng Quốc
Phòng, Giám Đốc CIA, cũng đã được thay thế. </p><p>Trước
viễn ảnh lờ mờ với đảng Dân Chủ và đương kim tổng thống, có lẽ dân Mỹ sẽ phải
chạy qua phiá Cộng Hòa hết, coi như tìm cái phao để khỏi chết chìm" Nhưng nhìn
lại thì thấy cái phao này cũng đầylỗ thủng!</p><p>Nhìn
vào khối ứng viên tổng thống của đảng Cộng Hòa, ta thấy một hình ảnh bát nháo của
một tổ chứckhông định hướng. Giữa một tá ứng viên và chuẩn ứng viên, ta thấy
hai ngôi sao nổi bật hơn cả. Đó là đương kim Thống Đốc Texas Rick Perry, và cựu
Thống Đốc Massachusetts Mitt Romney. Cả hai ông đều không phải là tay mơ, mà đều
là những thống đốc dầy mình kinh nghiệm hành pháp, và đã thành công lớn. Có thể
yên tâm phần nào trong vấn đề kinh nghiệm. </p><p>Nhưng
cái khúc mắc lớn là hai ông thống đốc này lại là hiện thân của hai khuynh hướng
và triết lý chính trị hoàn toàn đối nghịch. Một ông là bảo thủ, một ông là cấp
tiến tuy ôn hòa. Khác biệt gần như ban ngày ban đêm. Đưa đến câu hỏi hiển
nhiên: thế thì đảng Cộng Hòa muốn gì" Đi theo con đường cấp tiến ôn hòa hay bảo
thủ"</p><p>Chưa
hết. Ngôi sao bảo thủ Perry chưa nổi lên thì dường như đã bắt đầu lặn. Hai lần
xuất hiện trên truyền hình tranh luận cùng với các đồng chí, ông Perry đều có vẻ
như thất bại, trả lời luống cuống, mâu thuẫn, nói bậy rồi sau đó phải xin lỗi.
Kết quả, cuộc bầu cử vòng loại của bầu cử sơ bộ tại Florida, ông Perry thua đậm.
Kẻ chiến thắng là ông Herman Cain, một doanh gia da đen với khẩu khí còn hơn cả
TT Obama, và đặc biệt là còn bảo thủ hơn cả ông Perry. </p><p>Chiến
thắng của ông Cain chỉ làm nổi bật thêm mâu thuẫn hay đúng hơn, bối rối nội bộ
trong phe Cộng Hòa. Các chuyên gia chính trị gãi đầu gãi tai. Ông Cain là một
nhà kinh doanh đã thành công lớn -từng làm Tổng Giám Đốc chuỗi nhà hàng pizza
Godfather với cả ngàn tiệm rải rác khắp nước Mỹ- nhưng lại là tay mơ chính trị,
chưa bao giờ dính dáng xa gần gì đến chính trị. Lại một chính khách tay mơ chỉ
thắng nhờ múa võ miệng" Lạ lùng hơn nữa, ông này lại đã trở thành thần tượng mới
của Phong Trào Tea Party mà truyền thông phe ta đã khẳng định là phong trào của
dân da trắng kỳ thị da đen.Ông Cain mà đắc
cử trong khối Cộng Hòa thì ta sẽ chứng kiến cảnh hai ông chính khách da đen
tranh cử tổng thống trong một nước mà dân da đen chỉ chiếm có hơn 10% dân số! </p><p>Chuyện
này là chuyện hạ hồi phân giải. </p><p>Chuyện
bây giờ là sự lựa chọn trước mắt của dân Mỹ: một bên là một chính quyền đã thất
bại, và một bên là cử tri còn đang bối rối trong khi các ứng viên thì còn đang đấu
đá với nhau, chưa biết ai sẽ đại diện và đường hướng chính sách sẽ ra sao, chỉ
biết là ông ứng viên nào cũng đầy câu hỏi, chưa thuyết phục được ai hết. Một lựa
chọn không hấp dẫn tý nào. Tin mừng là còn 14 tháng nữa mới đi bầu. Trong lịch
chính trị Mỹ thời gian đó dài như 14 năm. Giờ này cách đây bốn năm (2007), thăm
dò dư luận cho thấy ông Obama còn thua bà Hillary tới 33 điểm. (2-10-11)</p><p>Lưu
ý: Một số độc giả đã hỏi tác giả tuần rồi sao không thấy bài viết trên Việt Báo
trên mạng. Thật ra bài viết tuần rồi "Vẫn Là Tăng Thuế" vì sơ sót kỹ thuật đã được
đăng trong mục Tin Cộng Đồng thay vì trong mục Bình Luận.</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a177838/nuoc-my-roi-nhu-to-vo

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/