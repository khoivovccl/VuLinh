# 'Chính Sách Hồi Giáo' Thất Bại?

06/03/2012

<p>...Hồi
giáo Ả Rậpquá khích là do việc lấy đất Ả
Rập biến thành nước Do Thái...</p><p>Cách
đây một thập niên, quân khủng bố Al Qaeda đánh xập hai tòa cao ốc World Trade
Center tại Nữu Ước và Ngũ Giác Đài ở Hoa Thịnh Đốn. Các phong trào Hồi Giáo quá
khích lúc đó mới thực sự trở thành một mối đe dọa lớn cho nước Mỹ. Dân Mỹ lần đầu
tiên mới nhìn thấy nguy cơ này.</p><p>Thật
ra, các cuộc tấn công của quân khủng bố Hồi Giáo quá khích không có gì mới lạ
vì đã xẩy ra thường xuyên từ thập niên 60-70 rồi. Thập niên đó là thập niên của
những vụ đánh cướp máy bay, bắt cóc con tin để trao đổi vài chuyện như thả tù
khủng bố đang bị giam, hay phổ biến tuyên cáo chính trị, hay chuộc tiền để các
tổ chức khủng bố có tiền hoạt động. Những cuộc tấn công này phần lớn xẩy ra bên
Âu Châu, hay trong vùng biển Địa Trung Hải, và thường nhắm thẳng vào dân Do
Thái.</p><p>Đối
với dân Mỹ, đó là những tin gây kinh hoàng, nhưng dù sao thì cũng chỉ là những
tin họ thấy trên truyền hình và báo chí. Cũng không khác gì chuyện ta đọc tin động
đất ở Indonesia chết mấy trăm ngàn người, hay tin sóng thần tại Nhật chôn vùi cả
chục thành phố. Chuyện kinh hoàng thật, nhưng vẫn là chuyện xa vời, vừa ăn cơm
tối vừa coi hình trên màn ảnh. Hết bữa cơm, hết tin tức, đến giờ coi phim diễu
sitcom, rồi đi ngủ, mai dậy sớm đi làm như thường lệ.</p><p>Cuộc
tấn công 9/11 đã thay đổi tận gốc lối suy nghĩ và cách nhìn của dân Mỹ về vấn đề
khủng bố nói riêng và Hồi giáo nói chung. Bây giờ không còn là chuyện cảm tử Hồi
giáo đánh nhau với mật vụ Mossad của Do Thái nữa, mà đã thành vấn đề của Mỹ.
Quan trọng hơn nữa, đây cũng không phải là chiến tranh Việt Nam xẩy ra bên kia địa
cầu, mà là chuyện xẩy ra ngay trên đất Mỹ. Giặc đã vào tới trong nhà rồi.</p><p>TT
Bush, vừa nhậm chức không bao lâu, và cũng như tất cả các vị tổng thống khác, đang
tối mặt lo lợi dụng tuần trăng mật nhằm đẩy qua quốc hội những luật để đời, đặc
biệt là luật cải cách giáo dục, trong khi chưa có thời giờ đào sâu mối đe dọa của
quân khủng bố. Dĩ nhiên là TT Bush vẫn còn nhớ là năm 1993, quân khủng bố Hồi
giáo quá khích đã đặt bom tính phá hai tòa cao ốc World Trade Center tại Nữu Ước,
nhưng cũng chỉ là một trò tấn công tài tử, chưa nghiêm trọng đến độ phải tập
trung mọi nỗ lực của cả tân nội các vào vấn đề này. Cải tổ hệ thống giáo dục và
cắt giảm thuế để phục hồi kinh tế sau cơn khủng hoảng điện toán dot.com vẫn là ưu
tiên hàng đầu. </p><p>Bây
giờ, nhiều người không ưa Bush vẫn thường chỉ trích TT Bush đã bất tài để xẩy
ra cuộc tấn công 9/11.</p><p>Sự thật thì đối phó với khủng bố lúc đó chưa
phải là vấn đề sinh tử. Hơn thế nữa, cho dù có là vấn đề sinh tử thì cũng chẳng
ai có thể biết trước được Al Qaeda sẽ cướp máy bay dân sự đâm thẳng vào các cao
ốc dân sự như vậy. Tổ chức an ninh tình báo của Mỹ chưa đủ khả năng biết trước được
những chuyện như vậy. Phải đợi đến sau khi xẩy ra vụ 9/11 thì người ta mới có
thể nghĩ đến các cách đề phòng hữu hiệu hơn. Và cũng phải nói thẳng là phải có
vụ 9/11 thì quốc hội mới chịu chi bạc ngàn tỷ để cải cách hệ thống an ninh, và
dân Mỹ mới chấp nhận giới hạn phần nào tự do cá nhân của mình. Hãy thử tưởng tượng
nếu không có vụ 9/11, thì làm sao có lý do đòi hỏi dân Mỹ phải cởi giầy, phải
chịu bị rờ mò khắp người trước khi lên máy bay?</p><p>Cuộc
tấn công đó cũng là dịp để nước Mỹ nhìn kỹ lại vấn đề Hồi giáo, và quyết định lại
chính sách đối ngoại đối với khối này. TT Bush trong những ngày đầu mò mẫm đã
khôn khéo tìm mọi cách tách rời các nhóm khủng bố ra khỏi khối Hồi giáo, một mặt
ra những quyết định chống khủng bố cực kỳ mạnh tay, mặt khác vuốt ve, ca tụng
khối Hồi giáo, mời các giáo sĩ Hồi giáo tham gia ngồi ghế hàng đầu trong các dịp
quốc lễ, để chứng minh nước Mỹ tôn trọng tôn giáo này.</p><p>TT
Bush cho ra đời một chính sách đối ngoại mới đối với khối Hồi giáo và Ả Rập nói
chung. Ông kêu gọi dân chủ và tự do cho khối dân này, như là liều thuốc dài hạn
chữa trị được căn bệnh khủng bố phát xuất từ các bất công xã hội, nghèo đói, bệnh
hoạn, thiếu tự do, không có dân chủ. Ông gia tăng mạnh mẽ viện trợ quân sự,
kinh tế, cũng như y tế và văn hoá cho các quốc gia trong vùng Trung Đông, đặc
biệt là Ả Rập Saoud và Ai Cập. Hàng trăm tỷ viện trợ mỗi năm được đổ vào các nước
được gọi là tương đối ôn hòa, có cơ hội cải cách trong khối Hồi giáo.</p><p>Trong
lý luận của TT Bush, giúp cho các nước trong khối này có tự do, dân chủ, kinh tế
phồn thịnh, ... thì các phong trào khủng bố chống Mỹ sẽ tự biến, không còn lý
do tồn tại nữa. Đó chính là phương thức trị bệnh khủng bố từ căn gốc, sẽ khiến
cho khối Hồi giáo thân thiện với Mỹ.</p><p>Riêng
đối với một vài nước ... hết thuốc chữa, thì chỉ có cách là nước Mỹ can thiệp bằng
vũ lực để thay đổi chế độ, nếu có thể. Đó là trường hợp của Afghanistan, là đất
của nhóm quá khích Taliban đã dung dưỡng Al Qaeda, và Iraq, là giang sơn của
Saddam Hussein. Cả hai chế độ này chẳng những không có một mảy mai hy vọng cải
tổ trong diễn biến hòa bình được, mà còn là công khai tuyên cáo chính sách chống
Mỹ bằng bạo lực đến cùng. Chỉ còn một cách là dùng vũ lực thay đổi các chế độ
Taliban và Saddam bằng những chế độ ôn hoà và thân thiện với Mỹ hơn.</p><p>Chính
sách của TT Bush chỉ mới là bước đầu trong một tiến trình thật dài.</p><p>TT
Obama lên kế nhiệm, và mặc dù hò hét chống đối TT Bush trên đủ mọi khía cạnh
khi còn tranh cử, nhưng khi nắm quyền thì đã lẳng lặng tiếp tục chính sách của
TT Bush.</p><p>Ở
đây, chúng ta cần thẳng thắn nhìn nhận trên phương diện kinh tế, xã hội, TT
Obama và TT Bush như là mặt trăng mặt trời, không bao giờ giáp mặt nhau được.
Nhưng trên phương diện đối ngoại, TT Obama hiển nhiên chỉ là người tiếp tục hướng
đi của TT Bush, tuy có phần đi mạnh hơn và xa hơn.</p><p>TT
Obama tiếp tục chính sách tách rời các nhóm khủng bố ra khỏi khối đa số Hồi
giáo, tiếp tục ve vãn tôn giáo này, nhưng đi xa hơn nhiều, bằng cách đi ngay Ai
Cập và Thổ Nhĩ Kỳ trong những tháng đầu vừa chấp chánh, để vuốt ve và xin lỗi
khối Hồi giáo (bài diễn văn tại Cairo và Ankarra).Mặt khác vẫn tiếp tục truy lùng Al Qaeda, tiếp
tục cuộc chiến tại Iraq, và đôn quân tại Afghanistan. Trại tù Guantanamo vẫn
còn đó. </p><p>Ở
đây, cũng cần nói thêm có nhiều người cho rằng chính sách của TT Obama khác
chính sách của TT Bush ở hai điểm: ông quyết tâm giết Bin Laden và rút quân khỏi
Iraq. Thật ra, nói như vậy có vẻ như... viết lại lịch sử, theo kiểu thành công
thì nhận vơ, thất bại thì đổ thừa.</p><p>Trong
vụ Bin Laden, tên trùm khủng bố bị theo dõi và giết bởi một lực lượng đặc nhiệm
do TT Bush thành lập. Công của TT Obama là... không thay đổi gì hết, vẫn để
nguyên lực lượng đó tại chỗ với nhiệm vụ cũ, và cái may mắn là lực lượng đó tìm
ra được tung tích của Bin Laden dưới thời Obama. Không có chuyện TT Bush thì cố
tình tha cho Bin Laden, trong khi TT Obama đích thân chui vào hang hóc Pakistan
để tìm rồi giết Bin Laden.</p><p>Việc
rút quân ra khỏi Iraq cũng vậy. Chương trình rút quân đã theo đúng lịch trình được
thoả thuận giữa TT Bush và Thủ Tướng Maliki từ trước khi TT Obama nhậm chức.
Công trạng của TT Obama nếu có, chỉ là tôn trọng hiệp ước giữa Bush và Maliki,
và đã đi xa hơn Bush là rút hết quân Mỹ về vì không thoả thuận được với Maliki
về con số lính duy trì lại tại Iraq.</p><p>Nói
tóm lại, chính sách đối phó với nạn khủng bố Hồi giáo quá khích của TT Obama chỉ
là một tiếp nối của chính sách của TT Bush, có khác chăng chỉ là khác ở tầm mức
ve vãn thôi.</p><p>Giờ
này đây, một thập niên sau khi chính sách này được áp dụng, có lẽ cũng là lúc
nhận định lại xem chính sách đó thành công hay thất bại. Dưới cái nhìn hết sức
chủ quan của kẻ viết này, dường như chính sách này đã hoàn toàn thất bại. </p><p>Từ
Ai Cập đến Tunisia, từ Libya đến Syria, người dân nổi loạn chống các chế đố độc
tài, nhưng chẳng có nơi nào chế độ mới lại tỏ vẻ thân thiện hơn với Mỹ. Iraq và
Afghanistan cũng không khác gì. Thất bại vì đã không nhận định đúng nguyên
nhân, từ đó đã không tìm ra được đúng thuốc. Bác sĩ chẩn bệnh không đúng thì dĩ
nhiên không thể cho đúng thuốc được.</p><p>Phải
nói cho ngay, vấn đề khủng bố của Hồi giáo quá khích đã được nhận định dưới nhiều
khía cạnh, từ văn hoá đến tôn giáo. Các học giả hay chiến lược gia đã viết sách
hoặc trường thiên đại luận về mối xung khắc giữa văn minh Ả Rập và văn minh Âu
Mỹ. Có người thì luận về khác biệt tôn giáo. Đó là những cái nhìn cực kỳ phức tạp
trong khi vấn đề giản dị hơn nhiều.</p><p>Tất
nhiên là đã có những khác biệt về tôn giáo và văn hoá như các tác giả đã nhận định.
Nhưng những khác biệt đó đã có từ cả ngàn năm, và ngoại trừ một thời đại dưới
thời trung cổ khi Âu Châu phát động cuộc "Thập tự chinh" mang màu sắc
thánh chiến -crusade - tại Trung Đông, thì tương đối những khác biệt đó vẫn được
hạn chế trong một giới hạn nào đó, chưa đến độ nổ tung ra thành chiến tranh đẫm
máu. </p><p>Dù
sao thì nhìn vào vấn đề như vậy có lẽ là đã đi quá xa vào quá khứ. Mâu thuẫn giữa
Hồi giáo/Ả Rập và Công giáo/Tây Phương ngày nay thực sự là hậu quả của một chuỗi
sự việc trong lịch sử. Thứ nhất, các cường quốc Âu châu đã chinh phục nhiều nước
Hồi giáo làm thuộc địa từ thế kỷ 19. </p><p>Rồi,
thứ hai, sau khi Đế quốc Hồi giáo Ottoman tan rã năm 1919 thì các nước Tây phương
(Âu châu và cả Hoa Kỳ, khi ấy là cường quốc mới nổi lên) đã chia lại lãnh thổ của
đế quốc này thành nhiều quốc gia và sắc tộc sống xen kẽ với nhau nên cũng gây
ra nhiều mâu thuẫn nan giải giữa hai hệ phái Sunni và Shia cùng bốn sắc tộc là
Thổ, Ba Tư, Á Rập và Kurd, hoặc giữa các nước Syria, Lebanon, Iraq, Iran,
v.v... Nguyên nhân thứ hai này, kinh tế gia Nguyễn Xuân Nghĩa có nói đến nhiều
lần nên người viết xin ghi lại ở đây.</p><p>Sau
cùng và kết tinh tất cả ẩn ức và khó chịu, các nước Âu châu còn lấy một phần đất
của dân Ả Rập đang sinh sống để thành lập một nước mới là nước Do Thái vào năm
1948, sau Đệ Nhị Thế Chiến. Các nước Âu châu đã để sáu triệu dân Do Thái bị Đức
quốc xã tàn sát nên cũng muốn chuộc tội và... gây tội khác. Vì quyết định này
ban hành mà chẳng ai thèm hỏi ý kiến các nước Ả Rập trong vùng, vốn dĩ cứ bị
coi như thuộc địa cũ. </p><p>Đây
là vùng thánh địa của ba tôn giáo lớn là công giáo, hồi giáo, và do thái giáo,
tự nhiên lại biến thành lãnh thổ của một nước mới tên là Israel. Dĩ nhiên vùng đất
này trước đây đã là đất của dân Do Thái, nhưng đó là chuyện ngàn năm trước. Và
trong giai đoạn đầu, Hoa Kỳ thật ra có ác cảm với chính quyền Israel vì dân Do
Thái khi đó lại thiên về Liên bang Xô viết - ngay thời Chiến tranh lạnh. Sau
này Mỹ mới đổi lập trường khi chính các nước Á Rập Hồi giáo lại ngả về phe Xô
viết. Đó là chuyện rắc rối hơn trong quan hệ giữa Hoa Kỳ và khối Á Rập.</p><p>Nhưng
trở lại chuyện Israel, với dân Á Rập Hồi giáo, do một quyết định của những kẻ
chiến thắng xưa kia là bọn thực dân, người Do Thái từ khắp nơi trên thế giới đổ
về chiếm cứ, gom dân Ả Rập địa phương - gọi là dân Palestine - vào một vài khu
giới hạn, coi họ là công dân hạng hai trên đất nước của mình trước đây. Bảo sao
khối dân này không bực mình và nổi loạn được? </p><p>Đã
vậy, kẻ thù Do Thái mới này lại quá mạnh, được sự hậu thuẫn của cả khối Âu Mỹ,
nên các nước Ả Rập có đầy mâu thuẫn trong vùng chẳng làm gì được. Mấy lần tiến đánh
Do Thái đều thua liểng xiểng.</p><p>Đã
bị ức hiếp, lại còn bất lực không thay đổi được gì, bị dồn ép quá, nên bắt buộc
họ phải tìm mọi cách chống và giết bằng hành động khủng bố, khủng bố Do Thái trước,
rồi khủng bố nước coi như đỡ đầu cho Do Thái là Mỹ.</p><p>Nói
nôm na ra, sự ra đời cũng như các hoạt động khủng bố của các nhóm Hồi giáo Ả Rập
quá khích là do việc lấy đất Ả Rập biến
thành nước Do Thái. Đó chính là nguyên nhân xâu xa thật sự của nạn khủng bố Hồi
giáo ngày nay. Ngày nào vấn đề này chưa được giải quyết ổn thỏa theo ý của khối
dân Ả Rập, tức là xoá bỏ nước Do Thái trên bản đồ Trung Đông, thì ngày đó dân Hồi
giáo vẫn còn không chấp nhận Mỹ, và sẽ vẫn còn nạn khủng bố chống Do Thái và chống
Mỹ. </p><p>Đây
là một sự thật mà ai cũng nhìn thấy, nhưng không ai dám nói đến. TT Bush hay TT
Obama cũng vậy, chẳng người nào dám đả động đến sự tồn vong của Do Thái. Chỉ đi
lòng vòng phía ngoài.</p><p>Từ
đó mới thấy chính sách vuốt ve hay ca tụng Ả Rập và Hồi giáo của cả TT Bush lẫn
TT Obama đều vô hiệu, không giải quyết được mâu thuẫn và không xoá bỏ được sự hận
thù Do Thái và Mỹ. Cho đến chính sách dùng vũ lực để thay đổi chế độ cũng vô hiệu
không kém, vì vẫn chưa đả động đến nguyên nhân thật sự của mâu thuẫn, tức là sự
tồn vong của Do Thái mà khối Hồi giáo không thể và không muốn chấp nhận. </p><p>Giải
pháp hai quốc gia Israel và Palestine cùng tồn tại đã được đề nghị nhiều lần, kể
cả dưới thời TT Bush với hậu thuẫn của xứ Á Rập Hồi giáo Saudi Arabia, mà vẫn
không thành, vì dân Á Rập tại Palestin ở hai khu vực lại có lập trường đối nghịch:
phe Fatah tại West Bank thì dung hoà, phe Hamas tại Gzaza thì đòi tử chiến để đưa
dân Do Thái xuống biển (với sự cổ võ của Iran, một xứ Ba Tư theo hệ phái Shia!)
ở đằng sau.</p><p>Vì
những mắc mứu phức tạp này, sau chục năm chiến tranh và tìm cách ổn định, tốn cả
ngàn tỷ và cả ngàn người chết, chúng ta vẫn không thấy có kết quả cụ thể gì tại
Iraq và Afghanistan. Chẳng khiến cho dân hai xứ này trở nên thân thiện với Mỹ hơn
trước. Tại đây, hiển nhiên là người dân có được nhiều tự do, dân chủ hơn dưới
các chế độ cũ, nhưng chẳng người nào nhớ ơn Bush hay Obama. Trái lại, bất cứ chuyện
lớn bé gì cũng có thể mau chóng trở thành điểm tập hợp của những phong trào chống
Mỹ.</p><p>Chuyện
đốt kinh Kuran là điển hình. </p><p>Trong
cả ngàn năm lịch sử cho đến ngày nay, các phe phái và các nước Hồi giáo đánh giết
nhau là chuyện thường, phá đền và đốt kinh cũng là chuyện không tránh được. Nhưng
khi khám phá ra quân đội Mỹ lỡ đốt vài cuốn kinh là dân Afghanistan không cần
biết Mỹ đã giúp mình giải thoát khỏi nạn Taliban như thế nào, cũng không cần biết
mấy cuốn kinh bị đốt là những phương tiện các tù nhân Taliban dùng để chuyển
tin cho nhau trong tù, ùn ùn xuống đường xỉ vả Mỹ, đốt cờ Mỹ, rồi giết luôn cả
lính và cố vấn Mỹ, bất chấp chuyện cấp lãnh đạo Mỹ, từ địa phương đến trung ương,
từ tướng tá đến tổng thống, cúi rạp mình xin lỗi chối chết. </p><p>Chuyện
chính quyền Obama xin lỗi thiên hạ bốn phương tám hướng đã trở thành chuyện cơm
bữa, nên có lẽ vì vậy đã mất hết ý nghĩa rồi.</p><p>Mười
năm sau khi chính sách Hồi giáo mới ra đời, kết quả chẳng có được là bao. Dân
Hồi giáo và Ả Rập vẫn không ưa Mỹ và khủng bố vẫn còn là một đe dọa thường trực
trong khi Âu châu già nua đã mệt mỏi thì chỉ muốn cầu hòa. Ngày nào vấn đề tồn
vong của Do Thái chưa được giải quyết ổn thỏa thì mọi biện pháp, từ củ cà rốt đến
cây gậy, từ thả bom đến viện trợ và xin lỗi, cũng đều không thể biến khối dân
này thành thân thiện hơn với Mỹ. (4-3-12)</p><p>Quý
độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài
của tác giả được đăng mỗi Thứ Ba trên Việt Báo.</p>

### Nguồn:

Viet Bao: https://vietbao.com/a184759/chinh-sach-hoi-giao-that-bai

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/