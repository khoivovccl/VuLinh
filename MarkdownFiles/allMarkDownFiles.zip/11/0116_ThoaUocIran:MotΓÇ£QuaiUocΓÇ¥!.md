# Thỏa Ước Iran: Một “Quái Ước”!

29/09/2015


<div style="text-align: center;"><span style="font-weight: bold;">xxx</span></div>
<br/>Đối với một thoả ước có quá nhiều “quái lạ” như vậy, câu hỏi là tại sao TT Obama vẫn khư khư ôm chặt như vậy? Bất chấp chống đối của hai phần ba TV, và bất chấp 60% dân Mỹ chống luôn. Kẻ viết này chỉ có thể đoán mò đây có lẽ là cái giá mà TT Obama chấp nhận trả để nhận được sự giúp đỡ ngầm của Iran, đánh ISIS dùm. Đại khái Iran kêu TT Obama bỏ cấm vận thì chúng tôi mới có tiền và có thể mua vũ khi đánh ISIS chứ! Khó có thể có được một giải thích nào khác.<br/><br/>Như vậy, ta thấy TT Obama đã đánh đổi mối nguy cơ nguyên tử về lâu về dài lấy việc diệt trừ được mối họa ISIS hiện hữu trước mắt. Bài toán không khó lắm. ISIS là mối nguy khi ông còn làm tổng thống, bom nguyên tử Iran là mối nguy khi ông đã về Hawaii tắm biển từ lâu rồi.<br/><br/>TT Obama và các đồng minh của ông sẽ phải nhận trách nhiệm trước lịch sử về lá bài liều mạng này. Điều này không ai chối cãi được. Lịch sử sẽ trả lời TT Obama tính toán có đúng hay không. Vì hoà bình của nhân loại, kẻ viết này thật tình mong đây là một tuyệt chiêu của TT Obama và ông đã tính toán rất chính xác. Hy vọng như vậy! TT Obama đã đắc cử nhờ bán “hy vọng” mà!<br/><br/>Dù sao thì ai cũng thấy cả hai thành tích để đời của TT Obama, đối nội Obamacare và đối ngoại thoả ước Iran, đều là hai thành tích... chui qua cửa hậu, cả hai thành quả để đời đều bị trên dưới 60% dân Mỹ chống. Obamacare cũng chui qua cửa hậu, nhưng ít ra cũng được 59 phiếu tại Thượng Viện, trong khi hiệp ước Iran chỉ được có 34 phiếu, mà lại còn chẳng ai ký, cũng chẳng có hiệu lực áp chế gì hết.<br/><br/>Đấm ngực khoe công có phần hơi lố lăng. Nhưng trong thời buổi hạn hán thành tích ngày nay của Nhà Nước Obama, bất cứ thành quả nào dù nhỏ đến đâu hay dù dựa trên “hy vọng” tới đâu cũng cần phải khua chiêng trống cho to. Một vài giọt nước trong khi khát cũng hết sức quan trọng. (27-09-15)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác giả được đăng trên Việt Báo mỗi thứ Ba.

### Nguồn:

Viet Bao: https://vietbao.com/a243506/thoa-uoc-iran-mot-quai-uoc

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/