# Syria: TT Obama Đang Làm Gì?

10/11/2015



### Nguồn:

Viet Bao: https://vietbao.com/a245289/syria-tt-obama-dang-lam-gi

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/