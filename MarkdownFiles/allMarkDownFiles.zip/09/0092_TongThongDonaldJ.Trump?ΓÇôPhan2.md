# Tổng Thống Donald J. Trump? – Phần 2

15/03/2016



### Nguồn:

Viet Bao: https://vietbao.com/a250493/tong-thong-donald-j-trump-phan-2

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/