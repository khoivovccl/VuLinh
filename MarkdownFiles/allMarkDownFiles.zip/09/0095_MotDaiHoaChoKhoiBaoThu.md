# Một Đại Họa Cho Khối Bảo Thủ

23/02/2016



### Nguồn:

Viet Bao: https://vietbao.com/a249642/mot-dai-hoa-cho-khoi-bao-thu

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/