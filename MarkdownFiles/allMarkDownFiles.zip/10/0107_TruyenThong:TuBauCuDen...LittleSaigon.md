# Truyền Thông: Từ Bầu Cử Đến... Little Saigon

01/12/2015



### Nguồn:

Viet Bao: https://vietbao.com/a246184/truyen-thong-tu-bau-cu-den-little-saigon

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/