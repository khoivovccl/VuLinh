# TT Obama: Thành Công Và Thất Bại: Phần 1 – Chính Trị Và Xã Hội

27/12/2016



### Nguồn:

Viet Bao: https://vietbao.com/a262116/tt-obama-thanh-cong-va-that-bai-phan-1-chinh-tri-va-xa-hoi

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/