# Sóng Thần Trump

15/11/2016



### Nguồn:

Viet Bao: https://vietbao.com/a260479/song-than-trump

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/