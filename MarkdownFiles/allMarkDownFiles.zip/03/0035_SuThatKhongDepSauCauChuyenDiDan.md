# Sự Thật Không Đẹp Sau Câu Chuyện Di Dân

04/04/2017



### Nguồn:

Viet Bao: https://vietbao.com/a266055/su-that-khong-dep-sau-cau-chuyen-di-dan

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/