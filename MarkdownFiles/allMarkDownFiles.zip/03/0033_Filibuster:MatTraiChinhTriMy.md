# Filibuster: Mặt Trái Chính Trị Mỹ

18/04/2017



### Nguồn:

Viet Bao: https://vietbao.com/a266582/filibuster-mat-trai-chinh-tri-my

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/