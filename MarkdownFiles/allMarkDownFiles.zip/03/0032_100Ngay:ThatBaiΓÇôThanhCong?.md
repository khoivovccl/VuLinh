# 100 Ngày: Thất Bại – Thành Công?

25/04/2017


<div style="text-align: center;"><span style="font-weight: bold;">xxx</span></div>
<br/>Nói chung, cho đến nay, những thất bại của TT Trump có vẻ nặng ký hơn những thành công, ít nhất là trong ngắn hạn. Từ đó, cộng với sự khai thác tối đa của TTDC đánh TT Trump không ngừng nghỉ, hậu thuẫn của TT Trump khó tránh được hậu quả bất lợi. Tỷ lệ hậu thuẫn của TT Trump cho đến nay đã xuống mức thấp nhất trong tất cả các tổng thống trong lịch sử cận đại, tuy đang bò lên lại trong mấy ngày gần đây.<br/><br/>TTDC đã thổi phồng hai cuộc bầu đặc biệt, tìm dân biểu thay thế ông Tom Price, tân bộ trưởng Y Tế, và ông Mike Pompeo, tân giám đốc FBI, cho rằng sẽ là cơ hội cho DC hạ CH vì TT Trump cho đến nay đã quá tệ. Kết quả khối DC thất bại mặc dù đã bơm cả chục triệu đô vào hai cuộc bầu dân biểu tầm thường. Ghế của ông Pompeo vẫn bị CH giữ, trong khi ghế của ông Price không ai đủ 50%, nên sẽ bầu lại tháng 6 tới.<br/><br/>Dĩ nhiên như TT Obama đã từng nói, cái mốc 100 ngày quá ngắn, chẳng nghiã lý gì, mà phải nhìn vào cái mốc 1.000 ngày. (23-04-17)<br/><br/>Vũ Linh<br/><br/>Quý độc giả có thể liên lạc với tác giả để góp ý qua email: Vulinh11@gmail.com. Bài của tác giả được đăng mỗi Thứ Ba trên Việt Báo.<br/><br/><br/>
<p><span style="font-weight: bold;">Đính Chính:</span><br/>Trong bài này, có sơ xuất ghi DB Mike Pompeo là "tân giám đốc FBI". Thật ra ông là tân giám đốc CIA.<br/>Xin đính chính và cảm ơn độc giả.<br/>Đa Tạ.<br/>Vũ Linh và Việt Báo</p>

### Nguồn:

Viet Bao: https://vietbao.com/a266864/100-ngay-that-bai-thanh-cong-

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/