# UPDATED: Những Oái Ăm Mới Của Chính Trị Mỹ

21/03/2017


<p>Nhà văn Vũ Linh viết:<br/><span style="font-style: italic;">“Chỉ trong cái 4-5 dòng ngắn ngủi này, cái cụ chuyên gia này đã sai lầm tới ba lần. Lần thứ nhất, chưa có bất cứ một văn kiện hay thoả ước nào giữa tướng Flynn và Nga hết, chưa ai đưa ra bất cứ bằng chứng cụ thể nào hết, chưa có điều tra và ra toà, kết án gì hết. Sai lầm thứ hai, tướng Flynn chỉ mới được TT Trump đề cử, chưa được quốc hội phê chuẩn thì làm gì đã có chức gì đâu mà từ? Ông chỉ là rút tên ra khỏi danh sách TT Trump đề nghị thôi. Sai lầm thứ ba là nếu tướng Flynn thật sự phạm luật Logan điều đình chuyện gì đó thì có “từ chức” cũng không thoát tội, vẫn có thể đi tù thật bất kể xách dép chạy đi đâu, chứ không phải từ chức là trốn được tội.”<br/></span></p>
<p>Độc giả từ Ohio viết bằng tiếng Anh, tòa soạn dịch một phần lý luận như sau:</p>
<p><span style="font-style: italic;">"FBI trước đó đã xem xét các cú điện thoại của Tướng Flynn trong khi Tướng Flynn bị ngờ vực về các tương tác với các viên chức Nga và việc Tướng Flynn sắp xếp Hội Đồng An Ninh Quốc Gia (National Security Council). Bộ Tư Pháp nhìn thấy cơ nguy bị bắt bí (blackmail) có thể xảy ra cho Tướng Flynn khi Tướng này muốn che giấu các liên hệ với Nga."</span><br/></p>
<p>Tới đây, một câu hỏi khác: <span style="font-weight: bold;">Tướng Flynn có cần quốc hội phê chuẩn hay không?</span><br/>Trả lời: <span style="font-weight: bold;">Không cần.</span><br/></p>
<p>Tướng Flynn đã tuyên thệ nhậm chức chưa? Trả lời rằng <span style="font-weight: bold;">Tướng Flynn đã tuyên thệ ngay ngày 20/1/2017</span>, ngày Tổng Thống Trump đăng quang. Cùng với Tướng Flynn, có gần 30 viên chức khác trong chính phủ Trump tuyên thệ nhậm chức. (<span style="font-weight: bold;">Requiring no Senate confirmation, Flynn was sworn in on Jan. 20</span> — the day Trump took over the presidency. Also sworn in at that time were nearly 30 other members of Trump's staff, including Bannon, Reince Priebus, Kellyanne Conway, Jared Kushner, Omarosa Manigault, Sean Spicer, Hope Hicks, Stephen Miller, and Katie Walsh. Xem: <a href="https://www.romper.com/p/does-the-national-security-adviser-require-senate-confirmation-not-at-all-34488">https://www.romper.com/p/does-the-national-security-adviser-require-senate-confirmation-not-at-all-34488</a>)</p>
<p><br/></p>
<br/><br/>

### Nguồn:

Viet Bao: https://vietbao.com/a265518/nhung-oai-am-moi-cua-chinh-tri-my

### Xin đọc thêm các bài viết khác tại đây:

DainamaxForum: https://www.facebook.com/Nghia72/

Viet (classical) liberal-Tập hợp người Việt tự do. : https://www.facebook.com/groups/431354977235094/about/